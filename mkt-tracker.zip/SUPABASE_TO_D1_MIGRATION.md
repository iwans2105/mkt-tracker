# Database Migration Architecture — Legacy Sources to Cloudflare D1

## 1. Source Code Audit Findings (Zero Supabase Runtime Usage)

A full source audit of the codebase confirmed:
- Zero `@supabase/supabase-js` packages, imports, RPC calls, RLS policies, Supabase Storage URLs, or Supabase Realtime channels existed in active runtime code.
- Legacy persistence instead resided across:
  1. **Server JSON stores** (`/data/server_users.json`, `/data/quota_policies.json`, `/data/quota_ledger.json`, `/data/server_audit_logs.json`, `/data/backups/`).
  2. **Dormant Node/local engines** (legacy `authEngine.ts`, `dbEngine.ts`, `quotaEngine.ts` — now completely removed).
  3. **Browser `localStorage` caches** across user workstations (`marcomm_requests_v2`, `marcomm_comments_v2`, `marcomm_activity_logs_v2`, `marcomm_master_data_v2`, etc.).

## 2. Target D1 Schema & Atomic Guarantees

- `migrations/0001_initial_schema.sql`: Defines 17 relational tables with `PRAGMA foreign_keys = ON`, JSON validity checks, and strict domain constraints (`regions`, `brands`, `units`, `departments`, `categories`, `teams`, `users`, `sessions`, `login_rate_limits`, `system_bootstrap_state`, `priority_quota_policies`, `requests`, `sub_items`, `priority_quota_idempotency`, `priority_quota_ledger`, `priority_quota_reconciliations`, `attachments`, `comments`, `activity_logs`, `notifications`, `security_audit_logs`, `backups`, `migration_runs`, `migration_conflicts`).
- `migrations/0002_quota_atomic_triggers.sql`: Database triggers (`trg_quota_ledger_insert_deduction`, `trg_requests_enforce_finite_quota`, `trg_quota_policy_guard_bounds`) guaranteeing atomic rollback on quota exhaustion inside `env.DB.batch()`.
- `migrations/0003_seed_master_data.sql`: Idempotent master data seed preserving canonical IDs and stripping any legacy `"Wilayah "` prefix on region names.

## 3. Idempotent & Resumable Migration Pipeline

1. **Read-Only Legacy Export**:
   - CLI: `npx tsx scripts/export-legacy-data.ts --browser <device-snapshot.json>`
   - UI (Settings -> Legacy Migration): `StorageService.exportLocalStorageSnapshot()` reads browser keys non-destructively without touching operational `/data/*.json`.
   - Excludes `server_sessions.json` and plaintext passwords/tokens.
2. **Staging-First Idempotent Import**:
   - `POST /api/migration/import` (Super Admin only) inserts missing records preserving original IDs, timestamps, ticket numbers, `quota_year` (WIB), and `approvalHistory`.
   - Identical existing rows are skipped cleanly (`skippedIdentical`).
   - Conflicting existing rows are **never overwritten**; they are written to `migration_conflicts` for explicit Super Admin review (`keep_existing` or `accept_incoming`) via Settings UI or `POST /api/migration/conflicts/:id/resolve`.
3. **CLI Staging Import & Verification**:
   - `npx tsx scripts/import-to-d1-r2.ts --url https://<staging-url> --file migration-exports/<bundle>.json --email <admin> --password <pass>`
