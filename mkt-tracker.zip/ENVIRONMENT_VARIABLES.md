# Environment Variables & Cloudflare Workers Secrets

Never commit `.env`, `.dev.vars`, or raw secret values to Git. Templates live in `.env.example` and `.dev.vars.example`.

## 1. Public Wrangler Vars (`wrangler.jsonc`)

| Variable | Purpose | Default / Placeholder |
| --- | --- | --- |
| `ENVIRONMENT` | Active runtime label (`local`, `staging`, `production`) | `local` |
| `APP_ORIGIN` | Authoritative origin URL for CORS & `Secure` cookie logic | `http://localhost:8787` / placeholder |
| `CUSTOM_DOMAIN_STATUS` | Tracks DNS cutover readiness | `placeholder_pending_dns_cutover` |

## 2. Encrypted Cloudflare Workers Secrets (`wrangler secret put`)

| Secret | Required | Purpose |
| --- | --- | --- |
| `SESSION_SECRET` | Yes (Staging/Prod) | HMAC-SHA256 key binding CSRF tokens to D1 sessions |
| `PASSWORD_PEPPER` | Recommended | Server-side HMAC pepper combined with PBKDF2-SHA256 |
| `GEMINI_API_KEY` | Optional | Enables live Gemini AI `/api/ai/*` endpoints (rule-based fallbacks active if unset) |
| `BOOTSTRAP_ADMIN_TOKEN` | Bootstrap Only | One-time Super Admin recovery secret (`/api/auth/bootstrap-recovery`) |
| `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASS`, `SMTP_FROM` | Optional | Transactional password recovery email relay (reports `BLOCKED` if omitted) |

## 3. Bindings (`wrangler.jsonc`)

- `DB`: Cloudflare D1 Database (`marcomm-db`, `marcomm-db-staging`, `marcomm-db-production`)
- `FILES_BUCKET`: Cloudflare R2 Bucket (`marcomm-files-local`, `marcomm-files-staging`, `marcomm-files-production`)
- `ASSETS`: Workers Static Assets (`./dist`)
