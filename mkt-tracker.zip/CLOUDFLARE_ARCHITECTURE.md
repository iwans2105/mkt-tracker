# Cloudflare Architecture — MARCOMM TASK | PT Lyman Devindo

## 1. Runtime & Infrastructure Topology

| Layer | Cloudflare Service | Local Preview Equivalent | Implementation Entry |
| --- | --- | --- | --- |
| Frontend Hosting | Cloudflare Workers Static Assets (`ASSETS`, SPA fallback) | Vite Dev Middleware / `dist/` static files | `wrangler.jsonc`, `index.html`, `src/` |
| Backend API | Cloudflare Workers + Hono (`/api/*`, `run_worker_first`) | Node HTTP bridge dispatching to `workerApp.fetch` | `src/worker/index.ts`, `src/worker/app.ts`, `server.ts` |
| Authoritative Database | Cloudflare D1 (`DB` binding, SQLite + `PRAGMA foreign_keys = ON`) | `node:sqlite` D1 adapter (`data/preview.local.sqlite`) | `migrations/0001..0003.sql`, `src/server/localAdapters.ts` |
| Private Object Storage | Cloudflare R2 (`FILES_BUCKET` binding) | Local disk R2 adapter (`data/local-r2/`) | `src/worker/routes/files.ts`, `src/worker/routes/system.ts` |
| Realtime Sync Replacement | Authenticated Smart Polling (`GET /api/sync` every 20s + visibility/focus/online listeners) | Identical Worker route | `src/worker/routes/notifications.ts`, `src/context/RequestContext.tsx` |
| AI Features | Gemini API via `@google/genai` inside Workers `/api/ai/*` (`GEMINI_API_KEY` Worker Secret) | Identical Worker route with deterministic rule fallbacks | `src/worker/routes/ai.ts`, `src/services/aiService.ts` |

## 2. Request Flow

1. Browser requests `/` or static assets -> served by Workers Static Assets (`not_found_handling: single-page-application`).
2. Browser requests `/api/*` -> `run_worker_first` routes directly to Hono Worker (`src/worker/app.ts`).
3. `authMiddleware` validates HttpOnly `marcomm_sid` cookie against D1 `sessions` table, enforces sliding 8h expiry, checks `users.is_active`, and enforces HMAC-SHA256 `X-CSRF-Token` validation on all `POST`/`PUT`/`PATCH`/`DELETE` mutations.
4. Business routes query/mutate Cloudflare D1 atomically (`env.DB.batch(...)`) and store private attachments & verified backups in Cloudflare R2 (`env.FILES_BUCKET`).

## 3. Production & Staging Separation

- Environments configured in `wrangler.jsonc`: `local` (default), `staging` (`marcomm-db-staging` + `marcomm-files-staging`), and `production` (`marcomm-db-production` + `marcomm-files-production`).
- Production commands are wrapped by `scripts/guarded-wrangler.ts` requiring both `ALLOW_PRODUCTION_DEPLOY=YES` and `--confirm-production`.
