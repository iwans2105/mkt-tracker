# Custom Domain & DNS Cutover Guide

## 1. Current Pre-Cutover Placeholder Configuration

Per migration requirements, production DNS and custom domain routing remain **unmodified** until explicit cutover approval:

- `wrangler.jsonc`:
  - `staging`: Uses `workers_dev: true` with `APP_ORIGIN = "https://marcomm-staging.example.workers.dev"` and `CUSTOM_DOMAIN_STATUS = "placeholder_pending_dns_cutover"`.
  - `production`: Uses placeholder `APP_ORIGIN = "https://marcomm.lyman-devindo.example.com"`, `CUSTOM_DOMAIN_STATUS = "configurable_placeholder_until_cutover"`, and commented-out `routes` block.

## 2. Controlled DNS & Custom Domain Cutover Steps (Post-Approval Only)

1. Ensure the target domain zone (e.g., `lyman.co.id`) is active on Cloudflare DNS with Universal SSL enabled.
2. In `wrangler.jsonc` under `env.production`:
   - Uncomment:
     ```jsonc
     "routes": [
       { "pattern": "marcomm.lyman.co.id", "custom_domain": true }
     ]
     ```
   - Update `vars.APP_ORIGIN` to `"https://marcomm.lyman.co.id"` and `vars.CUSTOM_DOMAIN_STATUS` to `"active_custom_domain"`.
3. Deploy via the guarded production cutover workflow (`ALLOW_PRODUCTION_DEPLOY=YES npm run deploy:production -- --confirm-production`).
4. Verify TLS handshake, HSTS/CORS/Origin cookie behavior (`Secure`, `HttpOnly`, `SameSite=Lax`), and `/api/system/health`.
