# Production Readiness & Cutover Checklist

**IMPORTANT**: Do NOT execute `db:migrate:production`, `deploy:production`, or DNS cutover until every blocking & staging gate is marked `PASS` and explicit approval is granted.

## 1. Architecture & Code Gates (Local)

- [x] Zero `@supabase` / Supabase runtime dependencies (`npm run check`)
- [x] Authoritative Cloudflare Workers + Hono API (`src/worker/*`) + Workers Static Assets (`./dist`)
- [x] D1 Schema (`0001`), Atomic Quota Triggers (`0002`), Clean Master Data Seed (`0003`)
- [x] Private R2 Object Storage (`/api/files/upload`, `/api/files/:id`) replacing `localStorage` & `blob:` URLs
- [x] PBKDF2-SHA256 (100k) + Pepper auth, HttpOnly cookies, CSRF, session rotation, D1 rate limiting
- [x] Vitest automated security, RBAC, concurrency, idempotency, backup & migration tests (`npm run test`)
- [x] Production deployment & migration guard active (`scripts/guarded-wrangler.ts`)

## 2. Staging Verification Gates (Pending Remote Cloudflare Credentials)

- [ ] Provision `marcomm-db-staging` (D1) and `marcomm-files-staging` (R2) and set `database_id` in `wrangler.jsonc`
- [ ] Set Staging Worker Secrets (`SESSION_SECRET`, `PASSWORD_PEPPER`, `GEMINI_API_KEY`, `BOOTSTRAP_ADMIN_TOKEN`)
- [ ] Run `npm run db:migrate:staging` and `npm run deploy:staging`
- [ ] Run multi-device legacy export + staging import + conflict reconciliation check
- [ ] Execute `npx tsx scripts/verify-deployment.ts --url https://<staging-url>` and record `PASS`

## 3. Production Cutover Gates (Requires Explicit Approval)

- [ ] Provision `marcomm-db-production` and `marcomm-files-production` + Production Worker Secrets
- [ ] Verify pre-cutover backup & rollback window (`BACKUP_AND_ROLLBACK.md`)
- [ ] Stakeholder sign-off for `ALLOW_PRODUCTION_DEPLOY=YES ... --confirm-production`
- [ ] Optional: DNS / Custom Domain cutover (`DOMAIN_SETUP.md`)
