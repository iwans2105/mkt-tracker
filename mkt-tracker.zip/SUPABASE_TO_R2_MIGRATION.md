# Private File & Asset Storage Migration — Cloudflare R2

## 1. Storage Architecture

All uploaded files (Request brief attachments, deliverable files, Level 2 Sub Item deliverables, profile avatars, and verified D1 JSON backups) are stored privately in Cloudflare R2 (`FILES_BUCKET` binding) and indexed in D1 `attachments` / `backups`.

- **Zero Public Bucket URLs**: `r2.dev` public access stays disabled. No presigned bypasses or unauthenticated asset URLs are exposed.
- **No Base64 Operational Payloads**: `CreateRequestModal`, `SubItemProgressModal`, `EditSubItemModal`, `RequestDetailDrawer`, and `UserProfileView` upload binaries via `StorageService.uploadFileToR2()` directly to `/api/files/upload` and reference `/api/files/:id`.

## 2. Security & Integrity Controls (`src/worker/routes/files.ts`)

1. **Upload Validation**:
   - File extension whitelist (`png, jpg, jpeg, webp, gif, svg, pdf, doc, docx, xls, xlsx, ppt, pptx, psd, ai, eps, mp4, mov, mpeg, avi, wav, mp3, zip, txt, csv`) + MIME prefix validation.
   - Enforced byte limits: 50 MB for general briefs/avatars, 100 MB for deliverables/sub-items.
   - Computes SHA-256 checksum (`sha256_checksum`), verifies R2 object existence via `FILES_BUCKET.head(r2Key)`, and records D1 metadata in `attachments`.
2. **Authorized Download RBAC (`GET /api/files/:id`)**:
   - Unauthenticated requests receive `401 Unauthorized`.
   - Backup objects require `super_admin` or `admin`.
   - Ticket attachments enforce `canUserViewRequest(user, request)` and `isUserWithinBrandScope(user, regionId, brandId)` — cross-brand or cross-requester attempts return `403 Forbidden`.
   - Sets `Cache-Control: private, no-store`, `X-Content-Type-Options: nosniff`, `X-File-SHA256`, and safe `Content-Disposition` (non-SVG image/PDF inline or forced `attachment`).

## 3. Legacy Base64 Attachment Upgrade

During migration (`POST /api/migration/import`), any legacy `data:*;base64,...` attachments inside `briefAttachments` or `deliverableAttachments` are decoded, SHA-256 hashed, uploaded privately to R2 under `<scope>/migrated/<brandId>/...`, registered in `attachments`, and rewritten to `/api/files/<attId>`.
