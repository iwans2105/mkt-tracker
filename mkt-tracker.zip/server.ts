import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import type { ExecutionContext } from '@cloudflare/workers-types';
import { workerApp } from './src/worker/app';
import type { WorkerBindings } from './src/worker/types';
import {
  applyLocalSqlMigrations,
  createLocalDiskR2Adapter,
  createNodeSqliteD1Adapter,
  seedLocalPreviewData,
} from './src/server/localAdapters';

function loadDevVars(rootDir: string) {
  for (const filename of ['.dev.vars', '.env.local', '.env']) {
    const filePath = path.join(rootDir, filename);
    if (!fs.existsSync(filePath)) continue;
    const lines = fs.readFileSync(filePath, 'utf8').split(/\r?\n/);
    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith('#')) continue;
      const eqIdx = trimmed.indexOf('=');
      if (eqIdx === -1) continue;
      const key = trimmed.slice(0, eqIdx).trim();
      let val = trimmed.slice(eqIdx + 1).trim();
      if ((val.startsWith('"') && val.endsWith('"')) || (val.startsWith("'") && val.endsWith("'"))) {
        val = val.slice(1, -1);
      }
      if (!process.env[key]) {
        process.env[key] = val;
      }
    }
  }
}

async function startLocalPreviewServer() {
  const rootDir = process.cwd();
  loadDevVars(rootDir);

  const PORT = Number(process.env.PORT || 3000);
  const sqlitePath = path.join(rootDir, 'data', 'preview.local.sqlite');
  const r2Dir = path.join(rootDir, 'data', 'local-r2');

  const { db, rawExec, checkpoint, close } = createNodeSqliteD1Adapter(sqlitePath);
  const bucket = createLocalDiskR2Adapter(r2Dir);

  applyLocalSqlMigrations(rawExec, rootDir);
  await seedLocalPreviewData(db, {
    pepper: process.env.PASSWORD_PEPPER,
    rootDir,
    readLegacyDataFolder: true,
  });

  const bindings: WorkerBindings = {
    DB: db,
    FILES_BUCKET: bucket,
    ENVIRONMENT: 'local-preview',
    CUSTOM_DOMAIN_STATUS: process.env.CUSTOM_DOMAIN_STATUS || 'placeholder',
    APP_ORIGIN: process.env.APP_ORIGIN || `http://localhost:${PORT}`,
    SESSION_SECRET: process.env.SESSION_SECRET || 'marcomm-local-preview-session-secret-change-me',
    PASSWORD_PEPPER: process.env.PASSWORD_PEPPER,
    GEMINI_API_KEY: process.env.GEMINI_API_KEY,
    BOOTSTRAP_ADMIN_TOKEN: process.env.BOOTSTRAP_ADMIN_TOKEN,
    SMTP_HOST: process.env.SMTP_HOST,
    SMTP_PORT: process.env.SMTP_PORT,
    SMTP_USER: process.env.SMTP_USER,
    SMTP_PASS: process.env.SMTP_PASS,
    SMTP_FROM: process.env.SMTP_FROM,
  };

  const isProd = process.env.NODE_ENV === 'production';
  let viteMiddleware: ((req: http.IncomingMessage, res: http.ServerResponse, next: () => void) => void) | null = null;

  const server = http.createServer(async (req, res) => {
    const reqUrl = new URL(req.url || '/', `http://${req.headers.host || `localhost:${PORT}`}`);

    // Handle /api/* via Cloudflare Hono Worker App
    if (reqUrl.pathname.startsWith('/api/')) {
      try {
        const chunks: Buffer[] = [];
        if (req.method !== 'GET' && req.method !== 'HEAD') {
          for await (const chunk of req) {
            chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk));
          }
        }
        const headers = new Headers();
        for (const [k, v] of Object.entries(req.headers)) {
          if (v === undefined) continue;
          if (Array.isArray(v)) v.forEach((item) => headers.append(k, item));
          else headers.set(k, v);
        }

        const webReq = new Request(reqUrl.toString(), {
          method: req.method,
          headers,
          body: chunks.length > 0 ? Buffer.concat(chunks) : undefined,
        });

        const webRes = await workerApp.fetch(webReq, bindings, {
          waitUntil: () => {},
          passThroughOnException: () => {},
        } as unknown as ExecutionContext);

        res.statusCode = webRes.status;
        webRes.headers.forEach((value, key) => {
          if (key.toLowerCase() === 'set-cookie') {
            const prev = res.getHeader('set-cookie');
            const nextList = Array.isArray(prev) ? [...prev, value] : prev ? [String(prev), value] : [value];
            res.setHeader('set-cookie', nextList);
          } else {
            res.setHeader(key, value);
          }
        });

        if (['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method || '')) {
          checkpoint();
        }

        if (webRes.body) {
          const buf = Buffer.from(await webRes.arrayBuffer());
          res.end(buf);
        } else {
          res.end();
        }
      } catch (err) {
        console.error('[Node Preview API Bridge Error]:', err);
        res.statusCode = 500;
        res.setHeader('Content-Type', 'application/json');
        res.end(JSON.stringify({ success: false, error: 'Local preview API bridge error' }));
      }
      return;
    }

    // Serve Vite SPA in dev or built dist/ in prod
    if (!isProd && viteMiddleware) {
      viteMiddleware(req, res, () => {
        res.statusCode = 404;
        res.end('Not found');
      });
      return;
    }

    const distDir = path.resolve(rootDir, 'dist');
    const candidate = path.join(distDir, reqUrl.pathname === '/' ? 'index.html' : reqUrl.pathname);
    const targetFile = fs.existsSync(candidate) && fs.statSync(candidate).isFile()
      ? candidate
      : path.join(distDir, 'index.html');
    if (fs.existsSync(targetFile)) {
      const ext = path.extname(targetFile).toLowerCase();
      const mimeMap: Record<string, string> = {
        '.html': 'text/html; charset=utf-8',
        '.js': 'application/javascript; charset=utf-8',
        '.css': 'text/css; charset=utf-8',
        '.png': 'image/png',
        '.jpg': 'image/jpeg',
        '.svg': 'image/svg+xml',
        '.json': 'application/json',
      };
      res.setHeader('Content-Type', mimeMap[ext] || 'application/octet-stream');
      if (ext === '.html') {
        res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
        res.setHeader('Pragma', 'no-cache');
        res.setHeader('Expires', '0');
      }
      res.end(fs.readFileSync(targetFile));
    } else {
      res.statusCode = 404;
      res.end('Build not found. Run npm run build.');
    }
  });

  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: process.env.DISABLE_HMR === 'true' ? false : { server },
      },
      appType: 'spa',
    });
    viteMiddleware = vite.middlewares;
  }

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`[MARCOMM TASK Preview Server] running on http://0.0.0.0:${PORT} (Hono Worker + node:sqlite D1 + Local R2)`);
  });

  const handleShutdown = () => {
    checkpoint();
    close();
    server.close(() => process.exit(0));
  };
  process.once('SIGINT', handleShutdown);
  process.once('SIGTERM', handleShutdown);
}

startLocalPreviewServer().catch((err) => {
  console.error('[Preview Server Fatal Error]:', err);
  process.exit(1);
});
