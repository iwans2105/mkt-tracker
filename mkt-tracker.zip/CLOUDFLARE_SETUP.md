# Cloudflare Infrastructure Setup Guide

## 1. Prerequisites

- Node.js 22+ (`node:sqlite` built-in used by local preview & Vitest D1 adapter)
- Wrangler CLI v4 (`npm install` installs `wrangler` locally)
- Authenticated Cloudflare Account (`npx wrangler login` or `CLOUDFLARE_API_TOKEN` + `CLOUDFLARE_ACCOUNT_ID`)

## 2. Local Development & Migration Testing

```bash
# Install dependencies
npm install

# Apply SQLite schema + triggers + master data seed to local Wrangler D1 state
npm run db:migrate:local

# Run Workers locally via Wrangler
npm run dev:worker

# Or run Node preview server (port 3000) backed by Hono Worker + node:sqlite D1 + Local Disk R2
npm run dev
```

## 3. Staging Provisioning Commands (Remote Cloudflare)

```bash
# 1. Create Staging D1 database & R2 bucket
npx wrangler d1 create marcomm-db-staging
npx wrangler r2 bucket create marcomm-files-staging

# 2. Update database_id in wrangler.jsonc under env.staging.d1_databases[0].database_id

# 3. Apply migrations to Staging D1
npm run db:migrate:staging

# 4. Configure Staging Secrets (never commit values)
npx wrangler secret put SESSION_SECRET --env staging
npx wrangler secret put PASSWORD_PEPPER --env staging
npx wrangler secret put GEMINI_API_KEY --env staging
npx wrangler secret put BOOTSTRAP_ADMIN_TOKEN --env staging

# 5. Build & Deploy Staging
npm run deploy:staging
```

## 4. Production Provisioning (Explicit Approval Required)

Create `marcomm-db-production` and `marcomm-files-production`, update `env.production.d1_databases[0].database_id` in `wrangler.jsonc`, and set production Worker Secrets via `npx wrangler secret put <NAME> --env production`. Do not run `db:migrate:production` or `deploy:production` without explicit cutover sign-off.
