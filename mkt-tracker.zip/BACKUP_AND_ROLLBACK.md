# Backup, Verification & Rollback Plan

## 1. Automated & On-Demand Verified D1 -> R2 Backups

- `POST /api/system/backup` (Admin / Super Admin) snapshots all 17 domain tables (excluding `sessions`, `password_hash`, and `recovery_token_hash`) to JSON, computes its **SHA-256 digest**, uploads to private Cloudflare R2 (`backups/marcomm_d1_backup_<ts>.json`), and records metadata in `backups`.
- `GET /api/system/backups/:id/download` re-computes SHA-256 on the streamed R2 object against D1 `checksum_sha256` before serving (`X-File-SHA256`), flagging `integrity_status = 'corrupted'` if tampered.
- CLI local D1 export: `npx wrangler d1 export <db-name> --remote --output=backup.sql`.

## 2. Legacy Retention Policy

- Original `/data/*.json` files (`server_users.json`, `quota_policies.json`, `quota_ledger.json`, `server_audit_logs.json`, `data/backups/`) MUST remain untouched on disk until Staging + Production verification and the agreed post-cutover rollback retention window expire.

## 3. Production Rollback Procedure

If any critical regression occurs after cutover:
1. **Worker Code Rollback**:
   ```bash
   npx wrangler deployments list --env production
   npx wrangler rollback <deployment-id> --env production
   ```
2. **D1 Database Restore**:
   - Restore from pre-cutover `wrangler d1 export` SQL dump or D1 Time Travel (`npx wrangler d1 time-travel restore marcomm-db-production --env production --timestamp="<ISO>"`).
3. **Emergency Local Fallback**:
   - Original `/data/*.json` remains intact for emergency audit or re-export.
