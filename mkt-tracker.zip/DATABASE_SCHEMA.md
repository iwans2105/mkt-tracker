# Cloudflare D1 Database Schema Reference

Authoritative SQL definitions live in `migrations/0001_initial_schema.sql`, `migrations/0002_quota_atomic_triggers.sql`, and `migrations/0003_seed_master_data.sql`. All tables execute with `PRAGMA foreign_keys = ON`.

## 1. Core Table Inventory (17 Tables)

| Domain | Tables | Key Constraints & Indexes |
| --- | --- | --- |
| Master Data | `regions`, `brands`, `units`, `departments`, `categories`, `teams` | Foreign keys (`brands.region_id -> regions.id`, `units.brand_id -> brands.id`); `is_active IN (0,1)` |
| Identity & Security | `users`, `sessions`, `login_rate_limits`, `system_bootstrap_state` | `users.email UNIQUE COLLATE NOCASE`, role `CHECK`, `sessions.user_id -> users.id`, `idx_sessions_expires` |
| Operations & Level 2 | `requests`, `sub_items`, `comments`, `activity_logs`, `notifications` | `requests.ticket_number UNIQUE`, `quota_year CHECK (1900..9999)`, `sub_items.parent_request_id -> requests.id` |
| Atomic Priority Quota | `priority_quota_policies`, `priority_quota_idempotency`, `priority_quota_ledger`, `priority_quota_reconciliations` | `UNIQUE(brand_id, year, priority)`, `CHECK(annual_limit = -1 OR used_count <= annual_limit)`, unique `idempotency_key` partial index |
| R2 Files & Governance | `attachments`, `security_audit_logs`, `backups`, `migration_runs`, `migration_conflicts` | `attachments.r2_key UNIQUE`, `backups.checksum_sha256`, `migration_conflicts.run_id -> migration_runs.id` |

## 2. Atomic Triggers (`0002_quota_atomic_triggers.sql`)

- `trg_requests_enforce_finite_quota`: Fires `BEFORE INSERT ON requests` for finite priorities (`urgent`, `high`, `medium`) when `is_migrated = 0`. Raises `ABORT 'QUOTA_EXHAUSTED'` if `used_count >= annual_limit`.
- `trg_quota_ledger_insert_deduction`: Fires `AFTER INSERT ON priority_quota_ledger` for `deduction`; verifies non-orphan `request_id` exists and increments `priority_quota_policies.used_count`.
- `trg_quota_ledger_insert_release` & `trg_quota_ledger_insert_adjustment`: Adjust `used_count` atomically on priority changes, manual adjustments, or historical reconciliations.
- `trg_quota_policy_guard_bounds`: Prevents `used_count < 0` or `used_count > annual_limit`, rolling back the entire D1 `batch()` atomically.
