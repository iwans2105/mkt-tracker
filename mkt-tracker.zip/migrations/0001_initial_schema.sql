-- MARCOMM TASK | PT Lyman Devindo
-- Migration 0001: Authoritative Cloudflare D1 Schema (SQLite)
-- Zero cascade deletion policy; strict referential integrity & domain checks.

PRAGMA foreign_keys = ON;

-- 1. Organizational Master Data
CREATE TABLE IF NOT EXISTS regions (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  code TEXT NOT NULL,
  is_active INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0, 1)),
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

CREATE TABLE IF NOT EXISTS brands (
  id TEXT PRIMARY KEY,
  region_id TEXT NOT NULL REFERENCES regions(id),
  name TEXT NOT NULL,
  code TEXT NOT NULL,
  is_active INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0, 1)),
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);
CREATE INDEX IF NOT EXISTS idx_brands_region ON brands(region_id);

CREATE TABLE IF NOT EXISTS units (
  id TEXT PRIMARY KEY,
  brand_id TEXT NOT NULL REFERENCES brands(id),
  name TEXT NOT NULL,
  code TEXT NOT NULL,
  is_active INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0, 1)),
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);
CREATE INDEX IF NOT EXISTS idx_units_brand ON units(brand_id);

CREATE TABLE IF NOT EXISTS departments (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  is_active INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0, 1)),
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

CREATE TABLE IF NOT EXISTS categories (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  sla_days_default INTEGER NOT NULL DEFAULT 3 CHECK (sla_days_default >= 1),
  is_active INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0, 1)),
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

CREATE TABLE IF NOT EXISTS teams (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  color TEXT NOT NULL DEFAULT '#3B82F6',
  is_active INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0, 1)),
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

-- 2. Users, Sessions & Edge-Consistent Rate Limits
CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  email TEXT NOT NULL UNIQUE COLLATE NOCASE,
  full_name TEXT NOT NULL,
  avatar_url TEXT,
  job_title TEXT NOT NULL DEFAULT '',
  department TEXT NOT NULL DEFAULT '',
  role TEXT NOT NULL CHECK (role IN ('requester', 'team_member', 'admin', 'super_admin')),
  is_reviewer INTEGER NOT NULL DEFAULT 0 CHECK (is_reviewer IN (0, 1)),
  teams_json TEXT NOT NULL DEFAULT '[]' CHECK (json_valid(teams_json)),
  competencies_json TEXT NOT NULL DEFAULT '[]' CHECK (json_valid(competencies_json)),
  assigned_regions_json TEXT NOT NULL DEFAULT '[]' CHECK (json_valid(assigned_regions_json)),
  assigned_brands_json TEXT NOT NULL DEFAULT '[]' CHECK (json_valid(assigned_brands_json)),
  is_active INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0, 1)),
  password_hash TEXT NOT NULL,
  recovery_token_hash TEXT,
  recovery_expires_at INTEGER,
  must_change_password INTEGER NOT NULL DEFAULT 0 CHECK (must_change_password IN (0, 1)),
  password_changed_at TEXT,
  last_login_at TEXT,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);
CREATE INDEX IF NOT EXISTS idx_users_role ON users(role);
CREATE INDEX IF NOT EXISTS idx_users_active ON users(is_active);

CREATE TABLE IF NOT EXISTS sessions (
  session_id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id),
  email TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('requester', 'team_member', 'admin', 'super_admin')),
  csrf_secret TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL,
  last_active_at INTEGER NOT NULL,
  ip_address TEXT,
  user_agent TEXT
);
CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_sessions_expires ON sessions(expires_at);

CREATE TABLE IF NOT EXISTS login_rate_limits (
  rate_key TEXT PRIMARY KEY,
  attempt_count INTEGER NOT NULL DEFAULT 0,
  first_attempt_ms INTEGER NOT NULL,
  updated_at_ms INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS system_bootstrap_state (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL,
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

-- 3. Priority Quota Governance (Annual WIB Separation + Atomic Ledger)
CREATE TABLE IF NOT EXISTS priority_quota_policies (
  id TEXT PRIMARY KEY,
  brand_id TEXT NOT NULL REFERENCES brands(id),
  year INTEGER NOT NULL CHECK (year BETWEEN 1900 AND 9999),
  priority TEXT NOT NULL CHECK (priority IN ('urgent', 'high', 'medium', 'low')),
  annual_limit INTEGER NOT NULL CHECK (annual_limit >= -1),
  used_count INTEGER NOT NULL DEFAULT 0 CHECK (used_count >= 0),
  sla_days INTEGER NOT NULL CHECK (sla_days >= 1),
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  UNIQUE (brand_id, year, priority),
  CHECK (annual_limit = -1 OR used_count <= annual_limit)
);
CREATE INDEX IF NOT EXISTS idx_quota_policies_brand_year ON priority_quota_policies(brand_id, year);

-- 4. Requests & Level 2 Sub Items
CREATE TABLE IF NOT EXISTS requests (
  id TEXT PRIMARY KEY,
  ticket_number TEXT NOT NULL UNIQUE,
  title TEXT NOT NULL,
  region_id TEXT NOT NULL REFERENCES regions(id),
  region_name TEXT NOT NULL,
  brand_id TEXT NOT NULL REFERENCES brands(id),
  brand_name TEXT NOT NULL,
  unit_id TEXT,
  unit_name TEXT,
  requester_department TEXT NOT NULL,
  category_id TEXT NOT NULL REFERENCES categories(id),
  category_name TEXT NOT NULL,
  description TEXT NOT NULL,
  deliverables_expected TEXT NOT NULL,
  priority TEXT NOT NULL CHECK (priority IN ('low', 'medium', 'high', 'urgent')),
  status TEXT NOT NULL DEFAULT 'todo' CHECK (status IN ('todo', 'in_progress', 'pending_review', 'revision', 'completed', 'on_hold', 'cancelled')),
  requester_id TEXT NOT NULL REFERENCES users(id),
  requester_name TEXT NOT NULL,
  requester_email TEXT NOT NULL,
  assigned_team_id TEXT,
  assigned_team_name TEXT,
  primary_assignee_id TEXT REFERENCES users(id),
  primary_assignee_name TEXT,
  collaborator_ids_json TEXT NOT NULL DEFAULT '[]' CHECK (json_valid(collaborator_ids_json)),
  collaborator_names_json TEXT NOT NULL DEFAULT '[]' CHECK (json_valid(collaborator_names_json)),
  reviewer_id TEXT REFERENCES users(id),
  reviewer_name TEXT,
  requested_deadline TEXT NOT NULL,
  committed_deadline TEXT,
  committed_deadline_snapshots_json TEXT NOT NULL DEFAULT '[]' CHECK (json_valid(committed_deadline_snapshots_json)),
  brief_attachments_json TEXT NOT NULL DEFAULT '[]' CHECK (json_valid(brief_attachments_json)),
  deliverable_attachments_json TEXT NOT NULL DEFAULT '[]' CHECK (json_valid(deliverable_attachments_json)),
  deliverable_links_json TEXT NOT NULL DEFAULT '[]' CHECK (json_valid(deliverable_links_json)),
  completed_at TEXT,
  deleted_at TEXT,
  deleted_reason TEXT,
  sla_fulfilled INTEGER CHECK (sla_fulfilled IN (0, 1) OR sla_fulfilled IS NULL),
  reopen_count INTEGER NOT NULL DEFAULT 0 CHECK (reopen_count >= 0),
  reopen_reason TEXT,
  hold_reason TEXT,
  cancel_reason TEXT,
  quota_year INTEGER NOT NULL DEFAULT 2026 CHECK (quota_year BETWEEN 1900 AND 9999),
  is_migrated INTEGER NOT NULL DEFAULT 0 CHECK (is_migrated IN (0, 1)),
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);
CREATE INDEX IF NOT EXISTS idx_requests_brand_status ON requests(brand_id, status);
CREATE INDEX IF NOT EXISTS idx_requests_region ON requests(region_id);
CREATE INDEX IF NOT EXISTS idx_requests_requester ON requests(requester_id);
CREATE INDEX IF NOT EXISTS idx_requests_assignee ON requests(primary_assignee_id);
CREATE INDEX IF NOT EXISTS idx_requests_created_at ON requests(created_at);

CREATE TABLE IF NOT EXISTS sub_items (
  id TEXT PRIMARY KEY,
  parent_request_id TEXT NOT NULL REFERENCES requests(id),
  title TEXT NOT NULL,
  description TEXT,
  owner_id TEXT REFERENCES users(id),
  owner_name TEXT,
  owner_role TEXT,
  owner_avatar TEXT,
  status TEXT NOT NULL DEFAULT 'todo' CHECK (status IN ('todo', 'in_progress', 'pending_review', 'revision', 'completed', 'on_hold', 'cancelled')),
  priority TEXT NOT NULL DEFAULT 'medium' CHECK (priority IN ('low', 'medium', 'high', 'urgent')),
  start_date TEXT,
  due_date TEXT,
  approval_date TEXT,
  approved_at TEXT,
  approved_by TEXT REFERENCES users(id),
  approved_by_name TEXT,
  approval_requires_verification INTEGER NOT NULL DEFAULT 0 CHECK (approval_requires_verification IN (0, 1)),
  approval_history_json TEXT NOT NULL DEFAULT '[]' CHECK (json_valid(approval_history_json)),
  deliverable_url TEXT,
  deliverable_file_name TEXT,
  notes TEXT,
  created_by TEXT NOT NULL,
  created_by_id TEXT NOT NULL REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  deleted_at TEXT,
  deleted_reason TEXT,
  deleted_by TEXT
);
CREATE INDEX IF NOT EXISTS idx_sub_items_parent ON sub_items(parent_request_id);
CREATE INDEX IF NOT EXISTS idx_sub_items_owner ON sub_items(owner_id);

-- 5. Priority Quota Ledger, Idempotency & Reconciliations
CREATE TABLE IF NOT EXISTS priority_quota_idempotency (
  idempotency_key TEXT PRIMARY KEY,
  request_id TEXT NOT NULL,
  brand_id TEXT NOT NULL,
  year INTEGER NOT NULL,
  priority TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

CREATE TABLE IF NOT EXISTS priority_quota_ledger (
  id TEXT PRIMARY KEY,
  brand_id TEXT NOT NULL REFERENCES brands(id),
  year INTEGER NOT NULL CHECK (year BETWEEN 1900 AND 9999),
  priority TEXT NOT NULL CHECK (priority IN ('urgent', 'high', 'medium', 'low')),
  request_id TEXT REFERENCES requests(id),
  ticket_number TEXT,
  transaction_type TEXT NOT NULL CHECK (transaction_type IN ('deduction', 'release', 'adjustment', 'reconciliation', 'policy_init')),
  quantity INTEGER NOT NULL,
  actor_id TEXT NOT NULL,
  actor_name TEXT NOT NULL,
  actor_role TEXT NOT NULL,
  reason TEXT NOT NULL,
  idempotency_key TEXT,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);
CREATE INDEX IF NOT EXISTS idx_quota_ledger_brand_year ON priority_quota_ledger(brand_id, year, created_at);
CREATE INDEX IF NOT EXISTS idx_quota_ledger_request ON priority_quota_ledger(request_id);
CREATE UNIQUE INDEX IF NOT EXISTS idx_quota_ledger_idempotency ON priority_quota_ledger(brand_id, year, idempotency_key) WHERE idempotency_key IS NOT NULL;

CREATE TABLE IF NOT EXISTS priority_quota_reconciliations (
  id TEXT PRIMARY KEY,
  brand_id TEXT NOT NULL DEFAULT 'all',
  year INTEGER NOT NULL UNIQUE CHECK (year BETWEEN 1900 AND 9999),
  total_reconciled INTEGER NOT NULL DEFAULT 0,
  applied_by TEXT NOT NULL,
  applied_by_name TEXT NOT NULL,
  applied_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

-- 6. Private R2 Object Metadata
CREATE TABLE IF NOT EXISTS attachments (
  id TEXT PRIMARY KEY,
  r2_key TEXT NOT NULL UNIQUE,
  file_name TEXT NOT NULL,
  mime_type TEXT NOT NULL,
  size_bytes INTEGER NOT NULL CHECK (size_bytes >= 0),
  sha256_checksum TEXT NOT NULL,
  scope_type TEXT NOT NULL CHECK (scope_type IN ('brief', 'deliverable', 'subitem', 'avatar', 'backup')),
  brand_id TEXT REFERENCES brands(id),
  region_id TEXT REFERENCES regions(id),
  request_id TEXT REFERENCES requests(id),
  sub_item_id TEXT REFERENCES sub_items(id),
  uploaded_by TEXT NOT NULL REFERENCES users(id),
  uploaded_by_name TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  deleted_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_attachments_request ON attachments(request_id);
CREATE INDEX IF NOT EXISTS idx_attachments_brand ON attachments(brand_id);

-- 7. Comments, Activity Logs, Notifications & Security Audit Logs
CREATE TABLE IF NOT EXISTS comments (
  id TEXT PRIMARY KEY,
  request_id TEXT NOT NULL REFERENCES requests(id),
  author_id TEXT NOT NULL REFERENCES users(id),
  author_name TEXT NOT NULL,
  author_avatar TEXT,
  role TEXT NOT NULL,
  content TEXT NOT NULL,
  type TEXT NOT NULL DEFAULT 'general' CHECK (type IN ('general', 'revision_note')),
  is_edited INTEGER NOT NULL DEFAULT 0 CHECK (is_edited IN (0, 1)),
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  updated_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_comments_request ON comments(request_id, created_at);

CREATE TABLE IF NOT EXISTS activity_logs (
  id TEXT PRIMARY KEY,
  request_id TEXT NOT NULL REFERENCES requests(id),
  actor_id TEXT NOT NULL,
  actor_name TEXT NOT NULL,
  actor_role TEXT NOT NULL,
  action_type TEXT NOT NULL,
  field_changed TEXT,
  old_value TEXT,
  new_value TEXT,
  reason TEXT,
  timestamp TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);
CREATE INDEX IF NOT EXISTS idx_activity_logs_request ON activity_logs(request_id, timestamp);

CREATE TABLE IF NOT EXISTS notifications (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id),
  request_id TEXT REFERENCES requests(id),
  ticket_number TEXT,
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  type TEXT NOT NULL,
  is_read INTEGER NOT NULL DEFAULT 0 CHECK (is_read IN (0, 1)),
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);
CREATE INDEX IF NOT EXISTS idx_notifications_user_read ON notifications(user_id, is_read, created_at);

CREATE TABLE IF NOT EXISTS security_audit_logs (
  id TEXT PRIMARY KEY,
  timestamp TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  action TEXT NOT NULL,
  actor_id TEXT NOT NULL,
  actor_name TEXT NOT NULL,
  actor_role TEXT NOT NULL,
  target_id TEXT,
  target_type TEXT,
  summary TEXT NOT NULL,
  details_json TEXT NOT NULL DEFAULT '{}' CHECK (json_valid(details_json))
);
CREATE INDEX IF NOT EXISTS idx_security_audit_timestamp ON security_audit_logs(timestamp);

-- 8. D1 Verified Backups & Migration Tracking Tables
CREATE TABLE IF NOT EXISTS backups (
  id TEXT PRIMARY KEY,
  filename TEXT NOT NULL,
  r2_key TEXT NOT NULL,
  checksum_sha256 TEXT NOT NULL,
  record_counts_json TEXT NOT NULL DEFAULT '{}' CHECK (json_valid(record_counts_json)),
  integrity_status TEXT NOT NULL DEFAULT 'valid' CHECK (integrity_status IN ('valid', 'corrupted')),
  created_by TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

CREATE TABLE IF NOT EXISTS migration_runs (
  id TEXT PRIMARY KEY,
  environment TEXT NOT NULL,
  device_label TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('running', 'completed', 'completed_with_conflicts', 'failed')),
  source_checksum TEXT,
  summary_json TEXT NOT NULL DEFAULT '{}' CHECK (json_valid(summary_json)),
  started_by TEXT NOT NULL,
  started_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  completed_at TEXT
);

CREATE TABLE IF NOT EXISTS migration_conflicts (
  id TEXT PRIMARY KEY,
  run_id TEXT NOT NULL REFERENCES migration_runs(id),
  table_name TEXT NOT NULL,
  record_id TEXT NOT NULL,
  conflict_type TEXT NOT NULL,
  device_label TEXT NOT NULL,
  source_payload_json TEXT NOT NULL CHECK (json_valid(source_payload_json)),
  existing_payload_json TEXT NOT NULL CHECK (json_valid(existing_payload_json)),
  resolution_status TEXT NOT NULL DEFAULT 'pending' CHECK (resolution_status IN ('pending', 'keep_existing', 'accept_incoming', 'merged')),
  resolved_by TEXT,
  resolved_at TEXT,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);
CREATE INDEX IF NOT EXISTS idx_migration_conflicts_status ON migration_conflicts(resolution_status);
