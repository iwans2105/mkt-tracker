-- MARCOMM TASK | PT Lyman Devindo
-- Migration 0004: Public Request Form Configuration & System Guest Actor
-- Enables secure token-guarded public request submissions without exposing internal accounts.

PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS public_form_config (
  id TEXT PRIMARY KEY CHECK (id = 'default'),
  enabled INTEGER NOT NULL DEFAULT 1 CHECK (enabled IN (0, 1)),
  require_token INTEGER NOT NULL DEFAULT 1 CHECK (require_token IN (0, 1)),
  allow_attachments INTEGER NOT NULL DEFAULT 1 CHECK (allow_attachments IN (0, 1)),
  access_token TEXT NOT NULL,
  token_hash TEXT NOT NULL,
  allowed_email_domains_json TEXT NOT NULL DEFAULT '[]' CHECK (json_valid(allowed_email_domains_json)),
  updated_by TEXT,
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

-- Non-loginable system actor row to satisfy foreign key constraints on requests & attachments
-- for public-link submissions while preserving real submitter name/email on the ticket record.
INSERT OR IGNORE INTO users (
  id,
  email,
  full_name,
  job_title,
  department,
  role,
  is_reviewer,
  teams_json,
  competencies_json,
  assigned_regions_json,
  assigned_brands_json,
  is_active,
  password_hash,
  must_change_password
) VALUES (
  'public-requester',
  'public-form@system.lyman.local',
  'Pengaju Tautan Publik',
  'External / Public Link',
  'Umum',
  'requester',
  0,
  '[]',
  '[]',
  '[]',
  '[]',
  0,
  '!DISABLED_PUBLIC_SYSTEM_ACCOUNT!',
  0
);
