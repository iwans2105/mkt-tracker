-- MARCOMM TASK | PT Lyman Devindo
-- Migration 0002: Database-Level Atomic Priority Quota Triggers
-- Ensures D1 batch operations fail cleanly as a single atomic unit if quota is exhausted or duplicated,
-- guaranteeing zero orphan requests and zero overconsumption under concurrency.

PRAGMA foreign_keys = ON;

-- 1. Enforce valid priority quota deduction ledger row before any active finite-priority request is created
--    unless it is inserted alongside an explicit migration bypass marker ('low' priority is always unlimited).
--    Note: Request creation runs in env.DB.batch([
--      1) UPDATE priority_quota_policies SET used_count = used_count + 1 WHERE ... AND (annual_limit = -1 OR used_count < annual_limit),
--      2) INSERT INTO requests (...),
--      3) INSERT INTO priority_quota_idempotency (...),
--      4) INSERT INTO priority_quota_ledger (...)
--    ])
--    If (1) fails to increment or if used_count exceeds annual_limit, SQLite CHECK + Trigger ABORT rolls back ALL statements in the batch.

CREATE TRIGGER IF NOT EXISTS trg_quota_ledger_insert_deduction
AFTER INSERT ON priority_quota_ledger
WHEN NEW.transaction_type = 'deduction' AND NEW.priority IN ('urgent', 'high', 'medium')
BEGIN
  -- Ensure request actually exists when request_id is specified
  SELECT RAISE(ABORT, 'ORPHAN_QUOTA_DEDUCTION')
  WHERE NEW.request_id IS NOT NULL
    AND NOT EXISTS (SELECT 1 FROM requests WHERE id = NEW.request_id);

  -- Increment materialized counter and verify capacity via policy CHECK constraint
  UPDATE priority_quota_policies
  SET used_count = used_count + ABS(NEW.quantity),
      updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
  WHERE brand_id = NEW.brand_id
    AND year = NEW.year
    AND priority = NEW.priority;

  SELECT RAISE(ABORT, 'QUOTA_POLICY_MISSING_OR_EXHAUSTED')
  WHERE changes() = 0;
END;

CREATE TRIGGER IF NOT EXISTS trg_quota_ledger_insert_release
AFTER INSERT ON priority_quota_ledger
WHEN NEW.transaction_type = 'release' AND NEW.priority IN ('urgent', 'high', 'medium')
BEGIN
  UPDATE priority_quota_policies
  SET used_count = MAX(0, used_count - ABS(NEW.quantity)),
      updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
  WHERE brand_id = NEW.brand_id
    AND year = NEW.year
    AND priority = NEW.priority;
END;

CREATE TRIGGER IF NOT EXISTS trg_quota_ledger_insert_adjustment
AFTER INSERT ON priority_quota_ledger
WHEN NEW.transaction_type IN ('adjustment', 'reconciliation') AND NEW.priority IN ('urgent', 'high', 'medium')
BEGIN
  UPDATE priority_quota_policies
  SET used_count = MAX(0, used_count - NEW.quantity),
      updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
  WHERE brand_id = NEW.brand_id
    AND year = NEW.year
    AND priority = NEW.priority;
END;

-- 2. Prevent inserting any non-low finite request via app API unless quota policy has remaining capacity or is historical migration
CREATE TRIGGER IF NOT EXISTS trg_requests_enforce_finite_quota
BEFORE INSERT ON requests
WHEN NEW.priority IN ('urgent', 'high', 'medium') AND NEW.deleted_at IS NULL AND NEW.is_migrated = 0
BEGIN
  SELECT RAISE(ABORT, 'QUOTA_EXHAUSTED')
  WHERE EXISTS (
    SELECT 1 FROM priority_quota_policies p
    WHERE p.brand_id = NEW.brand_id
      AND p.year = NEW.quota_year
      AND p.priority = NEW.priority
      AND p.annual_limit >= 0
      AND p.used_count >= p.annual_limit
  );
END;

-- 3. Prevent revoking or resetting used_count below 0
CREATE TRIGGER IF NOT EXISTS trg_quota_policy_guard_bounds
BEFORE UPDATE OF used_count ON priority_quota_policies
WHEN NEW.used_count < 0 OR (NEW.annual_limit >= 0 AND NEW.used_count > NEW.annual_limit)
BEGIN
  SELECT RAISE(ABORT, 'QUOTA_EXHAUSTED');
END;
