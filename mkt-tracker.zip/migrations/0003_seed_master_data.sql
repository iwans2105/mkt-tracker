-- MARCOMM TASK | PT Lyman Devindo
-- Migration 0003: Idempotent Seed for Organizational Master Data
-- Preserves canonical IDs & exact names (no "Wilayah " prefix on Jakarta/Bandung).

PRAGMA foreign_keys = ON;

INSERT OR IGNORE INTO regions (id, name, code, is_active) VALUES
  ('reg-jkt', 'Jakarta', 'JKT', 1),
  ('reg-bdg', 'Bandung', 'BDG', 1);

INSERT OR IGNORE INTO brands (id, region_id, name, code, is_active) VALUES
  ('brand-casa', 'reg-jkt', 'Casa Domaine', 'CD', 1),
  ('brand-wisma46', 'reg-jkt', 'Wisma 46', 'W46', 1),
  ('brand-jso', 'reg-jkt', 'Jakarta Serviced Offices', 'JSO', 1),
  ('brand-studio7', 'reg-jkt', 'Studio 7', 'S7', 1),
  ('brand-simprug', 'reg-jkt', 'Simprug Park Residences', 'SPR', 1),
  ('brand-puribugar', 'reg-jkt', 'Puri Bugar', 'PB', 1),
  ('brand-aries7', 'reg-jkt', 'Aries 7 Living', 'A7L', 1),
  ('brand-lyman', 'reg-jkt', 'Lyman Devindo', 'LD', 1),
  ('brand-masonpine', 'reg-bdg', 'Mason Pine Hotel', 'MPH', 1),
  ('brand-wahoo', 'reg-bdg', 'Wahoo Waterworld', 'WWW', 1),
  ('brand-parahyangan', 'reg-bdg', 'Parahyangan Golf', 'PG', 1),
  ('brand-kbp', 'reg-bdg', 'KBP Project', 'KBP', 1);

INSERT OR IGNORE INTO units (id, brand_id, name, code, is_active) VALUES
  ('unit-hrd', 'brand-lyman', 'HRD — Human Resources Development', 'HRD', 1),
  ('unit-ga', 'brand-lyman', 'GA — General Affairs', 'GA', 1);

INSERT OR IGNORE INTO departments (id, name, is_active) VALUES
  ('dept-hr', 'Human Resources Development (HRD)', 1),
  ('dept-ga', 'General Affairs (GA)', 1),
  ('dept-sales', 'Sales & Marketing', 1),
  ('dept-tenant', 'Tenant Relations & Property Management', 1),
  ('dept-finance', 'Finance & Accounting', 1),
  ('dept-legal', 'Legal & Corporate Secretary', 1),
  ('dept-hospitality', 'Hotel & Hospitality Operations', 1),
  ('dept-project', 'Project Development & Engineering', 1);

INSERT OR IGNORE INTO categories (id, name, sla_days_default, is_active) VALUES
  ('cat-graphic', 'Graphic Design', 3, 1),
  ('cat-motion', 'Motion Graphics & Video Editing', 5, 1),
  ('cat-socmed', 'Social Media Management', 2, 1),
  ('cat-doc', 'Photo & Video Documentation', 3, 1),
  ('cat-digital', 'Digital Marketing', 4, 1),
  ('cat-it', 'IT Support', 2, 1),
  ('cat-other', 'Other Requests', 3, 1);

INSERT OR IGNORE INTO teams (id, name, description, color, is_active) VALUES
  ('team-design', 'Graphic Design', 'Visual branding, digital & print layout design, marketing collateral, and motion graphics production.', '#3B82F6', 1),
  ('team-socmed-doc', 'Social Media & Documentation', 'Social media channel management, video reels/feed production, editorial schedules, and photo & video event coverage.', '#8B5CF6', 1),
  ('team-digital-marketing', 'Digital Marketing', 'Multi-platform advertising campaigns (Google Ads & Meta Ads), search engine optimization (SEO), and conversion analytics.', '#10B981', 1),
  ('team-it-support', 'IT Support & Systems', 'Technical infrastructure, digital portal management, media asset hosting, and marcomm application support.', '#F59E0B', 1);
