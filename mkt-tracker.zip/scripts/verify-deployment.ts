import fs from 'node:fs';
import path from 'node:path';

interface CheckResult {
  name: string;
  status: 'PASS' | 'FAIL' | 'SKIPPED';
  detail: string;
}

function scanForSupabase(dirPath: string): string[] {
  const hits: string[] = [];
  if (!fs.existsSync(dirPath)) return hits;
  for (const entry of fs.readdirSync(dirPath, { withFileTypes: true })) {
    if (['node_modules', '.wrangler', '.git'].includes(entry.name)) continue;
    const full = path.join(dirPath, entry.name);
    if (entry.isDirectory()) {
      hits.push(...scanForSupabase(full));
    } else if (/\.(ts|tsx|js|jsx|css|html)$/.test(entry.name)) {
      const text = fs.readFileSync(full, 'utf8');
      if (/@supabase|supabase\.co|SUPABASE_STORAGE_URL/.test(text)) {
        hits.push(full);
      }
    }
  }
  return hits;
}

async function main() {
  const args = process.argv.slice(2);
  let targetUrl = 'http://localhost:3000';
  let email = process.env.VERIFY_ADMIN_EMAIL || '';
  let password = process.env.VERIFY_ADMIN_PASSWORD || '';

  for (let i = 0; i < args.length; i++) {
    if (args[i] === '--url' && args[i + 1]) targetUrl = args[++i].replace(/\/$/, '');
    else if (args[i] === '--email' && args[i + 1]) email = args[++i];
    else if (args[i] === '--password' && args[i + 1]) password = args[++i];
  }

  const results: CheckResult[] = [];
  const rootDir = process.cwd();

  // 1. Static zero-Supabase runtime scan
  const srcHits = scanForSupabase(path.join(rootDir, 'src'));
  const distHits = scanForSupabase(path.join(rootDir, 'dist'));
  results.push({
    name: 'Zero Runtime Supabase Dependency Scan (src/ + dist/)',
    status: srcHits.length === 0 && distHits.length === 0 ? 'PASS' : 'FAIL',
    detail:
      srcHits.length === 0 && distHits.length === 0
        ? '0 occurrences in src/ and dist/'
        : `Found matches in: ${[...srcHits, ...distHits].join(', ')}`,
  });

  // 2. Health endpoint
  try {
    const res = await fetch(`${targetUrl}/api/system/health`);
    const body = (await res.json()) as { success?: boolean; status?: string; runtime?: string };
    results.push({
      name: 'GET /api/system/health',
      status: res.status === 200 && body.success && body.status === 'ok' ? 'PASS' : 'FAIL',
      detail: `HTTP ${res.status} (${body.runtime || 'unknown'})`,
    });
  } catch (err: unknown) {
    results.push({
      name: 'GET /api/system/health',
      status: 'FAIL',
      detail: err instanceof Error ? err.message : String(err),
    });
  }

  // 3. Unauthenticated API protection
  try {
    const res = await fetch(`${targetUrl}/api/requests`);
    results.push({
      name: 'Unauthenticated GET /api/requests returns 401',
      status: res.status === 401 ? 'PASS' : 'FAIL',
      detail: `HTTP ${res.status}`,
    });
  } catch (err: unknown) {
    results.push({
      name: 'Unauthenticated GET /api/requests returns 401',
      status: 'FAIL',
      detail: err instanceof Error ? err.message : String(err),
    });
  }

  // 4. Unauthenticated R2 file guard
  try {
    const res = await fetch(`${targetUrl}/api/files/nonexistent-check`);
    results.push({
      name: 'Unauthenticated GET /api/files/:id returns 401',
      status: res.status === 401 ? 'PASS' : 'FAIL',
      detail: `HTTP ${res.status}`,
    });
  } catch (err: unknown) {
    results.push({
      name: 'Unauthenticated GET /api/files/:id returns 401',
      status: 'FAIL',
      detail: err instanceof Error ? err.message : String(err),
    });
  }

  // 5. Uploaded Brand Icon Static Asset check
  try {
    const res = await fetch(`${targetUrl}/assets/aistudio/Marcom-Task-Request-Tracker_cfd946e5.png`);
    results.push({
      name: 'Brand Icon Asset Serve Check',
      status: res.status === 200 ? 'PASS' : 'FAIL',
      detail: `HTTP ${res.status}`,
    });
  } catch (err: unknown) {
    results.push({
      name: 'Brand Icon Asset Serve Check',
      status: 'FAIL',
      detail: err instanceof Error ? err.message : String(err),
    });
  }

  // 6. Optional authenticated CSRF + Services Status + Quota Years check
  if (email && password) {
    try {
      const loginRes = await fetch(`${targetUrl}/api/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });
      const loginJson = (await loginRes.json()) as { csrfToken?: string };
      const sid = (loginRes.headers.get('set-cookie') || '').match(/marcomm_sid=([^;]+)/)?.[1];
      if (!loginRes.ok || !sid || !loginJson.csrfToken) {
        results.push({
          name: 'Authenticated Smoke Check',
          status: 'FAIL',
          detail: `Login HTTP ${loginRes.status}`,
        });
      } else {
        const cookie = `marcomm_sid=${sid}`;
        const csrfFail = await fetch(`${targetUrl}/api/requests`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', Cookie: cookie },
          body: JSON.stringify({}),
        });
        const yearsRes = await fetch(`${targetUrl}/api/quotas/years`, {
          headers: { Cookie: cookie },
        });
        const statusRes = await fetch(`${targetUrl}/api/system/services-status`, {
          headers: { Cookie: cookie },
        });
        await fetch(`${targetUrl}/api/auth/logout`, {
          method: 'POST',
          headers: { Cookie: cookie, 'X-CSRF-Token': loginJson.csrfToken },
        });

        results.push({
          name: 'Authenticated CSRF Guard + D1/R2 Services Check',
          status: csrfFail.status === 403 && yearsRes.status === 200 && statusRes.status === 200 ? 'PASS' : 'FAIL',
          detail: `CSRF=${csrfFail.status}, QuotaYears=${yearsRes.status}, Services=${statusRes.status}`,
        });
      }
    } catch (err: unknown) {
      results.push({
        name: 'Authenticated Smoke Check',
        status: 'FAIL',
        detail: err instanceof Error ? err.message : String(err),
      });
    }
  } else {
    results.push({
      name: 'Authenticated CSRF Guard + D1/R2 Services Check',
      status: 'SKIPPED',
      detail: 'No --email / --password supplied (run Vitest or pass credentials).',
    });
  }

  let hasFail = false;
  for (const r of results) {
    if (r.status === 'FAIL') hasFail = true;
    console.log(`[${r.status}] ${r.name} -> ${r.detail}`);
  }
  process.exit(hasFail ? 1 : 0);
}

main();
