import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

interface BrowserSnapshot {
  deviceLabel?: string;
  exportedAt?: string;
  regions?: any[];
  brands?: any[];
  units?: any[];
  departments?: any[];
  categories?: any[];
  teams?: any[];
  users?: any[];
  requests?: any[];
  comments?: any[];
  activityLogs?: any[];
  notifications?: any[];
  quotaPolicies?: any[];
  quotaLedger?: any[];
}

function readJsonSafe<T>(filePath: string, fallback: T): T {
  if (!fs.existsSync(filePath)) return fallback;
  try {
    return JSON.parse(fs.readFileSync(filePath, 'utf8')) as T;
  } catch {
    return fallback;
  }
}

function sanitizeUserRecord(raw: any) {
  if (!raw || typeof raw !== 'object') return null;
  const copy: Record<string, unknown> = {};
  const forbiddenKeys = new Set([
    'password',
    'plaintextPassword',
    'currentPassword',
    'newPassword',
    'sessionId',
    'csrfSecret',
    'recoveryToken',
    'recoveryTokenHash',
  ]);

  for (const [k, v] of Object.entries(raw)) {
    if (forbiddenKeys.has(k)) continue;
    copy[k] = v;
  }

  // Only retain verifiable hashed passwords (scrypt salt:hash or pbkdf2_sha256$...)
  if (typeof copy.passwordHash === 'string') {
    const ph = copy.passwordHash;
    const isValidFormat = ph.startsWith('pbkdf2_sha256$') || (/^[0-9a-f]+:[0-9a-f]+$/i.test(ph) && ph.length > 32);
    if (!isValidFormat) {
      delete copy.passwordHash;
      copy.mustChangePassword = true;
    }
  }
  return copy;
}

function dedupeById<T extends { id?: string }>(items: T[]): T[] {
  const map = new Map<string, T>();
  for (const item of items) {
    if (!item || typeof item !== 'object') continue;
    const id = item.id ? String(item.id) : '';
    if (!id) continue;
    if (!map.has(id)) {
      map.set(id, item);
    }
  }
  return Array.from(map.values());
}

function main() {
  const args = process.argv.slice(2);
  const browserFiles: string[] = [];
  let outFile = '';

  for (let i = 0; i < args.length; i++) {
    if (args[i] === '--browser' && args[i + 1]) {
      browserFiles.push(args[++i]);
    } else if (args[i] === '--out' && args[i + 1]) {
      outFile = args[++i];
    }
  }

  const rootDir = process.cwd();
  const dataDir = path.join(rootDir, 'data');

  // Strict Read-Only ingestion of legacy server JSON files (EXCLUDES server_sessions.json by design)
  const serverUsersRaw = readJsonSafe<any[]>(path.join(dataDir, 'server_users.json'), []);
  const serverPoliciesRaw = readJsonSafe<any[]>(path.join(dataDir, 'quota_policies.json'), []);
  const serverLedgerRaw = readJsonSafe<any[]>(path.join(dataDir, 'quota_ledger.json'), []);

  const combined: Required<Omit<BrowserSnapshot, 'deviceLabel' | 'exportedAt'>> = {
    regions: [],
    brands: [],
    units: [],
    departments: [],
    categories: [],
    teams: [],
    users: serverUsersRaw.map(sanitizeUserRecord).filter(Boolean) as any[],
    requests: [],
    comments: [],
    activityLogs: [],
    notifications: [],
    quotaPolicies: [...serverPoliciesRaw],
    quotaLedger: [...serverLedgerRaw],
  };

  const sources: string[] = ['data/server_users.json', 'data/quota_policies.json', 'data/quota_ledger.json'];

  for (const bf of browserFiles) {
    const absPath = path.resolve(rootDir, bf);
    if (!fs.existsSync(absPath)) {
      console.warn(`[WARN] Browser export file not found, skipping: ${bf}`);
      continue;
    }
    const raw = readJsonSafe<any>(absPath, {});
    const snap: BrowserSnapshot = raw.data && typeof raw.data === 'object' ? raw.data : raw;
    sources.push(bf);

    if (Array.isArray(snap.regions)) combined.regions.push(...snap.regions);
    if (Array.isArray(snap.brands)) combined.brands.push(...snap.brands);
    if (Array.isArray(snap.units)) combined.units.push(...snap.units);
    if (Array.isArray(snap.departments)) combined.departments.push(...snap.departments);
    if (Array.isArray(snap.categories)) combined.categories.push(...snap.categories);
    if (Array.isArray(snap.teams)) combined.teams.push(...snap.teams);
    if (Array.isArray(snap.users)) {
      combined.users.push(...(snap.users.map(sanitizeUserRecord).filter(Boolean) as any[]));
    }
    if (Array.isArray(snap.requests)) combined.requests.push(...snap.requests);
    if (Array.isArray(snap.comments)) combined.comments.push(...snap.comments);
    if (Array.isArray(snap.activityLogs)) combined.activityLogs.push(...snap.activityLogs);
    if (Array.isArray(snap.notifications)) combined.notifications.push(...snap.notifications);
    if (Array.isArray(snap.quotaPolicies)) combined.quotaPolicies.push(...snap.quotaPolicies);
    if (Array.isArray(snap.quotaLedger)) combined.quotaLedger.push(...snap.quotaLedger);
  }

  // Deduplicate exact IDs without discarding differing payloads (Worker migration endpoint checks conflicts per device batch)
  const sanitizedData = {
    regions: dedupeById(combined.regions).map((r: any) => ({
      ...r,
      name: String(r.name || '').replace(/^Wilayah\s+/i, '').trim(),
    })),
    brands: dedupeById(combined.brands),
    units: dedupeById(combined.units),
    departments: dedupeById(combined.departments),
    categories: dedupeById(combined.categories),
    teams: dedupeById(combined.teams),
    users: dedupeById(combined.users),
    requests: dedupeById(combined.requests),
    comments: dedupeById(combined.comments),
    activityLogs: dedupeById(combined.activityLogs),
    notifications: dedupeById(combined.notifications),
    quotaPolicies: dedupeById(combined.quotaPolicies),
    quotaLedger: dedupeById(combined.quotaLedger),
  };

  const dataJson = JSON.stringify(sanitizedData);
  const checksumSha256 = crypto.createHash('sha256').update(dataJson).digest('hex');
  const nowIso = new Date().toISOString();

  const bundle = {
    schemaVersion: 'marcomm-migration-bundle-v2',
    exportedAt: nowIso,
    sources,
    securityNotes: [
      'Active session tokens (data/server_sessions.json) intentionally excluded.',
      'Plaintext passwords & recovery secrets stripped.',
      'Legacy /data/*.json files read in strict read-only mode.',
    ],
    inventory: {
      regions: sanitizedData.regions.length,
      brands: sanitizedData.brands.length,
      units: sanitizedData.units.length,
      departments: sanitizedData.departments.length,
      categories: sanitizedData.categories.length,
      teams: sanitizedData.teams.length,
      users: sanitizedData.users.length,
      requests: sanitizedData.requests.length,
      comments: sanitizedData.comments.length,
      activityLogs: sanitizedData.activityLogs.length,
      quotaPolicies: sanitizedData.quotaPolicies.length,
      quotaLedger: sanitizedData.quotaLedger.length,
    },
    checksumSha256,
    data: sanitizedData,
  };

  const exportDir = path.join(rootDir, 'migration-exports');
  fs.mkdirSync(exportDir, { recursive: true });
  const targetFile =
    outFile ||
    path.join(exportDir, `migration_export_${nowIso.replace(/[:.]/g, '-')}.json`);

  fs.writeFileSync(targetFile, JSON.stringify(bundle, null, 2), 'utf8');
  console.log('[EXPORT COMPLETE] Sanitized legacy data bundle written to:', targetFile);
  console.log('SHA-256:', checksumSha256);
  console.log('Inventory:', JSON.stringify(bundle.inventory));
}

main();
