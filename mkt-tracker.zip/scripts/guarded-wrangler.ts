import { spawnSync } from 'node:child_process';

type GuardedAction = 'migrate-production' | 'deploy-production';

function main() {
  const action = process.argv[2] as GuardedAction | undefined;
  const hasFlag = process.argv.includes('--confirm-production');
  const hasEnv = process.env.ALLOW_PRODUCTION_DEPLOY === 'YES';

  if (action !== 'migrate-production' && action !== 'deploy-production') {
    console.error('Usage: tsx scripts/guarded-wrangler.ts <migrate-production|deploy-production> --confirm-production');
    process.exit(1);
  }

  if (!hasEnv || !hasFlag) {
    console.error('========================================================================');
    console.error('[PRODUCTION GUARD BLOCKED] Explicit production cutover approval required.');
    console.error(`Requested action : ${action}`);
    console.error(`ALLOW_PRODUCTION_DEPLOY=YES : ${hasEnv ? 'PRESENT' : 'MISSING'}`);
    console.error(`--confirm-production flag   : ${hasFlag ? 'PRESENT' : 'MISSING'}`);
    console.error('To execute in an approved cutover window, pass BOTH ALLOW_PRODUCTION_DEPLOY=YES');
    console.error('and --confirm-production. Refer to PRODUCTION_READINESS_CHECKLIST.md.');
    console.error('========================================================================');
    process.exit(2);
  }

  if (action === 'migrate-production') {
    console.log('[PRODUCTION] Applying D1 migrations to marcomm-db-production...');
    const res = spawnSync(
      'npx',
      ['wrangler', 'd1', 'migrations', 'apply', 'marcomm-db-production', '--env', 'production', '--remote'],
      { stdio: 'inherit', shell: true }
    );
    process.exit(res.status ?? 1);
  }

  if (action === 'deploy-production') {
    console.log('[PRODUCTION] Building frontend assets and deploying Worker to production...');
    const buildRes = spawnSync('npm', ['run', 'build'], { stdio: 'inherit', shell: true });
    if (buildRes.status !== 0) {
      process.exit(buildRes.status ?? 1);
    }
    const deployRes = spawnSync(
      'npx',
      ['wrangler', 'deploy', '--env', 'production'],
      { stdio: 'inherit', shell: true }
    );
    process.exit(deployRes.status ?? 1);
  }
}

main();
