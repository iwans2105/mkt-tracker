import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

async function main() {
  const args = process.argv.slice(2);
  let filePath = '';
  let baseUrl = process.env.MIGRATION_TARGET_URL || 'http://localhost:3000';
  let email = process.env.MIGRATION_ADMIN_EMAIL || '';
  let password = process.env.MIGRATION_ADMIN_PASSWORD || '';
  let deviceLabel = 'cli-migrator';
  let dryRun = false;

  for (let i = 0; i < args.length; i++) {
    if (args[i] === '--file' && args[i + 1]) filePath = args[++i];
    else if (args[i] === '--url' && args[i + 1]) baseUrl = args[++i];
    else if (args[i] === '--email' && args[i + 1]) email = args[++i];
    else if (args[i] === '--password' && args[i + 1]) password = args[++i];
    else if (args[i] === '--device' && args[i + 1]) deviceLabel = args[++i];
    else if (args[i] === '--dry-run') dryRun = true;
  }

  const rootDir = process.cwd();
  if (!filePath) {
    const exportDir = path.join(rootDir, 'migration-exports');
    if (fs.existsSync(exportDir)) {
      const files = fs
        .readdirSync(exportDir)
        .filter((f) => f.endsWith('.json'))
        .sort()
        .reverse();
      if (files.length > 0) filePath = path.join(exportDir, files[0]);
    }
  }

  if (!filePath || !fs.existsSync(filePath)) {
    console.error('Error: Provide --file <migration_export.json> or run export-legacy-data.ts first.');
    process.exit(1);
  }

  const bundle = JSON.parse(fs.readFileSync(filePath, 'utf8'));
  const data = bundle.data || bundle;
  if (bundle.checksumSha256) {
    const actualSha = crypto.createHash('sha256').update(JSON.stringify(data)).digest('hex');
    if (actualSha !== bundle.checksumSha256) {
      console.error(`Checksum mismatch! Expected ${bundle.checksumSha256}, got ${actualSha}`);
      process.exit(1);
    }
  }

  console.log('[IMPORT] Target URL:', baseUrl);
  console.log('[IMPORT] Bundle File:', filePath);
  console.log('[IMPORT] Device Label:', deviceLabel);
  console.log('[IMPORT] Inventory:', JSON.stringify(bundle.inventory || {}));

  if (dryRun) {
    console.log('[DRY-RUN] Validation & checksum verification succeeded. No network requests sent.');
    process.exit(0);
  }

  if (!email || !password) {
    console.error('Error: Super Admin credentials required (--email and --password, or MIGRATION_ADMIN_EMAIL/MIGRATION_ADMIN_PASSWORD env vars).');
    process.exit(1);
  }

  const loginRes = await fetch(`${baseUrl.replace(/\/$/, '')}/api/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password }),
  });

  if (!loginRes.ok) {
    const errText = await loginRes.text();
    console.error(`[AUTH FAILED] HTTP ${loginRes.status}: ${errText}`);
    process.exit(1);
  }

  const loginData = (await loginRes.json()) as { csrfToken?: string; user?: { role?: string } };
  const setCookie = loginRes.headers.get('set-cookie') || '';
  const sidMatch = setCookie.match(/marcomm_sid=([^;]+)/);
  if (!sidMatch || !loginData.csrfToken) {
    console.error('[AUTH FAILED] Session cookie or CSRF token missing.');
    process.exit(1);
  }
  const cookieHeader = `marcomm_sid=${sidMatch[1]}`;

  const importRes = await fetch(`${baseUrl.replace(/\/$/, '')}/api/migration/import`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Cookie: cookieHeader,
      'X-CSRF-Token': loginData.csrfToken,
    },
    body: JSON.stringify({ deviceLabel, data }),
  });

  const importJson = await importRes.json();
  console.log('[IMPORT RESULT]:', JSON.stringify(importJson, null, 2));

  const reportRes = await fetch(`${baseUrl.replace(/\/$/, '')}/api/migration/reconciliation-report`, {
    headers: { Cookie: cookieHeader },
  });
  const reportJson = (await reportRes.json()) as { tableCounts?: unknown; conflicts?: unknown[] };
  console.log('[D1 RECONCILIATION COUNTS]:', JSON.stringify(reportJson.tableCounts));
  console.log('[PENDING CONFLICTS]:', Array.isArray(reportJson.conflicts) ? reportJson.conflicts.length : 0);

  await fetch(`${baseUrl.replace(/\/$/, '')}/api/auth/logout`, {
    method: 'POST',
    headers: { Cookie: cookieHeader, 'X-CSRF-Token': loginData.csrfToken },
  });
}

main().catch((err) => {
  console.error('[IMPORT FATAL]:', err);
  process.exit(1);
});
