import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import crypto from 'node:crypto';
import { createTestWorkerEnv } from './helpers/testEnv';
import { verifyPassword } from '../src/worker/crypto';

describe('Security, RBAC, CSRF, Session Rotation, Rate Limit & Private R2 Access (SEC-01..SEC-06)', () => {
  let env: Awaited<ReturnType<typeof createTestWorkerEnv>>;

  beforeEach(async () => {
    env = await createTestWorkerEnv();
  });

  afterEach(() => {
    env.cleanup();
  });

  it('SEC-01: Rejects unauthenticated access across protected API routes with 401', async () => {
    const endpoints = [
      '/api/requests',
      '/api/users',
      '/api/sync',
      '/api/quotas/years',
      '/api/master-data',
      '/api/files/att-missing',
      '/api/system/services-status',
      '/api/migration/reconciliation-report',
    ];
    for (const ep of endpoints) {
      const res = await env.requestWorker(ep);
      expect(res.status, `Expected 401 for ${ep}`).toBe(401);
    }
  });

  it('SEC-02: Enforces brand-scope & role-based RBAC on requests and quotas', async () => {
    const casaSession = await env.loginAs('requester.casa@lyman.co.id');
    const wahooSession = await env.loginAs('requester.wahoo@lyman.co.id');
    const jktAdmin = await env.loginAs('admin.jkt@lyman.co.id');

    // Requester Casa cannot submit for Bandung/Wahoo brand
    const crossBrandRes = await env.requestWorker('/api/requests', {
      method: 'POST',
      session: casaSession,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title: 'Cross Brand Attempt',
        regionId: 'reg-bdg',
        brandId: 'brand-wahoo',
        categoryId: 'cat-graphic',
        description: 'Should fail scope check',
        deliverablesExpected: 'Poster',
        requestedDeadline: '2026-12-01',
        priority: 'low',
      }),
    });
    expect(crossBrandRes.status).toBe(403);

    // Requester Casa creates valid ticket in own brand
    const validRes = await env.requestWorker('/api/requests', {
      method: 'POST',
      session: casaSession,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title: 'Casa Valid Brief',
        regionId: 'reg-jkt',
        brandId: 'brand-casa',
        categoryId: 'cat-graphic',
        description: 'Valid brief',
        deliverablesExpected: 'Banner',
        requestedDeadline: '2026-12-01',
        priority: 'low',
      }),
    });
    expect(validRes.status).toBe(201);
    const created = (await validRes.json()) as { request: { id: string } };

    // Requester Wahoo cannot read Requester Casa's ticket
    const readCross = await env.requestWorker(`/api/requests/${created.request.id}`, {
      session: wahooSession,
    });
    expect(readCross.status).toBe(403);

    // Jakarta Admin cannot adjust Bandung/Wahoo quota
    const quotaCross = await env.requestWorker('/api/quotas/adjust', {
      method: 'POST',
      session: jktAdmin,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        brandId: 'brand-wahoo',
        priority: 'urgent',
        quantity: 1,
        reason: 'Unauthorized cross-region quota adjustment',
      }),
    });
    expect(quotaCross.status).toBe(403);
  });

  it('SEC-03: Enforces CSRF token verification and session rotation + old-session revocation on password change', async () => {
    const oldSession1 = await env.loginAs('requester.casa@lyman.co.id');
    const oldSession2 = await env.loginAs('requester.casa@lyman.co.id');

    // Missing CSRF token on state-changing POST must return 403
    const missingCsrf = await env.requestWorker('/api/requests', {
      method: 'POST',
      session: oldSession1,
      omitCsrf: true,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title: 'No CSRF' }),
    });
    expect(missingCsrf.status).toBe(403);

    // Change password rotates oldSession1 and revokes oldSession2
    const changeRes = await env.requestWorker('/api/auth/change-password', {
      method: 'POST',
      session: oldSession1,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        currentPassword: env.defaultPass,
        newPassword: 'RotatedNewSecure#2026!',
        confirmNewPassword: 'RotatedNewSecure#2026!',
      }),
    });
    expect(changeRes.status).toBe(200);
    const changeBody = (await changeRes.json()) as { csrfToken: string };
    const newCookie = (changeRes.headers.get('set-cookie') || '').match(/marcomm_sid=([^;]+)/)?.[1];
    expect(newCookie).toBeTruthy();
    expect(`marcomm_sid=${newCookie}`).not.toBe(oldSession1.cookie);

    // Old rotated session & sibling session must both now be invalid
    const checkOld1 = await env.requestWorker('/api/requests', { session: oldSession1 });
    expect(checkOld1.status).toBe(401);
    const checkOld2 = await env.requestWorker('/api/requests', { session: oldSession2 });
    expect(checkOld2.status).toBe(401);

    // Newly rotated session works with new CSRF token
    const checkRotated = await env.requestWorker('/api/auth/me', {
      session: {
        cookie: `marcomm_sid=${newCookie}`,
        csrfToken: changeBody.csrfToken,
        userId: oldSession1.userId,
      },
    });
    expect(checkRotated.status).toBe(200);
    const meJson = (await checkRotated.json()) as { authenticated: boolean };
    expect(meJson.authenticated).toBe(true);
  });

  it('SEC-04: Enforces D1 rate limiting (429) after 5 consecutive failed logins', async () => {
    for (let i = 0; i < 5; i++) {
      const failRes = await env.requestWorker('/api/auth/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'cf-connecting-ip': '198.51.100.44',
        },
        body: JSON.stringify({
          email: 'requester.casa@lyman.co.id',
          password: 'WrongPasswordAttempt!',
        }),
      });
      expect(failRes.status).toBe(401);
    }

    const blockedRes = await env.requestWorker('/api/auth/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'cf-connecting-ip': '198.51.100.44',
      },
      body: JSON.stringify({
        email: 'requester.casa@lyman.co.id',
        password: env.defaultPass,
      }),
    });
    expect(blockedRes.status).toBe(429);
  });

  it('SEC-05: Enforces Private R2 Upload & Download RBAC with SHA-256 verification', async () => {
    const casaSession = await env.loginAs('requester.casa@lyman.co.id');
    const wahooSession = await env.loginAs('requester.wahoo@lyman.co.id');

    const fileBytes = Buffer.from('%PDF-1.4\nPrivate Casa Brand Brief Content\n%%EOF');
    const uploadRes = await env.requestWorker('/api/files/upload', {
      method: 'POST',
      session: casaSession,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        fileName: 'casa-brief.pdf',
        mimeType: 'application/pdf',
        dataBase64: fileBytes.toString('base64'),
        scopeType: 'brief',
        brandId: 'brand-casa',
        regionId: 'reg-jkt',
      }),
    });
    expect(uploadRes.status).toBe(200);
    const upJson = (await uploadRes.json()) as { file: { id: string; url: string; sha256: string } };
    expect(upJson.file.url).toBe(`/api/files/${upJson.file.id}`);

    // Unauthenticated download -> 401
    const unauthGet = await env.requestWorker(upJson.file.url);
    expect(unauthGet.status).toBe(401);

    // Cross-brand requester download -> 403
    const crossGet = await env.requestWorker(upJson.file.url, { session: wahooSession });
    expect(crossGet.status).toBe(403);

    // Authorized same-brand download -> 200 with exact SHA-256 header
    const authGet = await env.requestWorker(upJson.file.url, { session: casaSession });
    expect(authGet.status).toBe(200);
    expect(authGet.headers.get('X-File-SHA256')).toBe(upJson.file.sha256);
    const downloadedBuf = Buffer.from(await authGet.arrayBuffer());
    expect(downloadedBuf.equals(fileBytes)).toBe(true);
  });

  it('SEC-06: Immediately revokes sessions on deactivation & transparently upgrades legacy scrypt hash', async () => {
    // 1. Session revocation on user deactivation
    const superSession = await env.loginAs('sosmeda217@gmail.com');
    const reqSession = await env.loginAs('requester.casa@lyman.co.id');

    const deactivateRes = await env.requestWorker('/api/users/user-req-casa', {
      method: 'PUT',
      session: superSession,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ isActive: false }),
    });
    expect(deactivateRes.status).toBe(200);

    const revokedCheck = await env.requestWorker('/api/requests', { session: reqSession });
    expect(revokedCheck.status).toBe(401);

    // 2. Legacy scrypt hash compatibility + transparent upgrade to PBKDF2-SHA256 on login
    const legacySalt = crypto.randomBytes(16).toString('hex');
    const legacyPw = 'LegacyUserPass#2026!';
    const legacyDerived = crypto.scryptSync(legacyPw, legacySalt, 64, { N: 16384, r: 8, p: 1 }).toString('hex');
    const legacyHash = `${legacySalt}:${legacyDerived}`;

    expect(await verifyPassword(legacyPw, legacyHash, env.bindings.PASSWORD_PEPPER)).toBe(true);

    await env.db
      .prepare('UPDATE users SET password_hash = ? WHERE id = ?')
      .bind(legacyHash, 'user-member-design')
      .run();

    await env.loginAs('designer@lyman.co.id', legacyPw);

    const upgradedRow = await env.db
      .prepare('SELECT password_hash FROM users WHERE id = ?')
      .bind('user-member-design')
      .first<{ password_hash: string }>();
    expect(upgradedRow?.password_hash.startsWith('pbkdf2_sha256$100000$1$')).toBe(true);
  });
});
