import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import type { ExecutionContext } from '@cloudflare/workers-types';
import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import workerEntry from '../src/worker/index';
import { hashPassword } from '../src/worker/crypto';
import type { WorkerBindings } from '../src/worker/types';
import {
  applyLocalSqlMigrations,
  createLocalDiskR2Adapter,
  createNodeSqliteD1Adapter,
} from '../src/server/localAdapters';
import { createTestWorkerEnv } from './helpers/testEnv';

describe('Sign In, Sign Out, Refresh/Republish Cache Control & Save Persistence', () => {
  let env: Awaited<ReturnType<typeof createTestWorkerEnv>>;

  beforeEach(async () => {
    env = await createTestWorkerEnv();
  });

  afterEach(() => {
    env.cleanup();
  });

  it('enforces strict no-store/no-cache headers on all /api/* responses and SPA HTML entrypoints', async () => {
    const admin = await env.loginAs('admin.jkt@lyman.co.id');

    const apiRes = await env.requestWorker('/api/sync', {
      method: 'GET',
      session: admin,
    });
    expect(apiRes.status).toBe(200);
    expect(apiRes.headers.get('cache-control')).toContain('no-store');
    expect(apiRes.headers.get('cache-control')).toContain('no-cache');
    expect(apiRes.headers.get('cache-control')).toContain('must-revalidate');
    expect(apiRes.headers.get('pragma')).toBe('no-cache');
    expect(apiRes.headers.get('expires')).toBe('0');
    expect(apiRes.headers.get('surrogate-control')).toBe('no-store');

    const mockBindings: WorkerBindings = {
      ...env.bindings,
      ASSETS: {
        fetch: async (req: RequestInfo | URL) => {
          const urlStr = typeof req === 'string' ? req : req instanceof URL ? req.href : req.url;
          if (urlStr.endsWith('/assets/app-123.js')) {
            return new Response('console.log("ok")', {
              status: 200,
              headers: {
                'Content-Type': 'application/javascript',
                'Cache-Control': 'public, max-age=31536000, immutable',
              },
            });
          }
          return new Response('<!doctype html><html><body>MARCOMM TASK</body></html>', {
            status: 200,
            headers: {
              'Content-Type': 'text/html; charset=utf-8',
              'Cache-Control': 'public, max-age=3600',
            },
          });
        },
      } as unknown as WorkerBindings['ASSETS'],
    };

    const htmlRes = await workerEntry.fetch(
      new Request('http://localhost:8787/', {
        headers: { Accept: 'text/html' },
      }),
      mockBindings,
      { waitUntil: () => {}, passThroughOnException: () => {} } as unknown as ExecutionContext
    );
    expect(htmlRes.status).toBe(200);
    expect(htmlRes.headers.get('cache-control')).toBe('no-cache, no-store, must-revalidate');
    expect(htmlRes.headers.get('pragma')).toBe('no-cache');
    expect(htmlRes.headers.get('expires')).toBe('0');

    const deepRouteRes = await workerEntry.fetch(
      new Request('http://localhost:8787/requests/REQ-123', {
        headers: { Accept: 'text/html' },
      }),
      mockBindings,
      { waitUntil: () => {}, passThroughOnException: () => {} } as unknown as ExecutionContext
    );
    expect(deepRouteRes.headers.get('cache-control')).toBe('no-cache, no-store, must-revalidate');

    const hashedAssetRes = await workerEntry.fetch(
      new Request('http://localhost:8787/assets/app-123.js'),
      mockBindings,
      { waitUntil: () => {}, passThroughOnException: () => {} } as unknown as ExecutionContext
    );
    expect(hashedAssetRes.headers.get('cache-control')).toBe('public, max-age=31536000, immutable');
  });

  it('Sign In retrieves the latest D1 user profile, master data, requests, and quotas immediately', async () => {
    const nowIso = new Date().toISOString();
    await env.db
      .prepare('UPDATE users SET full_name = ?, job_title = ?, updated_at = ? WHERE id = ?')
      .bind('Admin Jakarta Updated', 'Lead Marcomm Manager', nowIso, 'user-admin-jkt')
      .run();

    await env.db
      .prepare(
        `INSERT INTO brands (id, region_id, name, code, is_active, created_at, updated_at)
         VALUES ('brand-fresh-sync', 'reg-jkt', 'Lyman Fresh Residence', 'LFR', 1, ?, ?)`
      )
      .bind(nowIso, nowIso)
      .run();

    const admin = await env.loginAs('admin.jkt@lyman.co.id');

    const [meRes, usersRes, masterRes, syncRes, quotaRes] = await Promise.all([
      env.requestWorker('/api/auth/me', { session: admin }),
      env.requestWorker('/api/users', { session: admin }),
      env.requestWorker('/api/master-data', { session: admin }),
      env.requestWorker('/api/sync', { session: admin }),
      env.requestWorker('/api/quotas/brand-casa?year=2026', { session: admin }),
    ]);

    expect(meRes.status).toBe(200);
    const meJson = (await meRes.json()) as { user: { fullName: string; jobTitle: string } };
    expect(meJson.user.fullName).toBe('Admin Jakarta Updated');
    expect(meJson.user.jobTitle).toBe('Lead Marcomm Manager');

    const usersJson = (await usersRes.json()) as { data: { id: string; fullName: string }[] };
    expect(usersJson.data.find((u) => u.id === 'user-admin-jkt')?.fullName).toBe('Admin Jakarta Updated');

    const masterJson = (await masterRes.json()) as { data: { brands: { id: string; name: string }[] } };
    expect(masterJson.data.brands.some((b) => b.id === 'brand-fresh-sync')).toBe(true);

    expect(syncRes.status).toBe(200);
    expect(quotaRes.status).toBe(200);
  });

  it('Save operations persist immediately to D1, bump parent updated_at on sub-item/comment writes, and clean up on Sign Out', async () => {
    const admin = await env.loginAs('admin.jkt@lyman.co.id');
    const reqCasa = await env.loginAs('requester.casa@lyman.co.id');

    // Create request
    const createRes = await env.requestWorker('/api/requests', {
      method: 'POST',
      session: reqCasa,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title: 'Digital Campaign Q4 Casa',
        regionId: 'reg-jkt',
        brandId: 'brand-casa',
        categoryId: 'cat-graphic',
        description: 'Social media assets & landing banner',
        deliverablesExpected: 'PNG 1080x1350',
        requestedDeadline: '2026-12-20',
        priority: 'urgent',
        quotaYear: 2026,
      }),
    });
    expect(createRes.status).toBe(201);
    const createdReq = ((await createRes.json()) as { request: { id: string; updatedAt: string } }).request;

    // Wait 5ms so updatedAt is strictly greater on subsequent writes
    await new Promise((resolve) => setTimeout(resolve, 10));

    // Post comment -> parent request updatedAt must bump
    const commentRes = await env.requestWorker(`/api/requests/${createdReq.id}/comments`, {
      method: 'POST',
      session: admin,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ content: 'Prioritas disetujui untuk produksi minggu ini.', type: 'general' }),
    });
    expect(commentRes.status).toBe(201);

    const syncAfterComment = await env.requestWorker('/api/sync', { session: admin });
    const syncJson1 = (await syncAfterComment.json()) as {
      requests: { id: string; updatedAt: string }[];
    };
    const afterCommentReq = syncJson1.requests.find((r) => r.id === createdReq.id)!;
    expect(afterCommentReq.updatedAt > createdReq.updatedAt).toBe(true);

    await new Promise((resolve) => setTimeout(resolve, 10));

    // Add sub-item -> parent request updatedAt must bump and sub-item must appear in /api/sync immediately
    const subRes = await env.requestWorker(`/api/requests/${createdReq.id}/sub-items`, {
      method: 'POST',
      session: admin,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title: 'KV Hero Banner IG Feed',
        priority: 'high',
        ownerId: 'user-member-design',
      }),
    });
    expect(subRes.status).toBe(201);

    const syncAfterSub = await env.requestWorker('/api/sync', { session: admin });
    const syncJson2 = (await syncAfterSub.json()) as {
      requests: { id: string; updatedAt: string; subItems?: { title: string }[] }[];
    };
    const afterSubReq = syncJson2.requests.find((r) => r.id === createdReq.id)!;
    expect(afterSubReq.updatedAt > afterCommentReq.updatedAt).toBe(true);
    expect(afterSubReq.subItems?.some((s) => s.title === 'KV Hero Banner IG Feed')).toBe(true);

    // Update profile via PUT /api/users/:id and verify immediate /api/auth/me reflection
    const profRes = await env.requestWorker(`/api/users/${reqCasa.userId}`, {
      method: 'PUT',
      session: reqCasa,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ fullName: 'Requester Casa Verified', jobTitle: 'Brand Coordinator' }),
    });
    expect(profRes.status).toBe(200);

    const meAfterSave = await env.requestWorker('/api/auth/me', { session: reqCasa });
    const meJson = (await meAfterSave.json()) as { user: { fullName: string; jobTitle: string } };
    expect(meJson.user.fullName).toBe('Requester Casa Verified');
    expect(meJson.user.jobTitle).toBe('Brand Coordinator');

    // Sign out persists auth_logout audit record & deletes session from D1
    const logoutRes = await env.requestWorker('/api/auth/logout', {
      method: 'POST',
      session: reqCasa,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ flushedClientChanges: true }),
    });
    expect(logoutRes.status).toBe(200);
    const logoutJson = (await logoutRes.json()) as { success: boolean; savedAt: string };
    expect(logoutJson.success).toBe(true);
    expect(typeof logoutJson.savedAt).toBe('string');

    const auditRow = await env.db
      .prepare("SELECT action, actor_id, details_json FROM security_audit_logs WHERE action = 'auth_logout' AND actor_id = ?")
      .bind(reqCasa.userId)
      .first<{ action: string; actor_id: string; details_json: string }>();
    expect(auditRow?.action).toBe('auth_logout');
    expect(JSON.parse(auditRow?.details_json || '{}').flushedClientChanges).toBe(true);

    const remainingSessions = await env.db
      .prepare('SELECT session_id FROM sessions WHERE user_id = ?')
      .bind(reqCasa.userId)
      .all();
    expect(remainingSessions.results.length).toBe(0);

    const postLogoutSync = await env.requestWorker('/api/sync', { session: reqCasa });
    expect(postLogoutSync.status).toBe(401);
  });

  it('persists file-backed SQLite state across WAL checkpoint and server restart (republish/refresh simulation)', async () => {
    const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'marcomm-sqlite-restart-'));
    const dbPath = path.join(tmpDir, 'preview.sqlite');
    const pepper = 'restart-test-pepper-2026';

    try {
      // Boot 1: initialize schema, seed admin, create data, checkpoint & close
      const boot1 = createNodeSqliteD1Adapter(dbPath);
      applyLocalSqlMigrations(boot1.rawExec, process.cwd());

      const nowIso = new Date().toISOString();
      const passHash = await hashPassword('RestartTest#2026!', pepper);
      await boot1.db
        .prepare(
          `INSERT INTO users
           (id, email, full_name, job_title, department, role, is_reviewer, teams_json, competencies_json,
            assigned_regions_json, assigned_brands_json, is_active, password_hash, must_change_password, created_at, updated_at)
           VALUES ('user-sa-restart', 'sa.restart@lyman.co.id', 'Super Admin Restart', 'Head', 'Marketing Komunikasi',
                   'super_admin', 1, '["team-design"]', '[]', '["all"]', '["all"]', 1, ?, 0, ?, ?)`
        )
        .bind(passHash, nowIso, nowIso)
        .run();

      await boot1.db
        .prepare(
          `INSERT INTO brands (id, region_id, name, code, is_active, created_at, updated_at)
           VALUES ('brand-republish-persist', 'reg-jkt', 'Persist Tower', 'PTW', 1, ?, ?)`
        )
        .bind(nowIso, nowIso)
        .run();

      boot1.checkpoint();
      boot1.close();

      // Boot 2: open same SQLite file cleanly and confirm rows survived republish/restart
      const boot2 = createNodeSqliteD1Adapter(dbPath);
      const brandRow = await boot2.db
        .prepare("SELECT name, code FROM brands WHERE id = 'brand-republish-persist'")
        .first<{ name: string; code: string }>();
      const userRow = await boot2.db
        .prepare("SELECT full_name FROM users WHERE id = 'user-sa-restart'")
        .first<{ full_name: string }>();

      expect(brandRow?.name).toBe('Persist Tower');
      expect(brandRow?.code).toBe('PTW');
      expect(userRow?.full_name).toBe('Super Admin Restart');
      boot2.close();
      createLocalDiskR2Adapter('memory');
    } finally {
      fs.rmSync(tmpDir, { recursive: true, force: true });
    }
  });
});
