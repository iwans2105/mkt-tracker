import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import { getWibSlaDeadlineDateString, getWibYear } from '../src/worker/utils/wib';
import { createTestWorkerEnv } from './helpers/testEnv';

describe('Public Request Form (Isolated /api/public/*, Token Security, Rate Limit & Atomic Quotas)', () => {
  let env: Awaited<ReturnType<typeof createTestWorkerEnv>>;

  beforeEach(async () => {
    env = await createTestWorkerEnv();
  });

  afterEach(() => {
    env.cleanup();
  });

  async function getAdminPublicToken(): Promise<{
    superSession: Awaited<ReturnType<typeof env.loginAs>>;
    accessToken: string;
  }> {
    const superSession = await env.loginAs('sosmeda217@gmail.com');
    const res = await env.requestWorker('/api/system/public-form-config', {
      method: 'GET',
      session: superSession,
    });
    expect(res.status).toBe(200);
    const json = (await res.json()) as {
      success: boolean;
      config: { accessToken: string; enabled: boolean; requireToken: boolean };
    };
    expect(json.success).toBe(true);
    expect(json.config.accessToken.length).toBeGreaterThanOrEqual(16);
    return { superSession, accessToken: json.config.accessToken };
  }

  it('rejects missing/invalid tokens with 401 and returns sanitized masterData without internal leaks on valid token', async () => {
    const { accessToken } = await getAdminPublicToken();

    // Missing token -> 401 and no masterData leaked
    const missingRes = await env.requestWorker('/api/public/request-form-config');
    expect(missingRes.status).toBe(401);
    const missingJson = (await missingRes.json()) as Record<string, unknown>;
    expect(missingJson.requiresToken).toBe(true);
    expect(missingJson.masterData).toBeUndefined();

    // Wrong token -> 401
    const wrongRes = await env.requestWorker('/api/public/request-form-config?token=wrong-token-123');
    expect(wrongRes.status).toBe(401);

    // Valid token -> 200 with ONLY active masterData (no users, requests, passwords, or secret tokens)
    const okRes = await env.requestWorker('/api/public/request-form-config', {
      headers: { 'X-Public-Form-Token': accessToken },
    });
    expect(okRes.status).toBe(200);
    const okText = await okRes.text();
    const okJson = JSON.parse(okText) as {
      success: boolean;
      config: { enabled: boolean; requireToken: boolean; allowAttachments: boolean; year: number };
      masterData: {
        regions: unknown[];
        brands: unknown[];
        units: unknown[];
        departments: unknown[];
        categories: unknown[];
      };
    };

    expect(okJson.success).toBe(true);
    expect(okJson.config.enabled).toBe(true);
    expect(okJson.masterData.regions.length).toBeGreaterThan(0);
    expect(okJson.masterData.brands.length).toBeGreaterThan(0);
    expect(okJson.masterData.departments.length).toBeGreaterThan(0);
    expect(okJson.masterData.categories.length).toBeGreaterThan(0);

    // Ensure zero sensitive internal user/token/ticket data leaks
    expect(okText).not.toContain('sosmeda217@gmail.com');
    expect(okText).not.toContain('admin.jkt@lyman.co.id');
    expect(okText).not.toContain('passwordHash');
    expect(okText).not.toContain(accessToken);
    expect((okJson.masterData as Record<string, unknown>).users).toBeUndefined();
    expect((okJson.masterData as Record<string, unknown>).requests).toBeUndefined();
  });

  it('enforces server-authoritative WIB SLA deadline, deducts quota atomically, notifies admins, and deduplicates idempotencyKey', async () => {
    const { accessToken } = await getAdminPublicToken();
    const wibYear = getWibYear();
    const expectedUrgentDeadline = getWibSlaDeadlineDateString(1);
    const idemKey = 'pub-idem-test-001';

    const submitPayload = {
      idempotencyKey: idemKey,
      requesterName: 'Siti Rahmawati',
      requesterEmail: 'siti.rahmawati@lyman.co.id',
      requesterDepartment: 'Sales & Leasing',
      title: 'Desain Standing Banner Event Pameran',
      regionId: 'reg-jkt',
      brandId: 'brand-casa',
      categoryId: 'cat-graphic',
      description: 'Kebutuhan materi visual standing banner pameran properti akhir pekan.',
      deliverablesExpected: 'File PDF siap cetak ukuran 80x180cm resolusi 300dpi',
      priority: 'urgent',
      // Client attempts to tamper with deadline to an earlier date; server MUST override it with WIB SLA (+1 day)
      requestedDeadline: '2020-01-01',
      referenceUrl: 'https://drive.google.com/drive/folders/sample-brief',
    };

    const res1 = await env.requestWorker('/api/public/requests', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Public-Form-Token': accessToken,
      },
      body: JSON.stringify(submitPayload),
    });
    expect(res1.status).toBe(201);
    const json1 = (await res1.json()) as {
      success: boolean;
      submission: {
        requestId: string;
        ticketNumber: string;
        requestedDeadline: string;
        slaDays: number;
        requesterName: string;
        requesterEmail: string;
      };
    };
    expect(json1.success).toBe(true);
    expect(json1.submission.ticketNumber).toMatch(new RegExp(`^REQ-${wibYear}-\\d{4}$`));
    expect(json1.submission.requestedDeadline).toBe(expectedUrgentDeadline);
    expect(json1.submission.slaDays).toBe(1);

    // Check D1 request row, quota counter, ledger & admin notifications
    const reqRow = await env.db
      .prepare('SELECT requester_id, requester_name, requester_email, requested_deadline, priority FROM requests WHERE id = ?')
      .bind(json1.submission.requestId)
      .first<Record<string, unknown>>();
    expect(reqRow?.requester_id).toBe('public-requester');
    expect(reqRow?.requester_name).toBe('Siti Rahmawati');
    expect(reqRow?.requester_email).toBe('siti.rahmawati@lyman.co.id');
    expect(reqRow?.requested_deadline).toBe(expectedUrgentDeadline);

    const quotaRes = await env.requestWorker('/api/public/quotas/brand-casa', {
      headers: { 'X-Public-Form-Token': accessToken },
    });
    expect(quotaRes.status).toBe(200);
    const quotaJson = (await quotaRes.json()) as {
      summary: { priorities: { urgent: { used: number; remaining: number; annualLimit: number } } };
    };
    expect(quotaJson.summary.priorities.urgent.used).toBe(1);
    expect(quotaJson.summary.priorities.urgent.remaining).toBe(
      quotaJson.summary.priorities.urgent.annualLimit - 1
    );

    const notifs = await env.db
      .prepare('SELECT user_id FROM notifications WHERE request_id = ?')
      .bind(json1.submission.requestId)
      .all<{ user_id: string }>();
    const notifiedIds = (notifs.results || []).map((n) => n.user_id);
    expect(notifiedIds).toContain('user-superadmin');
    expect(notifiedIds).toContain('user-admin-jkt');

    // Verify public-requester system account is never exposed via /api/users directory
    const adminSession = await env.loginAs('admin.jkt@lyman.co.id');
    const usersRes = await env.requestWorker('/api/users', { session: adminSession });
    const usersJson = (await usersRes.json()) as { data: { id: string }[] };
    expect(usersJson.data.some((u) => u.id === 'public-requester')).toBe(false);

    // Replay same idempotencyKey -> returns deduplicated confirmation without double quota deduction
    const res2 = await env.requestWorker('/api/public/requests', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Public-Form-Token': accessToken,
      },
      body: JSON.stringify(submitPayload),
    });
    expect(res2.status).toBe(200);
    const json2 = (await res2.json()) as { deduplicated?: boolean; submission: { requestId: string } };
    expect(json2.deduplicated).toBe(true);
    expect(json2.submission.requestId).toBe(json1.submission.requestId);

    const ledgerCount = await env.db
      .prepare('SELECT COUNT(*) AS cnt FROM priority_quota_ledger WHERE request_id = ?')
      .bind(json1.submission.requestId)
      .first<{ cnt: number }>();
    expect(ledgerCount?.cnt).toBe(1);
  });

  it('rejects requests when public form is disabled, email domain is disallowed, or reference URL is unsafe', async () => {
    const { superSession, accessToken } = await getAdminPublicToken();

    // Configure domain restriction = ['lyman.co.id']
    const updRes = await env.requestWorker('/api/system/public-form-config', {
      method: 'PUT',
      session: superSession,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        enabled: true,
        requireToken: true,
        allowAttachments: true,
        allowedEmailDomains: ['lyman.co.id'],
      }),
    });
    expect(updRes.status).toBe(200);

    // Non-corporate email rejected
    const badDomainRes = await env.requestWorker('/api/public/requests', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Public-Form-Token': accessToken,
      },
      body: JSON.stringify({
        requesterName: 'Pengaju Eksternal',
        requesterEmail: 'external@gmail.com',
        requesterDepartment: 'Marketing Komunikasi',
        title: 'Uji Validasi Domain Email',
        regionId: 'reg-jkt',
        brandId: 'brand-casa',
        categoryId: 'cat-graphic',
        description: 'Menguji pembatasan domain email korporat pada tautan publik.',
        deliverablesExpected: 'Poster PNG',
        priority: 'low',
      }),
    });
    expect(badDomainRes.status).toBe(400);

    // Unsafe javascript: URL rejected
    const badUrlRes = await env.requestWorker('/api/public/requests', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Public-Form-Token': accessToken,
      },
      body: JSON.stringify({
        requesterName: 'Budi Korporat',
        requesterEmail: 'budi@lyman.co.id',
        requesterDepartment: 'Marketing Komunikasi',
        title: 'Uji Validasi URL Referensi',
        regionId: 'reg-jkt',
        brandId: 'brand-casa',
        categoryId: 'cat-graphic',
        description: 'Menguji penolakan skema URL berbahaya pada kolom tautan referensi.',
        deliverablesExpected: 'Poster PNG',
        priority: 'low',
        referenceUrl: 'javascript:alert(1)',
      }),
    });
    expect(badUrlRes.status).toBe(400);

    // Disable public form -> 403 on both config and submit
    await env.requestWorker('/api/system/public-form-config', {
      method: 'PUT',
      session: superSession,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ enabled: false }),
    });

    const disabledCfg = await env.requestWorker('/api/public/request-form-config', {
      headers: { 'X-Public-Form-Token': accessToken },
    });
    expect(disabledCfg.status).toBe(403);
  });

  it('validates public R2 brief upload, blocks forged attachment IDs, and prevents anonymous file download', async () => {
    const { superSession, accessToken } = await getAdminPublicToken();

    // Disallowed file extension rejected
    const badFileRes = await env.requestWorker('/api/public/upload', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Public-Form-Token': accessToken,
      },
      body: JSON.stringify({
        fileName: 'malicious.html',
        mimeType: 'text/html',
        dataBase64: btoa('<script>alert(1)</script>'),
        brandId: 'brand-casa',
      }),
    });
    expect(badFileRes.status).toBe(400);

    // Valid PDF brief upload succeeds to R2
    const pdfBytes = btoa('%PDF-1.4\nSample brief content');
    const uploadRes = await env.requestWorker('/api/public/upload', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Public-Form-Token': accessToken,
      },
      body: JSON.stringify({
        fileName: 'brief-pameran.pdf',
        mimeType: 'application/pdf',
        dataBase64: pdfBytes,
        brandId: 'brand-casa',
      }),
    });
    expect(uploadRes.status).toBe(200);
    const uploadJson = (await uploadRes.json()) as {
      success: boolean;
      file: { id: string; url: string };
    };
    expect(uploadJson.success).toBe(true);

    // Anonymous caller CANNOT download private uploaded file
    const anonDownload = await env.requestWorker(`/api/files/${uploadJson.file.id}`);
    expect(anonDownload.status).toBe(401);

    // Forged attachment ID rejected on submit
    const forgedSubmit = await env.requestWorker('/api/public/requests', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Public-Form-Token': accessToken,
      },
      body: JSON.stringify({
        requesterName: 'Andi Wijaya',
        requesterEmail: 'andi@lyman.co.id',
        requesterDepartment: 'Marketing Komunikasi',
        title: 'Pengajuan Dengan Lampiran Palsu',
        regionId: 'reg-jkt',
        brandId: 'brand-casa',
        categoryId: 'cat-graphic',
        description: 'Menguji validasi kepemilikan ID lampiran dari database D1.',
        deliverablesExpected: 'Banner Sosial Media',
        priority: 'low',
        briefAttachments: [{ id: 'att-forged-does-not-exist' }],
      }),
    });
    expect(forgedSubmit.status).toBe(400);

    // Valid uploaded attachment ID succeeds & links to created ticket
    const validSubmit = await env.requestWorker('/api/public/requests', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Public-Form-Token': accessToken,
      },
      body: JSON.stringify({
        requesterName: 'Andi Wijaya',
        requesterEmail: 'andi@lyman.co.id',
        requesterDepartment: 'Marketing Komunikasi',
        title: 'Pengajuan Dengan Lampiran Brief Resmi',
        regionId: 'reg-jkt',
        brandId: 'brand-casa',
        categoryId: 'cat-graphic',
        description: 'Pengajuan brief pameran dengan dokumen PDF terlampir ke R2.',
        deliverablesExpected: 'Banner Sosial Media & Brosur Cetak',
        priority: 'low',
        briefAttachments: [{ id: uploadJson.file.id }],
      }),
    });
    expect(validSubmit.status).toBe(201);
    const validJson = (await validSubmit.json()) as { submission: { requestId: string } };

    // Authenticated Admin CAN download the attached brief
    const adminDownload = await env.requestWorker(`/api/files/${uploadJson.file.id}`, {
      session: superSession,
    });
    expect(adminDownload.status).toBe(200);
    expect(await adminDownload.text()).toContain('%PDF-1.4');

    const attMeta = await env.db
      .prepare('SELECT request_id FROM attachments WHERE id = ?')
      .bind(uploadJson.file.id)
      .first<{ request_id: string }>();
    expect(attMeta?.request_id).toBe(validJson.submission.requestId);
  });

  it('rejects exhausted brand quota with 409 + zero orphans, revokes old token on rotation, and rate limits brute force', async () => {
    const { superSession, accessToken } = await getAdminPublicToken();
    const year = getWibYear();

    // Set urgent limit = 1 for brand-wahoo
    await env.requestWorker('/api/quotas/policies', {
      method: 'PUT',
      session: superSession,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ brandId: 'brand-wahoo', year, limits: { urgent: 1 } }),
    });

    // First urgent public request succeeds
    const r1 = await env.requestWorker('/api/public/requests', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Public-Form-Token': accessToken },
      body: JSON.stringify({
        requesterName: 'Rina Bandung',
        requesterEmail: 'rina@lyman.co.id',
        requesterDepartment: 'Operations',
        title: 'Promo Akhir Pekan Wahoo 1',
        regionId: 'reg-bdg',
        brandId: 'brand-wahoo',
        categoryId: 'cat-graphic',
        description: 'Permintaan urgent pertama yang menghabiskan kuota tahunan brand.',
        deliverablesExpected: 'Instagram Story & Post',
        priority: 'urgent',
      }),
    });
    expect(r1.status).toBe(201);

    // Second urgent public request -> 409 Conflict, zero extra row
    const r2 = await env.requestWorker('/api/public/requests', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Public-Form-Token': accessToken },
      body: JSON.stringify({
        requesterName: 'Rina Bandung',
        requesterEmail: 'rina@lyman.co.id',
        requesterDepartment: 'Operations',
        title: 'Promo Akhir Pekan Wahoo 2',
        regionId: 'reg-bdg',
        brandId: 'brand-wahoo',
        categoryId: 'cat-graphic',
        description: 'Permintaan urgent kedua yang harus ditolak karena kuota habis.',
        deliverablesExpected: 'Instagram Story & Post',
        priority: 'urgent',
      }),
    });
    expect(r2.status).toBe(409);

    const wahooUrgentCount = await env.db
      .prepare("SELECT COUNT(*) AS cnt FROM requests WHERE brand_id = 'brand-wahoo' AND priority = 'urgent'")
      .first<{ cnt: number }>();
    expect(wahooUrgentCount?.cnt).toBe(1);

    // Token rotation invalidates old token immediately
    const rotRes = await env.requestWorker('/api/system/public-form-config/rotate', {
      method: 'POST',
      session: superSession,
    });
    expect(rotRes.status).toBe(200);
    const rotJson = (await rotRes.json()) as { config: { accessToken: string } };
    const newToken = rotJson.config.accessToken;
    expect(newToken).not.toBe(accessToken);

    const oldTokenCfg = await env.requestWorker('/api/public/request-form-config', {
      headers: { 'X-Public-Form-Token': accessToken },
    });
    expect(oldTokenCfg.status).toBe(401);

    const newTokenCfg = await env.requestWorker('/api/public/request-form-config', {
      headers: { 'X-Public-Form-Token': newToken },
    });
    expect(newTokenCfg.status).toBe(200);

    // Even if an authenticated Admin cookie is present, public form submission without CSRF header works cleanly
    const adminPublicSubmit = await env.requestWorker('/api/public/requests', {
      method: 'POST',
      session: superSession,
      omitCsrf: true,
      headers: {
        'Content-Type': 'application/json',
        'X-Public-Form-Token': newToken,
      },
      body: JSON.stringify({
        requesterName: 'Admin via Public Form',
        requesterEmail: 'admin.test@lyman.co.id',
        requesterDepartment: 'Marketing Komunikasi',
        title: 'Uji Pengajuan Publik Dengan Sesi Login Aktif',
        regionId: 'reg-jkt',
        brandId: 'brand-casa',
        categoryId: 'cat-graphic',
        description: 'Memastikan admin yang membuka link publik tetap bisa mengirim tanpa token CSRF internal.',
        deliverablesExpected: 'PDF Brief',
        priority: 'low',
      }),
    });
    expect(adminPublicSubmit.status).toBe(201);

    // Rate limiting against brute-force token guessing from a dedicated IP
    const attackerIp = '198.51.100.77';
    for (let i = 0; i < 10; i++) {
      const attempt = await env.requestWorker('/api/public/request-form-config', {
        headers: { 'cf-connecting-ip': attackerIp, 'X-Public-Form-Token': `guess-${i}` },
      });
      expect(attempt.status).toBe(401);
    }
    const blocked = await env.requestWorker('/api/public/request-form-config', {
      headers: { 'cf-connecting-ip': attackerIp, 'X-Public-Form-Token': newToken },
    });
    expect(blocked.status).toBe(429);
  });
});
