import type { ExecutionContext } from '@cloudflare/workers-types';
import { workerApp } from '../../src/worker/app';
import { hashPassword } from '../../src/worker/crypto';
import type { WorkerBindings } from '../../src/worker/types';
import {
  applyLocalSqlMigrations,
  createLocalDiskR2Adapter,
  createNodeSqliteD1Adapter,
} from '../../src/server/localAdapters';

export interface AuthSessionHandle {
  cookie: string;
  csrfToken: string;
  userId: string;
}

export async function createTestWorkerEnv(options: { pepper?: string; bootstrapToken?: string } = {}) {
  const { db, rawExec, close } = createNodeSqliteD1Adapter(':memory:');
  const bucket = createLocalDiskR2Adapter('memory');
  const pepper = options.pepper ?? 'test-pepper-secret-lyman-2026';

  applyLocalSqlMigrations(rawExec, process.cwd());

  const bindings: WorkerBindings = {
    DB: db,
    FILES_BUCKET: bucket,
    ENVIRONMENT: 'test',
    CUSTOM_DOMAIN_STATUS: 'placeholder',
    APP_ORIGIN: 'http://localhost:8787',
    SESSION_SECRET: 'test-session-hmac-secret-2026',
    PASSWORD_PEPPER: pepper,
    BOOTSTRAP_ADMIN_TOKEN: options.bootstrapToken ?? 'bootstrap-test-token-32-chars-minimum',
  };

  const defaultPass = 'TestSecure#2026!';
  const passHash = await hashPassword(defaultPass, pepper);
  const nowIso = new Date().toISOString();

  const seedUsers = [
    {
      id: 'user-superadmin',
      email: 'sosmeda217@gmail.com',
      fullName: 'Super Admin Utama',
      role: 'super_admin',
      isReviewer: 1,
      teams: ['team-design', 'team-socmed-doc'],
      regions: ['all'],
      brands: ['all'],
    },
    {
      id: 'user-admin-jkt',
      email: 'admin.jkt@lyman.co.id',
      fullName: 'Admin Jakarta',
      role: 'admin',
      isReviewer: 1,
      teams: ['team-design'],
      regions: ['reg-jkt'],
      brands: ['brand-casa', 'brand-wisma46'],
    },
    {
      id: 'user-req-casa',
      email: 'requester.casa@lyman.co.id',
      fullName: 'Requester Casa',
      role: 'requester',
      isReviewer: 0,
      teams: [],
      regions: ['reg-jkt'],
      brands: ['brand-casa'],
    },
    {
      id: 'user-req-wahoo',
      email: 'requester.wahoo@lyman.co.id',
      fullName: 'Requester Wahoo',
      role: 'requester',
      isReviewer: 0,
      teams: [],
      regions: ['reg-bdg'],
      brands: ['brand-wahoo'],
    },
    {
      id: 'user-member-design',
      email: 'designer@lyman.co.id',
      fullName: 'Desainer Grafis',
      role: 'team_member',
      isReviewer: 0,
      teams: ['team-design'],
      regions: ['all'],
      brands: ['all'],
    },
  ];

  for (const u of seedUsers) {
    await db
      .prepare(
        `INSERT INTO users
         (id, email, full_name, job_title, department, role, is_reviewer, teams_json, competencies_json,
          assigned_regions_json, assigned_brands_json, is_active, password_hash, must_change_password, created_at, updated_at)
         VALUES (?, ?, ?, 'Staff', 'Marketing Komunikasi', ?, ?, ?, '[]', ?, ?, 1, ?, 0, ?, ?)`
      )
      .bind(
        u.id,
        u.email,
        u.fullName,
        u.role,
        u.isReviewer,
        JSON.stringify(u.teams),
        JSON.stringify(u.regions),
        JSON.stringify(u.brands),
        passHash,
        nowIso,
        nowIso
      )
      .run();
  }

  async function requestWorker(
    path: string,
    init: RequestInit & { session?: AuthSessionHandle; omitCsrf?: boolean } = {}
  ): Promise<Response> {
    const headers = new Headers(init.headers);
    if (init.session) {
      headers.set('Cookie', init.session.cookie);
      if (
        !init.omitCsrf &&
        ['POST', 'PUT', 'PATCH', 'DELETE'].includes((init.method || 'GET').toUpperCase())
      ) {
        headers.set('X-CSRF-Token', init.session.csrfToken);
      }
    }
    if (!headers.has('cf-connecting-ip')) {
      headers.set('cf-connecting-ip', '203.0.113.10');
    }
    const req = new Request(`http://localhost:8787${path}`, {
      ...init,
      headers,
    });
    return workerApp.fetch(req, bindings, {
      waitUntil: () => {},
      passThroughOnException: () => {},
    } as unknown as ExecutionContext);
  }

  async function loginAs(email: string, password: string = defaultPass, ip = '203.0.113.10'): Promise<AuthSessionHandle> {
    const res = await requestWorker('/api/auth/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'cf-connecting-ip': ip,
      },
      body: JSON.stringify({ email, password }),
    });
    if (!res.ok) {
      throw new Error(`Login failed for ${email}: HTTP ${res.status} ${await res.text()}`);
    }
    const json = (await res.json()) as { csrfToken: string; user: { id: string } };
    const setCookie = res.headers.get('set-cookie') || '';
    const match = setCookie.match(/marcomm_sid=([^;]+)/);
    if (!match) throw new Error('Missing marcomm_sid cookie');
    return {
      cookie: `marcomm_sid=${match[1]}`,
      csrfToken: json.csrfToken,
      userId: json.user.id,
    };
  }

  return {
    db,
    bucket,
    bindings,
    defaultPass,
    requestWorker,
    loginAs,
    cleanup: () => close(),
  };
}
