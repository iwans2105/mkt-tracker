import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import { createTestWorkerEnv } from './helpers/testEnv';

describe('Atomic Priority Quota Engine & D1 Trigger Concurrency (CONC-01..CONC-04)', () => {
  let env: Awaited<ReturnType<typeof createTestWorkerEnv>>;

  beforeEach(async () => {
    env = await createTestWorkerEnv();
  });

  afterEach(() => {
    env.cleanup();
  });

  it('CONC-01: Concurrent submissions racing for the final quota slot allow exactly 1 and reject the rest with 409 + zero orphans', async () => {
    const superSession = await env.loginAs('sosmeda217@gmail.com');
    const reqCasa = await env.loginAs('requester.casa@lyman.co.id');
    const year = 2026;

    // Set Casa urgent limit = 1 for year 2026
    const polRes = await env.requestWorker('/api/quotas/policies', {
      method: 'PUT',
      session: superSession,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        brandId: 'brand-casa',
        year,
        limits: { urgent: 1 },
      }),
    });
    expect(polRes.status).toBe(200);

    // Fire 5 concurrent Urgent submissions simultaneously
    const responses = await Promise.all(
      Array.from({ length: 5 }, (_, idx) =>
        env.requestWorker('/api/requests', {
          method: 'POST',
          session: reqCasa,
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            title: `Concurrent Urgent ${idx + 1}`,
            regionId: 'reg-jkt',
            brandId: 'brand-casa',
            categoryId: 'cat-graphic',
            description: 'Race condition stress test',
            deliverablesExpected: 'Banner',
            requestedDeadline: '2026-12-15',
            priority: 'urgent',
            quotaYear: year,
          }),
        })
      )
    );

    const statuses = responses.map((r) => r.status);
    const createdCount = statuses.filter((s) => s === 201).length;
    const conflictCount = statuses.filter((s) => s === 409).length;

    expect(createdCount).toBe(1);
    expect(conflictCount).toBe(4);

    // Verify D1 database integrity: 1 request, 1 ledger row, used_count == 1
    const reqCount = await env.db
      .prepare("SELECT COUNT(*) AS cnt FROM requests WHERE brand_id = 'brand-casa' AND priority = 'urgent'")
      .first<{ cnt: number }>();
    const ledgerCount = await env.db
      .prepare("SELECT COUNT(*) AS cnt FROM priority_quota_ledger WHERE brand_id = 'brand-casa' AND priority = 'urgent'")
      .first<{ cnt: number }>();
    const polRow = await env.db
      .prepare("SELECT used_count, annual_limit FROM priority_quota_policies WHERE brand_id = 'brand-casa' AND year = ? AND priority = 'urgent'")
      .bind(year)
      .first<{ used_count: number; annual_limit: number }>();

    expect(reqCount?.cnt).toBe(1);
    expect(ledgerCount?.cnt).toBe(1);
    expect(polRow?.used_count).toBe(1);
    expect(polRow?.annual_limit).toBe(1);
  });

  it('CONC-02: Idempotency key deduplicates retried request submissions without double quota deduction', async () => {
    const reqCasa = await env.loginAs('requester.casa@lyman.co.id');
    const idemKey = 'idem-casa-retry-001';

    const payload = {
      title: 'Idempotent Request',
      regionId: 'reg-jkt',
      brandId: 'brand-casa',
      categoryId: 'cat-graphic',
      description: 'Double click test',
      deliverablesExpected: 'KV',
      requestedDeadline: '2026-12-20',
      priority: 'urgent',
      quotaYear: 2026,
      idempotencyKey: idemKey,
    };

    const res1 = await env.requestWorker('/api/requests', {
      method: 'POST',
      session: reqCasa,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    expect(res1.status).toBe(201);
    const json1 = (await res1.json()) as { request: { id: string; ticketNumber: string } };

    const res2 = await env.requestWorker('/api/requests', {
      method: 'POST',
      session: reqCasa,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    expect(res2.status).toBe(200);
    const json2 = (await res2.json()) as { deduplicated?: boolean; request: { id: string; ticketNumber: string } };
    expect(json2.deduplicated).toBe(true);
    expect(json2.request.id).toBe(json1.request.id);

    const ledgerCount = await env.db
      .prepare("SELECT COUNT(*) AS cnt FROM priority_quota_ledger WHERE request_id = ?")
      .bind(json1.request.id)
      .first<{ cnt: number }>();
    expect(ledgerCount?.cnt).toBe(1);
  });

  it('CONC-03: Level 2 Sub Items consume zero quota & priority reallocation moves quota atomically', async () => {
    const superSession = await env.loginAs('sosmeda217@gmail.com');
    const reqCasa = await env.loginAs('requester.casa@lyman.co.id');

    // Create a Medium request (consumes 1 medium, 0 urgent)
    const createRes = await env.requestWorker('/api/requests', {
      method: 'POST',
      session: reqCasa,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title: 'Parent Campaign',
        regionId: 'reg-jkt',
        brandId: 'brand-casa',
        categoryId: 'cat-graphic',
        description: 'Multi deliverable parent ticket',
        deliverablesExpected: '3 sub deliverables',
        requestedDeadline: '2026-12-20',
        priority: 'medium',
        quotaYear: 2026,
      }),
    });
    expect(createRes.status).toBe(201);
    const parentId = ((await createRes.json()) as { request: { id: string } }).request.id;

    // Create 3 Sub Items -> must consume 0 priority quota
    for (let i = 1; i <= 3; i++) {
      const subRes = await env.requestWorker(`/api/requests/${parentId}/sub-items`, {
        method: 'POST',
        session: superSession,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: `Sub Deliverable ${i}`,
          ownerId: 'user-member-design',
          priority: 'urgent',
        }),
      });
      expect(subRes.status).toBe(201);
    }

    const summaryAfterSubs = await env.requestWorker('/api/quotas/brand-casa?year=2026', {
      session: superSession,
    });
    const sumJson = (await summaryAfterSubs.json()) as {
      summary: { priorities: { medium: { used: number }; urgent: { used: number } } };
    };
    expect(sumJson.summary.priorities.medium.used).toBe(1);
    expect(sumJson.summary.priorities.urgent.used).toBe(0);

    // Reallocate parent priority from medium -> urgent (releases 1 medium, deducts 1 urgent)
    const reallocRes = await env.requestWorker(`/api/requests/${parentId}/priority`, {
      method: 'POST',
      session: superSession,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ newPriority: 'urgent', reason: 'Escalated by client' }),
    });
    expect(reallocRes.status).toBe(200);

    const summaryAfterRealloc = await env.requestWorker('/api/quotas/brand-casa?year=2026', {
      session: superSession,
    });
    const sumJson2 = (await summaryAfterRealloc.json()) as {
      summary: { priorities: { medium: { used: number }; urgent: { used: number } } };
    };
    expect(sumJson2.summary.priorities.medium.used).toBe(0);
    expect(sumJson2.summary.priorities.urgent.used).toBe(1);
  });

  it('CONC-04: Dynamic unlimited years (2024..2035) maintain isolated annual quotas and WIB reporting boundaries', async () => {
    const superSession = await env.loginAs('sosmeda217@gmail.com');

    // Configure policies for custom future year 2032
    const pol2032 = await env.requestWorker('/api/quotas/policies', {
      method: 'PUT',
      session: superSession,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        brandId: 'brand-casa',
        year: 2032,
        limits: { urgent: 2, high: 5 },
      }),
    });
    expect(pol2032.status).toBe(200);

    // Submit urgent request in 2032
    const req2032 = await env.requestWorker('/api/requests', {
      method: 'POST',
      session: superSession,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title: 'Future Roadmap 2032',
        regionId: 'reg-jkt',
        brandId: 'brand-casa',
        categoryId: 'cat-graphic',
        description: 'Year 2032 quota isolation test',
        deliverablesExpected: 'Concept',
        requestedDeadline: '2032-03-01',
        priority: 'urgent',
        quotaYear: 2032,
      }),
    });
    expect(req2032.status).toBe(201);

    // /api/quotas/years discovers 2032 dynamically
    const yearsRes = await env.requestWorker('/api/quotas/years', { session: superSession });
    const yearsJson = (await yearsRes.json()) as { years: number[] };
    expect(yearsJson.years).toContain(2032);

    // 2026 quota remains untouched while 2032 shows used=1, remaining=1
    const q2026 = (await (
      await env.requestWorker('/api/quotas/brand-casa?year=2026', { session: superSession })
    ).json()) as { summary: { priorities: { urgent: { used: number; remaining: number } } } };
    const q2032 = (await (
      await env.requestWorker('/api/quotas/brand-casa?year=2032', { session: superSession })
    ).json()) as { summary: { priorities: { urgent: { used: number; remaining: number } } } };

    expect(q2026.summary.priorities.urgent.used).toBe(0);
    expect(q2032.summary.priorities.urgent.used).toBe(1);
    expect(q2032.summary.priorities.urgent.remaining).toBe(1);

    // WIB custom range reporting endpoint responds cleanly with affectedYears
    const repRes = await env.requestWorker(
      '/api/quotas/reporting?brandId=brand-casa&mode=custom_range&startDate=2026-01-01&endDate=2027-12-31',
      { session: superSession }
    );
    expect(repRes.status).toBe(200);
    const repJson = (await repRes.json()) as { metrics: { affectedYears: number[]; startIsoWib: string } };
    expect(repJson.metrics.affectedYears).toEqual([2026, 2027]);
    expect(repJson.metrics.startIsoWib).toContain('+07:00');
  });
});
