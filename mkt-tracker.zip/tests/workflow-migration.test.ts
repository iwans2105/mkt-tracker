import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import { createTestWorkerEnv } from './helpers/testEnv';

describe('Workflow Lifecycle, Master Data, Verified Backups & Idempotent Migration Reconciliation (TC-01..TC-22)', () => {
  let env: Awaited<ReturnType<typeof createTestWorkerEnv>>;

  beforeEach(async () => {
    env = await createTestWorkerEnv();
  });

  afterEach(() => {
    env.cleanup();
  });

  it('Full Ticket Lifecycle: create -> assign -> in_progress -> deliverables -> pending_review -> revision -> completed -> reopen', async () => {
    const admin = await env.loginAs('admin.jkt@lyman.co.id');
    const reqCasa = await env.loginAs('requester.casa@lyman.co.id');
    const designer = await env.loginAs('designer@lyman.co.id');

    // 1. Requester creates request
    const createRes = await env.requestWorker('/api/requests', {
      method: 'POST',
      session: reqCasa,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title: 'Launch Brochure Casa',
        regionId: 'reg-jkt',
        brandId: 'brand-casa',
        categoryId: 'cat-graphic',
        description: 'Full A4 brochure',
        deliverablesExpected: 'PDF Print',
        requestedDeadline: '2026-12-10',
        priority: 'high',
        quotaYear: 2026,
      }),
    });
    expect(createRes.status).toBe(201);
    const reqId = ((await createRes.json()) as { request: { id: string } }).request.id;

    // 2. Admin assigns designer + reviewer + committed deadline
    const assignRes = await env.requestWorker(`/api/requests/${reqId}/assign`, {
      method: 'POST',
      session: admin,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        assignedTeamId: 'team-design',
        primaryAssigneeId: 'user-member-design',
        reviewerId: 'user-admin-jkt',
        committedDeadline: '2026-12-08',
        deadlineReason: 'Agreed production schedule',
      }),
    });
    expect(assignRes.status).toBe(200);

    // 3. Designer starts work -> in_progress
    const startRes = await env.requestWorker(`/api/requests/${reqId}/status`, {
      method: 'POST',
      session: designer,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ newStatus: 'in_progress' }),
    });
    expect(startRes.status).toBe(200);

    // 4. Designer cannot submit review without deliverables
    const noDelivRes = await env.requestWorker(`/api/requests/${reqId}/status`, {
      method: 'POST',
      session: designer,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ newStatus: 'pending_review' }),
    });
    expect(noDelivRes.status).toBe(403);

    // 5. Add deliverable link & submit for review
    const delivRes = await env.requestWorker(`/api/requests/${reqId}/deliverables`, {
      method: 'POST',
      session: designer,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        link: {
          id: 'lnk-1',
          title: 'Figma Final Layout',
          url: 'https://figma.com/file/casa-brochure',
          addedAt: new Date().toISOString(),
          addedBy: 'Desainer Grafis',
        },
      }),
    });
    expect(delivRes.status).toBe(200);

    const reviewRes = await env.requestWorker(`/api/requests/${reqId}/status`, {
      method: 'POST',
      session: designer,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ newStatus: 'pending_review' }),
    });
    expect(reviewRes.status).toBe(200);

    // 6. Reviewer requests revision -> resubmit -> approve completed -> admin reopen
    const revRes = await env.requestWorker(`/api/requests/${reqId}/status`, {
      method: 'POST',
      session: admin,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        newStatus: 'revision',
        revisionNote: 'Mohon perbesar logo pada halaman sampul.',
      }),
    });
    expect(revRes.status).toBe(200);

    const resubmitRes = await env.requestWorker(`/api/requests/${reqId}/status`, {
      method: 'POST',
      session: designer,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ newStatus: 'pending_review' }),
    });
    expect(resubmitRes.status).toBe(200);

    const completeRes = await env.requestWorker(`/api/requests/${reqId}/status`, {
      method: 'POST',
      session: admin,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ newStatus: 'completed' }),
    });
    expect(completeRes.status).toBe(200);
    const completedReq = ((await completeRes.json()) as { request: { status: string; completedAt: string } }).request;
    expect(completedReq.status).toBe('completed');
    expect(completedReq.completedAt).toBeTruthy();

    const reopenRes = await env.requestWorker(`/api/requests/${reqId}/reopen`, {
      method: 'POST',
      session: admin,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ reason: 'Klien meminta versi ukuran tambahan.' }),
    });
    expect(reopenRes.status).toBe(200);
    const reopenedReq = ((await reopenRes.json()) as { request: { status: string; reopenCount: number } }).request;
    expect(reopenedReq.status).toBe('in_progress');
    expect(reopenedReq.reopenCount).toBe(1);
  });

  it('Master Data strips "Wilayah " prefix cleanly & Level 2 Sub Item approval + reconciliation preserves audit trail', async () => {
    const superSession = await env.loginAs('sosmeda217@gmail.com');
    const designer = await env.loginAs('designer@lyman.co.id');

    // Create region with legacy prefix -> must strip "Wilayah "
    const regRes = await env.requestWorker('/api/master-data/regions', {
      method: 'POST',
      session: superSession,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: 'Wilayah Surabaya', code: 'SBY' }),
    });
    expect(regRes.status).toBe(201);
    const regJson = (await regRes.json()) as { item: { name: string } };
    expect(regJson.item.name).toBe('Surabaya');

    // Sub Item lifecycle: create -> progress pending_review -> team_member cannot approve -> admin approves -> reconcile historical approval
    const reqRes = await env.requestWorker('/api/requests', {
      method: 'POST',
      session: superSession,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title: 'Event Collateral',
        regionId: 'reg-jkt',
        brandId: 'brand-casa',
        categoryId: 'cat-graphic',
        description: 'Backdrop',
        deliverablesExpected: 'Print files',
        requestedDeadline: '2026-12-20',
        priority: 'low',
      }),
    });
    const parentId = ((await reqRes.json()) as { request: { id: string } }).request.id;

    const subRes = await env.requestWorker(`/api/requests/${parentId}/sub-items`, {
      method: 'POST',
      session: superSession,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title: 'Backdrop Stage',
        ownerId: 'user-member-design',
        priority: 'high',
      }),
    });
    const subId = ((await subRes.json()) as { subItem: { id: string } }).subItem.id;

    // Designer moves to pending_review
    const progRes = await env.requestWorker(`/api/requests/${parentId}/sub-items/${subId}/progress`, {
      method: 'POST',
      session: designer,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        status: 'pending_review',
        deliverableUrl: 'https://drive.google.com/file/backdrop',
      }),
    });
    expect(progRes.status).toBe(200);

    // Designer CANNOT self-approve Sub Item -> 403
    const selfApprove = await env.requestWorker(`/api/requests/${parentId}/sub-items/${subId}/approve`, {
      method: 'POST',
      session: designer,
    });
    expect(selfApprove.status).toBe(403);

    // Super Admin approves -> timestamps recorded
    const approveRes = await env.requestWorker(`/api/requests/${parentId}/sub-items/${subId}/approve`, {
      method: 'POST',
      session: superSession,
    });
    expect(approveRes.status).toBe(200);

    // Reconcile historical date
    const recRes = await env.requestWorker(`/api/requests/${parentId}/sub-items/${subId}/reconcile-approval`, {
      method: 'POST',
      session: superSession,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        verifiedApprovalDate: '2026-11-10T10:00:00.000Z',
        justification: 'Verified signed approval email archive',
      }),
    });
    expect(recRes.status).toBe(200);
  });

  it('Verified D1 -> R2 Backup with SHA-256 verification & Idempotent Multi-Device Migration + Non-Overwriting Conflict Detection', async () => {
    const superSession = await env.loginAs('sosmeda217@gmail.com');

    // 1. Create backup & download with checksum verification
    const bkpRes = await env.requestWorker('/api/system/backup', {
      method: 'POST',
      session: superSession,
    });
    expect(bkpRes.status).toBe(200);
    const bkpJson = (await bkpRes.json()) as { backup: { id: string; checksumSha256: string } };

    const dlRes = await env.requestWorker(`/api/system/backups/${bkpJson.backup.id}/download`, {
      session: superSession,
    });
    expect(dlRes.status).toBe(200);
    expect(dlRes.headers.get('X-File-SHA256')).toBe(bkpJson.backup.checksumSha256);

    // 2. Idempotent Migration Import with base64 attachment -> R2 upgrade & non-overwriting conflict logging
    const samplePngB64 = Buffer.from('fake-png-binary-content').toString('base64');
    const migrationPayload = {
      deviceLabel: 'device-a-macbook',
      data: {
        requests: [
          {
            id: 'req-mig-001',
            ticketNumber: 'REQ-2025-0099',
            title: 'Migrated Legacy Ticket',
            regionId: 'reg-jkt',
            regionName: 'Wilayah Jakarta',
            brandId: 'brand-casa',
            brandName: 'Casa Domaine',
            requesterDepartment: 'Marketing',
            categoryId: 'cat-graphic',
            categoryName: 'Graphic Design',
            description: 'Legacy brief with base64 attachment',
            deliverablesExpected: 'PNG Banner',
            priority: 'high',
            status: 'in_progress',
            requesterId: 'user-req-casa',
            requesterName: 'Requester Casa',
            requesterEmail: 'requester.casa@lyman.co.id',
            requestedDeadline: '2025-06-15',
            briefAttachments: [
              {
                id: 'att-mig-001',
                name: 'legacy-ref.png',
                size: 24,
                type: 'image/png',
                url: `data:image/png;base64,${samplePngB64}`,
                uploadedAt: '2025-06-01T08:00:00Z',
                uploadedBy: 'Requester Casa',
              },
            ],
            createdAt: '2025-06-01T08:00:00Z',
            updatedAt: '2025-06-02T09:00:00Z',
          },
        ],
      },
    };

    // First import: inserts ticket & migrates attachment to R2
    const imp1 = await env.requestWorker('/api/migration/import', {
      method: 'POST',
      session: superSession,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(migrationPayload),
    });
    expect(imp1.status).toBe(200);
    const imp1Json = (await imp1.json()) as {
      status: string;
      stats: { inserted: number; attachmentsUploadedToR2: number };
    };
    expect(imp1Json.stats.inserted).toBe(1);
    expect(imp1Json.stats.attachmentsUploadedToR2).toBe(1);

    // Re-importing identical payload from same/another device -> skippedIdentical = 1, 0 duplicates
    const imp2 = await env.requestWorker('/api/migration/import', {
      method: 'POST',
      session: superSession,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(migrationPayload),
    });
    const imp2Json = (await imp2.json()) as { stats: { inserted: number; skippedIdentical: number; conflictsLogged: number } };
    expect(imp2Json.stats.inserted).toBe(0);
    expect(imp2Json.stats.skippedIdentical).toBe(1);
    expect(imp2Json.stats.conflictsLogged).toBe(0);

    // Divergent snapshot from Device B -> MUST NOT overwrite, logs conflict instead
    const divergentPayload = {
      deviceLabel: 'device-b-windows',
      data: {
        requests: [
          {
            ...migrationPayload.data.requests[0],
            status: 'completed',
            updatedAt: '2025-06-05T14:00:00Z',
          },
        ],
      },
    };
    const imp3 = await env.requestWorker('/api/migration/import', {
      method: 'POST',
      session: superSession,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(divergentPayload),
    });
    const imp3Json = (await imp3.json()) as { status: string; stats: { conflictsLogged: number } };
    expect(imp3Json.status).toBe('completed_with_conflicts');
    expect(imp3Json.stats.conflictsLogged).toBe(1);

    // Verify existing D1 record remained 'in_progress' (never silently overwritten)
    const d1Row = await env.db
      .prepare('SELECT status, region_name, brief_attachments_json FROM requests WHERE id = ?')
      .bind('req-mig-001')
      .first<{ status: string; region_name: string; brief_attachments_json: string }>();
    expect(d1Row?.status).toBe('in_progress');
    expect(d1Row?.region_name).toBe('Jakarta'); // "Wilayah " stripped
    expect(d1Row?.brief_attachments_json).toContain('/api/files/att-mig-001');

    // Super Admin explicitly resolves conflict with keep_existing
    const reportRes = await env.requestWorker('/api/migration/reconciliation-report', { session: superSession });
    const reportJson = (await reportRes.json()) as { conflicts: { id: string; resolutionStatus: string }[] };
    expect(reportJson.conflicts.length).toBe(1);
    expect(reportJson.conflicts[0].resolutionStatus).toBe('pending');

    const resolveRes = await env.requestWorker(
      `/api/migration/conflicts/${reportJson.conflicts[0].id}/resolve`,
      {
        method: 'POST',
        session: superSession,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ decision: 'keep_existing' }),
      }
    );
    expect(resolveRes.status).toBe(200);
  });
});
