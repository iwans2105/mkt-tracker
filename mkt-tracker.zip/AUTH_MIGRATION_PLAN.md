# Authentication & Session Security — Cloudflare Workers + D1

## 1. Password Hashing & Workers Runtime Compatibility

- **Primary Algorithm**: WebCrypto `PBKDF2-HMAC-SHA256` with **100,000 iterations** (maximum supported by Cloudflare Workers BoringSSL), 16-byte cryptographic random salt, and optional server-side `PASSWORD_PEPPER` Worker Secret applied via HMAC-SHA256 pre-hash (`pbkdf2_sha256$100000$<peppered>$<saltHex>$<hashHex>`).
- **Legacy Compatibility**: Verifies legacy Node `scrypt` (`saltHex:derivedHex`, `N=16384, r=8, p=1`) hashes imported from `data/server_users.json` (`nodejs_compat` enabled in `wrangler.jsonc`) and **transparently re-hashes to PBKDF2-SHA256 + Pepper on first successful login**.
- **Password Policy**: Minimum 12 characters (`validatePasswordStrength`) rejecting common breached passwords (`COMMONLY_COMPROMISED_PASSWORDS`).

## 2. Session, Cookie & CSRF Hardening

- **Sessions in D1 (`sessions` table)**: Opaque 256-bit `session_id` stored in `HttpOnly`, `SameSite=Lax`, `Secure` (HTTPS origins) cookie `marcomm_sid`.
- **CSRF Protection**: Per-session HMAC-SHA256 token derived from `csrf_secret + SESSION_SECRET` and required via `X-CSRF-Token` header on all state-changing routes (`POST`, `PUT`, `PATCH`, `DELETE`). Token lives only in memory (`src/services/csrfStore.ts`), never `localStorage`.
- **Session Rotation & Immediate Revocation**:
  - Password changes rotate the active `session_id` + `csrf_secret` and revoke all sibling sessions.
  - User deactivation, deletion, or role modification immediately purges `sessions WHERE user_id = ?`.
- **D1-Backed Rate Limiting (`login_rate_limits`)**: Blocks IP and normalized email keys (`429 Too Many Requests`) after 5 consecutive failed logins within a 15-minute sliding window.

## 3. Password Recovery & One-Time Super Admin Bootstrap

- **`/api/auth/forgot-password` & `/api/auth/reset-password`**: Anti-enumeration responses; 15-minute SHA-256 hashed recovery tokens; purges all user sessions on completion. (Note: Outbound SMTP email delivery reports `BLOCKED` until real SMTP Worker Secrets are configured.)
- **`/api/auth/bootstrap-recovery`**: One-time Super Admin recovery guarded by `BOOTSTRAP_ADMIN_TOKEN` Worker Secret (timing-safe SHA-256 compare) and permanently locked in `system_bootstrap_state` (`super_admin_recovered_at`) once consumed.
- **No Plaintext Password or Session Migration**: Legacy `server_sessions.json` and unhashed passwords are never imported; unhashed migrated users have `must_change_password = 1`.
