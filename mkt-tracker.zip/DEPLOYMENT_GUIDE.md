# Deployment Guide — Staging & Controlled Production Cutover

## 1. Automated Verification Before Any Deploy

```bash
# Typecheck + Supabase zero-dependency check + Production Vite build
npm run check

# Security, RBAC, Concurrency, Idempotency & Migration test suites
npm run test

# Local Worker bundle dry-run check
npx wrangler deploy --dry-run
```

## 2. Staging Deployment & Data Migration

```bash
# 1. Apply D1 schema & triggers to Staging
npm run db:migrate:staging

# 2. Deploy Worker + Static Assets to Staging
npm run deploy:staging

# 3. Export legacy /data/*.json + optional device browser snapshots (strict read-only)
npx tsx scripts/export-legacy-data.ts --browser /path/to/browser-snapshot-1.json

# 4. Idempotent import to Staging D1 + R2
npx tsx scripts/import-to-d1-r2.ts \
  --url https://marcomm-staging.example.workers.dev \
  --email sosmeda217@gmail.com \
  --password "<SUPER_ADMIN_PASSWORD>" \
  --device "staging-initial-import"

# 5. Live HTTP verification
npx tsx scripts/verify-deployment.ts --url https://marcomm-staging.example.workers.dev
```

## 3. Production Cutover (Guarded — Explicit Approval Required)

1. Complete all items in `PRODUCTION_READINESS_CHECKLIST.md` and receive written stakeholder approval.
2. Bootstrap Super Admin credentials safely if needed via `/api/auth/bootstrap-recovery` (guarded by `BOOTSTRAP_ADMIN_TOKEN` secret).
3. Run guarded production migration & deployment:
   ```bash
   ALLOW_PRODUCTION_DEPLOY=YES npm run db:migrate:production -- --confirm-production
   ALLOW_PRODUCTION_DEPLOY=YES npm run deploy:production -- --confirm-production
   ```
4. Verify live endpoints: `npx tsx scripts/verify-deployment.ts --url https://<production-origin>`.
