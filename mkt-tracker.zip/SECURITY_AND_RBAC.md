# Security Controls & RBAC Matrix

## 1. Role Hierarchy & Authorization Enforcement

All authorization checks run server-side inside Hono Worker middleware & handlers (`src/worker/middleware/auth.ts`, `src/worker/routes/*`):

| Capability | `super_admin` | `admin` (Marcomm Admin) | `team_member` | `requester` |
| --- | --- | --- | --- | --- |
| View Requests | All | Brand/Region scoped | Assigned / Sub-owner / Team | Own created tickets only |
| Create Request | Any brand | Scoped brands | Scoped brands | Scoped brands |
| Assign PIC / Reviewer / Committed Deadline | Any | Scoped brands | Denied (`403`) | Denied (`403`) |
| Approve / Request Revision on Parent Ticket | Any | Scoped `pending_review` | Assigned Reviewer only | Denied (`403`) |
| Level 2 Sub Item Create / Edit / Delete | Any | Scoped brands | Denied (`403`) | Denied (`403`) |
| Level 2 Sub Item Progress Update | Any | Scoped brands | Assigned `ownerId` only (cannot self-approve) | Denied (`403`) |
| Level 2 Sub Item Approval (`completed`) | Yes | Scoped Admin | Assigned `reviewerId` only | Denied (`403`) |
| Priority Quota Policies & Adjustments | All brands | Scoped brands | Denied (`403`) | Denied (`403`) |
| Historical Quota Reconciliation Apply | Yes | Denied (`403`) | Denied (`403`) | Denied (`403`) |
| D1 Backups & Services Diagnostics | Yes | Yes | Denied (`403`) | Denied (`403`) |
| Operational Purge (`RESET`) & Legacy Migration | Yes | Denied (`403`) | Denied (`403`) | Denied (`403`) |
| Private R2 File Download (`/api/files/:id`) | Yes | Scoped | Allowed only if `canUserViewRequest` | Own/brand scoped only |

## 2. Defense-in-Depth Safeguards

- **HttpOnly Cookies + CSRF**: `marcomm_sid` cannot be read by JS; all mutations require `X-CSRF-Token`.
- **D1 Rate Limiting**: `/api/auth/login` locks after 5 consecutive failures per IP/email for 15 minutes (`429`).
- **Audit Logging**: Logins, failures, password changes/resets, RBAC denials, quota rejections/adjustments, user lifecycle mutations, backups, and migration reconciliations write to `security_audit_logs`.
- **Security Response Headers**: `X-Content-Type-Options: nosniff`, `Referrer-Policy: strict-origin-when-cross-origin`, `Permissions-Policy`.
