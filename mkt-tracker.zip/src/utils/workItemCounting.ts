import { RequestItem, RequestStatus, WorkItemCountingSummary } from '../types';

export type { WorkItemCountingSummary };

/**
 * Dynamic Work Item Counting System:
 * - A Request without active Sub Items counts as ONE work item using the parent Request status.
 * - A Request with one or more active Sub Items counts according to its active Sub Items only.
 * - Soft-deleted Sub Items (s.deletedAt) are strictly excluded from calculation.
 * - Parent Request is NEVER double-counted when active Sub Items exist.
 *
 * Formula:
 * Effective Work Item Count per Request =
 * - 1, when the Request has zero active Sub Items.
 * - Number of active Sub Items, when the Request has one or more active Sub Items.
 */
export function computeDynamicWorkItems(requests: RequestItem[]): WorkItemCountingSummary {
  const totalRequests = requests.length;
  let totalSubItems = 0;
  let totalWorkItems = 0;
  let completedParentRequests = 0;
  let contributingParentRequests = 0;

  const counts: Record<RequestStatus, number> = {
    todo: 0,
    in_progress: 0,
    pending_review: 0,
    revision: 0,
    completed: 0,
    on_hold: 0,
    cancelled: 0,
  };

  for (const req of requests) {
    if (req.status === 'completed') {
      completedParentRequests += 1;
    }

    const activeSubItems = (req.subItems || []).filter((s) => !s.deletedAt);
    totalSubItems += activeSubItems.length;

    if (activeSubItems.length === 0) {
      // Scenario A: Zero active Sub Items -> Parent counts as 1 work item with parent's status
      totalWorkItems += 1;
      counts[req.status] = (counts[req.status] || 0) + 1;
      if (req.status === 'completed') {
        contributingParentRequests += 1;
      }
    } else {
      // Scenario B/C/D: One or more active Sub Items -> Count by active Sub Items only
      // Do not count the parent Request again when Sub Items exist
      totalWorkItems += activeSubItems.length;
      let completedInThisReq = 0;
      for (const sub of activeSubItems) {
        counts[sub.status] = (counts[sub.status] || 0) + 1;
        if (sub.status === 'completed') {
          completedInThisReq += 1;
        }
      }
      if (completedInThisReq > 0) {
        contributingParentRequests += 1;
      }
    }
  }

  return {
    totalRequests,
    totalWorkItems,
    totalSubItems,
    todoWorkItems: counts.todo,
    inProgressWorkItems: counts.in_progress,
    pendingReviewWorkItems: counts.pending_review,
    completedWorkItems: counts.completed,
    onHoldWorkItems: counts.on_hold,
    cancelledWorkItems: counts.cancelled,
    // V12 Distinct Completed Metrics
    completedParentRequests,
    contributingParentRequests,
    // Status aliases
    todo: counts.todo,
    in_progress: counts.in_progress,
    pending_review: counts.pending_review,
    completed: counts.completed,
    on_hold: counts.on_hold,
    cancelled: counts.cancelled,
  };
}
