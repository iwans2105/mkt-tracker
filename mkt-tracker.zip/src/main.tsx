import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';

// Guard against Vite HMR WebSocket disconnects in proxy/iframe environment
if (typeof window !== 'undefined') {
  window.addEventListener('unhandledrejection', (event) => {
    const msg = event?.reason?.message || event?.reason?.stack || String(event?.reason || '');
    if (msg.includes('WebSocket') || msg.includes('@vite/client') || msg.includes('vite:ws')) {
      event.preventDefault();
      event.stopImmediatePropagation();
    }
  });
}

createRoot(document.getElementById('root')!).render(<App />);

