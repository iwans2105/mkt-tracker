import React, { createContext, useContext, useState, useEffect, useCallback, useRef } from 'react';
import { User, UserRole, RequestItem, RequestStatus, SubItem } from '../types';
import { setClientCsrfToken } from '../services/csrfStore';
import { useLanguage } from './LanguageContext';
import { STATUS_LABELS, STATUS_LABELS_ID } from '../components/common/StatusBadge';

const GUEST_USER: User = {
  id: '',
  email: '',
  fullName: '',
  jobTitle: '',
  department: '',
  role: 'requester',
  isReviewer: false,
  teams: [],
  competencies: [],
  assignedRegions: [],
  assignedBrands: [],
  isActive: false,
  createdAt: '',
};

interface AuthContextType {
  currentUser: User;
  allUsers: User[];
  isAuthenticated: boolean;
  isLoadingAuth: boolean;
  isLoggingOut: boolean;
  csrfToken: string | null;
  login: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => Promise<void>;
  registerBeforeLogoutFlush: (handler: () => Promise<void>) => () => void;
  refreshUsers: () => Promise<void>;
  forgotPassword: (email: string) => Promise<{ success: boolean; message: string; error?: string }>;
  resetPassword: (
    email: string,
    token: string,
    newPassword: string
  ) => Promise<{ success: boolean; message: string; error?: string }>;
  changePassword: (
    currentPassword: string,
    newPassword: string,
    confirmNewPassword: string
  ) => Promise<{ success: boolean; message?: string; error?: string }>;
  adminResetPassword: (
    targetUserId: string,
    newPassword: string,
    confirmNewPassword: string,
    mustChangePassword: boolean,
    adminPassword: string
  ) => Promise<{ success: boolean; message?: string; error?: string }>;
  setCurrentUserById: (userId: string) => void;

  updateUserAccount: (
    updated: User & { initialPassword?: string }
  ) => Promise<{ success: boolean; user?: User; error?: string }>;
  deleteUserAccount: (userId: string) => Promise<{ success: boolean; message: string }>;
  isSuperAdmin: boolean;
  isAdmin: boolean;
  isTeamMember: boolean;
  isRequester: boolean;
  canReview: boolean;

  // Granular RBAC helpers
  canViewRequest: (req: RequestItem) => boolean;
  canEditRequestBrief: (req: RequestItem) => boolean;
  canAssignRequest: (req: RequestItem) => boolean;
  canTransitionStatus: (
    req: RequestItem,
    targetStatus: RequestStatus
  ) => { allowed: boolean; reason?: string };
  canSubmitDeliverables: (req: RequestItem) => boolean;
  canApproveOrRevise: (req: RequestItem) => boolean;
  canReopenRequest: (req: RequestItem) => boolean;

  // Actions RBAC helpers (Strict Super Admin, Marcomm Admin within scope, and officially assigned PIC/Execution Team)
  isAssignedToRequest: (req: RequestItem) => boolean;
  isAuthorizedForRequestActions: (req: RequestItem) => boolean;
  canPerformRequestAction: (
    req: RequestItem,
    action: 'submit_review' | 'put_on_hold' | 'cancel_request' | 'resume'
  ) => { allowed: boolean; reason?: string };

  // Sub Item RBAC helpers (Strict Super Admin & Marcomm Admin authorization)
  canManageSubItems: (req?: RequestItem) => boolean;
  canCreateSubItem: (req: RequestItem) => boolean;
  canEditSubItem: (subItem: SubItem, req: RequestItem) => boolean;
  canDeleteSubItem: (subItem: SubItem, req: RequestItem) => boolean;
  canUpdateSubItemProgress: (subItem: SubItem, req: RequestItem) => boolean;
  canApproveSubItem: (subItem: SubItem, req: RequestItem) => boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { isIndonesian } = useLanguage();
  const [allUsers, setAllUsers] = useState<User[]>([]);
  const [currentUser, setCurrentUser] = useState<User>(GUEST_USER);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [isLoadingAuth, setIsLoadingAuth] = useState<boolean>(true);
  const [isLoggingOut, setIsLoggingOut] = useState<boolean>(false);
  const [csrfToken, setCsrfToken] = useState<string | null>(null);
  const beforeLogoutHandlersRef = useRef<Set<() => Promise<void>>>(new Set());

  const registerBeforeLogoutFlush = useCallback((handler: () => Promise<void>) => {
    beforeLogoutHandlersRef.current.add(handler);
    return () => {
      beforeLogoutHandlersRef.current.delete(handler);
    };
  }, []);

  useEffect(() => {
    setClientCsrfToken(csrfToken);
  }, [csrfToken]);

  const refreshUsers = useCallback(async (): Promise<void> => {
    try {
      const res = await fetch('/api/users', { credentials: 'include', cache: 'no-store' });
      if (res.ok) {
        const data = await res.json();
        if (data.success && Array.isArray(data.data)) {
          setAllUsers(data.data);
        }
      } else if (res.status === 401) {
        setIsAuthenticated(false);
        setCurrentUser(GUEST_USER);
        setAllUsers([]);
        setCsrfToken(null);
      }
    } catch {
      // Keep current list on transient network error
    }
  }, []);

  useEffect(() => {
    fetch('/api/auth/me', { credentials: 'include', cache: 'no-store' })
      .then((res) => res.json())
      .then(async (data) => {
        if (data.authenticated && data.user) {
          setCurrentUser(data.user);
          const token = data.csrfToken || null;
          setCsrfToken(token);
          setClientCsrfToken(token);
          setIsAuthenticated(true);
          await refreshUsers();
        } else {
          setIsAuthenticated(false);
          setCurrentUser(GUEST_USER);
          setAllUsers([]);
        }
      })
      .catch(() => {
        setIsAuthenticated(false);
        setCurrentUser(GUEST_USER);
      })
      .finally(() => {
        setIsLoadingAuth(false);
      });
  }, [refreshUsers]);

  const login = async (email: string, password: string): Promise<{ success: boolean; error?: string }> => {
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        cache: 'no-store',
        body: JSON.stringify({ email, password }),
      });
      const data = await res.json();
      if (data.success && data.user) {
        setCurrentUser(data.user);
        const token = data.csrfToken || null;
        setCsrfToken(token);
        setClientCsrfToken(token);
        setIsAuthenticated(true);
        await refreshUsers();
        return { success: true };
      }
      return {
        success: false,
        error: data.error || (isIndonesian ? 'Login gagal.' : 'Login failed.'),
      };
    } catch {
      return {
        success: false,
        error: isIndonesian
          ? 'Koneksi bermasalah. Silakan coba kembali.'
          : 'Connection error. Please try again.',
      };
    }
  };

  const logout = async (): Promise<void> => {
    if (isLoggingOut) return;
    setIsLoggingOut(true);
    try {
      const flushHandlers = Array.from(beforeLogoutHandlersRef.current);
      if (flushHandlers.length > 0) {
        await Promise.race([
          Promise.allSettled(flushHandlers.map((fn) => fn())),
          new Promise<void>((resolve) => setTimeout(resolve, 5000)),
        ]);
      }

      await fetch('/api/auth/logout', {
        method: 'POST',
        credentials: 'include',
        cache: 'no-store',
        headers: {
          'Content-Type': 'application/json',
          ...(csrfToken ? { 'X-CSRF-Token': csrfToken } : {}),
        },
        body: JSON.stringify({ flushedClientChanges: true }),
      });
    } catch (e) {
      console.warn('Logout network notice:', e);
    } finally {
      setIsAuthenticated(false);
      setCurrentUser(GUEST_USER);
      setAllUsers([]);
      setCsrfToken(null);
      setClientCsrfToken(null);
      setIsLoggingOut(false);
    }
  };

  const forgotPassword = async (
    email: string
  ): Promise<{ success: boolean; message: string; error?: string }> => {
    try {
      const res = await fetch('/api/auth/forgot-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        cache: 'no-store',
        body: JSON.stringify({ email }),
      });
      const data = await res.json();
      if (data.success) {
        return { success: true, message: data.message };
      }
      return {
        success: false,
        message: '',
        error: data.error || (isIndonesian ? 'Gagal memproses permintaan.' : 'Failed to process request.'),
      };
    } catch {
      return {
        success: false,
        message: '',
        error: isIndonesian
          ? 'Koneksi bermasalah. Silakan coba kembali.'
          : 'Connection error. Please try again.',
      };
    }
  };

  const resetPassword = async (
    email: string,
    token: string,
    newPassword: string
  ): Promise<{ success: boolean; message: string; error?: string }> => {
    try {
      const res = await fetch('/api/auth/reset-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        cache: 'no-store',
        body: JSON.stringify({ email, token, newPassword }),
      });
      const data = await res.json();
      if (data.success) {
        return { success: true, message: data.message };
      }
      return {
        success: false,
        message: '',
        error: data.error || (isIndonesian ? 'Gagal mereset password.' : 'Failed to reset password.'),
      };
    } catch {
      return {
        success: false,
        message: '',
        error: isIndonesian
          ? 'Koneksi bermasalah. Silakan coba kembali.'
          : 'Connection error. Please try again.',
      };
    }
  };

  const changePassword = async (
    currentPassword: string,
    newPassword: string,
    confirmNewPassword: string
  ): Promise<{ success: boolean; message?: string; error?: string }> => {
    try {
      const res = await fetch('/api/auth/change-password', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRF-Token': csrfToken || '',
        },
        credentials: 'include',
        cache: 'no-store',
        body: JSON.stringify({ currentPassword, newPassword, confirmNewPassword }),
      });
      const data = await res.json();
      if (data.success) {
        if (data.csrfToken) {
          setCsrfToken(data.csrfToken);
          setClientCsrfToken(data.csrfToken);
        }
        if (data.user) {
          setCurrentUser(data.user);
          setAllUsers((prev) => prev.map((u) => (u.id === data.user.id ? data.user : u)));
        }
        await refreshUsers();
        return { success: true, message: data.message };
      }
      return {
        success: false,
        error: data.error || (isIndonesian ? 'Gagal mengubah password.' : 'Failed to change password.'),
      };
    } catch {
      return {
        success: false,
        error: isIndonesian
          ? 'Koneksi bermasalah. Silakan coba kembali.'
          : 'Connection error. Please try again.',
      };
    }
  };

  const adminResetPassword = async (
    targetUserId: string,
    newPassword: string,
    confirmNewPassword: string,
    mustChangePassword: boolean,
    adminPassword: string
  ): Promise<{ success: boolean; message?: string; error?: string }> => {
    try {
      const res = await fetch('/api/auth/admin/reset-password', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRF-Token': csrfToken || '',
        },
        credentials: 'include',
        cache: 'no-store',
        body: JSON.stringify({
          targetUserId,
          newPassword,
          confirmNewPassword,
          mustChangePassword,
          adminPassword,
        }),
      });
      const data = await res.json();
      if (data.success) {
        await refreshUsers();
        return { success: true, message: data.message };
      }
      return {
        success: false,
        error: data.error || (isIndonesian ? 'Gagal mereset password pengguna.' : 'Failed to reset user password.'),
      };
    } catch {
      return {
        success: false,
        error: isIndonesian
          ? 'Koneksi bermasalah. Silakan coba kembali.'
          : 'Connection error. Please try again.',
      };
    }
  };

  const setCurrentUserById = (_userId: string) => {
    // Session switching is strictly controlled by server-side authentication cookies.
  };

  const updateUserAccount = async (
    updated: User & { initialPassword?: string }
  ): Promise<{ success: boolean; user?: User; error?: string }> => {
    const exists = allUsers.some((u) => u.id === updated.id);
    const endpoint = exists ? `/api/users/${updated.id}` : '/api/users';
    const method = exists ? 'PUT' : 'POST';

    try {
      const res = await fetch(endpoint, {
        method,
        headers: {
          'Content-Type': 'application/json',
          'X-CSRF-Token': csrfToken || '',
        },
        credentials: 'include',
        cache: 'no-store',
        body: JSON.stringify(updated),
      });
      const data = await res.json();
      if (!res.ok || !data.success || !data.user) {
        return {
          success: false,
          error: data.error || (isIndonesian ? 'Gagal menyimpan akun pengguna.' : 'Failed to save user account.'),
        };
      }
      const savedUser = data.user as User;
      setAllUsers((prev) =>
        exists ? prev.map((u) => (u.id === savedUser.id ? savedUser : u)) : [...prev, savedUser]
      );
      if (savedUser.id === currentUser.id) {
        setCurrentUser(savedUser);
      }
      await refreshUsers();
      return { success: true, user: savedUser };
    } catch {
      return {
        success: false,
        error: isIndonesian
          ? 'Koneksi bermasalah saat menyimpan akun pengguna.'
          : 'Network error while saving user account.',
      };
    }
  };

  const deleteUserAccount = async (userId: string): Promise<{ success: boolean; message: string }> => {
    const targetUser = allUsers.find((u) => u.id === userId);
    if (!targetUser) {
      return { success: false, message: isIndonesian ? 'Pengguna tidak ditemukan.' : 'User not found.' };
    }

    if (currentUser.id === userId) {
      return {
        success: false,
        message: isIndonesian
          ? 'Tidak dapat menghapus akun Anda sendiri yang sedang aktif digunakan.'
          : 'Cannot delete your own currently active account.',
      };
    }

    if (targetUser.email === 'sosmeda217@gmail.com' || targetUser.id === 'user-superadmin') {
      return {
        success: false,
        message: isIndonesian
          ? 'Akun Super Admin utama sistem dilindungi dan tidak dapat dihapus.'
          : 'The primary system Super Admin account is protected and cannot be deleted.',
      };
    }

    if (!isAdmin) {
      return {
        success: false,
        message: isIndonesian
          ? 'Hanya Admin atau Super Admin yang berhak menghapus akun pengguna.'
          : 'Only Admins or Super Admins are authorized to delete user accounts.',
      };
    }

    if (targetUser.role === 'super_admin' && !isSuperAdmin) {
      return {
        success: false,
        message: isIndonesian
          ? 'Hanya Super Admin yang berhak menghapus sesama akun Super Admin.'
          : 'Only a Super Admin is authorized to delete another Super Admin account.',
      };
    }

    try {
      const res = await fetch(`/api/users/${userId}`, {
        method: 'DELETE',
        headers: {
          'X-CSRF-Token': csrfToken || '',
        },
        credentials: 'include',
        cache: 'no-store',
      });
      const data = await res.json();
      if (!res.ok || !data.success) {
        return {
          success: false,
          message:
            data.error ||
            (isIndonesian ? 'Gagal menghapus akun pengguna.' : 'Failed to delete user account.'),
        };
      }
      await refreshUsers();
      return {
        success: true,
        message:
          data.message ||
          (isIndonesian
            ? `Akun pengguna ${targetUser.fullName} (${targetUser.email}) berhasil dihapus.`
            : `User account ${targetUser.fullName} (${targetUser.email}) deleted successfully.`),
      };
    } catch {
      return {
        success: false,
        message: isIndonesian
          ? 'Koneksi bermasalah saat menghapus akun.'
          : 'Network error while deleting account.',
      };
    }
  };

  const isSuperAdmin = currentUser.role === 'super_admin';
  const isAdmin = isSuperAdmin || currentUser.role === 'admin';
  const isTeamMember = currentUser.role === 'team_member';
  const isRequester = currentUser.role === 'requester';
  const canReview = currentUser.isReviewer || isAdmin;

  // Scope check helper
  const isWithinScope = (req: RequestItem): boolean => {
    if (isSuperAdmin) return true;
    if (isAdmin) {
      const regionMatch =
        currentUser.assignedRegions.includes('all') ||
        currentUser.assignedRegions.includes(req.regionId);
      const brandMatch =
        currentUser.assignedBrands.includes('all') ||
        currentUser.assignedBrands.includes(req.brandId);
      return regionMatch && brandMatch;
    }
    return true;
  };

  const canViewRequest = (req: RequestItem): boolean => {
    if (isSuperAdmin) return true;
    if (isAdmin) return isWithinScope(req);
    if (isRequester) {
      return req.requesterId === currentUser.id;
    }
    if (isTeamMember) {
      // In their team or directly assigned
      const isAssignee =
        req.primaryAssigneeId === currentUser.id ||
        (req.collaboratorIds && req.collaboratorIds.includes(currentUser.id));
      const isTeamMatch = req.assignedTeamId
        ? currentUser.teams.includes(req.assignedTeamId)
        : false;
      return isAssignee || isTeamMatch;
    }
    return false;
  };

  const canEditRequestBrief = (req: RequestItem): boolean => {
    if (isSuperAdmin) return true;
    if (isRequester && req.requesterId === currentUser.id && req.status === 'todo') {
      return true;
    }
    if (isAdmin && req.status === 'todo') {
      return true;
    }
    return false;
  };

  const canAssignRequest = (req: RequestItem): boolean => {
    return isAdmin && isWithinScope(req);
  };

  const canSubmitDeliverables = (req: RequestItem): boolean => {
    if (isAdmin) return true;
    if (isTeamMember) {
      return (
        req.primaryAssigneeId === currentUser.id ||
        (req.collaboratorIds && req.collaboratorIds.includes(currentUser.id))
      );
    }
    return false;
  };

  const canApproveOrRevise = (req: RequestItem): boolean => {
    if (req.status !== 'pending_review') return false;
    if (isSuperAdmin) return true;
    if (req.reviewerId === currentUser.id) return true;
    if (isAdmin && isWithinScope(req)) return true;
    if (currentUser.isReviewer && isWithinScope(req)) return true;
    return false;
  };

  const canReopenRequest = (req: RequestItem): boolean => {
    return req.status === 'completed' && isAdmin && isWithinScope(req);
  };

  /**
   * Evaluates if the authenticated user is officially assigned to the target parent Request
   * as the Primary Assignee (PIC) or designated Collaborator.
   */
  const isAssignedToRequest = (req: RequestItem): boolean => {
    if (!currentUser || !currentUser.id) return false;
    const isPrimary = req.primaryAssigneeId === currentUser.id;
    const isCollaborator = Array.isArray(req.collaboratorIds) && req.collaboratorIds.includes(currentUser.id);
    return isPrimary || isCollaborator;
  };

  /**
   * Evaluates if the user is authorized to perform Actions on the target Request:
   * 1. Super Admin: full authorization.
   * 2. Marcomm Admin: authorized within organizational scope.
   * 3. Officially assigned PIC / Execution Team: Primary Assignee or Collaborators.
   * All other users (unassigned Team Members, Requesters, Reviewers) are strictly unauthorized.
   */
  const isAuthorizedForRequestActions = (req: RequestItem): boolean => {
    if (!currentUser || !currentUser.id) return false;
    if (isSuperAdmin) return true;
    if (isAdmin && isWithinScope(req)) return true;
    if (isAssignedToRequest(req)) return true;
    return false;
  };

  /**
   * Action-level RBAC helper for existing buttons:
   * 'submit_review', 'put_on_hold', 'cancel_request', 'resume'
   */
  const stLabel = (st: RequestStatus) =>
    isIndonesian ? STATUS_LABELS_ID[st] || st : STATUS_LABELS[st] || st;

  const canPerformRequestAction = (
    req: RequestItem,
    action: 'submit_review' | 'put_on_hold' | 'cancel_request' | 'resume'
  ): { allowed: boolean; reason?: string } => {
    if (!isAuthorizedForRequestActions(req)) {
      return {
        allowed: false,
        reason: isIndonesian
          ? 'Hanya Super Admin, Marcomm Admin dalam cakupan, atau PIC / Tim Eksekusi yang ditugaskan yang dapat melakukan tindakan ini.'
          : 'Only Super Admin, Marcomm Admin within scope, or officially assigned PIC / Execution Team can perform this action.',
      };
    }

    if (action === 'submit_review') {
      if (req.status !== 'in_progress' && req.status !== 'revision') {
        return {
          allowed: false,
          reason: isIndonesian
            ? 'Ajukan Review hanya tersedia saat permintaan berstatus Sedang Dikerjakan atau Perlu Revisi.'
            : 'Submit for Review is only available when a request is In Progress or under Revision.',
        };
      }
      const hasDeliverables =
        (req.deliverableAttachments && req.deliverableAttachments.length > 0) ||
        (req.deliverableLinks && req.deliverableLinks.length > 0);
      if (!hasDeliverables) {
        return {
          allowed: false,
          reason: isIndonesian
            ? 'Anda harus mengunggah berkas hasil pekerjaan atau melampirkan tautan sebelum mengajukan review.'
            : 'You must upload deliverable files or attach links before submitting for review.',
        };
      }
      return { allowed: true };
    }

    if (action === 'put_on_hold') {
      if (req.status === 'completed' || req.status === 'cancelled' || req.status === 'on_hold') {
        return {
          allowed: false,
          reason: isIndonesian
            ? `Tidak dapat menunda permintaan dengan status ${stLabel(req.status)}.`
            : `Cannot place a ${stLabel(req.status)} request on hold.`,
        };
      }
      return { allowed: true };
    }

    if (action === 'cancel_request') {
      if (req.status === 'completed' || req.status === 'cancelled') {
        return {
          allowed: false,
          reason: isIndonesian
            ? `Tidak dapat membatalkan permintaan dengan status ${stLabel(req.status)}.`
            : `Cannot cancel a ${stLabel(req.status)} request.`,
        };
      }
      return { allowed: true };
    }

    if (action === 'resume') {
      if (req.status !== 'on_hold') {
        return {
          allowed: false,
          reason: isIndonesian
            ? 'Hanya dapat melanjutkan permintaan yang sedang berstatus Ditunda (On Hold).'
            : 'Can only resume a request that is currently On Hold.',
        };
      }
      return { allowed: true };
    }

    return {
      allowed: false,
      reason: isIndonesian ? 'Tindakan yang diminta tidak dikenal.' : 'Unknown action requested.',
    };
  };

  const canTransitionStatus = (
    req: RequestItem,
    targetStatus: RequestStatus
  ): { allowed: boolean; reason?: string } => {
    if (req.status === targetStatus) {
      return { allowed: true };
    }

    // 1. To Do -> In Progress
    if (req.status === 'todo' && targetStatus === 'in_progress') {
      if (!req.primaryAssigneeId) {
        return {
          allowed: false,
          reason: isIndonesian
            ? 'Pekerjaan belum dapat dimulai karena Pelaksana Utama belum ditugaskan oleh Admin.'
            : 'Work cannot begin because the Primary Assignee has not been assigned by an Admin.',
        };
      }
      if (!req.committedDeadline) {
        return {
          allowed: false,
          reason: isIndonesian
            ? 'Pekerjaan belum dapat dimulai karena Tenggat Komitmen belum ditetapkan oleh Admin.'
            : 'Work cannot begin because the Committed Deadline has not been set by an Admin.',
        };
      }
      const isAssignee = isAssignedToRequest(req);
      if (!isAdmin && !isAssignee) {
        return {
          allowed: false,
          reason: isIndonesian
            ? 'Hanya Pelaksana Utama atau Admin yang dapat memindahkan permintaan ini ke Sedang Dikerjakan.'
            : 'Only the Primary Assignee or an Admin can transition this request to In Progress.',
        };
      }
      return { allowed: true };
    }

    // 2. In Progress -> Pending Review
    if (req.status === 'in_progress' && targetStatus === 'pending_review') {
      if (!isAuthorizedForRequestActions(req)) {
        return {
          allowed: false,
          reason: isIndonesian
            ? 'Hanya Super Admin, Marcomm Admin dalam cakupan, atau PIC/Tim Eksekusi yang ditugaskan yang dapat mengajukan review.'
            : 'Only Super Admin, Marcomm Admin within scope, or assigned PIC/Execution Team can submit for review.',
        };
      }
      const hasDeliverables =
        req.deliverableAttachments.length > 0 || req.deliverableLinks.length > 0;
      if (!hasDeliverables) {
        return {
          allowed: false,
          reason: isIndonesian
            ? 'Anda harus mengunggah berkas hasil pekerjaan atau melampirkan tautan sebelum mengajukan review.'
            : 'You must upload deliverable files or attach links before submitting for review.',
        };
      }
      return { allowed: true };
    }

    // 3. Pending Review -> Revision
    if (req.status === 'pending_review' && targetStatus === 'revision') {
      if (!canApproveOrRevise(req)) {
        return {
          allowed: false,
          reason: isIndonesian
            ? 'Hanya Reviewer atau Admin yang berwenang yang dapat meminta revisi.'
            : 'Only authorized Reviewers or Admins can request a revision.',
        };
      }
      return { allowed: true };
    }

    // 4. Revision -> In Progress
    if (req.status === 'revision' && targetStatus === 'in_progress') {
      if (!isAuthorizedForRequestActions(req)) {
        return {
          allowed: false,
          reason: isIndonesian
            ? 'Hanya Pelaksana Utama, Kolaborator, atau Admin yang dapat melanjutkan pengerjaan revisi.'
            : 'Only the Primary Assignee, Collaborators, or an Admin can resume work on revisions.',
        };
      }
      return { allowed: true };
    }

    // 5. Revision -> Pending Review (direct re-submit)
    if (req.status === 'revision' && targetStatus === 'pending_review') {
      if (!isAuthorizedForRequestActions(req)) {
        return {
          allowed: false,
          reason: isIndonesian
            ? 'Hanya Super Admin, Marcomm Admin dalam cakupan, atau PIC/Tim Eksekusi yang ditugaskan yang dapat mengajukan ulang untuk direview.'
            : 'Only Super Admin, Marcomm Admin within scope, or assigned PIC/Execution Team can resubmit for review.',
        };
      }
      const hasDeliverables =
        req.deliverableAttachments.length > 0 || req.deliverableLinks.length > 0;
      if (!hasDeliverables) {
        return {
          allowed: false,
          reason: isIndonesian
            ? 'Berkas atau tautan hasil pekerjaan harus diperbarui sebelum diajukan ulang untuk direview.'
            : 'Deliverable files or links must be updated before resubmitting for review.',
        };
      }
      return { allowed: true };
    }

    // 6. Pending Review -> Completed
    if (req.status === 'pending_review' && targetStatus === 'completed') {
      if (!canApproveOrRevise(req)) {
        return {
          allowed: false,
          reason: isIndonesian
            ? 'Hanya Reviewer atau Admin yang berwenang yang dapat menyetujui dan menyelesaikan permintaan ini.'
            : 'Only authorized Reviewers or Admins can approve and complete this request.',
        };
      }
      return { allowed: true };
    }

    // 7. Completed -> In Progress (Reopen)
    if (req.status === 'completed' && targetStatus === 'in_progress') {
      if (!canReopenRequest(req)) {
        return {
          allowed: false,
          reason: isIndonesian
            ? 'Hanya Admin yang berwenang yang dapat membuka ulang permintaan yang sudah selesai.'
            : 'Only authorized Admins can reopen a completed request.',
        };
      }
      return { allowed: true };
    }

    // 8. Transition TO 'on_hold' (from todo, in_progress, pending_review, revision)
    if (targetStatus === 'on_hold') {
      if (req.status === 'completed' || req.status === 'cancelled') {
        return {
          allowed: false,
          reason: isIndonesian
            ? `Tidak dapat menunda permintaan dengan status ${stLabel(req.status)}.`
            : `Cannot place a ${stLabel(req.status)} request on hold.`,
        };
      }
      if (!isAuthorizedForRequestActions(req)) {
        return {
          allowed: false,
          reason: isIndonesian
            ? 'Hanya Super Admin, Marcomm Admin dalam cakupan, atau PIC/Tim Eksekusi yang ditugaskan yang dapat menunda permintaan ini.'
            : 'Only Super Admin, Marcomm Admin within scope, or assigned PIC/Execution Team can put this request on hold.',
        };
      }
      return { allowed: true };
    }

    // 9. Transition FROM 'on_hold' (resume to in_progress or todo)
    if (req.status === 'on_hold') {
      if (!isAuthorizedForRequestActions(req)) {
        return {
          allowed: false,
          reason: isIndonesian
            ? 'Hanya Super Admin, Marcomm Admin dalam cakupan, atau PIC/Tim Eksekusi yang ditugaskan yang dapat melanjutkan atau membatalkan permintaan ini.'
            : 'Only Super Admin, Marcomm Admin within scope, or assigned PIC/Execution Team can resume or cancel this request.',
        };
      }
      if (targetStatus === 'in_progress' || targetStatus === 'todo') {
        return { allowed: true };
      }
      if (targetStatus === 'cancelled') {
        return { allowed: true };
      }
      return {
        allowed: false,
        reason: isIndonesian
          ? 'Permintaan yang ditunda hanya dapat dilanjutkan ke Sedang Dikerjakan, Antrean (To Do), atau Dibatalkan.'
          : 'A request on hold can only be resumed to In Progress, To Do, or Cancelled.',
      };
    }

    // 10. Transition TO 'cancelled' (from todo, in_progress, pending_review, revision, on_hold)
    if (targetStatus === 'cancelled') {
      if (req.status === 'completed') {
        return {
          allowed: false,
          reason: isIndonesian
            ? 'Permintaan yang sudah selesai tidak dapat dibatalkan. Gunakan Buka Ulang Tiket jika diperlukan revisi.'
            : 'Completed requests cannot be cancelled. Use Reopen Ticket if revisions are required.',
        };
      }
      if (!isAuthorizedForRequestActions(req)) {
        return {
          allowed: false,
          reason: isIndonesian
            ? 'Hanya Super Admin, Marcomm Admin dalam cakupan, atau PIC/Tim Eksekusi yang ditugaskan yang dapat membatalkan permintaan ini.'
            : 'Only Super Admin, Marcomm Admin within scope, or assigned PIC/Execution Team can cancel this request.',
        };
      }
      return { allowed: true };
    }

    // 11. Transition FROM 'cancelled' (re-activate to todo or in_progress)
    if (req.status === 'cancelled') {
      if (!isAuthorizedForRequestActions(req)) {
        return {
          allowed: false,
          reason: isIndonesian
            ? 'Hanya Super Admin, Marcomm Admin dalam cakupan, atau PIC/Tim Eksekusi yang ditugaskan yang dapat mengaktifkan ulang permintaan yang dibatalkan.'
            : 'Only Super Admin, Marcomm Admin within scope, or assigned PIC/Execution Team can reactivate a cancelled request.',
        };
      }
      if (targetStatus === 'todo' || targetStatus === 'in_progress') {
        return { allowed: true };
      }
      return {
        allowed: false,
        reason: isIndonesian
          ? 'Permintaan yang dibatalkan hanya dapat diaktifkan ulang ke Antrean (To Do) atau Sedang Dikerjakan.'
          : 'Cancelled requests can only be reactivated to To Do or In Progress.',
      };
    }

    // Direct illegal shortcut
    return {
      allowed: false,
      reason: isIndonesian
        ? `Perubahan status langsung dari ${stLabel(req.status)} ke ${stLabel(targetStatus)} tidak diizinkan oleh aturan alur kerja sistem.`
        : `Direct status transition from ${stLabel(req.status)} to ${stLabel(targetStatus)} is not permitted by system workflow rules.`,
    };
  };

  // Sub Item RBAC implementations: ONLY Super Admin and Marcomm Admin may create, edit, and delete
  const canManageSubItems = (req?: RequestItem): boolean => {
    if (isSuperAdmin) return true;
    if (isAdmin) return req ? isWithinScope(req) : true;
    return false;
  };

  const canCreateSubItem = (req: RequestItem): boolean => {
    if (isSuperAdmin) return true;
    if (isAdmin) return isWithinScope(req);
    return false;
  };

  const canEditSubItem = (_subItem: SubItem, req: RequestItem): boolean => {
    if (isSuperAdmin) return true;
    if (isAdmin) return isWithinScope(req);
    return false;
  };

  const canDeleteSubItem = (_subItem: SubItem, req: RequestItem): boolean => {
    if (isSuperAdmin) return true;
    if (isAdmin) return isWithinScope(req);
    return false;
  };

  const canUpdateSubItemProgress = (subItem: SubItem, req: RequestItem): boolean => {
    if (isSuperAdmin) return true;
    if (isAdmin && isWithinScope(req)) return true;
    // Assigned team member can update their own sub item's progress
    if (isTeamMember && subItem.ownerId === currentUser.id) return true;
    return false;
  };

  const canApproveSubItem = (_subItem: SubItem, req: RequestItem): boolean => {
    if (isSuperAdmin) return true;
    if (isAdmin && isWithinScope(req)) return true;
    if (req.reviewerId && req.reviewerId === currentUser.id) return true;
    return false;
  };

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        allUsers,
        isAuthenticated,
        isLoadingAuth,
        isLoggingOut,
        csrfToken,
        login,
        logout,
        registerBeforeLogoutFlush,
        refreshUsers,
        forgotPassword,
        resetPassword,
        changePassword,
        adminResetPassword,
        setCurrentUserById,

        updateUserAccount,
        deleteUserAccount,
        isSuperAdmin,
        isAdmin,
        isTeamMember,
        isRequester,
        canReview,
        canViewRequest,
        canEditRequestBrief,
        canAssignRequest,
        canTransitionStatus,
        canSubmitDeliverables,
        canApproveOrRevise,
        canReopenRequest,
        isAssignedToRequest,
        isAuthorizedForRequestActions,
        canPerformRequestAction,
        canManageSubItems,
        canCreateSubItem,
        canEditSubItem,
        canDeleteSubItem,
        canUpdateSubItemProgress,
        canApproveSubItem,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
