import React, { createContext, useContext, useState, useEffect, useMemo, useCallback, useRef } from 'react';
import {
  RequestItem,
  SubItem,
  Region,
  Brand,
  Unit,
  Department,
  Category,
  Team,
  NotificationItem,
  FilterState,
  RequestStatus,
  RequestPriority,
  Attachment,
  DeliverableLink,
  AnalyticsSummary,
  WorkItemCountingSummary,
  BrandQuotaSummary,
  PriorityQuotaReconciliationPreview,
  PeriodReportingMetrics,
  ReportingPeriodMode,
} from '../types';
import { StorageService } from '../services/storageService';
import { computeDynamicWorkItems } from '../utils/workItemCounting';
import { useAuth } from './AuthContext';
import { useLanguage } from './LanguageContext';
import { STATUS_LABELS, STATUS_LABELS_ID } from '../components/common/StatusBadge';

interface Toast {
  id: string;
  type: 'success' | 'error' | 'info';
  message: string;
}

interface RequestContextType {
  requests: RequestItem[];
  filteredRequests: RequestItem[];
  regions: Region[];
  brands: Brand[];
  units: Unit[];
  departments: Department[];
  categories: Category[];
  teams: Team[];
  notifications: NotificationItem[];
  unreadNotificationCount: number;
  lastSyncedAt: string | null;
  isSyncing: boolean;
  syncVersion: number;
  syncNow: (options?: { force?: boolean; includeMasterData?: boolean }) => Promise<void>;
  filters: FilterState;
  setFilters: React.Dispatch<React.SetStateAction<FilterState>>;
  resetFilters: () => void;
  analytics: AnalyticsSummary;
  overviewWorkItems: WorkItemCountingSummary;
  toasts: Toast[];

  removeToast: (id: string) => void;
  showToast: (message: string, type?: Toast['type']) => void;

  // Actions
  createRequest: (
    data: Omit<
      RequestItem,
      | 'id'
      | 'ticketNumber'
      | 'status'
      | 'committedDeadlineSnapshots'
      | 'briefAttachments'
      | 'deliverableAttachments'
      | 'deliverableLinks'
      | 'reopenCount'
      | 'createdAt'
      | 'updatedAt'
    > & {
      briefAttachments?: Attachment[];
    }
  ) => Promise<{ success: boolean; request?: RequestItem; error?: string }>;

  updateRequestBrief: (
    requestId: string,
    data: Partial<Pick<RequestItem, 'title' | 'description' | 'deliverablesExpected' | 'priority' | 'requestedDeadline'>>
  ) => Promise<{ success: boolean; error?: string }>;

  assignRequest: (
    requestId: string,
    params: {
      assignedTeamId: string;
      primaryAssigneeId: string;
      collaboratorIds: string[];
      reviewerId?: string;
      committedDeadline: string;
      deadlineReason: string;
    }
  ) => Promise<{ success: boolean; error?: string }>;

  updateCommittedDeadline: (
    requestId: string,
    newDeadline: string,
    reason: string
  ) => Promise<{ success: boolean; error?: string }>;

  changeStatus: (
    requestId: string,
    newStatus: RequestStatus,
    extra?: {
      revisionNote?: string;
      holdReason?: string;
      cancelReason?: string;
      deliverableAttachment?: Attachment;
      deliverableLink?: DeliverableLink;
    }
  ) => Promise<{ success: boolean; error?: string }>;

  reopenRequest: (
    requestId: string,
    reason: string
  ) => Promise<{ success: boolean; error?: string }>;

  addDeliverable: (
    requestId: string,
    deliverable: { attachment?: Attachment; attachments?: Attachment[]; link?: DeliverableLink }
  ) => Promise<{ success: boolean; error?: string }>;

  // Sub Item Management Actions (Level 2 Deliverables)
  addSubItem: (
    parentRequestId: string,
    data: Omit<SubItem, 'id' | 'parentRequestId' | 'createdBy' | 'createdById' | 'createdAt' | 'updatedAt'>
  ) => Promise<{ success: boolean; subItem?: SubItem; error?: string }>;

  updateSubItem: (
    parentRequestId: string,
    subItemId: string,
    updates: Partial<SubItem>
  ) => Promise<{ success: boolean; error?: string }>;

  deleteSubItem: (
    parentRequestId: string,
    subItemId: string,
    reason: string
  ) => Promise<{ success: boolean; error?: string }>;

  updateSubItemProgress: (
    parentRequestId: string,
    subItemId: string,
    updates: {
      status?: RequestStatus;
      deliverableUrl?: string;
      deliverableFileName?: string;
      notes?: string;
    }
  ) => Promise<{ success: boolean; error?: string }>;

  approveSubItem: (
    parentRequestId: string,
    subItemId: string
  ) => Promise<{ success: boolean; error?: string }>;

  reconcileSubItemApproval: (
    parentRequestId: string,
    subItemId: string,
    verifiedDate: string,
    justification: string
  ) => Promise<{ success: boolean; error?: string }>;

  // Priority Quota Governance
  fetchBrandQuota: (brandId: string, brandName?: string, year?: number) => Promise<BrandQuotaSummary | null>;
  fetchAllBrandQuotas: (year?: number) => Promise<BrandQuotaSummary[]>;
  adjustBrandQuota: (
    brandId: string,
    brandName: string,
    priority: RequestPriority,
    quantity: number,
    reason: string,
    year?: number
  ) => Promise<{ success: boolean; newRemaining?: number; error?: string }>;
  updateBrandQuotaLimits: (
    brandId: string,
    limits: { urgent?: number; high?: number; medium?: number },
    year?: number
  ) => Promise<{ success: boolean; error?: string }>;
  fetchReconciliationPreview: (year?: number) => Promise<PriorityQuotaReconciliationPreview | null>;
  applyReconciliation: (year?: number) => Promise<{ success: boolean; appliedCount?: number; error?: string }>;
  fetchPeriodReportingMetrics: (
    brandId: string,
    brandName?: string,
    startDate?: string,
    endDate?: string,
    year?: number,
    mode?: ReportingPeriodMode
  ) => Promise<PeriodReportingMetrics | null>;
  fetchAvailableQuotaYears: () => Promise<{ activeYear: number; years: number[] } | null>;

  markNotificationAsRead: (id: string) => Promise<void>;
  markAllNotificationsAsRead: () => Promise<void>;
  exportCsv: () => void;

  // Master Data Actions
  saveMasterData: {
    addBrand: (brand: Omit<Brand, 'id'>) => Promise<boolean>;
    updateBrand: (brand: Brand) => Promise<boolean>;
    deleteBrand: (id: string) => Promise<boolean>;
    addUnit: (unit: Omit<Unit, 'id'>) => Promise<boolean>;
    updateUnit: (unit: Unit) => Promise<boolean>;
    deleteUnit: (id: string) => Promise<boolean>;
    addDepartment: (dept: Omit<Department, 'id'>) => Promise<boolean>;
    updateDepartment: (dept: Department) => Promise<boolean>;
    deleteDepartment: (id: string) => Promise<boolean>;
    addCategory: (cat: Omit<Category, 'id'>) => Promise<boolean>;
    updateCategory: (cat: Category) => Promise<boolean>;
    deleteCategory: (id: string) => Promise<boolean>;
    addTeam: (team: Omit<Team, 'id'>) => Promise<boolean>;
    updateTeam: (team: Team) => Promise<boolean>;
    deleteTeam: (id: string) => Promise<boolean>;
    addRegion: (region: Omit<Region, 'id'>) => Promise<boolean>;
    updateRegion: (region: Region) => Promise<boolean>;
    deleteRegion: (id: string) => Promise<boolean>;
  };
}

const defaultFilters: FilterState = {
  search: '',
  status: 'all',
  priority: 'all',
  regionId: 'all',
  brandId: 'all',
  categoryId: 'all',
  assignedTeamId: 'all',
  assigneeId: 'all',
  requesterId: 'all',
  overdueOnly: false,
  dateRange: 'all',
};

const SMART_POLL_INTERVAL_MS = 20_000;

const RequestContext = createContext<RequestContextType | undefined>(undefined);

export const RequestProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const {
    currentUser,
    isAuthenticated,
    csrfToken,
    registerBeforeLogoutFlush,
    canViewRequest,
    canTransitionStatus,
    canCreateSubItem,
    canEditSubItem,
    canDeleteSubItem,
    canUpdateSubItemProgress,
    canApproveSubItem,
  } = useAuth();
  const { isIndonesian } = useLanguage();
  const stLabel = (st: RequestStatus) =>
    isIndonesian ? STATUS_LABELS_ID[st] || st : STATUS_LABELS[st] || st;

  const [requests, setRequests] = useState<RequestItem[]>([]);
  const [regions, setRegions] = useState<Region[]>([]);
  const [brands, setBrands] = useState<Brand[]>([]);
  const [units, setUnits] = useState<Unit[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [teams, setTeams] = useState<Team[]>([]);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [lastSyncedAt, setLastSyncedAt] = useState<string | null>(null);
  const [isSyncing, setIsSyncing] = useState<boolean>(false);
  const [syncVersion, setSyncVersion] = useState<number>(0);
  const [filters, setFilters] = useState<FilterState>(defaultFilters);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const syncInFlightRef = useRef<boolean>(false);
  const syncInFlightPromiseRef = useRef<Promise<void> | null>(null);
  const pendingSyncRef = useRef<boolean>(false);
  const pendingIncludeMasterRef = useRef<boolean>(false);
  const brandsRef = useRef<Brand[]>(brands);
  const requestsRef = useRef<RequestItem[]>(requests);

  useEffect(() => {
    brandsRef.current = brands;
  }, [brands]);

  useEffect(() => {
    requestsRef.current = requests;
  }, [requests]);

  const showToast = (message: string, type: Toast['type'] = 'info') => {
    const id = `toast-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
    setToasts((prev) => [...prev, { id, type, message }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4500);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  const fetchMasterData = useCallback(async (): Promise<void> => {
    if (!isAuthenticated) return;
    try {
      const res = await fetch('/api/master-data', { credentials: 'include', cache: 'no-store' });
      if (!res.ok) return;
      const data = await res.json();
      if (data.success && data.data) {
        const md = data.data;
        setRegions(
          (md.regions || []).map((r: Region) => ({
            ...r,
            name: StorageService.normalizeRegionName(r.name),
          }))
        );
        setBrands(md.brands || []);
        setUnits(md.units || []);
        setDepartments(md.departments || []);
        setCategories(md.categories || []);
        setTeams((md.teams || []).map((t: Team) => StorageService.normalizeTeam(t)));
      }
    } catch {
      // Transient fetch failures recover on next sync cycle
    }
  }, [isAuthenticated]);

  const syncNow = useCallback(
    async (options?: { force?: boolean; includeMasterData?: boolean }): Promise<void> => {
      if (!isAuthenticated || !currentUser.id) return;

      if (syncInFlightRef.current && syncInFlightPromiseRef.current) {
        if (options?.force) {
          pendingSyncRef.current = true;
          if (options.includeMasterData) {
            pendingIncludeMasterRef.current = true;
          }
        }
        await syncInFlightPromiseRef.current;
        if (options?.force && pendingSyncRef.current) {
          return syncNow({ force: true, includeMasterData: pendingIncludeMasterRef.current });
        }
        return;
      }

      const run = (async () => {
        syncInFlightRef.current = true;
        setIsSyncing(true);
        try {
          if (options?.includeMasterData) {
            await fetchMasterData();
          }
          const res = await fetch('/api/sync', { credentials: 'include', cache: 'no-store' });
          if (!res.ok) return;
          const data = await res.json();
          if (data.success) {
            setRequests(Array.isArray(data.requests) ? data.requests : []);
            setNotifications(Array.isArray(data.notifications) ? data.notifications : []);
            setLastSyncedAt(data.syncedAt || new Date().toISOString());
            setSyncVersion((v) => v + 1);
          }
        } catch {
          // Keep current synced state on offline/transient error
        } finally {
          syncInFlightRef.current = false;
          syncInFlightPromiseRef.current = null;
          setIsSyncing(false);
        }
      })();

      syncInFlightPromiseRef.current = run;
      await run;

      if (pendingSyncRef.current) {
        const nextIncludeMaster = pendingIncludeMasterRef.current;
        pendingSyncRef.current = false;
        pendingIncludeMasterRef.current = false;
        await syncNow({ force: true, includeMasterData: nextIncludeMaster });
      }
    },
    [isAuthenticated, currentUser.id, fetchMasterData]
  );

  // Ensure any in-flight sync finishes before logout completes
  useEffect(() => {
    return registerBeforeLogoutFlush(async () => {
      if (syncInFlightPromiseRef.current) {
        await syncInFlightPromiseRef.current.catch(() => {});
      }
    });
  }, [registerBeforeLogoutFlush]);

  // Initial authenticated load + Smart Polling (20s visible interval + visibility/focus/online triggers)
  useEffect(() => {
    if (!isAuthenticated || !currentUser.id) {
      pendingSyncRef.current = false;
      pendingIncludeMasterRef.current = false;
      setRequests([]);
      setNotifications([]);
      setLastSyncedAt(null);
      setRegions([]);
      setBrands([]);
      setUnits([]);
      setDepartments([]);
      setCategories([]);
      setTeams([]);
      setFilters(defaultFilters);
      return;
    }

    void syncNow({ force: true, includeMasterData: true });

    const intervalId = window.setInterval(() => {
      if (typeof document === 'undefined' || document.visibilityState === 'visible') {
        void syncNow();
      }
    }, SMART_POLL_INTERVAL_MS);

    const handleVisibilityChange = () => {
      if (document.visibilityState === 'visible') {
        void syncNow();
      }
    };
    const handleFocusOrOnline = () => {
      void syncNow();
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    window.addEventListener('focus', handleFocusOrOnline);
    window.addEventListener('online', handleFocusOrOnline);

    return () => {
      window.clearInterval(intervalId);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('focus', handleFocusOrOnline);
      window.removeEventListener('online', handleFocusOrOnline);
    };
  }, [isAuthenticated, currentUser.id, syncNow]);

  const authHeaders = useCallback(
    (includeJson = true): Record<string, string> => ({
      ...(includeJson ? { 'Content-Type': 'application/json' } : {}),
      ...(csrfToken ? { 'X-CSRF-Token': csrfToken } : {}),
    }),
    [csrfToken]
  );

  const upsertLocalRequest = useCallback((reqItem: RequestItem) => {
    setRequests((prev) => {
      const idx = prev.findIndex((r) => r.id === reqItem.id);
      if (idx >= 0) {
        return prev.map((r) => (r.id === reqItem.id ? reqItem : r));
      }
      return [reqItem, ...prev];
    });
  }, []);

  const unreadNotificationCount = useMemo(() => {
    return notifications.filter((n) => !n.isRead).length;
  }, [notifications]);

  // Filter requests based on RBAC and active filters
  const filteredRequests = useMemo(() => {
    return requests.filter((req) => {
      if (!canViewRequest(req)) return false;

      if (filters.search) {
        const query = filters.search.toLowerCase().trim();
        const matchTitle = (req.title || '').toLowerCase().includes(query);
        const matchTicket = (req.ticketNumber || '').toLowerCase().includes(query);
        const reqName = req.requestorName || req.requesterName || '';
        const matchRequester = reqName.toLowerCase().includes(query);
        if (!matchTitle && !matchTicket && !matchRequester) return false;
      }

      if (filters.status !== 'all' && req.status !== filters.status) return false;
      if (filters.priority !== 'all' && req.priority !== filters.priority) return false;
      if (filters.regionId !== 'all' && req.regionId !== filters.regionId) return false;
      if (filters.brandId !== 'all' && req.brandId !== filters.brandId) return false;
      if (filters.categoryId !== 'all' && req.categoryId !== filters.categoryId) return false;
      if (filters.assignedTeamId !== 'all' && req.assignedTeamId !== filters.assignedTeamId) return false;

      if (filters.assigneeId !== 'all') {
        const isPrimary = req.primaryAssigneeId === filters.assigneeId;
        const isCollab = req.collaboratorIds && req.collaboratorIds.includes(filters.assigneeId);
        if (!isPrimary && !isCollab) return false;
      }

      if (filters.requesterId && filters.requesterId !== 'all') {
        if (req.requesterId !== filters.requesterId) return false;
      }

      if (filters.overdueOnly && !req.isOverdue) return false;

      if (filters.dateRange !== 'all' && req.createdAt) {
        const created = new Date(req.createdAt);
        const now = new Date();
        const reqDateStr = req.createdAt.split('T')[0];

        if (filters.dateRange === 'today') {
          if (created.toDateString() !== now.toDateString()) return false;
        } else if (filters.dateRange === 'this_week') {
          const oneWeekAgo = new Date();
          oneWeekAgo.setDate(now.getDate() - 7);
          if (created < oneWeekAgo) return false;
        } else if (filters.dateRange === 'this_month') {
          if (created.getMonth() !== now.getMonth() || created.getFullYear() !== now.getFullYear()) return false;
        } else if (filters.dateRange === 'custom') {
          if (filters.startDate && reqDateStr < filters.startDate) return false;
          if (filters.endDate && reqDateStr > filters.endDate) return false;
        }
      }

      return true;
    });
  }, [requests, canViewRequest, filters]);

  const authorizedRequests = useMemo(() => {
    return requests.filter((req) => canViewRequest(req));
  }, [requests, canViewRequest]);

  const overviewWorkItems = useMemo(() => {
    return computeDynamicWorkItems(authorizedRequests);
  }, [authorizedRequests]);

  const analytics = useMemo(() => {
    return StorageService.computeAnalytics(filteredRequests);
  }, [filteredRequests]);

  const resetFilters = () => {
    setFilters(defaultFilters);
  };

  // Atomic request creation + quota deduction on Worker D1
  const createRequest = async (
    data: Parameters<RequestContextType['createRequest']>[0]
  ): Promise<{ success: boolean; request?: RequestItem; error?: string }> => {
    try {
      const idempotencyKey =
        typeof crypto !== 'undefined' && crypto.randomUUID
          ? `idemp-${crypto.randomUUID()}`
          : `idemp-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;

      const res = await fetch('/api/requests', {
        method: 'POST',
        headers: authHeaders(true),
        credentials: 'include',
        cache: 'no-store',
        body: JSON.stringify({ ...data, idempotencyKey }),
      });

      const respData = await res.json().catch(() => ({}));
      if (!res.ok || !respData.success || !respData.request) {
        const errMsg =
          respData.error ||
          (isIndonesian
            ? 'Gagal membuat permintaan atau kuota prioritas telah habis.'
            : 'Failed to create request or annual priority quota exhausted.');
        showToast(errMsg, 'error');
        return { success: false, error: errMsg };
      }

      const createdReq = respData.request as RequestItem;
      upsertLocalRequest(createdReq);
      await syncNow({ force: true });
      showToast(
        isIndonesian
          ? `Permintaan ${createdReq.ticketNumber} berhasil dibuat!`
          : `Request ${createdReq.ticketNumber} created successfully!`,
        'success'
      );
      return { success: true, request: createdReq };
    } catch (e: unknown) {
      const err =
        e instanceof Error
          ? e.message
          : isIndonesian
          ? 'Gagal membuat permintaan'
          : 'Failed to create request';
      showToast(err, 'error');
      return { success: false, error: err };
    }
  };

  const updateRequestBrief = async (
    requestId: string,
    data: Partial<Pick<RequestItem, 'title' | 'description' | 'deliverablesExpected' | 'priority' | 'requestedDeadline'>>
  ): Promise<{ success: boolean; error?: string }> => {
    const req = requests.find((r) => r.id === requestId);
    if (!req) return { success: false, error: isIndonesian ? 'Permintaan tidak ditemukan' : 'Request not found' };

    if (req.status !== 'todo') {
      return {
        success: false,
        error: isIndonesian
          ? 'Detail brief hanya dapat diubah saat berstatus Antrean (To Do).'
          : 'Brief details can only be edited while in To Do / Backlog status.',
      };
    }

    try {
      const res = await fetch(`/api/requests/${requestId}/brief`, {
        method: 'PUT',
        headers: authHeaders(true),
        credentials: 'include',
        cache: 'no-store',
        body: JSON.stringify(data),
      });
      const respData = await res.json().catch(() => ({}));
      if (!res.ok || !respData.success) {
        const errMsg =
          respData.error ||
          (isIndonesian ? 'Gagal memperbarui detail brief.' : 'Failed to update brief details.');
        showToast(errMsg, 'error');
        return { success: false, error: errMsg };
      }
      if (respData.request) upsertLocalRequest(respData.request);
      await syncNow({ force: true });
      showToast(
        isIndonesian ? 'Detail brief berhasil diperbarui' : 'Brief details updated successfully',
        'success'
      );
      return { success: true };
    } catch (e: unknown) {
      const err = e instanceof Error ? e.message : 'Network error';
      showToast(err, 'error');
      return { success: false, error: err };
    }
  };

  const assignRequest = async (
    requestId: string,
    params: {
      assignedTeamId: string;
      primaryAssigneeId: string;
      collaboratorIds: string[];
      reviewerId?: string;
      committedDeadline: string;
      deadlineReason: string;
    }
  ): Promise<{ success: boolean; error?: string }> => {
    try {
      const res = await fetch(`/api/requests/${requestId}/assign`, {
        method: 'POST',
        headers: authHeaders(true),
        credentials: 'include',
        cache: 'no-store',
        body: JSON.stringify(params),
      });
      const respData = await res.json().catch(() => ({}));
      if (!res.ok || !respData.success) {
        const errMsg =
          respData.error ||
          (isIndonesian ? 'Gagal menyimpan penugasan tim.' : 'Failed to save team assignment.');
        showToast(errMsg, 'error');
        return { success: false, error: errMsg };
      }
      if (respData.request) upsertLocalRequest(respData.request);
      await syncNow({ force: true });
      showToast(
        isIndonesian
          ? 'Penugasan tim dan tenggat komitmen berhasil disimpan!'
          : 'Team assignment and committed deadline saved successfully!',
        'success'
      );
      return { success: true };
    } catch (e: unknown) {
      const err = e instanceof Error ? e.message : 'Network error';
      showToast(err, 'error');
      return { success: false, error: err };
    }
  };

  const updateCommittedDeadline = async (
    requestId: string,
    newDeadline: string,
    reason: string
  ): Promise<{ success: boolean; error?: string }> => {
    if (!reason || reason.trim().length < 5) {
      return {
        success: false,
        error: isIndonesian
          ? 'Alasan perubahan tenggat waktu wajib diisi (minimal 5 karakter).'
          : 'Deadline change reason is required (minimum 5 characters).',
      };
    }

    try {
      const res = await fetch(`/api/requests/${requestId}/deadline`, {
        method: 'PUT',
        headers: authHeaders(true),
        credentials: 'include',
        cache: 'no-store',
        body: JSON.stringify({ newDeadline, reason: reason.trim() }),
      });
      const respData = await res.json().catch(() => ({}));
      if (!res.ok || !respData.success) {
        const errMsg =
          respData.error ||
          (isIndonesian ? 'Gagal memperbarui tenggat komitmen.' : 'Failed to update committed deadline.');
        showToast(errMsg, 'error');
        return { success: false, error: errMsg };
      }
      if (respData.request) upsertLocalRequest(respData.request);
      await syncNow({ force: true });
      showToast(
        isIndonesian ? 'Tenggat komitmen berhasil diperbarui!' : 'Committed deadline updated successfully!',
        'success'
      );
      return { success: true };
    } catch (e: unknown) {
      const err = e instanceof Error ? e.message : 'Network error';
      showToast(err, 'error');
      return { success: false, error: err };
    }
  };

  const changeStatus = async (
    requestId: string,
    newStatus: RequestStatus,
    extra?: {
      revisionNote?: string;
      holdReason?: string;
      cancelReason?: string;
      deliverableAttachment?: Attachment;
      deliverableLink?: DeliverableLink;
    }
  ): Promise<{ success: boolean; error?: string }> => {
    const req = requests.find((r) => r.id === requestId);
    if (!req) return { success: false, error: isIndonesian ? 'Permintaan tidak ditemukan' : 'Request not found' };

    const check = canTransitionStatus(req, newStatus);
    if (!check.allowed) {
      showToast(check.reason || (isIndonesian ? 'Perubahan status ditolak' : 'Status transition rejected'), 'error');
      return { success: false, error: check.reason };
    }

    if (newStatus === 'revision' && (!extra?.revisionNote || extra.revisionNote.trim().length < 5)) {
      const msg = isIndonesian
        ? 'Catatan umpan balik revisi wajib diisi (minimal 5 karakter).'
        : 'Revision feedback notes are required (minimum 5 characters).';
      showToast(msg, 'error');
      return { success: false, error: msg };
    }
    if (newStatus === 'on_hold' && (!extra?.holdReason || extra.holdReason.trim().length < 5)) {
      const msg = isIndonesian
        ? 'Alasan penundaan permintaan wajib diisi (minimal 5 karakter).'
        : 'A reason is required to place a request on hold (minimum 5 characters).';
      showToast(msg, 'error');
      return { success: false, error: msg };
    }
    if (newStatus === 'cancelled' && (!extra?.cancelReason || extra.cancelReason.trim().length < 5)) {
      const msg = isIndonesian
        ? 'Alasan pembatalan permintaan wajib diisi (minimal 5 karakter).'
        : 'A reason is required to cancel a request (minimum 5 characters).';
      showToast(msg, 'error');
      return { success: false, error: msg };
    }

    try {
      const res = await fetch(`/api/requests/${requestId}/status`, {
        method: 'POST',
        headers: authHeaders(true),
        credentials: 'include',
        cache: 'no-store',
        body: JSON.stringify({
          newStatus,
          revisionNote: extra?.revisionNote?.trim(),
          holdReason: extra?.holdReason?.trim(),
          cancelReason: extra?.cancelReason?.trim(),
          deliverableAttachment: extra?.deliverableAttachment,
          deliverableLink: extra?.deliverableLink,
        }),
      });
      const respData = await res.json().catch(() => ({}));
      if (!res.ok || !respData.success) {
        const errMsg =
          respData.error ||
          (isIndonesian ? 'Perubahan status ditolak oleh server.' : 'Status transition rejected by server.');
        showToast(errMsg, 'error');
        return { success: false, error: errMsg };
      }

      if (respData.request) upsertLocalRequest(respData.request);
      await syncNow({ force: true });

      if (newStatus === 'on_hold') {
        showToast(isIndonesian ? 'Permintaan ditunda (On Hold).' : 'Request placed on hold.', 'info');
      } else if (newStatus === 'cancelled') {
        showToast(isIndonesian ? 'Permintaan telah dibatalkan.' : 'Request has been cancelled.', 'info');
      } else {
        showToast(
          isIndonesian
            ? `Status berhasil diperbarui menjadi "${stLabel(newStatus)}"`
            : `Status updated to "${stLabel(newStatus)}" successfully`,
          'success'
        );
      }
      return { success: true };
    } catch (e: unknown) {
      const err = e instanceof Error ? e.message : 'Network error';
      showToast(err, 'error');
      return { success: false, error: err };
    }
  };

  const reopenRequest = async (
    requestId: string,
    reason: string
  ): Promise<{ success: boolean; error?: string }> => {
    if (!reason || reason.trim().length < 5) {
      return {
        success: false,
        error: isIndonesian
          ? 'Alasan pembukaan ulang wajib diisi (minimal 5 karakter).'
          : 'Re-open reason is required (minimum 5 characters).',
      };
    }

    try {
      const res = await fetch(`/api/requests/${requestId}/reopen`, {
        method: 'POST',
        headers: authHeaders(true),
        credentials: 'include',
        cache: 'no-store',
        body: JSON.stringify({ reason: reason.trim() }),
      });
      const respData = await res.json().catch(() => ({}));
      if (!res.ok || !respData.success) {
        const errMsg =
          respData.error || (isIndonesian ? 'Gagal membuka ulang tugas.' : 'Failed to reopen task.');
        showToast(errMsg, 'error');
        return { success: false, error: errMsg };
      }
      if (respData.request) upsertLocalRequest(respData.request);
      await syncNow({ force: true });
      showToast(
        isIndonesian
          ? 'Tugas berhasil dibuka ulang ke Sedang Dikerjakan'
          : 'Task successfully reopened to In Progress',
        'info'
      );
      return { success: true };
    } catch (e: unknown) {
      const err = e instanceof Error ? e.message : 'Network error';
      showToast(err, 'error');
      return { success: false, error: err };
    }
  };

  const addDeliverable = async (
    requestId: string,
    deliverable: { attachment?: Attachment; attachments?: Attachment[]; link?: DeliverableLink }
  ): Promise<{ success: boolean; error?: string }> => {
    try {
      const res = await fetch(`/api/requests/${requestId}/deliverables`, {
        method: 'POST',
        headers: authHeaders(true),
        credentials: 'include',
        cache: 'no-store',
        body: JSON.stringify(deliverable),
      });
      const respData = await res.json().catch(() => ({}));
      if (!res.ok || !respData.success) {
        const errMsg =
          respData.error ||
          (isIndonesian ? 'Gagal menyimpan hasil pekerjaan.' : 'Failed to save deliverable.');
        showToast(errMsg, 'error');
        return { success: false, error: errMsg };
      }
      if (respData.request) upsertLocalRequest(respData.request);
      await syncNow({ force: true });
      showToast(
        isIndonesian ? 'Hasil pekerjaan berhasil disimpan!' : 'Deliverable saved successfully!',
        'success'
      );
      return { success: true };
    } catch (e: unknown) {
      const err = e instanceof Error ? e.message : 'Network error';
      showToast(err, 'error');
      return { success: false, error: err };
    }
  };

  // Sub Item Management Actions (Level 2 Deliverables)
  const addSubItem = async (
    parentRequestId: string,
    data: Omit<SubItem, 'id' | 'parentRequestId' | 'createdBy' | 'createdById' | 'createdAt' | 'updatedAt'>
  ): Promise<{ success: boolean; subItem?: SubItem; error?: string }> => {
    const parentReq = requests.find((r) => r.id === parentRequestId);
    if (!parentReq) {
      return { success: false, error: isIndonesian ? 'Permintaan induk tidak ditemukan.' : 'Parent request not found.' };
    }
    if (!canCreateSubItem(parentReq)) {
      const msg = isIndonesian
        ? 'Tidak Diizinkan: Hanya Super Admin dan Marcomm Admin yang dapat membuat Sub Item.'
        : 'Unauthorized: Only Super Admin and Marcomm Admin can create Sub Items.';
      showToast(msg, 'error');
      return { success: false, error: msg };
    }
    if (!data.title || !data.title.trim()) {
      const msg = isIndonesian ? 'Judul Sub Item wajib diisi.' : 'Sub Item title is required.';
      showToast(msg, 'error');
      return { success: false, error: msg };
    }

    try {
      const res = await fetch(`/api/requests/${parentRequestId}/sub-items`, {
        method: 'POST',
        headers: authHeaders(true),
        credentials: 'include',
        cache: 'no-store',
        body: JSON.stringify({ ...data, title: data.title.trim() }),
      });
      const respData = await res.json().catch(() => ({}));
      if (!res.ok || !respData.success || !respData.subItem) {
        const msg = respData.error || (isIndonesian ? 'Gagal membuat Sub Item.' : 'Failed to create Sub Item.');
        showToast(msg, 'error');
        return { success: false, error: msg };
      }
      await syncNow({ force: true });
      showToast(
        isIndonesian
          ? `Sub Item "${respData.subItem.title}" berhasil dibuat!`
          : `Sub Item "${respData.subItem.title}" created successfully!`,
        'success'
      );
      return { success: true, subItem: respData.subItem };
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : 'Network error';
      showToast(msg, 'error');
      return { success: false, error: msg };
    }
  };

  const updateSubItem = async (
    parentRequestId: string,
    subItemId: string,
    updates: Partial<SubItem>
  ): Promise<{ success: boolean; error?: string }> => {
    const parentReq = requests.find((r) => r.id === parentRequestId);
    const existing = parentReq?.subItems?.find((s) => s.id === subItemId);
    if (!parentReq || !existing) {
      return {
        success: false,
        error: isIndonesian ? 'Permintaan atau Sub Item tidak ditemukan.' : 'Request or Sub Item not found.',
      };
    }
    if (!canEditSubItem(existing, parentReq)) {
      const msg = isIndonesian
        ? 'Tidak Diizinkan: Hanya Super Admin dan Marcomm Admin yang dapat mengubah Sub Item.'
        : 'Unauthorized: Only Super Admin and Marcomm Admin can edit Sub Items.';
      showToast(msg, 'error');
      return { success: false, error: msg };
    }

    try {
      const res = await fetch(`/api/requests/${parentRequestId}/sub-items/${subItemId}`, {
        method: 'PUT',
        headers: authHeaders(true),
        credentials: 'include',
        cache: 'no-store',
        body: JSON.stringify(updates),
      });
      const respData = await res.json().catch(() => ({}));
      if (!res.ok || !respData.success) {
        const msg =
          respData.error || (isIndonesian ? 'Gagal memperbarui Sub Item.' : 'Failed to update Sub Item.');
        showToast(msg, 'error');
        return { success: false, error: msg };
      }
      await syncNow({ force: true });
      showToast(
        isIndonesian
          ? `Sub Item "${respData.subItem?.title || existing.title}" berhasil diperbarui!`
          : `Sub Item "${respData.subItem?.title || existing.title}" updated successfully!`,
        'success'
      );
      return { success: true };
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : 'Network error';
      showToast(msg, 'error');
      return { success: false, error: msg };
    }
  };

  const deleteSubItem = async (
    parentRequestId: string,
    subItemId: string,
    reason: string
  ): Promise<{ success: boolean; error?: string }> => {
    const parentReq = requests.find((r) => r.id === parentRequestId);
    const existing = parentReq?.subItems?.find((s) => s.id === subItemId);
    if (!parentReq || !existing) {
      return {
        success: false,
        error: isIndonesian ? 'Permintaan atau Sub Item tidak ditemukan.' : 'Request or Sub Item not found.',
      };
    }
    if (!canDeleteSubItem(existing, parentReq)) {
      const msg = isIndonesian
        ? 'Tidak Diizinkan: Hanya Super Admin dan Marcomm Admin yang dapat menghapus Sub Item.'
        : 'Unauthorized: Only Super Admin and Marcomm Admin can delete Sub Items.';
      showToast(msg, 'error');
      return { success: false, error: msg };
    }
    if (!reason || reason.trim().length < 5) {
      const msg = isIndonesian
        ? 'Alasan penghapusan wajib diisi minimal 5 karakter.'
        : 'Mandatory deletion reason must be at least 5 characters.';
      showToast(msg, 'error');
      return { success: false, error: msg };
    }

    try {
      const res = await fetch(`/api/requests/${parentRequestId}/sub-items/${subItemId}`, {
        method: 'DELETE',
        headers: authHeaders(true),
        credentials: 'include',
        cache: 'no-store',
        body: JSON.stringify({ reason: reason.trim() }),
      });
      const respData = await res.json().catch(() => ({}));
      if (!res.ok || !respData.success) {
        const msg =
          respData.error || (isIndonesian ? 'Gagal menghapus Sub Item.' : 'Failed to delete Sub Item.');
        showToast(msg, 'error');
        return { success: false, error: msg };
      }
      await syncNow({ force: true });
      showToast(
        isIndonesian
          ? `Sub Item "${existing.title}" berhasil dihapus.`
          : `Sub Item "${existing.title}" deleted successfully.`,
        'info'
      );
      return { success: true };
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : 'Network error';
      showToast(msg, 'error');
      return { success: false, error: msg };
    }
  };

  const updateSubItemProgress = async (
    parentRequestId: string,
    subItemId: string,
    updates: {
      status?: RequestStatus;
      deliverableUrl?: string;
      deliverableFileName?: string;
      notes?: string;
    }
  ): Promise<{ success: boolean; error?: string }> => {
    const parentReq = requests.find((r) => r.id === parentRequestId);
    const existing = parentReq?.subItems?.find((s) => s.id === subItemId);
    if (!parentReq || !existing) {
      return {
        success: false,
        error: isIndonesian ? 'Permintaan atau Sub Item tidak ditemukan.' : 'Request or Sub Item not found.',
      };
    }
    if (!canUpdateSubItemProgress(existing, parentReq)) {
      const msg = isIndonesian
        ? 'Tidak Diizinkan: Anda hanya dapat memperbarui progres Sub Item yang ditugaskan kepada Anda.'
        : 'Unauthorized: You can only update progress on Sub Items assigned to you.';
      showToast(msg, 'error');
      return { success: false, error: isIndonesian ? 'Tidak diizinkan.' : 'Unauthorized.' };
    }
    if (updates.status === 'completed' && !canApproveSubItem(existing, parentReq)) {
      const msg = isIndonesian
        ? 'Tidak Diizinkan: Sub Item hanya dapat ditandai Selesai melalui persetujuan resmi oleh Reviewer atau Administrator yang berwenang.'
        : 'Unauthorized: Sub Items can only be marked Completed through official approval by an authorized Reviewer or Administrator.';
      showToast(msg, 'error');
      return {
        success: false,
        error: isIndonesian
          ? 'Persetujuan resmi diperlukan untuk menyelesaikan Sub Item.'
          : 'Official approval required to complete a Sub Item.',
      };
    }

    try {
      const res = await fetch(`/api/requests/${parentRequestId}/sub-items/${subItemId}/progress`, {
        method: 'POST',
        headers: authHeaders(true),
        credentials: 'include',
        cache: 'no-store',
        body: JSON.stringify(updates),
      });
      const respData = await res.json().catch(() => ({}));
      if (!res.ok || !respData.success) {
        const msg =
          respData.error ||
          (isIndonesian ? 'Gagal memperbarui progres Sub Item.' : 'Failed to update Sub Item progress.');
        showToast(msg, 'error');
        return { success: false, error: msg };
      }
      await syncNow({ force: true });
      showToast(
        isIndonesian
          ? `Progres Sub Item "${existing.title}" berhasil diperbarui!`
          : `Sub Item "${existing.title}" progress updated!`,
        'success'
      );
      return { success: true };
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : 'Network error';
      showToast(msg, 'error');
      return { success: false, error: msg };
    }
  };

  const approveSubItem = async (
    parentRequestId: string,
    subItemId: string
  ): Promise<{ success: boolean; error?: string }> => {
    const parentReq = requests.find((r) => r.id === parentRequestId);
    const existing = parentReq?.subItems?.find((s) => s.id === subItemId);
    if (!parentReq || !existing) {
      return {
        success: false,
        error: isIndonesian ? 'Permintaan atau Sub Item tidak ditemukan.' : 'Request or Sub Item not found.',
      };
    }
    if (!canApproveSubItem(existing, parentReq)) {
      showToast(
        isIndonesian
          ? 'Tidak Diizinkan: Hanya Super Admin dan Marcomm Admin yang dapat menyetujui Sub Item.'
          : 'Unauthorized: Only Super Admin and Marcomm Admin can approve Sub Items.',
        'error'
      );
      return { success: false, error: isIndonesian ? 'Tidak diizinkan.' : 'Unauthorized.' };
    }

    try {
      const resp = await fetch(`/api/requests/${parentRequestId}/sub-items/${subItemId}/approve`, {
        method: 'POST',
        headers: authHeaders(true),
        credentials: 'include',
        cache: 'no-store',
      });
      const data = await resp.json().catch(() => ({}));
      if (!resp.ok || !data.success) {
        const errMsg =
          data.error ||
          (isIndonesian ? 'Validasi persetujuan server gagal.' : 'Server approval validation failed.');
        showToast(errMsg, 'error');
        return { success: false, error: errMsg };
      }
      await syncNow({ force: true });
      showToast(
        isIndonesian
          ? `Sub Item "${existing.title}" disetujui dan selesai!`
          : `Sub Item "${existing.title}" approved and completed!`,
        'success'
      );
      return { success: true };
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : 'Network error';
      showToast(msg, 'error');
      return { success: false, error: msg };
    }
  };

  const reconcileSubItemApproval = async (
    parentRequestId: string,
    subItemId: string,
    verifiedDate: string,
    justification: string
  ): Promise<{ success: boolean; error?: string }> => {
    const parentReq = requests.find((r) => r.id === parentRequestId);
    const existing = parentReq?.subItems?.find((s) => s.id === subItemId);
    if (!parentReq || !existing) {
      return {
        success: false,
        error: isIndonesian ? 'Permintaan atau Sub Item tidak ditemukan.' : 'Request or Sub Item not found.',
      };
    }
    if (currentUser.role !== 'super_admin' && currentUser.role !== 'admin') {
      showToast(
        isIndonesian
          ? 'Tidak Diizinkan: Hanya Super Admin dan Marcomm Admin yang dapat merekonsiliasi catatan persetujuan.'
          : 'Unauthorized: Only Super Admin and Marcomm Admin can reconcile approval records.',
        'error'
      );
      return { success: false, error: isIndonesian ? 'Tidak diizinkan.' : 'Unauthorized.' };
    }

    try {
      const resp = await fetch(`/api/requests/${parentRequestId}/sub-items/${subItemId}/reconcile-approval`, {
        method: 'POST',
        headers: authHeaders(true),
        credentials: 'include',
        cache: 'no-store',
        body: JSON.stringify({ verifiedApprovalDate: verifiedDate, justification }),
      });
      const data = await resp.json().catch(() => ({}));
      if (!resp.ok || !data.success) {
        const errMsg =
          data.error || (isIndonesian ? 'Rekonsiliasi server gagal.' : 'Server reconciliation failed.');
        showToast(errMsg, 'error');
        return { success: false, error: errMsg };
      }
      await syncNow({ force: true });
      showToast(
        isIndonesian
          ? `Tanggal persetujuan untuk "${existing.title}" berhasil direkonsiliasi!`
          : `Approval date for "${existing.title}" successfully reconciled!`,
        'success'
      );
      return { success: true };
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : 'Network error';
      showToast(msg, 'error');
      return { success: false, error: msg };
    }
  };

  const markNotificationAsRead = async (id: string) => {
    setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, isRead: true } : n)));
    await fetch(`/api/notifications/${id}/read`, {
      method: 'POST',
      headers: authHeaders(false),
      credentials: 'include',
      cache: 'no-store',
    }).catch(() => {});
  };

  const markAllNotificationsAsRead = async () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, isRead: true })));
    await fetch('/api/notifications/read-all', {
      method: 'POST',
      headers: authHeaders(false),
      credentials: 'include',
      cache: 'no-store',
    }).catch(() => {});
  };

  const exportCsv = () => {
    StorageService.exportRequestsToCsv(filteredRequests, isIndonesian);
    showToast(
      isIndonesian ? 'Laporan CSV berhasil diunduh' : 'CSV report downloaded successfully',
      'success'
    );
  };

  // Helper for master data API mutations
  const mutateMaster = async (
    url: string,
    method: 'POST' | 'PUT' | 'DELETE',
    body: unknown | undefined,
    successMsg: string
  ): Promise<boolean> => {
    try {
      const res = await fetch(url, {
        method,
        headers: authHeaders(body !== undefined),
        credentials: 'include',
        cache: 'no-store',
        body: body !== undefined ? JSON.stringify(body) : undefined,
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok || !data.success) {
        showToast(
          data.error || (isIndonesian ? 'Gagal menyimpan perubahan master data.' : 'Failed to save master data.'),
          'error'
        );
        return false;
      }
      await fetchMasterData();
      await syncNow({ force: true });
      showToast(successMsg, 'success');
      return true;
    } catch (e: unknown) {
      showToast(e instanceof Error ? e.message : 'Network error', 'error');
      return false;
    }
  };

  const saveMasterData = {
    addBrand: (brand: Omit<Brand, 'id'>) =>
      mutateMaster(
        '/api/master-data/brands',
        'POST',
        brand,
        isIndonesian ? `Brand "${brand.name}" berhasil ditambahkan` : `Brand "${brand.name}" added successfully`
      ),
    updateBrand: (brand: Brand) =>
      mutateMaster(
        `/api/master-data/brands/${brand.id}`,
        'PUT',
        brand,
        isIndonesian ? `Brand "${brand.name}" berhasil diperbarui` : `Brand "${brand.name}" updated successfully`
      ),
    deleteBrand: (id: string) => {
      const item = brands.find((b) => b.id === id);
      return mutateMaster(
        `/api/master-data/brands/${id}`,
        'DELETE',
        undefined,
        isIndonesian
          ? `Brand "${item?.name || id}" berhasil dihapus`
          : `Brand "${item?.name || id}" deleted successfully`
      );
    },
    addUnit: (unit: Omit<Unit, 'id'>) =>
      mutateMaster(
        '/api/master-data/units',
        'POST',
        unit,
        isIndonesian
          ? `Unit internal "${unit.name}" berhasil ditambahkan`
          : `Internal unit "${unit.name}" added successfully`
      ),
    updateUnit: (unit: Unit) =>
      mutateMaster(
        `/api/master-data/units/${unit.id}`,
        'PUT',
        unit,
        isIndonesian ? `Unit "${unit.name}" berhasil diperbarui` : `Unit "${unit.name}" updated successfully`
      ),
    deleteUnit: (id: string) => {
      const item = units.find((u) => u.id === id);
      return mutateMaster(
        `/api/master-data/units/${id}`,
        'DELETE',
        undefined,
        isIndonesian ? `Unit "${item?.name || id}" berhasil dihapus` : `Unit "${item?.name || id}" deleted successfully`
      );
    },
    addDepartment: (dept: Omit<Department, 'id'>) =>
      mutateMaster(
        '/api/master-data/departments',
        'POST',
        dept,
        isIndonesian
          ? `Departemen "${dept.name}" berhasil ditambahkan`
          : `Department "${dept.name}" added successfully`
      ),
    updateDepartment: (dept: Department) =>
      mutateMaster(
        `/api/master-data/departments/${dept.id}`,
        'PUT',
        dept,
        isIndonesian
          ? `Departemen "${dept.name}" berhasil diperbarui`
          : `Department "${dept.name}" updated successfully`
      ),
    deleteDepartment: (id: string) => {
      const item = departments.find((d) => d.id === id);
      return mutateMaster(
        `/api/master-data/departments/${id}`,
        'DELETE',
        undefined,
        isIndonesian
          ? `Departemen "${item?.name || id}" berhasil dihapus`
          : `Department "${item?.name || id}" deleted successfully`
      );
    },
    addCategory: (cat: Omit<Category, 'id'>) =>
      mutateMaster(
        '/api/master-data/categories',
        'POST',
        cat,
        isIndonesian
          ? `Kategori "${cat.name}" berhasil ditambahkan`
          : `Category "${cat.name}" added successfully`
      ),
    updateCategory: (cat: Category) =>
      mutateMaster(
        `/api/master-data/categories/${cat.id}`,
        'PUT',
        cat,
        isIndonesian
          ? `Kategori "${cat.name}" berhasil diperbarui`
          : `Category "${cat.name}" updated successfully`
      ),
    deleteCategory: (id: string) => {
      const item = categories.find((c) => c.id === id);
      return mutateMaster(
        `/api/master-data/categories/${id}`,
        'DELETE',
        undefined,
        isIndonesian
          ? `Kategori "${item?.name || id}" berhasil dihapus`
          : `Category "${item?.name || id}" deleted successfully`
      );
    },
    addTeam: (team: Omit<Team, 'id'>) =>
      mutateMaster(
        '/api/master-data/teams',
        'POST',
        team,
        isIndonesian ? `Tim "${team.name}" berhasil ditambahkan` : `Team "${team.name}" added successfully`
      ),
    updateTeam: (team: Team) =>
      mutateMaster(
        `/api/master-data/teams/${team.id}`,
        'PUT',
        team,
        isIndonesian ? `Tim "${team.name}" berhasil diperbarui` : `Team "${team.name}" updated successfully`
      ),
    deleteTeam: (id: string) => {
      const item = teams.find((t) => t.id === id);
      return mutateMaster(
        `/api/master-data/teams/${id}`,
        'DELETE',
        undefined,
        isIndonesian ? `Tim "${item?.name || id}" berhasil dihapus` : `Team "${item?.name || id}" deleted successfully`
      );
    },
    addRegion: (region: Omit<Region, 'id'>) =>
      mutateMaster(
        '/api/master-data/regions',
        'POST',
        region,
        isIndonesian
          ? `Wilayah "${region.name}" berhasil ditambahkan`
          : `Region "${region.name}" added successfully`
      ),
    updateRegion: (region: Region) =>
      mutateMaster(
        `/api/master-data/regions/${region.id}`,
        'PUT',
        region,
        isIndonesian
          ? `Wilayah "${region.name}" berhasil diperbarui`
          : `Region "${region.name}" updated successfully`
      ),
    deleteRegion: (id: string) => {
      const item = regions.find((r) => r.id === id);
      return mutateMaster(
        `/api/master-data/regions/${id}`,
        'DELETE',
        undefined,
        isIndonesian
          ? `Wilayah "${item?.name || id}" berhasil dihapus`
          : `Region "${item?.name || id}" deleted successfully`
      );
    },
  };

  // Priority Quota Governance methods (always pass credentials: 'include' & cache: 'no-store')
  const fetchBrandQuota = useCallback(
    async (brandId: string, brandName?: string, year?: number): Promise<BrandQuotaSummary | null> => {
      try {
        const q = new URLSearchParams();
        if (brandName) q.append('brandName', brandName);
        if (year) q.append('year', String(year));
        const res = await fetch(`/api/quotas/${brandId}?${q.toString()}`, {
          credentials: 'include',
          cache: 'no-store',
        });
        if (res.ok) {
          const data = await res.json();
          return data.summary || null;
        }
        return null;
      } catch (e) {
        console.error('fetchBrandQuota error:', e);
        return null;
      }
    },
    []
  );

  const fetchAllBrandQuotas = useCallback(async (year?: number): Promise<BrandQuotaSummary[]> => {
    try {
      const q = new URLSearchParams();
      if (year) q.append('year', String(year));
      q.append('brands', JSON.stringify(brandsRef.current.map((b) => ({ id: b.id, name: b.name }))));
      const res = await fetch(`/api/quotas?${q.toString()}`, {
        credentials: 'include',
        cache: 'no-store',
      });
      if (res.ok) {
        const data = await res.json();
        return data.summaries || [];
      }
      return [];
    } catch (e) {
      console.error('fetchAllBrandQuotas error:', e);
      return [];
    }
  }, []);

  const adjustBrandQuota = useCallback(
    async (
      brandId: string,
      brandName: string,
      priority: RequestPriority,
      quantity: number,
      reason: string,
      year?: number
    ): Promise<{ success: boolean; newRemaining?: number; error?: string }> => {
      try {
        const res = await fetch('/api/quotas/adjust', {
          method: 'POST',
          headers: authHeaders(true),
          credentials: 'include',
          cache: 'no-store',
          body: JSON.stringify({ brandId, brandName, priority, quantity, reason, year }),
        });
        const data = await res.json();
        if (res.ok && data.success) {
          await syncNow({ force: true });
          return { success: true, newRemaining: data.newRemaining };
        }
        return { success: false, error: data.error || 'Gagal menyesuaikan kuota.' };
      } catch (e: unknown) {
        return { success: false, error: e instanceof Error ? e.message : 'Network error' };
      }
    },
    [authHeaders, syncNow]
  );

  const updateBrandQuotaLimits = useCallback(
    async (
      brandId: string,
      limits: { urgent?: number; high?: number; medium?: number },
      year?: number
    ): Promise<{ success: boolean; error?: string }> => {
      try {
        const res = await fetch('/api/quotas/policies', {
          method: 'PUT',
          headers: authHeaders(true),
          credentials: 'include',
          cache: 'no-store',
          body: JSON.stringify({ brandId, limits, year }),
        });
        const data = await res.json();
        if (res.ok && data.success) {
          await syncNow({ force: true });
          return { success: true };
        }
        return { success: false, error: data.error || 'Gagal memperbarui batas kuota.' };
      } catch (e: unknown) {
        return { success: false, error: e instanceof Error ? e.message : 'Network error' };
      }
    },
    [authHeaders, syncNow]
  );

  const fetchReconciliationPreview = useCallback(
    async (year?: number): Promise<PriorityQuotaReconciliationPreview | null> => {
      try {
        const res = await fetch('/api/quotas/reconciliation/preview', {
          method: 'POST',
          headers: authHeaders(true),
          credentials: 'include',
          cache: 'no-store',
          body: JSON.stringify({
            brands: brandsRef.current.map((b) => ({ id: b.id, name: b.name })),
            requests: requestsRef.current,
            year,
          }),
        });
        if (res.ok) {
          const data = await res.json();
          return data.preview || null;
        }
        return null;
      } catch (e) {
        console.error('fetchReconciliationPreview error:', e);
        return null;
      }
    },
    [authHeaders]
  );

  const applyReconciliation = useCallback(
    async (year?: number): Promise<{ success: boolean; appliedCount?: number; error?: string }> => {
      try {
        const res = await fetch('/api/quotas/reconciliation/apply', {
          method: 'POST',
          headers: authHeaders(true),
          credentials: 'include',
          cache: 'no-store',
          body: JSON.stringify({
            brands: brandsRef.current.map((b) => ({ id: b.id, name: b.name })),
            requests: requestsRef.current,
            year,
          }),
        });
        const data = await res.json();
        if (res.ok && data.success) {
          await syncNow({ force: true });
          return { success: true, appliedCount: data.appliedCount };
        }
        return { success: false, error: data.error || 'Gagal menerapkan rekonsiliasi kuota.' };
      } catch (e: unknown) {
        return { success: false, error: e instanceof Error ? e.message : 'Network error' };
      }
    },
    [authHeaders, syncNow]
  );

  const fetchPeriodReportingMetrics = useCallback(
    async (
      brandId: string,
      brandName?: string,
      startDate?: string,
      endDate?: string,
      year?: number,
      mode?: ReportingPeriodMode
    ): Promise<PeriodReportingMetrics | null> => {
      try {
        const q = new URLSearchParams();
        q.append('brandId', brandId);
        if (brandName) q.append('brandName', brandName);
        if (startDate) q.append('startDate', startDate);
        if (endDate) q.append('endDate', endDate);
        if (year) q.append('year', String(year));
        if (mode) q.append('mode', mode);

        const res = await fetch(`/api/quotas/reporting?${q.toString()}`, {
          credentials: 'include',
          cache: 'no-store',
        });
        if (res.ok) {
          const data = await res.json();
          return data.metrics || null;
        }
        return null;
      } catch (e) {
        console.error('fetchPeriodReportingMetrics error:', e);
        return null;
      }
    },
    []
  );

  const fetchAvailableQuotaYears = useCallback(async (): Promise<{ activeYear: number; years: number[] } | null> => {
    try {
      const res = await fetch('/api/quotas/years', { credentials: 'include', cache: 'no-store' });
      if (res.ok) {
        const data = await res.json();
        if (data.success && Array.isArray(data.years)) {
          return { activeYear: data.activeYear, years: data.years };
        }
      }
      return null;
    } catch (e) {
      console.error('fetchAvailableQuotaYears error:', e);
      return null;
    }
  }, []);

  return (
    <RequestContext.Provider
      value={{
        requests,
        filteredRequests,
        regions,
        brands,
        units,
        departments,
        categories,
        teams,
        notifications,
        unreadNotificationCount,
        lastSyncedAt,
        isSyncing,
        syncVersion,
        syncNow,
        filters,
        setFilters,
        resetFilters,
        analytics,
        overviewWorkItems,
        toasts,

        removeToast,
        showToast,
        createRequest,
        updateRequestBrief,
        assignRequest,
        updateCommittedDeadline,
        changeStatus,
        reopenRequest,
        addDeliverable,
        addSubItem,
        updateSubItem,
        deleteSubItem,
        updateSubItemProgress,
        approveSubItem,
        reconcileSubItemApproval,
        fetchBrandQuota,
        fetchAllBrandQuotas,
        adjustBrandQuota,
        updateBrandQuotaLimits,
        fetchReconciliationPreview,
        applyReconciliation,
        fetchPeriodReportingMetrics,
        fetchAvailableQuotaYears,
        markNotificationAsRead,
        markAllNotificationsAsRead,
        exportCsv,
        saveMasterData,
      }}
    >
      {children}
    </RequestContext.Provider>
  );
};

export const useRequests = (): RequestContextType => {
  const context = useContext(RequestContext);
  if (!context) {
    throw new Error('useRequests must be used within a RequestProvider');
  }
  return context;
};
