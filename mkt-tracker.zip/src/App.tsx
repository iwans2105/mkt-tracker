import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { RequestProvider, useRequests } from './context/RequestContext';
import { LanguageProvider, useLanguage } from './context/LanguageContext';
import { Header } from './components/layout/Header';
import { Sidebar, ActiveNavTab } from './components/layout/Sidebar';
import { LoginPage } from './components/auth/LoginPage';
import { ForcePasswordChangeScreen } from './components/auth/ForcePasswordChangeScreen';
import { RequestFilterBar } from './components/requests/RequestFilterBar';
import { RequestTableView } from './components/requests/RequestTableView';
import { RequestKanbanView } from './components/requests/RequestKanbanView';
import { CreateRequestModal } from './components/form/CreateRequestModal';
import { PublicRequestPage } from './components/form/PublicRequestPage';
import { RequestDetailDrawer } from './components/detail/RequestDetailDrawer';
import { AnalyticsDashboard } from './components/analytics/AnalyticsDashboard';
import { WorkloadView } from './components/analytics/WorkloadView';
import { PdfReportModal } from './components/analytics/PdfReportModal';
import { UserManagementView } from './components/admin/UserManagementView';
import { MasterDataView } from './components/admin/MasterDataView';
import { SettingsView } from './components/admin/SettingsView';
import { UserProfileView } from './components/profile/UserProfileView';
import { AiHubView } from './components/ai/AiHubView';
import { PriorityQuotaWidget } from './components/dashboard/PriorityQuotaWidget';
import { ToastContainer } from './components/common/ToastContainer';
import { RequestStatus } from './types';
import {
  ListTodo,
  TrendingUp,
  Clock,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  PlusCircle,
  FileText,
  Layers,
  Archive,
  User,
  Building2,
} from 'lucide-react';

const MainAppContent: React.FC = () => {
  const { currentUser, isSuperAdmin, isAdmin, isRequester, isTeamMember } = useAuth();
  const { t, isIndonesian } = useLanguage();
  const {
    filteredRequests,
    requests,
    analytics,
    overviewWorkItems,
    filters,
    setFilters,
    toasts,
    removeToast,
    exportCsv,
  } = useRequests();


  // Navigation and view state with role-aware default landing
  const [activeNavTab, setActiveNavTab] = useState<ActiveNavTab>(() => {
    if (isRequester) return 'dashboard';
    if (isTeamMember && !isAdmin) return 'requests';
    return 'dashboard';
  });

  // Guard against forbidden tabs when role changes or unauthorized access is attempted
  useEffect(() => {
    if (isRequester && ['workload', 'analytics', 'users', 'master_data', 'settings', 'ai_hub'].includes(activeNavTab)) {
      setActiveNavTab('dashboard');
    } else if (isTeamMember && !isAdmin && ['users', 'master_data', 'settings', 'analytics'].includes(activeNavTab)) {
      setActiveNavTab('requests');
    } else if (isAdmin && !isSuperAdmin && ['users', 'master_data', 'settings'].includes(activeNavTab)) {
      setActiveNavTab('dashboard');
    }
  }, [currentUser.role, isRequester, isTeamMember, isAdmin, isSuperAdmin, activeNavTab]);
  const [viewMode, setViewMode] = useState<'table' | 'kanban'>('table');
  const [groupByMode, setGroupByMode] = useState<'status' | 'requestor' | 'none'>('status');
  const [completedGroupByMode, setCompletedGroupByMode] = useState<'brand' | 'requestor' | 'none'>('brand');

  // Active requests (exclude completed) vs Completed requests
  const activeRequests = filteredRequests.filter((r) => r.status !== 'completed');
  const completedRequests = filteredRequests.filter((r) => r.status === 'completed');

  // Modals state
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [createPrefill, setCreatePrefill] = useState<{
    title?: string;
    description?: string;
    deliverables?: string;
    priority?: 'urgent' | 'high' | 'medium' | 'low';
    categoryId?: string;
  } | null>(null);
  const [isPdfReportOpen, setIsPdfReportOpen] = useState(false);
  const [selectedRequestId, setSelectedRequestId] = useState<string | null>(null);
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);

  const getNavTitle = (): string => {
    switch (activeNavTab) {
      case 'dashboard':
        return t('nav.dashboard');
      case 'requests':
        if (isRequester) return isIndonesian ? 'Permintaan Saya (Aktif)' : 'My Requests (Active)';
        if (isTeamMember && !isAdmin) return isIndonesian ? 'Tugas Saya (Aktif)' : 'My Assigned Tasks (Active)';
        return t('nav.requests');
      case 'completed':
        return t('nav.completed');
      case 'ai_hub':
        return t('nav.ai_hub');
      case 'workload':
        return t('nav.workload');
      case 'analytics':
        return t('nav.analytics');
      case 'users':
        return t('nav.users');
      case 'master_data':
        return t('nav.master_data');
      case 'settings':
        return t('nav.settings');
      case 'profile':
        return t('nav.profile');
      default:
        return 'MARCOMM PRO';
    }
  };

  const handleFilterByStatus = (status: RequestStatus) => {
    if (status === 'completed') {
      setActiveNavTab('completed');
    } else {
      setFilters((prev) => ({ ...prev, status }));
      setActiveNavTab('requests');
    }
  };

  const handleCreateSuccess = (requestId: string) => {
    setSelectedRequestId(requestId);
    setActiveNavTab('requests');
  };

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (isIndonesian) {
      if (hour < 11) return 'Selamat Pagi';
      if (hour < 15) return 'Selamat Siang';
      if (hour < 18) return 'Selamat Sore';
      return 'Selamat Malam';
    }
    if (hour < 12) return 'Good Morning';
    if (hour < 18) return 'Good Afternoon';
    return 'Good Evening';
  };

  return (
    <div className="flex min-h-screen bg-[#F7FAF8] text-[#111827] font-sans antialiased">
      {/* Sidebar Navigation */}
      <Sidebar
        activeTab={activeNavTab}
        onSelectTab={setActiveNavTab}
        isOpenMobile={isMobileSidebarOpen}
        onCloseMobile={() => setIsMobileSidebarOpen(false)}
        onOpenCreateModal={() => setIsCreateModalOpen(true)}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top Header */}
        <Header
          onOpenCreateModal={() => setIsCreateModalOpen(true)}
          onToggleMobileSidebar={() => setIsMobileSidebarOpen(!isMobileSidebarOpen)}
          onSelectRequestDetail={(id) => setSelectedRequestId(id)}
          currentViewTitle={getNavTitle()}
        />

        {/* Content View Container */}
        <main className="flex-1 p-4 md:p-8 max-w-7xl w-full mx-auto space-y-6">
          {/* 1. Dashboard View */}
          {activeNavTab === 'dashboard' && (
            <div className="space-y-6">
              {/* Welcome Banner */}
              <div className="p-5 sm:p-6 bg-white rounded-2xl border border-[#E5E7EB] shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4 sm:gap-5 relative overflow-hidden">
                <div className="space-y-1.5 relative z-10 min-w-0">
                  <div className="flex items-center gap-2.5 flex-wrap">
                    <h2 className="text-xl sm:text-2xl font-bold text-[#111827] tracking-tight truncate">
                      {getGreeting()}, {currentUser.fullName} 👋
                    </h2>
                    <span className="text-[11px] sm:text-xs px-2.5 py-0.5 rounded-md bg-[#D1FAE5] text-[#065F46] font-bold border border-[#A7F3D0] capitalize shrink-0">
                      {currentUser.role.replace('_', ' ')}
                    </span>
                  </div>
                  <p className="text-xs text-[#64748B] leading-relaxed max-w-xl">
                    {isIndonesian
                      ? 'Sistem pelacakan tugas komunikasi pemasaran & alur kerja deliverable terpusat untuk Lyman Group di Jakarta & Bandung.'
                      : 'Centralized marketing communications task tracking & deliverable workflow system for Lyman Group across Jakarta & Bandung.'}
                  </p>
                </div>

                <div className="flex items-center gap-2 sm:gap-2.5 relative z-10 shrink-0 flex-wrap sm:flex-nowrap">
                  <button
                    onClick={() => setIsCreateModalOpen(true)}
                    className="flex-1 sm:flex-initial flex items-center justify-center gap-2 px-4 py-2.5 text-xs font-bold text-white bg-[#065F46] hover:bg-[#044e39] rounded-xl transition-all shadow-xs hover:shadow-md cursor-pointer whitespace-nowrap active:scale-[0.98]"
                  >
                    <PlusCircle className="w-4 h-4 shrink-0" />
                    <span>{t('common.newRequest')}</span>
                  </button>
                  <button
                    onClick={() => setActiveNavTab('requests')}
                    className="flex-1 sm:flex-initial flex items-center justify-center gap-2 px-4 py-2.5 text-xs font-semibold text-[#111827] bg-white hover:bg-[#F0FDF4] border border-[#E5E7EB] rounded-xl transition-colors cursor-pointer whitespace-nowrap"
                  >
                    <ListTodo className="w-4 h-4 text-[#065F46] shrink-0" />
                    <span>{isIndonesian ? 'Daftar Tugas' : 'Task Pipeline'}</span>
                  </button>
                </div>
              </div>

              {/* Fast Snapshot Metrics with Dynamic Work Item Counting */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5 sm:gap-4">
                <div
                  onClick={() => handleFilterByStatus('todo')}
                  title={
                    isIndonesian
                      ? 'Menghitung item kerja aktif. Permintaan Utama tanpa Sub Item dihitung 1; Permintaan dengan Sub Item dihitung berdasarkan Sub Item aktifnya.'
                      : 'Counts actionable work items. Parent Requests without Sub Items count as one; Requests with Sub Items count by their active Sub Items.'
                  }
                  className="p-4 sm:p-5 bg-white rounded-2xl border border-[#E5E7EB] shadow-2xs hover:border-slate-400 hover:-translate-y-0.5 hover:shadow-md cursor-pointer transition-all duration-200 group"
                >
                  <div className="flex items-center justify-between text-xs text-[#64748B] mb-1.5 sm:mb-2">
                    <span className="font-semibold truncate">{t('status.todo')}</span>
                    <span className="w-2.5 h-2.5 rounded-full bg-slate-400 shrink-0 ml-1" />
                  </div>
                  <div className="text-2xl sm:text-3xl font-extrabold text-[#111827] font-mono tabular-nums tracking-tight">
                    {overviewWorkItems.todoWorkItems}
                  </div>
                  <div className="text-[11px] text-[#64748B] mt-1 flex items-center justify-between font-medium truncate">
                    <span>{isIndonesian ? 'Menunggu mulai' : 'Pending kickoff'}</span>
                    <span className="text-[10px] text-slate-400 font-mono">
                      {isIndonesian ? 'Item Kerja' : 'Work Items'}
                    </span>
                  </div>
                </div>

                <div
                  onClick={() => handleFilterByStatus('in_progress')}
                  title={
                    isIndonesian
                      ? 'Menghitung item kerja aktif. Permintaan Utama tanpa Sub Item dihitung 1; Permintaan dengan Sub Item dihitung berdasarkan Sub Item aktifnya.'
                      : 'Counts actionable work items. Parent Requests without Sub Items count as one; Requests with Sub Items count by their active Sub Items.'
                  }
                  className="p-4 sm:p-5 bg-white rounded-2xl border border-[#E5E7EB] shadow-2xs hover:border-blue-400 hover:-translate-y-0.5 hover:shadow-md cursor-pointer transition-all duration-200 group"
                >
                  <div className="flex items-center justify-between text-xs text-blue-700 mb-1.5 sm:mb-2">
                    <span className="font-semibold truncate">{t('status.in_progress')}</span>
                    <span className="w-2.5 h-2.5 rounded-full bg-blue-500 shrink-0 ml-1" />
                  </div>
                  <div className="text-2xl sm:text-3xl font-extrabold text-blue-700 font-mono tabular-nums tracking-tight">
                    {overviewWorkItems.inProgressWorkItems}
                  </div>
                  <div className="text-[11px] text-blue-600/80 mt-1 flex items-center justify-between font-medium truncate">
                    <span>{isIndonesian ? 'Sedang diproduksi' : 'In active production'}</span>
                    <span className="text-[10px] text-blue-400 font-mono">
                      {isIndonesian ? 'Item Kerja' : 'Work Items'}
                    </span>
                  </div>
                </div>

                <div
                  onClick={() => handleFilterByStatus('pending_review')}
                  title={
                    isIndonesian
                      ? 'Menghitung item kerja aktif. Permintaan Utama tanpa Sub Item dihitung 1; Permintaan dengan Sub Item dihitung berdasarkan Sub Item aktifnya.'
                      : 'Counts actionable work items. Parent Requests without Sub Items count as one; Requests with Sub Items count by their active Sub Items.'
                  }
                  className="p-4 sm:p-5 bg-white rounded-2xl border border-[#E5E7EB] shadow-2xs hover:border-purple-400 hover:-translate-y-0.5 hover:shadow-md cursor-pointer transition-all duration-200 group"
                >
                  <div className="flex items-center justify-between text-xs text-purple-700 mb-1.5 sm:mb-2">
                    <span className="font-semibold truncate">{t('status.pending_review')}</span>
                    <span className="w-2.5 h-2.5 rounded-full bg-purple-500 shrink-0 ml-1" />
                  </div>
                  <div className="text-2xl sm:text-3xl font-extrabold text-purple-700 font-mono tabular-nums tracking-tight">
                    {overviewWorkItems.pendingReviewWorkItems}
                  </div>
                  <div className="text-[11px] text-purple-600/80 mt-1 flex items-center justify-between font-medium truncate">
                    <span>{isIndonesian ? 'Menunggu persetujuan' : 'Awaiting approval'}</span>
                    <span className="text-[10px] text-purple-400 font-mono">
                      {isIndonesian ? 'Item Kerja' : 'Work Items'}
                    </span>
                  </div>
                </div>

                <div
                  onClick={() => handleFilterByStatus('completed')}
                  title={
                    isIndonesian
                      ? 'Menghitung item kerja yang selesai. Permintaan Utama tanpa Sub Item dihitung 1; Permintaan dengan Sub Item dihitung berdasarkan Sub Item aktif yang selesai.'
                      : 'Counts completed actionable work items. Parent Requests without Sub Items count as one; Requests with Sub Items count by their completed active Sub Items.'
                  }
                  className="p-4 sm:p-5 bg-white rounded-2xl border border-[#E5E7EB] shadow-2xs hover:border-emerald-500 hover:-translate-y-0.5 hover:shadow-md cursor-pointer transition-all duration-200 group"
                >
                  <div className="flex items-center justify-between text-xs text-[#065F46] mb-1.5 sm:mb-2">
                    <span className="font-semibold truncate">{t('status.completed')}</span>
                    <CheckCircle2 className="w-4 h-4 text-[#10B981] shrink-0 ml-1" />
                  </div>
                  <div className="text-2xl sm:text-3xl font-extrabold text-[#065F46] font-mono tabular-nums tracking-tight">
                    {overviewWorkItems.completedWorkItems}
                  </div>
                  <div className="text-[11px] text-[#065F46] mt-1 flex items-center justify-between font-semibold truncate">
                    <span>
                      {isIndonesian
                        ? `Dari ${overviewWorkItems.contributingParentRequests} Permintaan Utama`
                        : `Across ${overviewWorkItems.contributingParentRequests} Parent Requests`}
                    </span>
                    <span className="text-[10px] text-emerald-600 font-mono">
                      {analytics.slaFulfillmentRate !== null
                        ? `SLA ${analytics.slaFulfillmentRate}%`
                        : isIndonesian
                        ? 'Item Kerja'
                        : 'Work Items'}
                    </span>
                  </div>
                </div>
              </div>

              {/* Priority Quota Overview Widget */}
              <PriorityQuotaWidget onNavigateToQuotaSettings={() => setActiveNavTab('settings')} />

              {/* Recent Requests Section */}
              <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-4 sm:p-6 space-y-3.5">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-sm font-bold text-slate-900">
                      {isIndonesian ? 'Permintaan Pekerjaan Terbaru' : 'Recent Work Requests'}
                    </h3>
                    <p className="text-xs text-slate-500 mt-0.5">
                      {isIndonesian
                        ? 'Tugas aktif yang memerlukan perhatian dan peninjauan tim segera.'
                        : 'Active tasks requiring immediate team attention and review.'}
                    </p>
                  </div>
                  <button
                    onClick={() => setActiveNavTab('requests')}
                    className="text-xs font-semibold text-blue-600 hover:text-blue-800 flex items-center gap-1 hover:underline"
                  >
                    <span>{isIndonesian ? 'Lihat Semua' : 'View All'}</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>

                <RequestTableView
                  requests={filteredRequests.slice(0, 5)}
                  onSelectRequest={(id) => setSelectedRequestId(id)}
                />
              </div>
            </div>
          )}

          {/* 2. Requests List View (Table & Kanban) - Active Requests Grouped by Status */}
          {activeNavTab === 'requests' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-3.5 sm:p-4 rounded-2xl border border-slate-200 shadow-2xs">
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="text-sm sm:text-base font-bold text-slate-900">
                      {isIndonesian ? `Alur Kerja Aktif (${activeRequests.length})` : `Active Work Pipeline (${activeRequests.length})`}
                    </h2>
                    <span className="text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200 hidden sm:inline">
                      {isIndonesian ? 'Pengelompokan Status Langsung' : 'Live Status Grouping'}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 mt-0.5">
                    {isIndonesian
                      ? 'Tugas diatur berdasarkan tahapan status (Antrean → Sedang Dikerjakan → Menunggu Review → Perlu Revisi → Ditunda).'
                      : 'Tasks are organized by status stage (To Do → In Progress → Pending Review → Revision → On Hold).'}
                  </p>
                </div>

                {viewMode === 'table' && (
                  <div className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-xl border border-slate-200 shrink-0 self-end sm:self-auto text-xs">
                    <span className="text-[11px] text-slate-500 font-semibold px-1.5 hidden md:inline">
                      {isIndonesian ? 'Kelompokkan:' : 'Group By:'}
                    </span>
                    <button
                      type="button"
                      onClick={() => setGroupByMode('status')}
                      className={`px-2.5 py-1 rounded-lg font-semibold transition-colors ${
                        groupByMode === 'status'
                          ? 'bg-white text-[#065F46] font-bold shadow-xs'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      Status
                    </button>
                    <button
                      type="button"
                      onClick={() => setGroupByMode('requestor')}
                      className={`px-2.5 py-1 rounded-lg font-semibold transition-colors flex items-center gap-1 ${
                        groupByMode === 'requestor'
                          ? 'bg-[#065F46] text-white font-bold shadow-xs'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                      title={isIndonesian ? 'Kelompokkan permintaan berdasarkan Pemohon' : "Group requests by Requestor's Name"}
                    >
                      <User className="w-3 h-3" />
                      <span>{isIndonesian ? 'Pemohon' : 'Requestor'}</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setGroupByMode('none')}
                      className={`px-2.5 py-1 rounded-lg font-semibold transition-colors ${
                        groupByMode === 'none'
                          ? 'bg-white text-slate-900 font-bold shadow-xs'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      {isIndonesian ? 'Daftar Rata' : 'Flat'}
                    </button>
                  </div>
                )}
              </div>

              <RequestFilterBar
                viewMode={viewMode}
                onChangeViewMode={setViewMode}
                onExportCsv={exportCsv}
                totalFilteredCount={activeRequests.length}
                hideCompletedStatusFilter={true}
              />

              {viewMode === 'table' ? (
                <RequestTableView
                  requests={activeRequests}
                  onSelectRequest={(id) => setSelectedRequestId(id)}
                  groupByStatus={groupByMode === 'status'}
                  groupByRequestor={groupByMode === 'requestor'}
                />
              ) : (
                <RequestKanbanView
                  requests={activeRequests}
                  onSelectRequest={(id) => setSelectedRequestId(id)}
                  includeCompleted={false}
                />
              )}
            </div>
          )}

          {/* 3. Dedicated Completed Requests Page */}
          {activeNavTab === 'completed' && (
            <div className="space-y-4">
              {/* Header summary banner */}
              <div className="bg-gradient-to-r from-[#065F46] via-[#047857] to-[#064e3b] text-white p-5 sm:p-6 rounded-2xl border border-emerald-600/30 shadow-md">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="w-2.5 h-2.5 rounded-full bg-[#A7F3D0] animate-pulse" />
                      <span className="text-xs font-mono font-bold uppercase tracking-wider text-[#A7F3D0]">
                        {isIndonesian ? 'Arsip & Deliverable Selesai' : 'Archive & Completed Deliverables'}
                      </span>
                    </div>
                    <h2 className="text-lg sm:text-xl font-extrabold text-white">
                      {isIndonesian
                        ? `Arsip Permintaan Selesai (${completedRequests.length} Permintaan)`
                        : `Completed Requests Archive (${completedRequests.length} Requests)`}
                    </h2>
                    <p className="text-xs text-emerald-100 max-w-xl leading-relaxed">
                      {isIndonesian
                        ? 'Repositori lengkap seluruh deliverable final yang telah disetujui reviewer, siap diunduh kapan saja.'
                        : 'Comprehensive repository of all finalized deliverables approved by reviewers, available for download anytime.'}
                    </p>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      onClick={exportCsv}
                      className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-black/20 hover:bg-black/30 border border-white/20 rounded-xl transition-colors shadow-2xs"
                    >
                      <span>{t('common.exportCsv')}</span>
                    </button>
                    <button
                      onClick={() => setIsPdfReportOpen(true)}
                      className="flex items-center gap-1.5 px-4 py-2 text-xs font-bold text-[#065F46] bg-white hover:bg-slate-100 rounded-xl transition-colors shadow-xs"
                    >
                      <span>{t('common.printPdf')}</span>
                    </button>
                  </div>
                </div>
              </div>

              {/* Key SLA & Performance Metrics for Completed Requests */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="p-3.5 bg-white rounded-2xl border border-slate-200 shadow-2xs">
                  <div className="text-xs text-slate-500 mb-1">
                    {isIndonesian ? 'Item Pekerjaan Selesai' : 'Completed Work Items'}
                  </div>
                  <div className="text-xl sm:text-2xl font-extrabold text-[#065F46] font-mono tabular-nums">
                    {overviewWorkItems.completedWorkItems}
                  </div>
                  <div className="text-[10px] text-slate-400 mt-0.5">
                    {isIndonesian
                      ? `Dari ${overviewWorkItems.contributingParentRequests} Permintaan Utama (${overviewWorkItems.completedParentRequests} terarsip)`
                      : `Across ${overviewWorkItems.contributingParentRequests} Parent Requests (${overviewWorkItems.completedParentRequests} archived)`}
                  </div>
                </div>

                <div className="p-3.5 bg-white rounded-2xl border border-slate-200 shadow-2xs">
                  <div className="text-xs text-slate-500 mb-1">
                    {isIndonesian ? 'Tepat Waktu (SLA)' : 'On-Time (SLA)'}
                  </div>
                  <div className="text-xl sm:text-2xl font-extrabold text-emerald-700 font-mono tabular-nums">
                    {completedRequests.filter((r) => r.slaFulfilled).length}
                  </div>
                  <div className="text-[10px] text-emerald-600 mt-0.5">
                    {isIndonesian ? 'Sesuai tenggat' : 'Met deadline'}
                  </div>
                </div>

                <div className="p-3.5 bg-white rounded-2xl border border-slate-200 shadow-2xs">
                  <div className="text-xs text-slate-500 mb-1">
                    {isIndonesian ? 'Selesai Terlambat' : 'Late Completion'}
                  </div>
                  <div className="text-xl sm:text-2xl font-extrabold text-amber-700 font-mono tabular-nums">
                    {completedRequests.filter((r) => r.committedDeadline && !r.slaFulfilled).length}
                  </div>
                  <div className="text-[10px] text-amber-600 mt-0.5">
                    {isIndonesian ? 'Melewati tenggat' : 'Missed deadline'}
                  </div>
                </div>

                <div className="p-3.5 bg-white rounded-2xl border border-slate-200 shadow-2xs">
                  <div className="text-xs text-slate-500 mb-1">
                    {isIndonesian ? 'Tingkat Kepatuhan SLA' : 'SLA Compliance Rate'}
                  </div>
                  <div className="text-xl sm:text-2xl font-extrabold text-blue-700 font-mono tabular-nums">
                    {analytics.slaFulfillmentRate !== null ? `${analytics.slaFulfillmentRate}%` : '—'}
                  </div>
                  <div className="text-[10px] text-blue-600 mt-0.5">
                    {analytics.slaFulfillmentRate !== null
                      ? (isIndonesian ? 'Rasio tepat waktu' : 'On-time ratio')
                      : (isIndonesian ? 'Tidak Ada Data' : 'No Data Available')}
                  </div>
                </div>
              </div>

              {/* Dedicated Filter Bar for Completed Requests */}
              <RequestFilterBar
                viewMode="table"
                onChangeViewMode={() => {}}
                onExportCsv={exportCsv}
                totalFilteredCount={completedRequests.length}
                hideStatusFilter={true}
                hideViewModeToggle={true}
              />

              {/* Grouping Control for Completed Requests */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-3.5 sm:p-4 rounded-2xl border border-slate-200 shadow-2xs">
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-sm sm:text-base font-bold text-slate-900">
                      {isIndonesian
                        ? `Arsip Hasil Kerja Selesai (${completedRequests.length})`
                        : `Completed Deliverables Archive (${completedRequests.length})`}
                    </h3>
                    <span className="text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200">
                      {completedGroupByMode === 'brand'
                        ? (isIndonesian ? 'Dikelompokkan per Brand' : 'Grouped by Brand')
                        : completedGroupByMode === 'requestor'
                        ? (isIndonesian ? 'Dikelompokkan per Pemohon' : "Grouped by Requestor's Name")
                        : (isIndonesian ? 'Daftar Rata' : 'Flat List')}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 mt-0.5">
                    {isIndonesian
                      ? 'Permintaan yang telah selesai dikategorikan ke dalam tabel khusus berdasarkan entitas Brand (contoh: Mason Pine Hotel, Wisma 46, Lyman Devindo).'
                      : 'Finalized requests are categorized into dedicated tables by Brand entity (e.g. Mason Pine Hotel, Wisma 46, Lyman Devindo).'}
                  </p>
                </div>

                <div className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-xl border border-slate-200 shrink-0 self-end sm:self-auto text-xs">
                  <span className="text-[11px] text-slate-500 font-semibold px-1.5 hidden md:inline">
                    {isIndonesian ? 'Kelompokkan:' : 'Group By:'}
                  </span>
                  <button
                    type="button"
                    onClick={() => setCompletedGroupByMode('brand')}
                    className={`px-2.5 py-1 rounded-lg font-semibold transition-colors flex items-center gap-1 ${
                      completedGroupByMode === 'brand'
                        ? 'bg-[#065F46] text-white font-bold shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                    title={isIndonesian ? 'Kelompokkan berdasarkan Brand' : 'Group completed requests by Brand'}
                  >
                    <Building2 className="w-3.5 h-3.5" />
                    <span>Brand</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setCompletedGroupByMode('requestor')}
                    className={`px-2.5 py-1 rounded-lg font-semibold transition-colors flex items-center gap-1 ${
                      completedGroupByMode === 'requestor'
                        ? 'bg-[#065F46] text-white font-bold shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                    title={isIndonesian ? 'Kelompokkan berdasarkan Pemohon' : 'Group completed requests by Requestor'}
                  >
                    <User className="w-3.5 h-3.5" />
                    <span>{isIndonesian ? 'Pemohon' : 'Requestor'}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setCompletedGroupByMode('none')}
                    className={`px-2.5 py-1 rounded-lg font-semibold transition-colors ${
                      completedGroupByMode === 'none'
                        ? 'bg-white text-slate-900 font-bold shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {isIndonesian ? 'Daftar Rata' : 'Flat'}
                  </button>
                </div>
              </div>

              {/* Table of completed requests grouped by Brand */}
              <RequestTableView
                requests={completedRequests}
                onSelectRequest={(id) => setSelectedRequestId(id)}
                groupByBrand={completedGroupByMode === 'brand'}
                groupByRequestor={completedGroupByMode === 'requestor'}
                groupByStatus={false}
                hideStatusColumn={true}
              />
            </div>
          )}

          {/* 3. AI Marcomm Hub View */}
          {activeNavTab === 'ai_hub' && (
            <AiHubView
              onOpenCreateWithPrefill={(prefill) => {
                setCreatePrefill(prefill);
                setIsCreateModalOpen(true);
              }}
              onSelectRequestDetail={(id) => setSelectedRequestId(id)}
            />
          )}

          {/* 4. Workload View */}
          {activeNavTab === 'workload' && (
            <WorkloadView onSelectRequest={(id) => setSelectedRequestId(id)} />
          )}

          {/* 5. Analytics View */}
          {activeNavTab === 'analytics' && (
            <AnalyticsDashboard
              onOpenPdfReport={() => setIsPdfReportOpen(true)}
              onFilterByStatus={handleFilterByStatus}
            />
          )}

          {/* 6. User Management View */}
          {activeNavTab === 'users' && <UserManagementView />}

          {/* 7. Master Data View */}
          {activeNavTab === 'master_data' && <MasterDataView />}

          {/* 8. Settings View */}
          {activeNavTab === 'settings' && <SettingsView />}

          {/* 9. User Profile View */}
          {activeNavTab === 'profile' && <UserProfileView />}
        </main>
      </div>

      {/* Detail Drawer Modal */}
      <RequestDetailDrawer
        requestId={selectedRequestId}
        onClose={() => setSelectedRequestId(null)}
      />

      {/* Create Request Modal */}
      <CreateRequestModal
        isOpen={isCreateModalOpen}
        onClose={() => {
          setIsCreateModalOpen(false);
          setCreatePrefill(null);
        }}
        onSuccess={handleCreateSuccess}
        initialPrefill={createPrefill}
      />

      {/* PDF Report Print Modal */}
      <PdfReportModal
        isOpen={isPdfReportOpen}
        onClose={() => setIsPdfReportOpen(false)}
      />

      {/* Notification Toast Container */}
      <ToastContainer toasts={toasts} onClose={removeToast} />
    </div>
  );
};

const isPublicRequestRoute = (): boolean => {
  if (typeof window === 'undefined') return false;
  const pathname = window.location.pathname.replace(/\/+$/, '') || '/';
  if (pathname === '/submit-request' || pathname === '/public-request') {
    return true;
  }
  const params = new URLSearchParams(window.location.search);
  return params.get('form') === 'public';
};

const AppRoot: React.FC = () => {
  const { isAuthenticated, isLoadingAuth, currentUser } = useAuth();
  const { isIndonesian } = useLanguage();

  if (isPublicRequestRoute()) {
    return <PublicRequestPage />;
  }

  if (isLoadingAuth) {
    return (
      <div className="min-h-screen bg-[#F7FAF8] flex flex-col items-center justify-center p-4">
        <img
          src="/assets/aistudio/Marcom-Task-Request-Tracker_cfd946e5.png"
          alt="MARCOMM Task-Request Tracker"
          className="w-14 h-14 object-contain animate-pulse mb-3 drop-shadow-md select-none"
          loading="eager"
          decoding="async"
          onError={(e) => {
            const target = e.currentTarget;
            if (!target.src.includes('/public/')) {
              target.src = '/public/assets/aistudio/Marcom-Task-Request-Tracker_cfd946e5.png';
            }
          }}
        />
        <div className="text-sm font-bold text-slate-800">MARCOMM TASK</div>
        <div className="text-xs text-slate-400 mt-1">
          {isIndonesian ? 'Memverifikasi sesi akun...' : 'Verifying account session...'}
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <LoginPage />;
  }

  if (currentUser?.mustChangePassword) {
    return <ForcePasswordChangeScreen />;
  }

  return (
    <RequestProvider>
      <MainAppContent />
    </RequestProvider>
  );
};


export default function App() {
  return (
    <LanguageProvider>
      <AuthProvider>
        <AppRoot />
      </AuthProvider>
    </LanguageProvider>
  );
}
