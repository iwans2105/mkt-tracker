import React, { useState } from 'react';
import { X, Trash2, AlertTriangle } from 'lucide-react';
import { RequestItem, SubItem } from '../../types';
import { useRequests } from '../../context/RequestContext';
import { useLanguage } from '../../context/LanguageContext';

interface DeleteSubItemModalProps {
  parentRequest: RequestItem;
  subItem: SubItem;
  onClose: () => void;
}

export const DeleteSubItemModal: React.FC<DeleteSubItemModalProps> = ({
  parentRequest,
  subItem,
  onClose,
}) => {
  const { deleteSubItem, showToast } = useRequests();
  const { isIndonesian } = useLanguage();
  const [reason, setReason] = useState('');
  const [isDeleting, setIsDeleting] = useState(false);

  const handleDelete = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!reason.trim() || reason.trim().length < 5) {
      showToast(
        isIndonesian
          ? 'Alasan penghapusan wajib diisi minimal 5 karakter.'
          : 'Mandatory deletion reason must be at least 5 characters.',
        'error'
      );
      return;
    }

    setIsDeleting(true);
    try {
      const res = await deleteSubItem(parentRequest.id, subItem.id, reason.trim());
      if (res.success) {
        onClose();
      }
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-white rounded-2xl p-6 max-w-md w-full border border-slate-200 shadow-2xl space-y-4 animate-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="flex items-start justify-between pb-3 border-b border-slate-200">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-rose-100 text-rose-600">
              <Trash2 className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                {isIndonesian ? 'Hapus Sementara Sub Item' : 'Soft-Delete Sub Item'}
              </h3>
              <p className="text-[11px] text-slate-500">
                {isIndonesian ? 'Tiket:' : 'Ticket:'} {parentRequest.ticketNumber}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1 rounded-lg"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleDelete} className="space-y-3.5 text-xs">
          {/* Target Item Card */}
          <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-1">
            <span className="text-[11px] font-semibold text-slate-500 block">
              {isIndonesian ? 'Sub Item yang akan dihapus:' : 'Sub Item to be deleted:'}
            </span>
            <strong className="text-slate-900 font-bold block text-sm">{subItem.title}</strong>
            {subItem.ownerName && (
              <span className="text-[11px] text-slate-600 block">
                {isIndonesian ? 'Penanggung Jawab:' : 'Owner:'} {subItem.ownerName}
              </span>
            )}
          </div>

          {/* Warning notice */}
          <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-900 text-xs leading-relaxed space-y-1">
            <div className="flex items-center gap-1.5 font-bold">
              <AlertTriangle className="w-3.5 h-3.5 text-rose-600" />
              <span>{isIndonesian ? 'Penghapusan Lunak Terkendali' : 'Controlled Soft Deletion'}</span>
            </div>
            <p className="text-[11px] text-rose-800">
              {isIndonesian
                ? 'Sub item ini akan dihapus dari daftar kerja aktif dan perhitungan penyelesaian. Seluruh log audit historis dan stempel waktu tetap disimpan.'
                : 'This sub item will be removed from active work lists and completion counts. All historical audit logs and timestamps are retained.'}
            </p>
          </div>

          {/* Mandatory Reason */}
          <div>
            <label className="block font-bold text-slate-800 mb-1">
              {isIndonesian ? 'Alasan Penghapusan Wajib' : 'Mandatory Deletion Reason'} <span className="text-rose-500">*</span>
            </label>
            <textarea
              rows={3}
              required
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder={
                isIndonesian
                  ? 'Berikan alasan (min 5 karakter), mis., Lingkup deliverable digabung ke tiket mobile website atau dibatalkan oleh manajer brand...'
                  : 'Provide reason (min 5 chars), e.g., Deliverable scope merged into website mobile ticket or canceled by brand manager...'
              }
              className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-rose-500/20 focus:border-rose-500 text-slate-900 leading-relaxed text-xs"
            />
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              disabled={isDeleting}
              className="px-4 py-2 font-semibold text-slate-700 bg-white border border-slate-300 rounded-xl hover:bg-slate-50 transition-colors"
            >
              {isIndonesian ? 'Batal' : 'Cancel'}
            </button>
            <button
              type="submit"
              disabled={isDeleting}
              className="px-4 py-2 font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-xl shadow-xs transition-colors flex items-center gap-1.5 active:scale-[0.98]"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>
                {isDeleting
                  ? (isIndonesian ? 'Menghapus...' : 'Deleting...')
                  : (isIndonesian ? 'Konfirmasi Hapus' : 'Confirm Soft Deletion')}
              </span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
