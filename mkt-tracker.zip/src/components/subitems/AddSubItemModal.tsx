import React, { useState } from 'react';
import { X, Plus, Calendar, AlertTriangle, User as UserIcon, Tag, AlignLeft } from 'lucide-react';
import { RequestItem, SubItem, RequestPriority } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { useRequests } from '../../context/RequestContext';
import { useLanguage } from '../../context/LanguageContext';

interface AddSubItemModalProps {
  parentRequest: RequestItem;
  onClose: () => void;
}

export const AddSubItemModal: React.FC<AddSubItemModalProps> = ({ parentRequest, onClose }) => {
  const { allUsers, currentUser } = useAuth();
  const { addSubItem, showToast } = useRequests();
  const { isIndonesian } = useLanguage();

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [ownerId, setOwnerId] = useState('');
  const [priority, setPriority] = useState<RequestPriority>(parentRequest.priority || 'medium');
  const [startDate, setStartDate] = useState('');
  const [dueDate, setDueDate] = useState(parentRequest.committedDeadline || '');
  const [notes, setNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Filter users eligible as assignees (team members, admins)
  const assignableUsers = allUsers.filter(
    (u) => u.isActive && (u.role === 'team_member' || u.role === 'admin' || u.role === 'super_admin')
  );

  // Warning if due date exceeds parent deadline
  const isPastParentDeadline = Boolean(
    dueDate && parentRequest.committedDeadline && dueDate > parentRequest.committedDeadline
  );

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      showToast(isIndonesian ? 'Judul Sub Item wajib diisi.' : 'Sub Item title is required.', 'error');
      return;
    }

    setIsSubmitting(true);
    try {
      const selectedOwner = assignableUsers.find((u) => u.id === ownerId);

      const res = await addSubItem(parentRequest.id, {
        title: title.trim(),
        description: description.trim() || undefined,
        ownerId: selectedOwner?.id,
        ownerName: selectedOwner?.fullName,
        ownerRole: selectedOwner?.jobTitle || selectedOwner?.role,
        ownerAvatar: selectedOwner?.avatarUrl,
        status: 'todo',
        priority,
        startDate: startDate || undefined,
        dueDate: dueDate || undefined,
        notes: notes.trim() || undefined,
      });

      if (res.success) {
        onClose();
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-white rounded-2xl p-6 max-w-lg w-full border border-slate-200 shadow-2xl space-y-4 animate-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="flex items-start justify-between pb-3 border-b border-slate-200">
          <div>
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#10B981]" />
              <h3 className="text-sm sm:text-base font-bold text-slate-900">
                {isIndonesian ? 'Tambah Sub Item / Hasil Pekerjaan' : 'Add Sub Item / Deliverable'}
              </h3>
            </div>
            <p className="text-xs text-slate-500 mt-0.5 truncate max-w-sm">
              {isIndonesian ? 'Tugas Induk:' : 'Parent Task:'} <strong className="text-slate-800">{parentRequest.ticketNumber}</strong> · {parentRequest.title}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1 rounded-lg"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3.5 text-xs">
          {/* Sub Item Title */}
          <div>
            <label className="block font-bold text-slate-800 mb-1">
              {isIndonesian ? 'Judul Sub Item' : 'Sub Item Title'} <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder={
                isIndonesian
                  ? 'mis., Instagram Feed, Banner Desktop Website, Videotron 15 dtk...'
                  : 'e.g., Instagram Feed, Website Desktop Banner, Videotron 15s...'
              }
              className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#065F46]/20 focus:border-[#065F46] text-slate-900"
            />
          </div>

          {/* Scope / Description */}
          <div>
            <label className="block font-bold text-slate-800 mb-1">
              {isIndonesian ? 'Spesifikasi Hasil Pekerjaan / Deskripsi' : 'Deliverable Specifications / Description'}
            </label>
            <textarea
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder={
                isIndonesian
                  ? 'mis., Carousel 1080x1080px 5 slide, cetak CMYK 300dpi, atau MP4 4K 60fps...'
                  : 'e.g., 1080x1080px carousel 5 slides, CMYK print ready 300dpi, or 4K 60fps MP4...'
              }
              className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#065F46]/20 focus:border-[#065F46] text-slate-900 leading-relaxed"
            />
          </div>

          {/* Owner & Priority Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-slate-800 mb-1">
                {isIndonesian ? 'Penanggung Jawab / Pelaksana' : 'Owner / Assignee'}
              </label>
              <select
                value={ownerId}
                onChange={(e) => setOwnerId(e.target.value)}
                className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#065F46]/20 focus:border-[#065F46] text-slate-900 font-medium"
              >
                <option value="">
                  {isIndonesian ? '-- Pilih Spesialis / Pelaksana --' : '-- Select Specialist / Owner --'}
                </option>
                {assignableUsers.map((u) => (
                  <option key={u.id} value={u.id}>
                    {u.fullName} ({u.jobTitle})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-bold text-slate-800 mb-1">
                {isIndonesian ? 'Prioritas' : 'Priority'}
              </label>
              <select
                value={priority}
                onChange={(e) => setPriority(e.target.value as RequestPriority)}
                className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#065F46]/20 focus:border-[#065F46] text-slate-900 font-medium"
              >
                <option value="low">{isIndonesian ? 'Prioritas Rendah' : 'Low Priority'}</option>
                <option value="medium">{isIndonesian ? 'Prioritas Sedang' : 'Medium Priority'}</option>
                <option value="high">{isIndonesian ? 'Prioritas Tinggi' : 'High Priority'}</option>
                <option value="urgent">{isIndonesian ? 'Prioritas Mendesak' : 'Urgent Priority'}</option>
              </select>
            </div>
          </div>

          {/* Dates Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-slate-800 mb-1">
                {isIndonesian ? 'Tanggal Mulai (Opsional)' : 'Start Date (Optional)'}
              </label>
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full p-2 bg-slate-50 border border-slate-300 rounded-xl focus:bg-white text-slate-900 font-mono text-xs"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-800 mb-1">
                {isIndonesian ? 'Tenggat Waktu' : 'Due Date'}
              </label>
              <input
                type="date"
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                className="w-full p-2 bg-slate-50 border border-slate-300 rounded-xl focus:bg-white text-slate-900 font-mono text-xs"
              />
            </div>
          </div>

          {/* Deadline Warning if exceeding parent deadline */}
          {isPastParentDeadline && (
            <div className="p-2.5 bg-amber-50 border border-amber-200 rounded-xl text-amber-900 flex items-start gap-2 text-xs">
              <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
              <div>
                <strong className="block font-bold">
                  {isIndonesian
                    ? 'Peringatan: Tenggat waktu melebihi batas tugas induk'
                    : 'Notice: Due date exceeds parent deadline'}
                </strong>
                <span className="text-[11px] text-amber-800">
                  {isIndonesian
                    ? `Tenggat tugas induk adalah ${parentRequest.committedDeadline}. Sub item ini akan ditandai jika dijadwalkan melewati batas permintaan induk.`
                    : `Parent task committed deadline is ${parentRequest.committedDeadline}. This sub item will be flagged if scheduled after the parent request.`}
                </span>
              </div>
            </div>
          )}

          {/* Working Notes */}
          <div>
            <label className="block font-bold text-slate-800 mb-1">
              {isIndonesian ? 'Catatan Awal / Instruksi' : 'Initial Notes / Instructions'}
            </label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder={
                isIndonesian
                  ? 'mis., Gunakan aset Identitas Brand Lyman v3 dari tautan Drive...'
                  : 'e.g., Use Lyman Brand Identity v3 assets from drive link...'
              }
              className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:bg-white text-slate-900"
            />
          </div>

          {/* Form Actions */}
          <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              disabled={isSubmitting}
              className="px-4 py-2 font-semibold text-slate-700 bg-white border border-slate-300 rounded-xl hover:bg-slate-50 transition-colors"
            >
              {isIndonesian ? 'Batal' : 'Cancel'}
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-4 py-2 font-bold text-white bg-[#065F46] hover:bg-[#044e39] rounded-xl shadow-xs transition-colors flex items-center gap-1.5 active:scale-[0.98]"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>
                {isSubmitting
                  ? (isIndonesian ? 'Menambahkan...' : 'Adding...')
                  : (isIndonesian ? 'Buat Sub Item' : 'Create Sub Item')}
              </span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
