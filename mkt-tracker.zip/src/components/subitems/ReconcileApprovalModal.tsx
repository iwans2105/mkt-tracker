import React, { useState } from 'react';
import { X, CalendarCheck, ShieldAlert, CheckCircle2 } from 'lucide-react';
import { SubItem, RequestItem } from '../../types';
import { useRequests } from '../../context/RequestContext';
import { useLanguage } from '../../context/LanguageContext';

interface ReconcileApprovalModalProps {
  isOpen: boolean;
  onClose: () => void;
  subItem: SubItem;
  parentRequest: RequestItem;
}

export const ReconcileApprovalModal: React.FC<ReconcileApprovalModalProps> = ({
  isOpen,
  onClose,
  subItem,
  parentRequest,
}) => {
  const { reconcileSubItemApproval } = useRequests();
  const { isIndonesian } = useLanguage();

  const [verifiedDate, setVerifiedDate] = useState(() => {
    const parentCompleted = parentRequest.completedAt ? parentRequest.completedAt.split('T')[0] : '';
    const now = new Date().toISOString().split('T')[0];
    return parentCompleted || now;
  });
  const [justification, setJustification] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!verifiedDate) {
      setError(
        isIndonesian
          ? 'Tanggal persetujuan yang diverifikasi wajib dipilih.'
          : 'Verified approval date is required.'
      );
      return;
    }
    if (justification.trim().length < 5) {
      setError(
        isIndonesian
          ? 'Justifikasi audit wajib diisi minimal 5 karakter.'
          : 'Audit justification must be at least 5 characters.'
      );
      return;
    }

    setIsSubmitting(true);
    setError(null);

    const isoTimestamp = `${verifiedDate}T12:00:00.000Z`;
    const res = await reconcileSubItemApproval(
      parentRequest.id,
      subItem.id,
      isoTimestamp,
      justification.trim()
    );

    setIsSubmitting(false);
    if (res.success) {
      onClose();
    } else {
      setError(
        res.error ||
          (isIndonesian ? 'Gagal merekonsiliasi tanggal persetujuan.' : 'Failed to reconcile approval date.')
      );
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xl w-full max-w-md overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        <div className="p-4 sm:p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-emerald-100 text-[#065F46] rounded-xl">
              <CalendarCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                {isIndonesian ? 'Rekonsiliasi Tanggal Persetujuan' : 'Reconcile Approval Date'}
              </h3>
              <p className="text-[11px] text-slate-500">
                {isIndonesian
                  ? 'Jejak Audit & Koreksi Verifikasi'
                  : 'Audit Trail & Verification Correction'}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-200/60 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-4 sm:p-5 space-y-4 text-xs">
          {error && (
            <div className="p-2.5 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl text-xs flex items-start gap-2">
              <ShieldAlert className="w-4 h-4 text-rose-500 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 space-y-1">
            <div className="font-semibold text-slate-700 truncate">
              {isIndonesian ? 'Hasil Pekerjaan:' : 'Deliverable:'}{' '}
              <span className="text-slate-900 font-bold">{subItem.title}</span>
            </div>
            <div className="text-[11px] text-slate-500">
              {isIndonesian ? 'Tiket Induk:' : 'Parent Ticket:'}{' '}
              <span className="font-mono text-slate-700">{parentRequest.ticketNumber}</span> ({parentRequest.title})
            </div>
            {subItem.ownerName && (
              <div className="text-[11px] text-slate-500">
                {isIndonesian ? 'Penanggung Jawab:' : 'Deliverable Owner:'}{' '}
                <span className="font-medium text-slate-700">{subItem.ownerName}</span>
              </div>
            )}
          </div>

          <div>
            <label className="block font-bold text-slate-800 mb-1">
              {isIndonesian
                ? 'Tanggal Persetujuan Resmi yang Diverifikasi'
                : 'Verified Official Approval Date'}{' '}
              <span className="text-rose-500">*</span>
            </label>
            <input
              type="date"
              value={verifiedDate}
              onChange={(e) => setVerifiedDate(e.target.value)}
              className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#065F46]/20 focus:border-[#065F46] text-slate-900 font-mono text-xs"
              required
            />
            <p className="text-[10px] text-slate-400 mt-1">
              {isIndonesian
                ? 'Pilih tanggal persetujuan sebenarnya berdasarkan konfirmasi komunikasi atau arsip deliverable.'
                : 'Select the actual approval date based on communication confirmation or deliverable archive.'}
            </p>
          </div>

          <div>
            <label className="block font-bold text-slate-800 mb-1">
              {isIndonesian ? 'Justifikasi Audit Rekonsiliasi' : 'Reconciliation Audit Justification'}{' '}
              <span className="text-rose-500">*</span>
            </label>
            <textarea
              rows={3}
              value={justification}
              onChange={(e) => setJustification(e.target.value)}
              placeholder={
                isIndonesian
                  ? 'Contoh: Diverifikasi dari email persetujuan Marcomm Lead tertanggal 10 Nov 2026...'
                  : 'Example: Verified from Marcomm Lead approval email dated 10 Nov 2026...'
              }
              className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#065F46]/20 focus:border-[#065F46] text-slate-900 text-xs"
              required
            />
            <p className="text-[10px] text-slate-400 mt-1">
              {isIndonesian
                ? 'Alasan ini akan disimpan secara permanen di Jejak Audit Keamanan dan Log Aktivitas.'
                : 'This justification will be permanently recorded in the Security Audit Trail and Activity Log.'}
            </p>
          </div>

          <div className="pt-2 flex items-center justify-end gap-2 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              disabled={isSubmitting}
              className="px-3.5 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900 bg-white hover:bg-slate-100 border border-slate-300 rounded-xl transition-colors"
            >
              {isIndonesian ? 'Batal' : 'Cancel'}
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="flex items-center gap-1.5 px-4 py-2 text-xs font-bold text-white bg-[#065F46] hover:bg-[#044e39] rounded-xl shadow-xs transition-colors disabled:opacity-50"
            >
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>
                {isSubmitting
                  ? (isIndonesian ? 'Menyimpan...' : 'Saving...')
                  : (isIndonesian ? 'Simpan Rekonsiliasi' : 'Save Reconciliation')}
              </span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
