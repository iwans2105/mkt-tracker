import React, { useState, useRef } from 'react';
import {
  X,
  Send,
  Link as LinkIcon,
  FileText,
  CheckCircle2,
  AlertCircle,
  UploadCloud,
  FileImage,
  Film,
  Music,
  FileSpreadsheet,
  FileCode,
  Trash2,
} from 'lucide-react';
import { RequestItem, SubItem, RequestStatus } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { useRequests } from '../../context/RequestContext';
import { useLanguage } from '../../context/LanguageContext';
import { StorageService } from '../../services/storageService';
import { StatusBadge } from '../common/StatusBadge';

const ALLOWED_EXTENSIONS = [
  'png',
  'jpg',
  'jpeg',
  'psd',
  'ai',
  'pdf',
  'docx',
  'xlsx',
  'mp4',
  'mov',
  'mpeg',
  'avi',
  'wav',
  'mp3',
];

const ACCEPT_ATTR =
  '.png,.jpg,.jpeg,.psd,.ai,.pdf,.docx,.xlsx,.mp4,.mov,.mpeg,.avi,.wav,.mp3';

interface SubItemProgressModalProps {
  parentRequest: RequestItem;
  subItem: SubItem;
  onClose: () => void;
}

export const SubItemProgressModal: React.FC<SubItemProgressModalProps> = ({
  parentRequest,
  subItem,
  onClose,
}) => {
  const { currentUser, isAdmin, csrfToken } = useAuth();
  const { updateSubItemProgress, showToast } = useRequests();
  const { language } = useLanguage();

  const [status, setStatus] = useState<RequestStatus>(subItem.status);
  const [deliverableFile, setDeliverableFile] = useState<File | null>(null);
  const [deliverableUrl, setDeliverableUrl] = useState(subItem.deliverableUrl || '');
  const [deliverableFileName, setDeliverableFileName] = useState(subItem.deliverableFileName || '');
  const [fileError, setFileError] = useState<string | null>(null);
  const [showUrlField, setShowUrlField] = useState(Boolean(subItem.deliverableUrl && !subItem.deliverableFileName));
  const [notes, setNotes] = useState(subItem.notes || '');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFileError(null);
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const file = files[0];
    const ext = file.name.split('.').pop()?.toLowerCase() || '';
    if (!ALLOWED_EXTENSIONS.includes(ext)) {
      setFileError(
        language === 'id'
          ? `Format .${ext} tidak didukung. Format didukung: PNG, JPG, JPEG, PSD, AI, PDF, DOCX, XLSX, MP4, MOV, MPEG, AVI, WAV, MP3`
          : `Format .${ext} is not supported. Supported: PNG, JPG, JPEG, PSD, AI, PDF, DOCX, XLSX, MP4, MOV, MPEG, AVI, WAV, MP3`
      );
      if (fileInputRef.current) fileInputRef.current.value = '';
      return;
    }

    setDeliverableFile(file);
    setDeliverableFileName(file.name);
  };

  const handleRemoveFile = () => {
    setDeliverableFile(null);
    setDeliverableFileName('');
    if (!showUrlField) {
      setDeliverableUrl('');
    }
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const getSubItemFileIcon = (fileName: string) => {
    const ext = fileName.split('.').pop()?.toLowerCase() || '';
    if (['png', 'jpg', 'jpeg'].includes(ext)) return <FileImage className="w-4 h-4 text-emerald-600" />;
    if (['psd', 'ai'].includes(ext)) return <FileCode className="w-4 h-4 text-purple-600" />;
    if (['mp4', 'mov', 'mpeg', 'avi'].includes(ext)) return <Film className="w-4 h-4 text-rose-600" />;
    if (['wav', 'mp3'].includes(ext)) return <Music className="w-4 h-4 text-amber-600" />;
    if (['xlsx'].includes(ext)) return <FileSpreadsheet className="w-4 h-4 text-emerald-700" />;
    return <FileText className="w-4 h-4 text-blue-600" />;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setFileError(null);
    try {
      let finalDeliverableUrl = deliverableUrl.startsWith('blob:') ? '' : deliverableUrl.trim();
      let finalFileName = deliverableFileName.trim();

      if (deliverableFile) {
        const uploaded = await StorageService.uploadFileToR2(
          deliverableFile,
          {
            scopeType: 'subitem',
            requestId: parentRequest.id,
            subItemId: subItem.id,
            brandId: parentRequest.brandId,
            regionId: parentRequest.regionId,
          },
          csrfToken
        );
        finalDeliverableUrl = uploaded.url;
        finalFileName = uploaded.name;
      }

      const res = await updateSubItemProgress(parentRequest.id, subItem.id, {
        status,
        deliverableUrl: finalDeliverableUrl || undefined,
        deliverableFileName: finalFileName || undefined,
        notes: notes.trim() || undefined,
      });

      if (res.success) {
        onClose();
      }
    } catch (err: any) {
      const msg =
        err?.message ||
        (language === 'id' ? 'Gagal mengunggah file deliverable ke R2.' : 'Failed to upload deliverable file to R2.');
      setFileError(msg);
      showToast(msg, 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-white rounded-2xl p-6 max-w-md w-full border border-slate-200 shadow-2xl space-y-4 animate-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="flex items-start justify-between pb-3 border-b border-slate-200">
          <div>
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#065F46]" />
              <h3 className="text-sm sm:text-base font-bold text-slate-900">
                {language === 'id' ? 'Perbarui Progres Sub Item' : 'Update Sub Item Progress'}
              </h3>
            </div>
            <p className="text-xs text-slate-500 mt-0.5 truncate max-w-sm">
              {language === 'id' ? 'Hasil Pekerjaan:' : 'Deliverable:'} <strong className="text-slate-800">{subItem.title}</strong>
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1 rounded-lg"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3.5 text-xs">
          {/* Sub Item Info Card */}
          <div className="p-3 bg-slate-50 border border-slate-200/90 rounded-xl space-y-1">
            <div className="flex items-center justify-between text-[11px]">
              <span className="text-slate-500">
                {language === 'id' ? 'Status Saat Ini:' : 'Current Status:'}
              </span>
              <StatusBadge status={subItem.status} size="sm" compact={true} />
            </div>
            {subItem.dueDate && (
              <div className="text-[11px] text-slate-600">
                {language === 'id' ? 'Tenggat Waktu:' : 'Due Date:'} <span className="font-mono font-semibold">{subItem.dueDate}</span>
              </div>
            )}
            {subItem.description && (
              <p className="text-[11px] text-slate-500 italic mt-1">{subItem.description}</p>
            )}
          </div>

          {/* Workflow Status Selection */}
          <div>
            <label className="block font-bold text-slate-800 mb-1">
              {language === 'id' ? 'Perbarui Status' : 'Update Status'}
            </label>
            <select
              value={status}
              onChange={(e) => setStatus(e.target.value as RequestStatus)}
              className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#065F46]/20 focus:border-[#065F46] text-slate-900 font-semibold"
            >
              <option value="todo">{language === 'id' ? 'Antrean (To Do)' : 'To Do / Backlog'}</option>
              <option value="in_progress">{language === 'id' ? 'Sedang Dikerjakan (Mulai Kerja)' : 'In Progress (Start Working)'}</option>
              <option value="pending_review">{language === 'id' ? 'Kirim untuk Review (Menunggu Review)' : 'Submit for Review (Pending Review)'}</option>
              <option value="on_hold">{language === 'id' ? 'Ditunda (On Hold / Terkendala)' : 'Put On Hold (Blocked)'}</option>
              {isAdmin && (
                <option value="completed">
                  {language === 'id' ? 'Setujui & Selesaikan (Admin)' : 'Approve & Complete (Admin)'}
                </option>
              )}
              {isAdmin && (
                <option value="cancelled">
                  {language === 'id' ? 'Dibatalkan (Admin)' : 'Cancelled (Admin)'}
                </option>
              )}
            </select>
          </div>

          {/* Deliverable File Upload */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="block font-bold text-slate-800 flex items-center gap-1.5">
                <UploadCloud className="w-3.5 h-3.5 text-[#065F46]" />
                <span>
                  {language === 'id' ? 'Unggah File Deliverable' : 'Upload Deliverable File'}
                </span>
                <span className="text-[10px] font-semibold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200">
                  {language === 'id' ? '14 Format Didukung' : '14 Formats'}
                </span>
              </label>
              <button
                type="button"
                onClick={() => setShowUrlField(!showUrlField)}
                className="text-[11px] font-semibold text-blue-600 hover:text-blue-800 hover:underline flex items-center gap-1"
              >
                <LinkIcon className="w-3 h-3" />
                <span>{showUrlField ? (language === 'id' ? 'Sembunyikan URL' : 'Hide URL') : (language === 'id' ? '+ Tambah URL Preview' : '+ Add Preview URL')}</span>
              </button>
            </div>

            <input
              ref={fileInputRef}
              type="file"
              accept={ACCEPT_ATTR}
              onChange={handleFileChange}
              className="hidden"
            />

            {!deliverableFileName ? (
              <div
                onClick={() => fileInputRef.current?.click()}
                className="p-4 bg-slate-50 border-2 border-dashed border-slate-300 hover:border-[#065F46] rounded-xl text-center cursor-pointer transition-colors group"
              >
                <div className="w-9 h-9 rounded-xl bg-white shadow-2xs border border-slate-200 flex items-center justify-center mx-auto mb-2 group-hover:scale-105 transition-transform">
                  <UploadCloud className="w-5 h-5 text-[#065F46]" />
                </div>
                <div className="text-xs font-semibold text-slate-800">
                  {language === 'id' ? 'Pilih file hasil pekerjaan' : 'Choose deliverable file'}
                </div>
                <div className="text-[10px] text-slate-500 mt-1">
                  PNG, JPG, JPEG, PSD, AI, PDF, DOCX, XLSX, MP4, MOV, MPEG, AVI, WAV, MP3
                </div>
              </div>
            ) : (
              <div className="p-3 bg-emerald-50/70 border border-emerald-200 rounded-xl flex items-center justify-between gap-2">
                <div className="flex items-center gap-2.5 truncate min-w-0">
                  <div className="w-8 h-8 rounded-lg bg-white border border-emerald-200 flex items-center justify-center shrink-0">
                    {getSubItemFileIcon(deliverableFileName)}
                  </div>
                  <div className="truncate">
                    <div className="text-xs font-bold text-slate-900 truncate">
                      {deliverableFileName}
                    </div>
                    <div className="text-[10px] font-medium text-emerald-700 flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                      <span>
                        {deliverableFile
                          ? `${Math.round(deliverableFile.size / 1024)} KB`
                          : language === 'id'
                          ? 'Terlampir'
                          : 'Attached'}
                      </span>
                      <span>•</span>
                      <span>{deliverableFileName.split('.').pop()?.toUpperCase()}</span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-1 shrink-0">
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="px-2 py-1 text-[11px] font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
                  >
                    {language === 'id' ? 'Ganti' : 'Change'}
                  </button>
                  <button
                    type="button"
                    onClick={handleRemoveFile}
                    className="p-1 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-rose-50"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}

            {fileError && (
              <p className="text-[11px] font-semibold text-rose-600 mt-1 flex items-center gap-1">
                <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                <span>{fileError}</span>
              </p>
            )}
          </div>

          {/* Optional External Deliverable URL */}
          {showUrlField && (
            <div className="animate-in fade-in duration-150">
              <label className="block font-bold text-slate-800 mb-1 flex items-center gap-1 text-[11px]">
                <LinkIcon className="w-3.5 h-3.5 text-slate-400" />
                <span>{language === 'id' ? 'Tautan Eksternal Tambahan (Google Drive / Figma / Preview)' : 'Additional External Link (Google Drive / Figma / Preview)'}</span>
              </label>
              <input
                type="url"
                value={deliverableUrl.startsWith('blob:') ? '' : deliverableUrl}
                onChange={(e) => setDeliverableUrl(e.target.value)}
                placeholder={
                  language === 'id'
                    ? 'https://drive.google.com/... atau https://figma.com/...'
                    : 'https://drive.google.com/... or https://figma.com/...'
                }
                className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:bg-white text-slate-900 font-mono text-xs"
              />
            </div>
          )}

          {/* Progress Notes */}
          <div>
            <label className="block font-bold text-slate-800 mb-1">
              {language === 'id' ? 'Catatan Progres / Catatan Reviewer' : 'Progress Notes / Reviewer Note'}
            </label>
            <textarea
              rows={3}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder={
                language === 'id'
                  ? 'Jelaskan perubahan yang dilakukan, revisi yang ditindaklanjuti, atau alasan perubahan status...'
                  : 'Explain changes made, feedback addressed, or reasons for status change...'
              }
              className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:bg-white text-slate-900 leading-relaxed text-xs"
            />
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              disabled={isSubmitting}
              className="px-4 py-2 font-semibold text-slate-700 bg-white border border-slate-300 rounded-xl hover:bg-slate-50 transition-colors"
            >
              {language === 'id' ? 'Batal' : 'Cancel'}
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-4 py-2 font-bold text-white bg-[#065F46] hover:bg-[#044e39] rounded-xl shadow-xs transition-colors flex items-center gap-1.5 active:scale-[0.98]"
            >
              <Send className="w-3.5 h-3.5" />
              <span>
                {isSubmitting
                  ? (language === 'id' ? 'Memperbarui...' : 'Updating...')
                  : (language === 'id' ? 'Simpan Progres' : 'Save Progress')}
              </span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
