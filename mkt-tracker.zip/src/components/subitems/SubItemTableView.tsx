import React, { useState } from 'react';
import {
  Plus,
  CheckCircle2,
  Clock,
  Calendar,
  User as UserIcon,
  Edit2,
  Trash2,
  ExternalLink,
  AlertCircle,
  FileText,
  PlayCircle,
  RotateCcw,
  PauseCircle,
  Ban,
  Check,
  Send,
  HelpCircle,
  CalendarCheck,
  ShieldAlert,
} from 'lucide-react';
import { RequestItem, SubItem, RequestStatus, RequestPriority } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { useRequests } from '../../context/RequestContext';
import { useLanguage } from '../../context/LanguageContext';
import { StatusBadge, PriorityBadge } from '../common/StatusBadge';
import { AddSubItemModal } from './AddSubItemModal';
import { EditSubItemModal } from './EditSubItemModal';
import { DeleteSubItemModal } from './DeleteSubItemModal';
import { SubItemProgressModal } from './SubItemProgressModal';
import { ReconcileApprovalModal } from './ReconcileApprovalModal';

interface SubItemTableViewProps {
  parentRequest: RequestItem;
  onRefresh?: () => void;
}

export const SubItemTableView: React.FC<SubItemTableViewProps> = ({ parentRequest }) => {
  const {
    currentUser,
    canCreateSubItem,
    canEditSubItem,
    canDeleteSubItem,
    canUpdateSubItemProgress,
    canApproveSubItem,
  } = useAuth();

  const { approveSubItem } = useRequests();
  const { isIndonesian } = useLanguage();

  // Modals state
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingSubItem, setEditingSubItem] = useState<SubItem | null>(null);
  const [deletingSubItem, setDeletingSubItem] = useState<SubItem | null>(null);
  const [progressSubItem, setProgressSubItem] = useState<SubItem | null>(null);
  const [reconcilingSubItem, setReconcilingSubItem] = useState<SubItem | null>(null);

  const subItems = (parentRequest.subItems || []).filter((s) => !s.deletedAt);

  // Completion calculation (excluding cancelled)
  const eligibleSubItems = subItems.filter((s) => s.status !== 'cancelled');
  const completedSubItems = eligibleSubItems.filter((s) => s.status === 'completed');
  const completionPercentage =
    eligibleSubItems.length > 0
      ? Math.round((completedSubItems.length / eligibleSubItems.length) * 100)
      : null;

  const handleQuickApprove = async (sub: SubItem, e: React.MouseEvent) => {
    e.stopPropagation();
    await approveSubItem(parentRequest.id, sub.id);
  };

  const formatDate = (dateStr?: string) => {
    if (!dateStr) return '—';
    const locale = isIndonesian ? 'id-ID' : 'en-GB';
    try {
      // If simple YYYY-MM-DD
      if (/^\d{4}-\d{2}-\d{2}$/.test(dateStr)) {
        const parts = dateStr.split('-');
        const d = new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]));
        return d.toLocaleDateString(locale, { day: '2-digit', month: 'short', year: 'numeric' });
      }
      const d = new Date(dateStr);
      return d.toLocaleDateString(locale, {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
        timeZone: 'Asia/Jakarta',
      });
    } catch {
      return dateStr;
    }
  };

  const formatApprovalDateTime = (dateStr?: string) => {
    if (!dateStr) return '';
    const locale = isIndonesian ? 'id-ID' : 'en-GB';
    try {
      const d = new Date(dateStr);
      const datePart = d.toLocaleDateString(locale, {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
        timeZone: 'Asia/Jakarta',
      });
      const timePart = d.toLocaleTimeString(locale, {
        hour: '2-digit',
        minute: '2-digit',
        hour12: false,
        timeZone: 'Asia/Jakarta',
      });
      return `${datePart}, ${timePart} WIB`;
    } catch {
      return dateStr;
    }
  };

  const isOverdue = (sub: SubItem) => {
    if (sub.status === 'completed' || sub.status === 'cancelled' || sub.status === 'on_hold') {
      return false;
    }
    if (!sub.dueDate) return false;
    const todayStr = new Date().toISOString().split('T')[0];
    return sub.dueDate < todayStr;
  };

  return (
    <div className="bg-slate-50/80 rounded-2xl border border-slate-200/90 p-4 space-y-3.5 my-2 shadow-2xs">
      {/* Top Header & Sub Item Progress Summary */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200/80">
        <div className="space-y-1">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-xs font-bold text-slate-900 tracking-tight flex items-center gap-1.5">
              <span>{isIndonesian ? 'Sub Item / Hasil Pekerjaan' : 'Sub Items / Deliverables'}</span>
              <span className="font-mono px-2 py-0.5 rounded-full text-[11px] bg-[#D1FAE5] text-[#065F46] font-bold border border-[#A7F3D0]">
                {subItems.length} {isIndonesian ? 'item' : subItems.length === 1 ? 'item' : 'items'}
              </span>
            </span>
            {completionPercentage !== null && (
              <span className="text-[11px] font-semibold text-slate-600 bg-white px-2 py-0.5 rounded-md border border-slate-200">
                {isIndonesian ? 'Progres:' : 'Progress:'}{' '}
                <strong className="text-[#065F46] font-mono">{completionPercentage}%</strong> (
                {completedSubItems.length}/{eligibleSubItems.length}{' '}
                {isIndonesian ? 'selesai' : 'completed'})
              </span>
            )}
          </div>
          <p className="text-[11px] text-slate-500">
            {isIndonesian ? (
              <>
                Rincian hasil pekerjaan individual untuk <strong className="text-slate-700">{parentRequest.ticketNumber}</strong> ({parentRequest.title}).
              </>
            ) : (
              <>
                Individual deliverables breakdown for <strong className="text-slate-700">{parentRequest.ticketNumber}</strong> ({parentRequest.title}).
              </>
            )}
          </p>
        </div>

        {/* Action Button: + Add Sub Item (Strict Super Admin / Marcomm Admin only) */}
        {canCreateSubItem(parentRequest) && (
          <button
            type="button"
            onClick={() => setIsAddModalOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-white bg-[#065F46] hover:bg-[#044e39] rounded-xl shadow-xs transition-all active:scale-[0.98] shrink-0 self-start sm:self-auto"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>{isIndonesian ? 'Tambah Sub Item' : 'Add Sub Item'}</span>
          </button>
        )}
      </div>

      {/* Progress Bar */}
      {eligibleSubItems.length > 0 && completionPercentage !== null && (
        <div className="space-y-1">
          <div className="w-full h-1.5 rounded-full bg-slate-200 overflow-hidden">
            <div
              className="h-full bg-[#10B981] transition-all duration-300 rounded-full"
              style={{ width: `${completionPercentage}%` }}
            />
          </div>
        </div>
      )}

      {/* Sub Item Table matching the prompt's layout */}
      <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white shadow-2xs">
        <table className="w-full text-left text-xs">
          <thead>
            <tr className="bg-slate-100/80 border-b border-slate-200 text-slate-600 font-bold uppercase tracking-wider text-[10px]">
              <th className="py-2.5 px-3.5 min-w-[200px]">Sub Item</th>
              <th className="py-2.5 px-3.5 w-44">{isIndonesian ? 'Penanggung Jawab' : 'Owner'}</th>
              <th className="py-2.5 px-3.5 w-32">Status</th>
              <th className="py-2.5 px-3.5 w-28">{isIndonesian ? 'Tenggat Waktu' : 'Due Date'}</th>
              <th className="py-2.5 px-3.5 w-28">{isIndonesian ? 'Tgl Persetujuan' : 'Approval Date'}</th>
              <th className="py-2.5 px-3.5 text-right w-28">{isIndonesian ? 'Aksi' : 'Actions'}</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {subItems.length === 0 ? (
              <tr>
                <td colSpan={6} className="py-6 text-center text-xs text-slate-400 italic">
                  {isIndonesian
                    ? 'Belum ada sub item yang dibuat untuk permintaan ini.'
                    : 'No sub items created yet for this request.'}
                  {canCreateSubItem(parentRequest) && (
                    <span className="block mt-1 text-[11px] text-[#065F46] font-semibold">
                      {isIndonesian
                        ? 'Klik "+ Tambah Sub Item" di atas untuk menambahkan hasil pekerjaan seperti Instagram Feed, Banner Website, Videotron, dll.'
                        : 'Click "+ Add Sub Item" above to add deliverables like Instagram Feed, Website Banner, Videotron, etc.'}
                    </span>
                  )}
                </td>
              </tr>
            ) : (
              subItems.map((sub) => {
                const overdue = isOverdue(sub);
                const isOwner = sub.ownerId === currentUser.id;
                const canEdit = canEditSubItem(sub, parentRequest);
                const canDelete = canDeleteSubItem(sub, parentRequest);
                const canProgress = canUpdateSubItemProgress(sub, parentRequest);
                const canApprove = canApproveSubItem(sub, parentRequest) && sub.status === 'pending_review';

                return (
                  <tr
                    key={sub.id}
                    className="hover:bg-slate-50/80 transition-colors group"
                  >
                    {/* Sub Item Title & Description */}
                    <td className="py-2.5 px-3.5 align-middle">
                      <div className="flex items-start gap-2">
                        <div className="mt-0.5">
                          <PriorityBadge priority={sub.priority} compact={true} />
                        </div>
                        <div className="min-w-0">
                          <span className="font-bold text-slate-900 block truncate leading-snug">
                            {sub.title}
                          </span>
                          {sub.description && (
                            <p className="text-[11px] text-slate-500 line-clamp-1 mt-0.5">
                              {sub.description}
                            </p>
                          )}
                          {sub.deliverableUrl && (
                            <a
                              href={sub.deliverableUrl}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="inline-flex items-center gap-1 text-[10px] font-semibold text-blue-600 hover:text-blue-800 hover:underline mt-0.5"
                            >
                              <ExternalLink className="w-2.5 h-2.5" />
                              <span>{isIndonesian ? 'Lihat Tautan Hasil' : 'View Deliverable Link'}</span>
                            </a>
                          )}
                          {sub.deliverableFileName && !sub.deliverableUrl && (
                            <span className="text-[10px] text-slate-500 italic block mt-0.5">
                              File: {sub.deliverableFileName}
                            </span>
                          )}
                        </div>
                      </div>
                    </td>

                    {/* Owner */}
                    <td className="py-2.5 px-3.5 align-middle whitespace-nowrap">
                      {sub.ownerName ? (
                        <div className="flex items-center gap-2 min-w-0">
                          <div className="w-6 h-6 rounded-full bg-emerald-100 text-[#065F46] font-bold text-[10px] flex items-center justify-center shrink-0 border border-emerald-200">
                            {sub.ownerName.charAt(0)}
                          </div>
                          <div className="min-w-0 truncate">
                            <span className="font-semibold text-slate-800 block text-xs truncate">
                              {sub.ownerName}
                            </span>
                            <span className="text-[10px] text-slate-400 block truncate">
                              {sub.ownerRole || (isIndonesian ? 'Spesialis' : 'Specialist')}
                            </span>
                          </div>
                        </div>
                      ) : (
                        <span className="text-[11px] text-slate-400 italic">
                          {isIndonesian ? 'Belum Ditugaskan' : 'Unassigned'}
                        </span>
                      )}
                    </td>

                    {/* Status */}
                    <td className="py-2.5 px-3.5 align-middle whitespace-nowrap">
                      <StatusBadge status={sub.status} size="sm" compact={true} />
                    </td>

                    {/* Due Date */}
                    <td className="py-2.5 px-3.5 align-middle whitespace-nowrap">
                      <div className="flex items-center gap-1 font-mono text-[11px] text-slate-700">
                        <Calendar className="w-3 h-3 text-slate-400" />
                        <span>{formatDate(sub.dueDate)}</span>
                      </div>
                      {overdue && (
                        <span className="text-[10px] font-bold text-rose-600 flex items-center gap-0.5 mt-0.5">
                          <AlertCircle className="w-2.5 h-2.5" />
                          <span>{isIndonesian ? 'Terlambat' : 'Overdue'}</span>
                        </span>
                      )}
                    </td>

                    {/* Approval Date */}
                    <td className="py-2.5 px-3.5 align-middle whitespace-nowrap">
                      {sub.approvalDate || sub.approvedAt ? (
                        <div
                          title={
                            isIndonesian
                              ? `Persetujuan Resmi: ${formatApprovalDateTime(sub.approvalDate || sub.approvedAt)}${sub.approvedByName ? ` oleh ${sub.approvedByName}` : ''}`
                              : `Official Approval: ${formatApprovalDateTime(sub.approvalDate || sub.approvedAt)}${sub.approvedByName ? ` by ${sub.approvedByName}` : ''}`
                          }
                          className="flex items-center gap-1.5 text-[11px] text-emerald-800 font-mono font-medium"
                        >
                          <CalendarCheck className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                          <span>{formatDate(sub.approvalDate || sub.approvedAt)}</span>
                        </div>
                      ) : sub.approvalRequiresVerification ? (
                        <button
                          type="button"
                          onClick={() => (currentUser.role === 'super_admin' || currentUser.role === 'admin') && setReconcilingSubItem(sub)}
                          title={
                            isIndonesian
                              ? 'Tanggal Persetujuan Belum Ada — Perlu Verifikasi di Jejak Audit. Klik untuk rekonsiliasi.'
                              : 'Approval Date Missing — Requires Verification in Audit Trail. Click to reconcile.'
                          }
                          className="inline-flex items-center gap-1 text-[10px] font-semibold text-amber-700 bg-amber-50 hover:bg-amber-100 border border-amber-200 px-2 py-0.5 rounded-md transition-colors"
                        >
                          <AlertCircle className="w-3 h-3 text-amber-500 shrink-0" />
                          <span>{isIndonesian ? 'Perlu Verifikasi' : 'Needs Verification'}</span>
                        </button>
                      ) : (
                        <span className="text-slate-400 text-xs">—</span>
                      )}
                    </td>

                    {/* Actions */}
                    <td className="py-2.5 px-3.5 align-middle text-right whitespace-nowrap">
                      <div className="flex items-center justify-end gap-1">
                        {/* Quick Approve for Reviewer/Admin when in pending_review */}
                        {canApprove && (
                          <button
                            type="button"
                            onClick={(e) => handleQuickApprove(sub, e)}
                            title={isIndonesian ? 'Setujui hasil pekerjaan & tandai selesai' : 'Approve deliverable and mark completed'}
                            className="p-1.5 text-white bg-[#065F46] hover:bg-[#044e39] rounded-lg shadow-2xs transition-colors"
                          >
                            <Check className="w-3 h-3" />
                          </button>
                        )}

                        {/* Update Progress Button for Assigned Team Member or Admin */}
                        {canProgress && (
                          <button
                            type="button"
                            onClick={() => setProgressSubItem(sub)}
                            title={
                              isOwner
                                ? (isIndonesian ? 'Perbarui progres atau kirim hasil pekerjaan' : 'Update your progress or submit deliverable')
                                : (isIndonesian ? 'Perbarui progres' : 'Update progress')
                            }
                            className="px-2 py-1 text-[11px] font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 border border-slate-300 rounded-lg transition-colors flex items-center gap-1"
                          >
                            <Send className="w-3 h-3 text-[#065F46]" />
                            <span>{isIndonesian ? 'Progres' : 'Progress'}</span>
                          </button>
                        )}

                        {/* Edit Button (Admin/Super Admin only) */}
                        {canEdit && (
                          <button
                            type="button"
                            onClick={() => setEditingSubItem(sub)}
                            title={isIndonesian ? 'Edit detail Sub Item' : 'Edit Sub Item details'}
                            className="p-1.5 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-lg transition-colors"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                        )}

                        {/* Soft Delete Button (Admin/Super Admin only) */}
                        {canDelete && (
                          <button
                            type="button"
                            onClick={() => setDeletingSubItem(sub)}
                            title={isIndonesian ? 'Hapus Sub Item (Soft-delete)' : 'Delete Sub Item (Soft-delete)'}
                            className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* Bottom + Add Sub Item Bar for Admins */}
      {canCreateSubItem(parentRequest) && (
        <div className="pt-1 flex items-center justify-between text-xs">
          <span className="text-[11px] text-slate-400">
            {isIndonesian
              ? 'Hanya Super Admin & Marcomm Admin yang dapat menambah, mengedit, atau menghapus Sub Item.'
              : 'Only Super Admin & Marcomm Admin can add, edit, or delete Sub Items.'}
          </span>
          <button
            type="button"
            onClick={() => setIsAddModalOpen(true)}
            className="text-xs font-bold text-[#065F46] hover:text-[#044e39] hover:underline flex items-center gap-1"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>{isIndonesian ? '+ Tambah Sub Item' : '+ Add Sub Item'}</span>
          </button>
        </div>
      )}

      {/* Modals */}
      {isAddModalOpen && (
        <AddSubItemModal
          parentRequest={parentRequest}
          onClose={() => setIsAddModalOpen(false)}
        />
      )}

      {editingSubItem && (
        <EditSubItemModal
          parentRequest={parentRequest}
          subItem={editingSubItem}
          onClose={() => setEditingSubItem(null)}
        />
      )}

      {deletingSubItem && (
        <DeleteSubItemModal
          parentRequest={parentRequest}
          subItem={deletingSubItem}
          onClose={() => setDeletingSubItem(null)}
        />
      )}

      {progressSubItem && (
        <SubItemProgressModal
          parentRequest={parentRequest}
          subItem={progressSubItem}
          onClose={() => setProgressSubItem(null)}
        />
      )}

      {reconcilingSubItem && (
        <ReconcileApprovalModal
          parentRequest={parentRequest}
          subItem={reconcilingSubItem}
          isOpen={true}
          onClose={() => setReconcilingSubItem(null)}
        />
      )}
    </div>
  );
};
