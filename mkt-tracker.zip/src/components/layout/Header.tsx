import React, { useState, useRef, useEffect } from 'react';
import {
  Bell,
  CheckCircle,
  Clock,
  AlertTriangle,
  RotateCcw,
  Sparkles,
  ExternalLink,
  ChevronDown,
  User as UserIcon,
  Plus,
  Menu,
  LogOut,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useRequests } from '../../context/RequestContext';
import { useLanguage } from '../../context/LanguageContext';
import { LanguageSwitcher } from '../common/LanguageSwitcher';
import { NotificationItem } from '../../types';

interface HeaderProps {
  onOpenCreateModal: () => void;
  onToggleMobileSidebar: () => void;
  onSelectRequestDetail: (requestId: string) => void;
  currentViewTitle: string;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenCreateModal,
  onToggleMobileSidebar,
  onSelectRequestDetail,
  currentViewTitle,
}) => {
  const { currentUser, isSuperAdmin, isAdmin, logout, isLoggingOut } = useAuth();
  const { notifications, unreadNotificationCount, markNotificationAsRead, markAllNotificationsAsRead } =
    useRequests();
  const { t, isIndonesian } = useLanguage();

  const [isNotifOpen, setIsNotifOpen] = useState(false);
  const notifRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (notifRef.current && !notifRef.current.contains(e.target as Node)) {
        setIsNotifOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const getNotifIcon = (type: NotificationItem['type']) => {
    switch (type) {
      case 'assignment':
        return <UserIcon className="w-4 h-4 text-blue-600" />;
      case 'review_request':
        return <Clock className="w-4 h-4 text-amber-600" />;
      case 'revision':
        return <RotateCcw className="w-4 h-4 text-orange-600" />;
      case 'completed':
        return <CheckCircle className="w-4 h-4 text-emerald-600" />;
      case 'overdue':
        return <AlertTriangle className="w-4 h-4 text-rose-600" />;
      default:
        return <Bell className="w-4 h-4 text-slate-500" />;
    }
  };

  return (
    <header className="sticky top-0 z-30 flex items-center justify-between gap-2 sm:gap-4 md:gap-6 px-3 sm:px-6 md:px-8 py-2.5 sm:py-3 bg-white/95 backdrop-blur-md border-b border-slate-200">
      {/* Zone 1: Mobile toggle & Breadcrumb context */}
      <div className="flex items-center gap-2 sm:gap-3 min-w-0 flex-1 sm:flex-initial">
        <button
          onClick={onToggleMobileSidebar}
          className="lg:hidden p-1.5 sm:p-2 text-slate-600 hover:text-slate-900 rounded-lg hover:bg-slate-100 transition-colors shrink-0"
          aria-label={isIndonesian ? 'Buka menu navigasi' : 'Open navigation menu'}
        >
          <Menu className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-1.5 sm:gap-2 text-xs sm:text-sm min-w-0">
          <span className="font-semibold text-slate-400 hidden sm:inline shrink-0">Marcomm</span>
          <span className="text-slate-300 hidden sm:inline shrink-0">/</span>
          <h1 className="font-bold text-slate-900 truncate text-sm sm:text-base md:text-lg leading-tight">
            {currentViewTitle}
          </h1>
        </div>
      </div>

      {/* Zone 2: Fast Stats / Workspace indicator (Clean unboxed text) */}
      <div className="hidden xl:flex items-center gap-4 text-xs text-[#64748B] font-medium shrink-0">
        <span className="flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-[#10B981]" />
          <span>{t('app.region')}</span>
        </span>
        <span aria-hidden="true" className="text-slate-300">·</span>
        <span>{t('app.division')}</span>
      </div>

      {/* Zone 3: Actions, Notifications, & User Profile */}
      <div className="flex items-center gap-1.5 sm:gap-2.5 md:gap-3 shrink-0">
        {/* Language Switcher */}
        <LanguageSwitcher variant="compact" />

        {/* Create Request CTA */}
        <button
          onClick={onOpenCreateModal}
          className="flex items-center gap-1.5 px-3 sm:px-4 py-2 text-xs font-bold text-white bg-[#065F46] hover:bg-[#044e39] rounded-xl shadow-xs transition-all active:scale-[0.98] whitespace-nowrap"
        >
          <Plus className="w-4 h-4 shrink-0" />
          <span className="hidden sm:inline">{t('header.newRequest')}</span>
          <span className="sm:hidden">{t('header.newRequest')}</span>
        </button>

        {/* Notifications Dropdown */}
        <div className="relative" ref={notifRef}>
          <button
            onClick={() => setIsNotifOpen((prev) => !prev)}
            className="relative p-2 text-[#64748B] hover:text-[#111827] rounded-xl hover:bg-[#F0FDF4] transition-colors shrink-0"
            aria-label={t('header.notifications')}
          >
            <Bell className="w-4.5 h-4.5 sm:w-5 sm:h-5" />
            {unreadNotificationCount > 0 && (
              <span className="absolute top-1 right-1 sm:top-1.5 sm:right-1.5 flex h-4 w-4 items-center justify-center rounded-full bg-rose-600 text-[10px] font-bold text-white font-mono tabular-nums">
                {unreadNotificationCount > 9 ? '9+' : unreadNotificationCount}
              </span>
            )}
          </button>

          {isNotifOpen && (
            <div className="absolute right-0 mt-2 w-[calc(100vw-2rem)] max-w-sm sm:w-96 rounded-2xl bg-white shadow-xl border border-[#E5E7EB] py-2 z-50 animate-in fade-in zoom-in-95 duration-150">
              <div className="px-4 py-2.5 border-b border-[#E5E7EB] flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-[#111827]">{t('header.notifications')}</span>
                  {unreadNotificationCount > 0 && (
                    <span className="px-1.5 py-0.5 rounded text-[11px] font-semibold bg-rose-100 text-rose-700">
                      {unreadNotificationCount} {isIndonesian ? 'Baru' : 'New'}
                    </span>
                  )}
                </div>
                {unreadNotificationCount > 0 && (
                  <button
                    onClick={markAllNotificationsAsRead}
                    className="text-[11px] text-[#065F46] hover:text-[#044e39] font-semibold hover:underline"
                  >
                    {t('header.markAllRead')}
                  </button>
                )}
              </div>

              <div className="max-h-80 overflow-y-auto divide-y divide-slate-100">
                {notifications.length === 0 ? (
                  <div className="p-6 text-center text-xs text-slate-400">
                    {t('header.noNotifications')}
                  </div>
                ) : (
                  notifications.map((n) => (
                    <div
                      key={n.id}
                      onClick={() => {
                        markNotificationAsRead(n.id);
                        if (n.requestId) {
                          onSelectRequestDetail(n.requestId);
                          setIsNotifOpen(false);
                        }
                      }}
                      className={`p-3.5 hover:bg-slate-50 transition-colors cursor-pointer flex items-start gap-3 ${
                        !n.isRead ? 'bg-blue-50/30' : ''
                      }`}
                    >
                      <div className="mt-0.5 p-1.5 rounded-lg bg-slate-100 shrink-0">
                        {getNotifIcon(n.type)}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between gap-1">
                          <p className="text-xs font-bold text-slate-900 truncate">{n.title}</p>
                          <span className="text-[10px] text-slate-400 whitespace-nowrap font-mono tabular-nums">
                            {n.createdAt.split('T')[0]}
                          </span>
                        </div>
                        <p className="text-xs text-slate-600 mt-0.5 line-clamp-2 leading-relaxed">
                          {n.message}
                        </p>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </div>

        {/* User Mini Profile & Logout */}
        <div
          className="flex items-center gap-2 pl-2 border-l border-slate-200"
          title={`${isIndonesian ? 'Profil' : 'Profile'}: ${currentUser.fullName} (${currentUser.jobTitle || currentUser.role})`}
        >
          <img
            src={
              currentUser.avatarUrl ||
              'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80'
            }
            alt={currentUser.fullName}
            className="w-8 h-8 rounded-full object-cover border border-slate-200"
          />
          <div className="hidden lg:block text-left">
            <div className="text-xs font-bold text-slate-900 truncate max-w-[130px]">
              {currentUser.fullName}
            </div>
            <div className="text-[10px] text-slate-500 capitalize">
              {currentUser.role.replace('_', ' ')}
            </div>
          </div>
          <button
            type="button"
            disabled={isLoggingOut}
            onClick={() => logout()}
            title={isIndonesian ? 'Keluar & Simpan' : 'Save & Logout'}
            aria-label={isIndonesian ? 'Keluar' : 'Logout'}
            className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 disabled:opacity-50 disabled:cursor-wait rounded-lg transition-colors ml-1"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
};
