import React from 'react';
import {
  LayoutDashboard,
  PlusCircle,
  ListTodo,
  CheckCircle2,
  Users2,
  BarChart3,
  ShieldCheck,
  Database,
  Settings,
  User,
  Sparkles,
  Layers,
  Briefcase,
  X,
  LogOut,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useRequests } from '../../context/RequestContext';
import { useLanguage } from '../../context/LanguageContext';

export type ActiveNavTab =
  | 'dashboard'
  | 'requests'
  | 'completed'
  | 'ai_hub'
  | 'workload'
  | 'analytics'
  | 'users'
  | 'master_data'
  | 'settings'
  | 'profile';

interface SidebarProps {
  activeTab: ActiveNavTab;
  onSelectTab: (tab: ActiveNavTab) => void;
  isOpenMobile: boolean;
  onCloseMobile: () => void;
  onOpenCreateModal: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  onSelectTab,
  isOpenMobile,
  onCloseMobile,
  onOpenCreateModal,
}) => {
  const { currentUser, isSuperAdmin, isAdmin, isRequester, isTeamMember, logout } = useAuth();
  const { requests } = useRequests();
  const { t, isIndonesian } = useLanguage();

  const handleNavClick = (tab: ActiveNavTab) => {
    onSelectTab(tab);
    onCloseMobile();
  };

  // Dynamic request label based on role
  const getRequestsLabel = () => {
    if (isRequester) return t('nav.myRequests');
    if (isTeamMember && !isAdmin) return t('nav.myTasks');
    return t('nav.requests');
  };

  const completedCount = requests.filter((r) => r.status === 'completed').length;

  const navItems = [
    {
      id: 'dashboard' as ActiveNavTab,
      label: t('nav.dashboard'),
      icon: <LayoutDashboard className="w-4 h-4" />,
      badge: null,
      visible: true,
    },
    {
      id: 'requests' as ActiveNavTab,
      label: getRequestsLabel(),
      icon: <ListTodo className="w-4 h-4" />,
      badge: requests.filter((r) => r.status !== 'completed').length,
      visible: true,
    },
    {
      id: 'completed' as ActiveNavTab,
      label: t('nav.completed'),
      icon: <CheckCircle2 className="w-4 h-4 text-emerald-500" />,
      badge: completedCount,
      visible: true,
    },
    {
      id: 'ai_hub' as ActiveNavTab,
      label: t('nav.aiHub'),
      icon: <Sparkles className="w-4 h-4 text-indigo-400" />,
      badge: '9 AI',
      visible: isAdmin || isTeamMember,
    },
    {
      id: 'workload' as ActiveNavTab,
      label: t('nav.workload'),
      icon: <Briefcase className="w-4 h-4" />,
      badge: null,
      visible: isAdmin || isTeamMember,
    },
    {
      id: 'analytics' as ActiveNavTab,
      label: t('nav.analytics'),
      icon: <BarChart3 className="w-4 h-4" />,
      badge: null,
      visible: isAdmin,
    },
    {
      id: 'users' as ActiveNavTab,
      label: t('nav.users'),
      icon: <Users2 className="w-4 h-4" />,
      badge: null,
      visible: isSuperAdmin,
    },
    {
      id: 'master_data' as ActiveNavTab,
      label: t('nav.masterData'),
      icon: <Database className="w-4 h-4" />,
      badge: null,
      visible: isSuperAdmin,
    },
    {
      id: 'settings' as ActiveNavTab,
      label: t('nav.settings'),
      icon: <Settings className="w-4 h-4" />,
      badge: null,
      visible: isSuperAdmin,
    },
    {
      id: 'profile' as ActiveNavTab,
      label: t('nav.profile'),
      icon: <User className="w-4 h-4" />,
      badge: null,
      visible: true,
    },
  ];

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpenMobile && (
        <div
          onClick={onCloseMobile}
          className="fixed inset-0 z-40 bg-slate-900/50 backdrop-blur-xs lg:hidden"
        />
      )}

      {/* Sidebar Container */}
      <aside
        className={`fixed top-0 bottom-0 left-0 z-40 w-64 h-screen max-h-screen bg-white border-r border-[#E5E7EB] text-slate-700 flex flex-col transition-transform duration-200 ease-in-out lg:translate-x-0 lg:static lg:z-10 ${
          isOpenMobile ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Brand Area */}
        <div className="p-5 border-b border-[#E5E7EB] flex items-center justify-between bg-white">
          <div className="flex items-center gap-3">
            <img
              src="/assets/aistudio/Marcom-Task-Request-Tracker_cfd946e5.png"
              alt="MARCOMM Task-Request Tracker"
              className="w-10 h-10 object-contain shrink-0 select-none"
              loading="eager"
              decoding="async"
              onError={(e) => {
                const target = e.currentTarget;
                if (!target.src.includes('/public/')) {
                  target.src = '/public/assets/aistudio/Marcom-Task-Request-Tracker_cfd946e5.png';
                }
              }}
            />
            <div>
              <div className="font-extrabold text-sm text-[#111827] tracking-tight flex items-center gap-1.5">
                <span>MARCOMM</span>
                <span className="text-[10px] px-1.5 py-0.5 rounded-md bg-[#D1FAE5] text-[#065F46] border border-[#A7F3D0] font-bold font-mono">
                  PRO
                </span>
              </div>
              <div className="text-[11px] text-[#64748B] font-medium">{t('app.subtitle')}</div>
            </div>
          </div>
          <button
            onClick={onCloseMobile}
            aria-label={isIndonesian ? 'Tutup menu navigasi' : 'Close navigation menu'}
            className="lg:hidden p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Create Request Action Button */}
        <div className="p-4 bg-white">
          <button
            onClick={() => {
              onOpenCreateModal();
              onCloseMobile();
            }}
            className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl text-xs font-bold text-white bg-[#065F46] hover:bg-[#044e39] transition-all shadow-xs active:scale-[0.98]"
          >
            <PlusCircle className="w-4 h-4" />
            <span>{t('nav.newRequest')}</span>
          </button>
        </div>

        {/* Navigation links */}
        <nav className="flex-1 overflow-y-auto px-3 py-2 space-y-1">
          {navItems
            .filter((item) => item.visible)
            .map((item) => {
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id)}
                  className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all ${
                    isActive
                      ? 'bg-[#065F46] text-white shadow-xs font-semibold'
                      : 'text-[#64748B] hover:text-[#111827] hover:bg-[#F0FDF4]'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <span className={isActive ? 'text-white' : 'text-slate-500'}>{item.icon}</span>
                    <span>{item.label}</span>
                  </div>
                  {item.badge !== null && (typeof item.badge === 'number' ? item.badge > 0 : Boolean(item.badge)) && (
                    <span
                      className={`text-[11px] px-2 py-0.5 rounded-full font-mono tabular-nums font-semibold ${
                        isActive
                          ? 'bg-[#044e39] text-[#D1FAE5]'
                          : 'bg-[#F1F5F9] text-[#475569] border border-[#E2E8F0]'
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
        </nav>

        {/* Bottom Current Profile Card */}
        <div className="p-4 border-t border-[#E5E7EB] bg-[#F7FAF8]">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-semibold text-[#64748B]">
              {isIndonesian ? 'Pengguna Aktif' : 'Active User'}
            </span>
            <span className="text-[10px] text-[#065F46] font-mono font-bold flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-[#10B981] animate-pulse" />
              {isIndonesian ? 'Aktif' : 'Online'}
            </span>
          </div>

          <div className="flex items-center gap-2.5 p-2.5 rounded-xl bg-white border border-[#E5E7EB] shadow-2xs">
            <img
              src={
                currentUser.avatarUrl ||
                'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80'
              }
              alt={currentUser.fullName}
              className="w-9 h-9 rounded-full object-cover shrink-0 border border-[#E5E7EB]"
            />
            <div className="min-w-0 flex-1 text-left">
              <div className="text-xs font-bold text-[#111827] truncate">{currentUser.fullName}</div>
              <div className="text-[11px] text-[#64748B] truncate capitalize">
                {currentUser.role.replace('_', ' ')}
                {currentUser.isReviewer && ' · Reviewer'}
              </div>
            </div>
            <button
              type="button"
              onClick={() => logout()}
              title={isIndonesian ? 'Keluar' : 'Logout'}
              aria-label={isIndonesian ? 'Keluar' : 'Logout'}
              className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors shrink-0"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </aside>
    </>
  );
};
