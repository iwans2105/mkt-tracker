import React, { useState, useEffect } from 'react';
import {
  X,
  Upload,
  Link as LinkIcon,
  AlertCircle,
  FileText,
  CheckCircle2,
  Trash2,
  HelpCircle,
  Paperclip,
  Sparkles,
  RefreshCw,
  User,
  UserCheck,
  Lock,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useRequests } from '../../context/RequestContext';
import { useLanguage } from '../../context/LanguageContext';
import { RequestPriority, Attachment, BrandQuotaSummary, PRIORITY_SLA_DAYS } from '../../types';
import { StorageService } from '../../services/storageService';
import { AiService } from '../../services/aiService';
import { PriorityQuotaSelector } from './PriorityQuotaSelector';

function getWibTodayDateString(): string {
  try {
    return new Intl.DateTimeFormat('en-CA', {
      timeZone: 'Asia/Jakarta',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
    }).format(new Date());
  } catch {
    return new Date().toISOString().split('T')[0];
  }
}

function getSlaDeadlineDateString(slaDays: number): string {
  const safeDays = Math.max(1, Number.isFinite(slaDays) ? Math.round(slaDays) : 1);
  const baseDateStr = getWibTodayDateString();
  const [year, month, day] = baseDateStr.split('-').map(Number);
  return new Date(Date.UTC(year, month - 1, day + safeDays)).toISOString().split('T')[0];
}

interface CreateRequestModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (requestId: string) => void;
  initialPrefill?: {
    title?: string;
    description?: string;
    deliverables?: string;
    priority?: RequestPriority;
    categoryId?: string;
  } | null;
}

export const CreateRequestModal: React.FC<CreateRequestModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  initialPrefill,
}) => {
  const { currentUser, allUsers, isAdmin, csrfToken } = useAuth();
  const { requests, regions, brands, units, departments, categories, createRequest } = useRequests();
  const { isIndonesian } = useLanguage();

  const [previewTicketNumber, setPreviewTicketNumber] = useState('');
  const [isUploadingFiles, setIsUploadingFiles] = useState(false);
  const [requestorId, setRequestorId] = useState(currentUser.id);
  const [requestorName, setRequestorName] = useState(currentUser.fullName);
  const [requestorEmail, setRequestorEmail] = useState(currentUser.email);
  const [title, setTitle] = useState('');
  const [regionId, setRegionId] = useState('');
  const [brandId, setBrandId] = useState('');
  const [unitId, setUnitId] = useState('');
  const [requesterDepartment, setRequesterDepartment] = useState('');
  const [categoryId, setCategoryId] = useState('');
  const [description, setDescription] = useState('');
  const [deliverablesExpected, setDeliverablesExpected] = useState('');
  const [priority, setPriority] = useState<RequestPriority>('medium');
  const [brandQuotaSummary, setBrandQuotaSummary] = useState<BrandQuotaSummary | null>(null);
  const [requestedDeadline, setRequestedDeadline] = useState(() =>
    getSlaDeadlineDateString(PRIORITY_SLA_DAYS.medium)
  );

  const effectiveSlaDays =
    brandQuotaSummary?.priorities[priority]?.slaDays ?? PRIORITY_SLA_DAYS[priority];

  // Attachments & links
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const [referenceUrl, setReferenceUrl] = useState('');
  const [uploadError, setUploadError] = useState('');

  // Submission state
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});

  // Inline AI Assistant State
  const [showAiBox, setShowAiBox] = useState(false);
  const [aiPrompt, setAiPrompt] = useState('');
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [aiSlaNote, setAiSlaNote] = useState('');

  useEffect(() => {
    if (isOpen) {
      const currentYear = new Date().getFullYear();
      const prefix = `REQ-${currentYear}-`;
      const maxSeq = requests.reduce((max, r) => {
        if (r.ticketNumber?.startsWith(prefix)) {
          const n = parseInt(r.ticketNumber.slice(prefix.length), 10);
          if (!Number.isNaN(n) && n > max) return n;
        }
        return max;
      }, 0);
      setPreviewTicketNumber(`${prefix}${String(maxSeq + 1).padStart(4, '0')}`);
      // Initialize Requestor's Name from authenticated profile
      setRequestorId(currentUser.id);
      setRequestorName(currentUser.fullName);
      setRequestorEmail(currentUser.email);
      // Default department to user's department if available
      if (currentUser?.department) {
        setRequesterDepartment(currentUser.department);
      }
      // Default to first region
      if (regions.length > 0 && !regionId) {
        setRegionId(regions[0].id);
      }
      // Apply prefill if provided
      if (initialPrefill) {
        if (initialPrefill.title) setTitle(initialPrefill.title);
        if (initialPrefill.description) setDescription(initialPrefill.description);
        if (initialPrefill.deliverables) setDeliverablesExpected(initialPrefill.deliverables);
        if (initialPrefill.priority) setPriority(initialPrefill.priority);
        if (initialPrefill.categoryId) setCategoryId(initialPrefill.categoryId);
      }
    }
  }, [isOpen, currentUser, regions, initialPrefill]);

  // Keep Requested Deadline strictly synchronized with active Priority & SLA Commitment
  useEffect(() => {
    if (isOpen) {
      setRequestedDeadline(getSlaDeadlineDateString(effectiveSlaDays));
    }
  }, [isOpen, priority, effectiveSlaDays]);

  const handleSelectRequestor = (selectedUserId: string) => {
    setRequestorId(selectedUserId);
    const found = allUsers.find((u) => u.id === selectedUserId);
    if (found) {
      setRequestorName(found.fullName);
      setRequestorEmail(found.email);
      if (found.department) {
        setRequesterDepartment(found.department);
      }
    }
  };

  const handleRunInlineAi = async () => {
    if (!aiPrompt.trim()) return;
    setIsAiLoading(true);
    try {
      const selectedBrandName = brands.find((b) => b.id === brandId)?.name || '';
      const res = await AiService.getRequestAssistant({
        prompt: aiPrompt,
        brand: selectedBrandName,
      });
      if (res.title) setTitle(res.title);
      if (res.description) setDescription(res.description);
      if (res.deliverables) setDeliverablesExpected(res.deliverables.join('\n'));
      if (res.recommendedPriority) setPriority(res.recommendedPriority);
      if (res.slaRationale) setAiSlaNote(res.slaRationale);
      setShowAiBox(false);
    } catch (err) {
      console.error('AI assistant error:', err);
    } finally {
      setIsAiLoading(false);
    }
  };

  // Update brand list when region changes
  const availableBrands = brands.filter((b) => b.regionId === regionId);

  // Check if selected brand has units (e.g. Lyman Devindo)
  const availableUnits = units.filter((u) => u.brandId === brandId);

  if (!isOpen) return null;

  // File size limit: 50MB
  const MAX_FILE_SIZE = 50 * 1024 * 1024;
  const ALLOWED_EXTENSIONS = [
    'pdf',
    'jpg',
    'jpeg',
    'png',
    'webp',
    'docx',
    'xlsx',
    'pptx',
    'mp4',
    'zip',
  ];

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    setUploadError('');
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const validFiles: File[] = [];
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const ext = file.name.split('.').pop()?.toLowerCase() || '';

      if (!ALLOWED_EXTENSIONS.includes(ext)) {
        setUploadError(
          isIndonesian
            ? `Format file "${file.name}" tidak didukung. Silakan unggah PDF, JPG, PNG, WEBP, DOCX, XLSX, PPTX, MP4, atau ZIP.`
            : `File format "${file.name}" is not supported. Please upload PDF, JPG, PNG, WEBP, DOCX, XLSX, PPTX, MP4, or ZIP.`
        );
        return;
      }

      if (file.size > MAX_FILE_SIZE) {
        setUploadError(
          isIndonesian
            ? `Ukuran file "${file.name}" melebihi batas maksimal 50MB.`
            : `File "${file.name}" exceeds the maximum 50MB size limit.`
        );
        return;
      }
      validFiles.push(file);
    }

    setIsUploadingFiles(true);
    try {
      for (const file of validFiles) {
        const uploaded = await StorageService.uploadFileToR2(
          file,
          {
            scopeType: 'brief',
            brandId: brandId || undefined,
            regionId: regionId || undefined,
          },
          csrfToken
        );
        setAttachments((prev) => [...prev, uploaded]);
      }
    } catch (err: any) {
      setUploadError(
        err?.message ||
          (isIndonesian
            ? 'Gagal mengunggah lampiran ke Cloudflare R2.'
            : 'Failed to upload attachment to Cloudflare R2.')
      );
    } finally {
      setIsUploadingFiles(false);
      e.target.value = '';
    }
  };

  const removeAttachment = (id: string) => {
    setAttachments((prev) => prev.filter((a) => a.id !== id));
  };

  const validate = (): boolean => {
    const errors: Record<string, string> = {};

    if (!requestorName.trim()) {
      errors.requestorName = isIndonesian
        ? 'Nama Pemohon wajib diisi.'
        : "Requestor's Name is required.";
    }
    if (!title.trim() || title.trim().length < 5) {
      errors.title = isIndonesian
        ? 'Judul pekerjaan wajib diisi (minimal 5 karakter).'
        : 'Title is required (minimum 5 characters).';
    }
    if (!regionId) {
      errors.regionId = isIndonesian ? 'Wilayah wajib dipilih.' : 'Region must be selected.';
    }
    if (!brandId) {
      errors.brandId = isIndonesian
        ? 'Brand / Entitas wajib dipilih.'
        : 'Brand / Entity must be selected.';
    }
    if (!requesterDepartment) {
      errors.requesterDepartment = isIndonesian
        ? 'Departemen pemohon wajib dipilih.'
        : 'Requester department must be selected.';
    }
    if (!categoryId) {
      errors.categoryId = isIndonesian
        ? 'Kategori tugas wajib dipilih.'
        : 'Task category must be selected.';
    }
    if (!description.trim() || description.trim().length < 15) {
      errors.description = isIndonesian
        ? 'Deskripsi brief wajib diisi (minimal 15 karakter).'
        : 'Brief requirements are required (minimum 15 characters).';
    }
    if (!deliverablesExpected.trim() || deliverablesExpected.trim().length < 5) {
      errors.deliverablesExpected = isIndonesian
        ? 'Hasil pekerjaan yang diharapkan wajib diisi.'
        : 'Expected deliverables are required.';
    }
    const resolvedDeadline = requestedDeadline || getSlaDeadlineDateString(effectiveSlaDays);
    if (!resolvedDeadline) {
      errors.requestedDeadline = isIndonesian
        ? 'Tanggal tenggat yang diminta wajib diisi.'
        : 'Requested deadline date is required.';
    } else {
      const today = getWibTodayDateString();
      if (resolvedDeadline < today) {
        errors.requestedDeadline = isIndonesian
          ? 'Tenggat waktu yang diminta tidak boleh di masa lalu.'
          : 'Requested deadline cannot be in the past.';
      }
    }

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate() || isSubmitting) return;

    setIsSubmitting(true);
    try {
      const selectedRegion = regions.find((r) => r.id === regionId);
      const selectedBrand = brands.find((b) => b.id === brandId);
      const selectedUnit = units.find((u) => u.id === unitId);
      const selectedCategory = categories.find((c) => c.id === categoryId);

      // Prepend reference link to description or attachments if present
      let finalDescription = description;
      if (referenceUrl.trim()) {
        finalDescription += `\n\n[Additional Reference Link]: ${referenceUrl.trim()}`;
      }

      const authoritativeDeadline = getSlaDeadlineDateString(effectiveSlaDays);

      const res = await createRequest({
        title: title.trim(),
        regionId,
        regionName: selectedRegion?.name || '',
        brandId,
        brandName: selectedBrand?.name || '',
        unitId: unitId || undefined,
        unitName: selectedUnit ? selectedUnit.name : undefined,
        requesterDepartment,
        categoryId,
        categoryName: selectedCategory?.name || '',
        description: finalDescription,
        deliverablesExpected: deliverablesExpected.trim(),
        priority,
        requesterId: requestorId || currentUser.id,
        requesterName: requestorName.trim(),
        requestorName: requestorName.trim(),
        requesterEmail: requestorEmail || currentUser.email,
        requestedDeadline: authoritativeDeadline,
        collaboratorIds: [],
        briefAttachments: attachments,
      });

      if (res.success && res.request) {
        onSuccess(res.request.id);
        onClose();
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2.5 sm:p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-3xl w-full max-h-[92vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="px-4 sm:px-6 py-3.5 sm:py-5 border-b border-slate-200 flex items-center justify-between bg-slate-50 gap-2 shrink-0">
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-base sm:text-lg font-bold text-slate-900 truncate">
                {isIndonesian ? 'Buat Permintaan Kerja Baru' : 'New Work Request'}
              </h2>
              <span className="font-mono text-xs font-bold px-2 py-0.5 rounded-md bg-[#D1FAE5] text-[#065F46] border border-[#A7F3D0] shrink-0">
                {previewTicketNumber}
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-0.5 truncate hidden sm:block">
              {isIndonesian
                ? 'Formulir pengajuan brief permintaan kreatif & media untuk divisi Marketing Communications.'
                : 'Creative & media request brief submission form for the Marketing Communications division.'}
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-200/60 transition-colors shrink-0"
            aria-label={isIndonesian ? 'Tutup formulir' : 'Close form'}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4 sm:space-y-5">
          {/* Section: Pemohon Info (Auto from session) */}
          <div className="p-2.5 sm:p-3 bg-slate-50 rounded-xl border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-1 text-xs text-slate-600">
            <div className="truncate">
              <span className="text-slate-400">{isIndonesian ? 'Pemohon: ' : 'Requester: '}</span>
              <strong className="text-slate-900 font-semibold">{currentUser.fullName}</strong>
              <span className="text-slate-400 mx-1.5">·</span>
              <span className="truncate">{currentUser.email}</span>
            </div>
            <span className="text-[11px] text-slate-500 bg-white px-2 py-0.5 rounded border border-slate-200 shrink-0 self-start sm:self-auto">
              {isIndonesian ? 'Sesi Pengguna Terverifikasi' : 'Verified User Session'}
            </span>
          </div>

          {/* AI Request Assistant Quick Helper Card */}
          <div className="rounded-xl border border-indigo-200 bg-gradient-to-r from-indigo-50/90 to-purple-50/70 p-3.5 space-y-2.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-indigo-600" />
                <span className="text-xs font-bold text-indigo-950">
                  {isIndonesian
                    ? 'Asisten Permintaan AI (Generator Brief Instan)'
                    : 'AI Request Assistant (Instant Brief Generator)'}
                </span>
              </div>
              <button
                type="button"
                onClick={() => setShowAiBox(!showAiBox)}
                className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 underline underline-offset-2"
              >
                {showAiBox
                  ? isIndonesian
                    ? 'Tutup'
                    : 'Close'
                  : isIndonesian
                  ? 'Buka Draf Otomatis'
                  : 'Open Auto-Draft'}
              </button>
            </div>

            {showAiBox && (
              <div className="pt-2 border-t border-indigo-100 space-y-2">
                <p className="text-[11px] text-slate-600">
                  {isIndonesian
                    ? 'Masukkan ide mentah atau poin-poin kebutuhan Anda. AI akan menyusun judul terstruktur, deskripsi ruang lingkup, deliverable, dan rekomendasi SLA langsung ke formulir ini.'
                    : 'Enter your raw ideas or bullet points. AI will formulate a structured title, scope description, deliverables, and recommended SLA directly into this form.'}
                </p>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={aiPrompt}
                    onChange={(e) => setAiPrompt(e.target.value)}
                    placeholder={
                      isIndonesian
                        ? 'Contoh: Butuh flyer promo akhir pekan Wahoo Waterworld diskon 25% untuk feed dan reels...'
                        : 'e.g., Need weekend promotional flyer for Wahoo Waterworld with 25% discount for feed and reels...'
                    }
                    className="flex-1 text-xs px-3 py-1.5 bg-white border border-indigo-200 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleRunInlineAi();
                      }
                    }}
                  />
                  <button
                    type="button"
                    onClick={handleRunInlineAi}
                    disabled={isAiLoading || !aiPrompt.trim()}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-600 text-white font-medium text-xs hover:bg-indigo-700 disabled:opacity-50 transition-colors shrink-0 shadow-xs"
                  >
                    {isAiLoading ? (
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    ) : (
                      <Sparkles className="w-3.5 h-3.5" />
                    )}
                    {isAiLoading
                      ? isIndonesian
                        ? 'Menyusun...'
                        : 'Drafting...'
                      : isIndonesian
                      ? 'Terapkan Draf AI'
                      : 'Apply AI Draft'}
                  </button>
                </div>
              </div>
            )}

            {aiSlaNote && (
              <div className="text-[11px] text-amber-800 bg-amber-50 p-2 rounded border border-amber-200">
                <strong>{isIndonesian ? 'Rekomendasi SLA AI:' : 'AI SLA Recommendation:'}</strong> {aiSlaNote}
              </div>
            )}
          </div>

          {/* Field: Requestor's Name */}
          <div className="p-3.5 bg-slate-50/80 rounded-xl border border-slate-200 space-y-1.5">
            <div className="flex items-center justify-between">
              <label htmlFor="requestorNameInput" className="flex items-center gap-1.5 text-xs font-bold text-slate-900">
                <User className="w-3.5 h-3.5 text-[#065F46]" />
                <span>{isIndonesian ? 'Nama Pemohon' : "Requestor's Name"}</span>
                <span className="text-rose-500">*</span>
              </label>
              {isAdmin ? (
                <span className="text-[10px] font-semibold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                  {isIndonesian ? 'Admin: Pengajuan Atas Nama Aktif' : 'Admin: On-Behalf Submission Enabled'}
                </span>
              ) : (
                <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-[#065F46] bg-[#D1FAE5] px-2 py-0.5 rounded-full border border-[#A7F3D0]">
                  <UserCheck className="w-3 h-3 text-[#065F46]" />
                  {isIndonesian ? 'Identitas Korporat Terverifikasi' : 'Verified Corporate Identity'}
                </span>
              )}
            </div>

            {isAdmin ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                <div>
                  <label className="block text-[11px] text-slate-500 mb-1">
                    {isIndonesian ? 'Pilih dari Direktori Pengguna Terdaftar' : 'Select from Registered User Directory'}
                  </label>
                  <select
                    value={requestorId}
                    onChange={(e) => handleSelectRequestor(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-[#065F46]/20 focus:border-[#065F46]"
                  >
                    {allUsers.map((u) => (
                      <option key={u.id} value={u.id}>
                        {u.fullName} ({u.role} · {u.department || (isIndonesian ? 'Umum' : 'General')})
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-[11px] text-slate-500 mb-1">
                    {isIndonesian ? 'Nama Lengkap Pemohon' : 'Requestor Full Name'}
                  </label>
                  <input
                    id="requestorNameInput"
                    type="text"
                    value={requestorName}
                    onChange={(e) => setRequestorName(e.target.value)}
                    placeholder={isIndonesian ? 'Masukkan nama pemohon' : "Enter requestor's name"}
                    className={`w-full px-3 py-2 text-xs bg-white border rounded-xl focus:outline-hidden focus:ring-2 focus:ring-[#065F46]/20 ${
                      formErrors.requestorName ? 'border-rose-500' : 'border-slate-300 focus:border-[#065F46]'
                    }`}
                  />
                </div>
              </div>
            ) : (
              <div className="relative">
                <input
                  id="requestorNameInput"
                  type="text"
                  value={requestorName}
                  readOnly
                  aria-readonly="true"
                  className="w-full px-3.5 py-2 text-xs bg-white/80 border border-slate-200 text-slate-800 font-medium rounded-xl cursor-not-allowed select-none focus:outline-none"
                />
                <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-1.5 text-[11px] text-slate-400">
                  <span className="hidden sm:inline">
                    {isIndonesian ? 'Terisi otomatis dari akun' : 'Auto-populated from account'}
                  </span>
                  <UserCheck className="w-3.5 h-3.5 text-[#065F46]" />
                </div>
              </div>
            )}
            {formErrors.requestorName && (
              <p className="text-[11px] text-rose-600 mt-1">{formErrors.requestorName}</p>
            )}
          </div>

          {/* Judul Pekerjaan */}
          <div>
            <label className="block text-xs font-bold text-slate-900 mb-1">
              {isIndonesian ? 'Judul Pekerjaan' : 'Task Title'} <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder={
                isIndonesian
                  ? 'Contoh: Desain Brosur Cetak Promo Ramadhan 2026'
                  : 'e.g., Ramadhan Promo 2026 Print Brochure Design'
              }
              className={`w-full px-3.5 py-2 text-xs bg-white border rounded-xl focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 ${
                formErrors.title ? 'border-rose-500 focus:border-rose-500' : 'border-slate-300 focus:border-blue-600'
              }`}
            />
            {formErrors.title && <p className="text-[11px] text-rose-600 mt-1">{formErrors.title}</p>}
          </div>

          {/* 3-Column: Wilayah, Brand, Unit */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-900 mb-1">
                {isIndonesian ? 'Wilayah' : 'Region'} <span className="text-rose-500">*</span>
              </label>
              <select
                value={regionId}
                onChange={(e) => {
                  setRegionId(e.target.value);
                  setBrandId('');
                  setBrandQuotaSummary(null);
                  setUnitId('');
                }}
                className={`w-full px-3 py-2 text-xs bg-white border rounded-xl focus:outline-hidden ${
                  formErrors.regionId ? 'border-rose-500' : 'border-slate-300 focus:border-blue-600'
                }`}
              >
                <option value="">{isIndonesian ? 'Pilih Wilayah' : 'Select Region'}</option>
                {regions.map((reg) => (
                  <option key={reg.id} value={reg.id}>
                    {reg.name}
                  </option>
                ))}
              </select>
              {formErrors.regionId && <p className="text-[11px] text-rose-600 mt-1">{formErrors.regionId}</p>}
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-900 mb-1">
                {isIndonesian ? 'Brand / Entitas' : 'Brand / Entity'} <span className="text-rose-500">*</span>
              </label>
              <select
                value={brandId}
                disabled={!regionId}
                onChange={(e) => {
                  setBrandId(e.target.value);
                  setBrandQuotaSummary(null);
                  setUnitId('');
                }}
                className={`w-full px-3 py-2 text-xs bg-white border rounded-xl focus:outline-hidden disabled:bg-slate-100 ${
                  formErrors.brandId ? 'border-rose-500' : 'border-slate-300 focus:border-blue-600'
                }`}
              >
                <option value="">{isIndonesian ? 'Pilih Brand' : 'Select Brand'}</option>
                {availableBrands.map((b) => (
                  <option key={b.id} value={b.id}>
                    {b.name}
                  </option>
                ))}
              </select>
              {formErrors.brandId && <p className="text-[11px] text-rose-600 mt-1">{formErrors.brandId}</p>}
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-900 mb-1">
                {isIndonesian ? 'Unit Bisnis Internal (Opsional)' : 'Internal Business Unit (Optional)'}
              </label>
              <select
                value={unitId}
                disabled={availableUnits.length === 0}
                onChange={(e) => setUnitId(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-xl focus:outline-hidden disabled:bg-slate-100"
              >
                <option value="">
                  {availableUnits.length > 0
                    ? isIndonesian
                      ? 'Pilih Unit Bisnis'
                      : 'Select Business Unit'
                    : isIndonesian
                    ? 'Tidak ada unit khusus'
                    : 'No dedicated unit'}
                </option>
                {availableUnits.map((u) => (
                  <option key={u.id} value={u.id}>
                    {u.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* 2-Column: Departemen Pemohon & Kategori Pekerjaan */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-900 mb-1">
                {isIndonesian ? 'Departemen Pemohon' : 'Requester Department'} <span className="text-rose-500">*</span>
              </label>
              <select
                value={requesterDepartment}
                onChange={(e) => setRequesterDepartment(e.target.value)}
                className={`w-full px-3 py-2 text-xs bg-white border rounded-xl focus:outline-hidden ${
                  formErrors.requesterDepartment ? 'border-rose-500' : 'border-slate-300 focus:border-blue-600'
                }`}
              >
                <option value="">{isIndonesian ? 'Pilih Departemen' : 'Select Department'}</option>
                {departments.map((dept) => (
                  <option key={dept.id} value={dept.name}>
                    {dept.name}
                  </option>
                ))}
              </select>
              {formErrors.requesterDepartment && (
                <p className="text-[11px] text-rose-600 mt-1">{formErrors.requesterDepartment}</p>
              )}
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-900 mb-1">
                {isIndonesian ? 'Kategori Tugas' : 'Task Category'} <span className="text-rose-500">*</span>
              </label>
              <select
                value={categoryId}
                onChange={(e) => setCategoryId(e.target.value)}
                className={`w-full px-3 py-2 text-xs bg-white border rounded-xl focus:outline-hidden ${
                  formErrors.categoryId ? 'border-rose-500' : 'border-slate-300 focus:border-blue-600'
                }`}
              >
                <option value="">{isIndonesian ? 'Pilih Kategori' : 'Select Category'}</option>
                {categories.map((cat) => (
                  <option key={cat.id} value={cat.id}>
                    {cat.name}
                  </option>
                ))}
              </select>
              {formErrors.categoryId && (
                <p className="text-[11px] text-rose-600 mt-1">{formErrors.categoryId}</p>
              )}
            </div>
          </div>

          {/* Deskripsi Kebutuhan */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-xs font-bold text-slate-900">
                {isIndonesian ? 'Deskripsi Brief & Ruang Lingkup' : 'Brief Requirements & Scope'}{' '}
                <span className="text-rose-500">*</span>
              </label>
              <span className="text-[10px] text-slate-400 font-mono tabular-nums">
                {description.length}/5000
              </span>
            </div>
            <textarea
              rows={4}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder={
                isIndonesian
                  ? 'Jelaskan tujuan, pesan utama, target audiens, teks/copy wajib, dan referensi gaya visual secara rinci...'
                  : 'Provide detailed objectives, key messages, target audience, mandatory copy text, and any visual style references...'
              }
              className={`w-full px-3.5 py-2.5 text-xs bg-white border rounded-xl focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 leading-relaxed ${
                formErrors.description ? 'border-rose-500' : 'border-slate-300 focus:border-blue-600'
              }`}
            />
            {formErrors.description && (
              <p className="text-[11px] text-rose-600 mt-1">{formErrors.description}</p>
            )}
          </div>

          {/* Deliverables yang Diharapkan */}
          <div>
            <label className="block text-xs font-bold text-slate-900 mb-1">
              {isIndonesian ? 'Deliverable yang Diharapkan' : 'Expected Deliverables'}{' '}
              <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              value={deliverablesExpected}
              onChange={(e) => setDeliverablesExpected(e.target.value)}
              placeholder={
                isIndonesian
                  ? 'Contoh: PDF siap cetak 300dpi, aset logo PNG transparan, dan video MP4 1080x1920'
                  : 'e.g., Print-ready 300dpi PDF, transparent PNG logo assets, and 1080x1920 MP4 video'
              }
              className={`w-full px-3.5 py-2 text-xs bg-white border rounded-xl focus:outline-hidden ${
                formErrors.deliverablesExpected ? 'border-rose-500' : 'border-slate-300 focus:border-blue-600'
              }`}
            />
            {formErrors.deliverablesExpected && (
              <p className="text-[11px] text-rose-600 mt-1">{formErrors.deliverablesExpected}</p>
            )}
          </div>

          {/* Priority Quota Selector & Auto-Locked Requested Deadline */}
          <div className="space-y-3">
            <PriorityQuotaSelector
              brandId={brandId}
              brandName={brands.find((b) => b.id === brandId)?.name || (isIndonesian ? 'Brand Terpilih' : 'Selected Brand')}
              selectedPriority={priority}
              onSummaryLoaded={setBrandQuotaSummary}
              onChange={(newP) => {
                setPriority(newP);
                const nextSlaDays =
                  brandQuotaSummary?.priorities[newP]?.slaDays ?? PRIORITY_SLA_DAYS[newP];
                setRequestedDeadline(getSlaDeadlineDateString(nextSlaDays));
              }}
              disabled={isSubmitting}
            />

            <div>
              <div className="flex items-center justify-between mb-1 gap-2">
                <label className="text-xs font-bold text-slate-900">
                  {isIndonesian ? 'Tenggat Waktu yang Diminta' : 'Requested Deadline'}{' '}
                  <span className="text-rose-500">*</span>
                </label>
                <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-[#065F46] bg-[#D1FAE5]/70 px-2 py-0.5 rounded-full border border-[#A7F3D0]">
                  <Lock className="w-3 h-3 text-[#065F46]" />
                  <span>
                    {isIndonesian
                      ? `Otomatis sesuai SLA (+${effectiveSlaDays} Hari)`
                      : `Auto-locked to SLA (+${effectiveSlaDays} ${effectiveSlaDays === 1 ? 'Day' : 'Days'})`}
                  </span>
                </span>
              </div>
              <div className="relative">
                <input
                  type="date"
                  value={requestedDeadline}
                  readOnly
                  disabled
                  aria-readonly="true"
                  tabIndex={-1}
                  className={`w-full px-3 py-2 text-xs bg-slate-50 border text-slate-800 font-semibold rounded-xl font-mono cursor-not-allowed select-none focus:outline-none ${
                    formErrors.requestedDeadline ? 'border-rose-500' : 'border-slate-200'
                  }`}
                />
              </div>
              <p className="text-[11px] text-slate-500 mt-1">
                {isIndonesian
                  ? 'Tanggal otomatis terisi dan dikunci berdasarkan Prioritas & Komitmen SLA yang dipilih.'
                  : 'Date is automatically populated and locked based on the selected Priority & SLA Commitment.'}
              </p>
              {formErrors.requestedDeadline && (
                <p className="text-[11px] text-rose-600 mt-1">{formErrors.requestedDeadline}</p>
              )}
            </div>
          </div>

          {/* Lampiran File & Tautan Referensi */}
          <div className="p-4 bg-slate-50/70 rounded-xl border border-slate-200 space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                <Paperclip className="w-3.5 h-3.5 text-slate-500" />
                <span>
                  {isIndonesian
                    ? 'Lampiran Brief (PDF, DOCX, JPG, PNG, MP4, ZIP maks. 50MB)'
                    : 'Brief Attachments (PDF, DOCX, JPG, PNG, MP4, ZIP max 50MB)'}
                </span>
              </label>
            </div>

            <div className="flex items-center gap-3">
              <label className="cursor-pointer inline-flex items-center gap-2 px-3 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-xl transition-colors shadow-2xs">
                <Upload className="w-3.5 h-3.5 text-slate-500" />
                <span>
                  {isUploadingFiles
                    ? isIndonesian
                      ? 'Mengunggah...'
                      : 'Uploading...'
                    : isIndonesian
                    ? 'Pilih File'
                    : 'Choose Files'}
                </span>
                <input
                  type="file"
                  multiple
                  disabled={isUploadingFiles || isSubmitting}
                  onChange={handleFileUpload}
                  className="hidden"
                  accept=".pdf,.jpg,.jpeg,.png,.webp,.docx,.xlsx,.pptx,.mp4,.zip"
                />
              </label>
              <span className="text-[11px] text-slate-400">
                {isIndonesian
                  ? `${attachments.length} file dipilih`
                  : `${attachments.length} ${attachments.length === 1 ? 'file' : 'files'} selected`}
              </span>
            </div>

            {uploadError && <p className="text-[11px] text-rose-600">{uploadError}</p>}

            {/* Attachment list */}
            {attachments.length > 0 && (
              <div className="space-y-1.5 pt-2">
                {attachments.map((att) => (
                  <div
                    key={att.id}
                    className="flex items-center justify-between p-2 bg-white rounded-lg border border-slate-200 text-xs"
                  >
                    <div className="flex items-center gap-2 truncate">
                      <FileText className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                      <span className="truncate font-medium text-slate-800">{att.name}</span>
                      <span className="text-[10px] text-slate-400 font-mono">
                        ({Math.round(att.size / 1024)} KB)
                      </span>
                    </div>
                    <button
                      type="button"
                      onClick={() => removeAttachment(att.id)}
                      className="p-1 text-slate-400 hover:text-rose-600 transition-colors"
                      title={isIndonesian ? 'Hapus lampiran' : 'Remove attachment'}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            )}

            {/* Optional reference URL */}
            <div className="pt-2">
              <label className="block text-xs font-medium text-slate-700 mb-1">
                {isIndonesian
                  ? 'Tautan Referensi Eksternal (Google Drive / Figma / Pinterest / Dropbox)'
                  : 'External Reference Link (Google Drive / Figma / Pinterest / Dropbox)'}
              </label>
              <div className="relative">
                <LinkIcon className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="url"
                  value={referenceUrl}
                  onChange={(e) => setReferenceUrl(e.target.value)}
                  placeholder="https://drive.google.com/..."
                  className="w-full pl-8 pr-3 py-1.5 text-xs bg-white border border-slate-300 rounded-lg focus:outline-hidden focus:border-blue-600"
                />
              </div>
            </div>
          </div>

          {/* Footer Submit Buttons */}
          <div className="pt-3 border-t border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <span className="text-xs text-slate-500 text-left">
              {isIndonesian ? (
                <>
                  Permintaan ini akan otomatis masuk ke antrean <strong>Antrean (To Do)</strong>.
                </>
              ) : (
                <>
                  This request will be automatically queued under <strong>To Do / Backlog</strong>.
                </>
              )}
            </span>
            <div className="flex items-center gap-2.5 w-full sm:w-auto justify-end">
              <button
                type="button"
                onClick={onClose}
                disabled={isSubmitting}
                className="flex-1 sm:flex-initial px-4 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-xl hover:bg-slate-100 transition-colors"
              >
                {isIndonesian ? 'Batal' : 'Cancel'}
              </button>
              <button
                type="submit"
                disabled={isSubmitting || isUploadingFiles}
                className="flex-1 sm:flex-initial px-5 py-2 text-xs font-bold text-white bg-[#065F46] hover:bg-[#044e39] disabled:bg-[#065F46]/50 rounded-xl shadow-xs transition-colors active:scale-[0.98]"
              >
                {isSubmitting
                  ? isIndonesian
                    ? 'Mengirim...'
                    : 'Submitting...'
                  : isIndonesian
                  ? 'Kirim Permintaan'
                  : 'Submit Request'}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
