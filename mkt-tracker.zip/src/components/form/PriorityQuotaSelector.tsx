import React, { useEffect, useState, useCallback } from 'react';
import { Clock, AlertCircle, CheckCircle2, ShieldAlert } from 'lucide-react';
import { RequestPriority, BrandQuotaSummary, PriorityAvailability, PRIORITY_SLA_DAYS } from '../../types';
import { useRequests } from '../../context/RequestContext';
import { useLanguage } from '../../context/LanguageContext';

interface PriorityQuotaSelectorProps {
  brandId: string;
  brandName: string;
  selectedPriority: RequestPriority;
  onChange: (priority: RequestPriority) => void;
  onSummaryLoaded?: (summary: BrandQuotaSummary | null) => void;
  disabled?: boolean;
}

export const PriorityQuotaSelector: React.FC<PriorityQuotaSelectorProps> = ({
  brandId,
  brandName,
  selectedPriority,
  onChange,
  onSummaryLoaded,
  disabled = false,
}) => {
  const { fetchBrandQuota, syncVersion } = useRequests();
  const { language } = useLanguage();

  const [quotaSummary, setQuotaSummary] = useState<BrandQuotaSummary | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const loadQuota = useCallback(async () => {
    if (!brandId) {
      setQuotaSummary(null);
      onSummaryLoaded?.(null);
      return;
    }
    setIsLoading(true);
    try {
      const summary = await fetchBrandQuota(brandId, brandName);
      if (summary) {
        setQuotaSummary(summary);
        onSummaryLoaded?.(summary);

        // TC-14: If previously selected priority is exhausted for the newly selected brand, auto-switch to an available one
        const currentPrioInfo = summary.priorities[selectedPriority];
        if (currentPrioInfo && currentPrioInfo.isExhausted) {
          // Find first available priority in preference order: high -> medium -> low
          const fallbackOrder: RequestPriority[] = ['high', 'medium', 'low'];
          const available = fallbackOrder.find((p) => !summary.priorities[p]?.isExhausted);
          if (available) {
            onChange(available);
          }
        }
      }
    } finally {
      setIsLoading(false);
    }
  }, [brandId, brandName, fetchBrandQuota, onChange, selectedPriority]);

  useEffect(() => {
    loadQuota();
  }, [brandId, brandName, syncVersion]);

  const priorityOrder: RequestPriority[] = ['urgent', 'high', 'medium', 'low'];

  const getPriorityBadgeClass = (prio: RequestPriority, isSelected: boolean, isExhausted: boolean) => {
    if (isExhausted) {
      return 'border-slate-200 bg-slate-50 opacity-60 cursor-not-allowed';
    }
    if (isSelected) {
      return 'border-[#065F46] bg-emerald-50/70 ring-1 ring-[#065F46] shadow-2xs';
    }
    return 'border-slate-200 hover:border-slate-300 bg-white hover:bg-slate-50/60 cursor-pointer';
  };

  const allFastExhausted =
    quotaSummary &&
    quotaSummary.priorities.urgent?.isExhausted &&
    quotaSummary.priorities.high?.isExhausted &&
    quotaSummary.priorities.medium?.isExhausted;

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <label className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
          <span>{language === 'id' ? 'Prioritas & Komitmen SLA' : 'Priority & SLA Commitment'}</span>
          <span className="text-rose-500">*</span>
        </label>
        {quotaSummary && (
          <span className="text-[10px] text-slate-500 font-mono">
            {language === 'id' ? `Tahun ${quotaSummary.year}` : `Year ${quotaSummary.year}`}
          </span>
        )}
      </div>

      {allFastExhausted && (
        <div className="p-2.5 bg-amber-50 border border-amber-200 rounded-xl text-amber-800 text-[11px] flex items-start gap-2">
          <ShieldAlert className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
          <div className="leading-snug">
            {language === 'id'
              ? `Seluruh kuota prioritas cepat untuk ${brandName} tahun ini telah habis. Permintaan dialihkan ke prioritas Rendah (Standar 14 Hari).`
              : `All expedited priority quotas for ${brandName} have been exhausted this year. Requests default to Low Priority (Standard 14 Days).`}
          </div>
        </div>
      )}

      {/* Grid of Priority Options matching Master Prompt Section 3 */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
        {priorityOrder.map((prio) => {
          const info: PriorityAvailability | undefined = quotaSummary?.priorities[prio];
          const isSelected = selectedPriority === prio;
          const isExhausted = Boolean(info?.isExhausted);
          const isUnlimited = info?.annualLimit === -1 || prio === 'low';

          const prioTitle =
            language === 'id'
              ? prio === 'urgent'
                ? 'Mendesak'
                : prio === 'high'
                ? 'Tinggi'
                : prio === 'medium'
                ? 'Sedang'
                : 'Rendah'
              : prio.charAt(0).toUpperCase() + prio.slice(1);

          const slaDays = info?.slaDays ?? PRIORITY_SLA_DAYS[prio];
          const slaLabel =
            language === 'id'
              ? `SLA ${slaDays} Hari`
              : `${slaDays} ${slaDays === 1 ? 'Day' : 'Days'} SLA`;

          let quotaText = language === 'id' ? 'Kapasitas Standar' : 'Standard Baseline';
          if (!isUnlimited && info) {
            quotaText =
              language === 'id'
                ? `Sisa ${info.remaining}/${info.annualLimit}`
                : `${info.remaining}/${info.annualLimit} Remaining`;
          }

          return (
            <div
              key={prio}
              onClick={() => {
                if (!disabled && !isExhausted) {
                  onChange(prio);
                }
              }}
              className={`p-2.5 rounded-xl border transition-all flex flex-col justify-between ${getPriorityBadgeClass(
                prio,
                isSelected,
                isExhausted
              )}`}
            >
              <div className="flex items-center justify-between gap-1 mb-1">
                <div className="flex items-center gap-2">
                  <input
                    type="radio"
                    name="requestPriority"
                    checked={isSelected}
                    disabled={disabled || isExhausted}
                    onChange={() => onChange(prio)}
                    className="accent-[#065F46] cursor-pointer disabled:cursor-not-allowed"
                  />
                  <span
                    className={`font-bold ${
                      prio === 'urgent'
                        ? 'text-rose-700'
                        : prio === 'high'
                        ? 'text-amber-700'
                        : prio === 'medium'
                        ? 'text-blue-700'
                        : 'text-slate-700'
                    }`}
                  >
                    {prioTitle}
                  </span>
                </div>

                {/* SLA target badge */}
                <span className="text-[10px] font-mono font-semibold px-1.5 py-0.5 rounded bg-slate-100 text-slate-700">
                  {slaLabel}
                </span>
              </div>

              {/* Quota details & Status */}
              <div className="flex items-center justify-between text-[11px] pt-1 border-t border-slate-100/80 gap-2">
                <span className="text-slate-500 font-mono text-[10px]">
                  {quotaText}
                </span>

                {isExhausted ? (
                  <span className="text-[10px] font-bold text-rose-700 bg-rose-50 px-1.5 py-0.5 rounded border border-rose-200">
                    {language === 'id' ? 'Kuota Habis' : 'Quota Exhausted'}
                  </span>
                ) : isUnlimited ? (
                  <span className="text-[10px] font-medium text-slate-500">
                    {language === 'id' ? 'Tanpa Batas' : 'Unlimited'}
                  </span>
                ) : (
                  <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200">
                    {language === 'id' ? 'Tersedia' : 'Available'}
                  </span>
                )}
              </div>
            </div>
          );
        })}
      </div>

      <div className="text-[10px] text-slate-400 leading-snug flex items-center justify-between pt-0.5">
        <span>
          {language === 'id'
            ? `Kuota prioritas berlaku per Brand dan digunakan bersama oleh semua pemohon pada ${brandName}.`
            : `Priority quota is allocated per Brand and shared by all requesters under ${brandName}.`}
        </span>
        {isLoading && (
          <span className="text-[10px] text-[#065F46] animate-pulse">
            {language === 'id' ? 'Menyinkronkan...' : 'Syncing...'}
          </span>
        )}
      </div>
    </div>
  );
};
