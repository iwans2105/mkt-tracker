import React, { useState, useEffect, useCallback } from 'react';
import {
  Upload,
  Link as LinkIcon,
  FileText,
  CheckCircle2,
  Trash2,
  Paperclip,
  User,
  Mail,
  Lock,
  ShieldAlert,
  KeyRound,
  ArrowLeft,
  Copy,
  Check,
  AlertTriangle,
  PlusCircle,
} from 'lucide-react';
import { useLanguage } from '../../context/LanguageContext';
import {
  Attachment,
  Brand,
  BrandQuotaSummary,
  Category,
  Department,
  PRIORITY_SLA_DAYS,
  PriorityAvailability,
  Region,
  RequestPriority,
  Unit,
} from '../../types';

function getWibTodayDateString(): string {
  try {
    return new Intl.DateTimeFormat('en-CA', {
      timeZone: 'Asia/Jakarta',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
    }).format(new Date());
  } catch {
    return new Date().toISOString().split('T')[0];
  }
}

function getSlaDeadlineDateString(slaDays: number): string {
  const safeDays = Math.max(1, Number.isFinite(slaDays) ? Math.round(slaDays) : 1);
  const baseDateStr = getWibTodayDateString();
  const [year, month, day] = baseDateStr.split('-').map(Number);
  return new Date(Date.UTC(year, month - 1, day + safeDays)).toISOString().split('T')[0];
}

function generateIdempotencyKey(): string {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    return `pub-${crypto.randomUUID()}`;
  }
  return `pub-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
}

interface PublicFormConfigState {
  enabled: boolean;
  requireToken: boolean;
  allowAttachments: boolean;
  allowedEmailDomains: string[];
  year: number;
  todayWib: string;
}

interface PublicMasterDataState {
  regions: Region[];
  brands: Brand[];
  units: Unit[];
  departments: Department[];
  categories: Category[];
}

interface SubmissionConfirmation {
  requestId: string;
  ticketNumber: string;
  title: string;
  regionName: string;
  brandName: string;
  categoryName: string;
  priority: RequestPriority;
  slaDays: number;
  requestedDeadline: string;
  requesterName: string;
  requesterEmail: string;
  submittedAt: string;
}

export const PublicRequestPage: React.FC = () => {
  const { language, setLanguage, isIndonesian } = useLanguage();

  const [accessToken, setAccessToken] = useState<string>(() => {
    if (typeof window === 'undefined') return '';
    return new URLSearchParams(window.location.search).get('token') || '';
  });
  const [tokenInput, setTokenInput] = useState<string>(() => {
    if (typeof window === 'undefined') return '';
    return new URLSearchParams(window.location.search).get('token') || '';
  });

  const [isLoadingConfig, setIsLoadingConfig] = useState(true);
  const [configError, setConfigError] = useState<string | null>(null);
  const [requiresTokenPrompt, setRequiresTokenPrompt] = useState(false);
  const [isDisabledForm, setIsDisabledForm] = useState(false);
  const [config, setConfig] = useState<PublicFormConfigState | null>(null);
  const [masterData, setMasterData] = useState<PublicMasterDataState>({
    regions: [],
    brands: [],
    units: [],
    departments: [],
    categories: [],
  });

  // Submitter identity (manual entry, no login required)
  const [requesterName, setRequesterName] = useState('');
  const [requesterEmail, setRequesterEmail] = useState('');
  const [requesterDepartment, setRequesterDepartment] = useState('');

  // Brief fields
  const [title, setTitle] = useState('');
  const [regionId, setRegionId] = useState('');
  const [brandId, setBrandId] = useState('');
  const [unitId, setUnitId] = useState('');
  const [categoryId, setCategoryId] = useState('');
  const [description, setDescription] = useState('');
  const [deliverablesExpected, setDeliverablesExpected] = useState('');
  const [priority, setPriority] = useState<RequestPriority>('medium');
  const [brandQuotaSummary, setBrandQuotaSummary] = useState<BrandQuotaSummary | null>(null);
  const [isLoadingQuota, setIsLoadingQuota] = useState(false);
  const [requestedDeadline, setRequestedDeadline] = useState(() =>
    getSlaDeadlineDateString(PRIORITY_SLA_DAYS.medium)
  );

  // Attachments & optional link
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const [isUploadingFiles, setIsUploadingFiles] = useState(false);
  const [uploadError, setUploadError] = useState('');
  const [referenceUrl, setReferenceUrl] = useState('');

  // Submit & Confirmation state
  const [idempotencyKey, setIdempotencyKey] = useState<string>(() => generateIdempotencyKey());
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState('');
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});
  const [confirmation, setConfirmation] = useState<SubmissionConfirmation | null>(null);
  const [copiedTicket, setCopiedTicket] = useState(false);

  const effectiveSlaDays =
    brandQuotaSummary?.priorities[priority]?.slaDays ?? PRIORITY_SLA_DAYS[priority];

  const loadConfig = useCallback(async (tokenToUse: string) => {
    setIsLoadingConfig(true);
    setConfigError(null);
    setRequiresTokenPrompt(false);
    setIsDisabledForm(false);

    try {
      const res = await fetch('/api/public/request-form-config', {
        headers: tokenToUse ? { 'X-Public-Form-Token': tokenToUse } : {},
        cache: 'no-store',
      });
      const data = await res.json().catch(() => ({}));

      if (!res.ok || !data.success) {
        if (data.disabled) {
          setIsDisabledForm(true);
        } else if (data.requiresToken || res.status === 401) {
          setRequiresTokenPrompt(true);
        }
        setConfigError(
          data.error ||
            (isIndonesian
              ? 'Formulir publik tidak dapat diakses saat ini.'
              : 'Public form is currently unavailable.')
        );
        return;
      }

      setConfig(data.config);
      setMasterData(data.masterData);
      if (data.masterData?.regions?.length > 0) {
        setRegionId((prev) => prev || data.masterData.regions[0].id);
      }
    } catch {
      setConfigError(
        isIndonesian
          ? 'Gagal terhubung ke server. Periksa koneksi internet Anda dan coba lagi.'
          : 'Failed to connect to the server. Please check your connection and try again.'
      );
    } finally {
      setIsLoadingConfig(false);
    }
  }, [isIndonesian]);

  useEffect(() => {
    loadConfig(accessToken);
  }, [accessToken, loadConfig]);

  // Fetch brand quota availability whenever brand changes
  useEffect(() => {
    if (!brandId || !config) {
      setBrandQuotaSummary(null);
      return;
    }

    let cancelled = false;
    setIsLoadingQuota(true);

    fetch(`/api/public/quotas/${encodeURIComponent(brandId)}`, {
      headers: accessToken ? { 'X-Public-Form-Token': accessToken } : {},
      cache: 'no-store',
    })
      .then((r) => r.json())
      .then((data) => {
        if (cancelled) return;
        if (data.success && data.summary) {
          const summary = data.summary as BrandQuotaSummary;
          setBrandQuotaSummary(summary);
          const currentInfo = summary.priorities[priority];
          if (currentInfo && currentInfo.isExhausted) {
            const fallbackOrder: RequestPriority[] = ['high', 'medium', 'low'];
            const available = fallbackOrder.find((p) => !summary.priorities[p]?.isExhausted);
            if (available) setPriority(available);
          }
        }
      })
      .catch(() => {
        if (!cancelled) setBrandQuotaSummary(null);
      })
      .finally(() => {
        if (!cancelled) setIsLoadingQuota(false);
      });

    return () => {
      cancelled = true;
    };
  }, [brandId, config, accessToken]);

  // Keep Requested Deadline strictly locked & synced to Priority & SLA Commitment
  useEffect(() => {
    setRequestedDeadline(getSlaDeadlineDateString(effectiveSlaDays));
  }, [priority, effectiveSlaDays]);

  const availableBrands = masterData.brands.filter((b) => b.regionId === regionId);
  const availableUnits = masterData.units.filter((u) => u.brandId === brandId);
  const selectedBrandName =
    masterData.brands.find((b) => b.id === brandId)?.name ||
    (isIndonesian ? 'Brand Terpilih' : 'Selected Brand');

  const handleUnlockWithToken = (e: React.FormEvent) => {
    e.preventDefault();
    const cleaned = tokenInput.trim();
    setAccessToken(cleaned);
    if (typeof window !== 'undefined' && cleaned) {
      const nextUrl = new URL(window.location.href);
      nextUrl.searchParams.set('token', cleaned);
      window.history.replaceState({}, '', nextUrl.toString());
    }
  };

  const MAX_PUBLIC_BYTES = 25 * 1024 * 1024;
  const ALLOWED_EXTENSIONS = ['pdf', 'jpg', 'jpeg', 'png', 'webp', 'docx', 'xlsx', 'pptx', 'mp4', 'zip'];

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    setUploadError('');
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const validFiles: File[] = [];
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const ext = file.name.split('.').pop()?.toLowerCase() || '';
      if (!ALLOWED_EXTENSIONS.includes(ext)) {
        setUploadError(
          isIndonesian
            ? `Format file "${file.name}" tidak didukung. Gunakan PDF, JPG, PNG, WEBP, DOCX, XLSX, PPTX, MP4, atau ZIP.`
            : `Unsupported format for "${file.name}". Allowed: PDF, JPG, PNG, WEBP, DOCX, XLSX, PPTX, MP4, ZIP.`
        );
        e.target.value = '';
        return;
      }
      if (file.size > MAX_PUBLIC_BYTES) {
        setUploadError(
          isIndonesian
            ? `Ukuran file "${file.name}" melebihi batas maksimal 25MB untuk tautan publik.`
            : `File "${file.name}" exceeds the 25MB public form limit.`
        );
        e.target.value = '';
        return;
      }
      validFiles.push(file);
    }

    setIsUploadingFiles(true);
    try {
      for (const file of validFiles) {
        const formData = new FormData();
        formData.append('file', file);
        if (brandId) formData.append('brandId', brandId);
        if (regionId) formData.append('regionId', regionId);
        if (accessToken) formData.append('token', accessToken);

        const res = await fetch('/api/public/upload', {
          method: 'POST',
          headers: accessToken ? { 'X-Public-Form-Token': accessToken } : {},
          cache: 'no-store',
          body: formData,
        });
        const data = await res.json().catch(() => ({}));
        if (!res.ok || !data.success || !data.file) {
          throw new Error(
            data.error ||
              (isIndonesian
                ? 'Gagal mengunggah lampiran brief.'
                : 'Failed to upload brief attachment.')
          );
        }
        setAttachments((prev) => [...prev, data.file as Attachment]);
      }
    } catch (err: unknown) {
      setUploadError(
        err instanceof Error
          ? err.message
          : isIndonesian
          ? 'Gagal mengunggah file.'
          : 'Failed to upload file.'
      );
    } finally {
      setIsUploadingFiles(false);
      e.target.value = '';
    }
  };

  const validateForm = (): boolean => {
    const errors: Record<string, string> = {};
    const cleanEmail = requesterEmail.trim().toLowerCase();

    if (requesterName.trim().length < 2) {
      errors.requesterName = isIndonesian
        ? 'Nama Lengkap Pemohon wajib diisi (min. 2 karakter).'
        : 'Full name is required (min 2 characters).';
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(cleanEmail)) {
      errors.requesterEmail = isIndonesian
        ? 'Alamat email pemohon tidak valid.'
        : 'Valid requester email address is required.';
    } else if (config && config.allowedEmailDomains.length > 0) {
      const domain = cleanEmail.split('@')[1] || '';
      if (!config.allowedEmailDomains.includes(domain)) {
        errors.requesterEmail = isIndonesian
          ? `Gunakan email korporat berakhiran ${config.allowedEmailDomains.map((d) => `@${d}`).join(', ')}.`
          : `Email domain must be ${config.allowedEmailDomains.map((d) => `@${d}`).join(', ')}.`;
      }
    }
    if (!requesterDepartment) {
      errors.requesterDepartment = isIndonesian
        ? 'Departemen pemohon wajib dipilih.'
        : 'Requester department must be selected.';
    }
    if (title.trim().length < 5) {
      errors.title = isIndonesian
        ? 'Judul pekerjaan wajib diisi (min. 5 karakter).'
        : 'Task title is required (min 5 characters).';
    }
    if (!regionId) {
      errors.regionId = isIndonesian ? 'Wilayah wajib dipilih.' : 'Region is required.';
    }
    if (!brandId) {
      errors.brandId = isIndonesian ? 'Brand / Entitas wajib dipilih.' : 'Brand is required.';
    }
    if (!categoryId) {
      errors.categoryId = isIndonesian ? 'Kategori tugas wajib dipilih.' : 'Task category is required.';
    }
    if (description.trim().length < 15) {
      errors.description = isIndonesian
        ? 'Deskripsi brief wajib diisi (min. 15 karakter).'
        : 'Brief description is required (min 15 characters).';
    }
    if (deliverablesExpected.trim().length < 5) {
      errors.deliverablesExpected = isIndonesian
        ? 'Deliverable yang diharapkan wajib diisi (min. 5 karakter).'
        : 'Expected deliverables are required (min 5 characters).';
    }
    if (referenceUrl.trim()) {
      try {
        const parsed = new URL(referenceUrl.trim());
        if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
          errors.referenceUrl = isIndonesian
            ? 'Tautan referensi harus diawali http:// atau https://.'
            : 'Reference link must start with http:// or https://.';
        }
      } catch {
        errors.referenceUrl = isIndonesian
          ? 'Format tautan referensi tidak valid.'
          : 'Invalid reference URL format.';
      }
    }

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitError('');
    if (!validateForm() || isSubmitting) return;

    setIsSubmitting(true);
    try {
      const res = await fetch('/api/public/requests', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(accessToken ? { 'X-Public-Form-Token': accessToken } : {}),
        },
        cache: 'no-store',
        body: JSON.stringify({
          token: accessToken,
          idempotencyKey,
          requesterName: requesterName.trim(),
          requesterEmail: requesterEmail.trim().toLowerCase(),
          requesterDepartment,
          title: title.trim(),
          regionId,
          brandId,
          unitId: unitId || undefined,
          categoryId,
          description: description.trim(),
          deliverablesExpected: deliverablesExpected.trim(),
          priority,
          referenceUrl: referenceUrl.trim() || undefined,
          briefAttachments: attachments.map((a) => ({ id: a.id })),
        }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok || !data.success || !data.submission) {
        setSubmitError(
          data.error ||
            (isIndonesian
              ? 'Gagal mengirim permintaan kerja. Periksa isian Anda dan coba lagi.'
              : 'Failed to submit work request. Please check your inputs and try again.')
        );
        return;
      }

      setConfirmation(data.submission as SubmissionConfirmation);
    } catch {
      setSubmitError(
        isIndonesian
          ? 'Koneksi bermasalah saat mengirim permintaan. Coba kirim ulang.'
          : 'Network error while submitting request. Please try again.'
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleResetForNewSubmission = () => {
    setConfirmation(null);
    setTitle('');
    setBrandId('');
    setUnitId('');
    setCategoryId('');
    setDescription('');
    setDeliverablesExpected('');
    setPriority('medium');
    setBrandQuotaSummary(null);
    setAttachments([]);
    setReferenceUrl('');
    setFormErrors({});
    setSubmitError('');
    setUploadError('');
    setIdempotencyKey(generateIdempotencyKey());
  };

  const handleCopyTicketNumber = async () => {
    if (!confirmation?.ticketNumber) return;
    try {
      await navigator.clipboard.writeText(confirmation.ticketNumber);
      setCopiedTicket(true);
      setTimeout(() => setCopiedTicket(false), 2000);
    } catch {
      // Ignore clipboard fallback
    }
  };

  const priorityOrder: RequestPriority[] = ['urgent', 'high', 'medium', 'low'];
  const allFastExhausted =
    brandQuotaSummary &&
    brandQuotaSummary.priorities.urgent?.isExhausted &&
    brandQuotaSummary.priorities.high?.isExhausted &&
    brandQuotaSummary.priorities.medium?.isExhausted;

  return (
    <div className="min-h-screen bg-[#F7FAF8] text-slate-900 font-sans antialiased flex flex-col">
      {/* Top Corporate Bar */}
      <header className="bg-white border-b border-slate-200">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <img
              src="/assets/aistudio/Marcom-Task-Request-Tracker_cfd946e5.png"
              alt="MARCOMM Task-Request Tracker"
              className="w-9 h-9 object-contain shrink-0"
              onError={(e) => {
                const target = e.currentTarget;
                if (!target.src.includes('/public/')) {
                  target.src = '/public/assets/aistudio/Marcom-Task-Request-Tracker_cfd946e5.png';
                }
              }}
            />
            <div className="min-w-0">
              <div className="font-extrabold text-sm text-slate-900 tracking-tight truncate">
                MARCOMM TASK <span className="text-[#065F46]">· LYMAN GROUP</span>
              </div>
              <div className="text-[11px] text-slate-500 truncate">
                {isIndonesian
                  ? 'Formulir Pengajuan Permintaan Kerja (Akses Publik)'
                  : 'Work Request Submission Form (Public Link)'}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <div className="inline-flex rounded-lg border border-slate-200 bg-slate-50 p-0.5 text-[11px] font-bold">
              <button
                type="button"
                onClick={() => setLanguage('id')}
                className={`px-2 py-1 rounded-md transition-colors ${
                  language === 'id' ? 'bg-white text-[#065F46] shadow-2xs' : 'text-slate-500'
                }`}
              >
                ID
              </button>
              <button
                type="button"
                onClick={() => setLanguage('en')}
                className={`px-2 py-1 rounded-md transition-colors ${
                  language === 'en' ? 'bg-white text-[#065F46] shadow-2xs' : 'text-slate-500'
                }`}
              >
                EN
              </button>
            </div>
            <a
              href="/"
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 rounded-xl transition-colors"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">
                {isIndonesian ? 'Portal Internal' : 'Internal Portal'}
              </span>
            </a>
          </div>
        </div>
      </header>

      {/* Main Centered Container */}
      <main className="flex-1 w-full max-w-3xl mx-auto px-4 sm:px-6 py-6 sm:py-10">
        {isLoadingConfig ? (
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-8 text-center space-y-2">
            <div className="text-sm font-bold text-slate-800">
              {isIndonesian ? 'Memuat Formulir Permintaan Kerja...' : 'Loading Work Request Form...'}
            </div>
            <p className="text-xs text-slate-500">
              {isIndonesian
                ? 'Memverifikasi tautan akses dan master data resmi.'
                : 'Verifying access link and official master data.'}
            </p>
          </div>
        ) : isDisabledForm ? (
          <div className="bg-white rounded-2xl border border-rose-200 shadow-xs p-8 text-center space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-rose-50 border border-rose-200 flex items-center justify-center mx-auto">
              <AlertTriangle className="w-6 h-6 text-rose-600" />
            </div>
            <div className="space-y-1">
              <h1 className="text-base font-bold text-slate-900">
                {isIndonesian ? 'Formulir Publik Dinonaktifkan' : 'Public Request Form Disabled'}
              </h1>
              <p className="text-xs text-slate-600 max-w-md mx-auto">
                {configError}
              </p>
            </div>
            <a
              href="/"
              className="inline-flex items-center gap-2 px-4 py-2 text-xs font-bold text-white bg-[#065F46] hover:bg-[#044e39] rounded-xl transition-colors"
            >
              {isIndonesian ? 'Masuk ke Portal Internal' : 'Sign In to Internal Portal'}
            </a>
          </div>
        ) : requiresTokenPrompt || (!config && configError) ? (
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-6 sm:p-8 max-w-md mx-auto space-y-5">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-50 border border-emerald-200 flex items-center justify-center shrink-0">
                <KeyRound className="w-5 h-5 text-[#065F46]" />
              </div>
              <div>
                <h1 className="text-base font-bold text-slate-900">
                  {isIndonesian ? 'Verifikasi Kode Akses Tautan Publik' : 'Public Link Access Verification'}
                </h1>
                <p className="text-xs text-slate-500 mt-1">
                  {isIndonesian
                    ? 'Masukkan kode akses resmi dari tim Marketing Communications untuk membuka formulir pengajuan.'
                    : 'Enter the official access token provided by Marketing Communications to open the submission form.'}
                </p>
              </div>
            </div>

            {configError && (
              <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-xs text-rose-700">
                {configError}
              </div>
            )}

            <form onSubmit={handleUnlockWithToken} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-800 mb-1">
                  {isIndonesian ? 'Kode Akses / Token' : 'Access Token'}
                </label>
                <input
                  type="text"
                  value={tokenInput}
                  onChange={(e) => setTokenInput(e.target.value)}
                  placeholder={isIndonesian ? 'Tempel token tautan...' : 'Paste link token...'}
                  className="w-full px-3.5 py-2 text-xs font-mono bg-white border border-slate-300 rounded-xl focus:outline-none focus:border-[#065F46]"
                />
              </div>
              <button
                type="submit"
                disabled={!tokenInput.trim()}
                className="w-full py-2.5 px-4 text-xs font-bold text-white bg-[#065F46] hover:bg-[#044e39] disabled:opacity-50 rounded-xl transition-colors"
              >
                {isIndonesian ? 'Buka Formulir' : 'Open Form'}
              </button>
            </form>
          </div>
        ) : confirmation ? (
          /* Confirmation Receipt Screen */
          <div className="bg-white rounded-2xl border border-emerald-200 shadow-xs overflow-hidden">
            <div className="px-6 py-6 bg-[#F7FAF8] border-b border-emerald-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-start gap-3">
                <div className="w-11 h-11 rounded-2xl bg-emerald-100 border border-emerald-300 flex items-center justify-center shrink-0">
                  <CheckCircle2 className="w-6 h-6 text-[#065F46]" />
                </div>
                <div>
                  <h1 className="text-lg font-extrabold text-slate-900">
                    {isIndonesian
                      ? 'Permintaan Kerja Berhasil Diajukan'
                      : 'Work Request Submitted Successfully'}
                  </h1>
                  <p className="text-xs text-slate-600 mt-0.5">
                    {isIndonesian
                      ? 'Tiket Anda telah masuk ke antrean tim Marketing Communications dan notifikasi otomatis telah dikirim ke Admin terkait.'
                      : 'Your ticket is now queued with Marketing Communications and scoped Admins have been notified.'}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <span className="font-mono text-sm font-extrabold px-3 py-1.5 rounded-xl bg-[#D1FAE5] text-[#065F46] border border-[#A7F3D0] tabular-nums">
                  {confirmation.ticketNumber}
                </span>
                <button
                  type="button"
                  onClick={handleCopyTicketNumber}
                  className="p-2 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-600"
                  title={isIndonesian ? 'Salin nomor tiket' : 'Copy ticket number'}
                >
                  {copiedTicket ? <Check className="w-4 h-4 text-[#065F46]" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <div className="p-6 space-y-5">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
                  <div className="text-slate-500 mb-0.5">
                    {isIndonesian ? 'Judul Pekerjaan' : 'Task Title'}
                  </div>
                  <div className="font-bold text-slate-900">{confirmation.title}</div>
                </div>
                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
                  <div className="text-slate-500 mb-0.5">
                    {isIndonesian ? 'Pemohon' : 'Requester'}
                  </div>
                  <div className="font-bold text-slate-900">{confirmation.requesterName}</div>
                  <div className="text-[11px] text-slate-500">{confirmation.requesterEmail}</div>
                </div>
                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
                  <div className="text-slate-500 mb-0.5">
                    {isIndonesian ? 'Brand / Wilayah / Kategori' : 'Brand / Region / Category'}
                  </div>
                  <div className="font-bold text-slate-900">
                    {confirmation.brandName} · {confirmation.regionName}
                  </div>
                  <div className="text-[11px] text-slate-500">{confirmation.categoryName}</div>
                </div>
                <div className="p-3.5 rounded-xl bg-emerald-50/70 border border-emerald-200">
                  <div className="text-[#065F46] font-semibold mb-0.5 flex items-center gap-1">
                    <Lock className="w-3 h-3" />
                    <span>{isIndonesian ? 'Tenggat Waktu SLA Terverifikasi' : 'Verified SLA Deadline'}</span>
                  </div>
                  <div className="font-mono font-extrabold text-sm text-[#065F46] tabular-nums">
                    {confirmation.requestedDeadline}
                  </div>
                  <div className="text-[11px] text-slate-600 uppercase font-semibold">
                    {confirmation.priority} · SLA +{confirmation.slaDays}{' '}
                    {isIndonesian ? 'Hari' : confirmation.slaDays === 1 ? 'Day' : 'Days'}
                  </div>
                </div>
              </div>

              <div className="pt-4 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3">
                <span className="text-xs text-slate-500">
                  {isIndonesian
                    ? 'Simpan nomor tiket di atas sebagai referensi tindak lanjut.'
                    : 'Save the ticket number above for follow-up reference.'}
                </span>
                <div className="flex items-center gap-2.5 w-full sm:w-auto justify-end">
                  <button
                    type="button"
                    onClick={handleResetForNewSubmission}
                    className="flex-1 sm:flex-initial inline-flex items-center justify-center gap-1.5 px-4 py-2 text-xs font-bold text-white bg-[#065F46] hover:bg-[#044e39] rounded-xl transition-colors"
                  >
                    <PlusCircle className="w-3.5 h-3.5" />
                    <span>{isIndonesian ? 'Ajukan Permintaan Baru' : 'Submit Another Request'}</span>
                  </button>
                  <a
                    href="/"
                    className="flex-1 sm:flex-initial inline-flex items-center justify-center gap-1.5 px-4 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-xl transition-colors"
                  >
                    <span>{isIndonesian ? 'Masuk ke Portal Internal' : 'Go to Internal Portal'}</span>
                  </a>
                </div>
              </div>
            </div>
          </div>
        ) : (
          /* Main Public Request Submission Form */
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
            {/* Form Header */}
            <div className="px-5 sm:px-6 py-4 sm:py-5 border-b border-slate-200 bg-slate-50 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <h1 className="text-base sm:text-lg font-extrabold text-slate-900">
                  {isIndonesian ? 'Buat Permintaan Kerja Baru' : 'New Work Request'}
                </h1>
                <p className="text-xs text-slate-500 mt-0.5">
                  {isIndonesian
                    ? 'Formulir pengajuan brief permintaan kreatif & media divisi Marketing Communications tanpa perlu login akun.'
                    : 'Submit a creative & media brief to the Marketing Communications division without signing in.'}
                </p>
              </div>
              <span className="text-[11px] font-mono font-bold px-2.5 py-1 rounded-lg bg-[#D1FAE5] text-[#065F46] border border-[#A7F3D0] self-start sm:self-auto shrink-0">
                {isIndonesian ? 'Tautan Publik Terverifikasi' : 'Verified Public Link'}
              </span>
            </div>

            <form onSubmit={handleSubmit} className="p-5 sm:p-6 space-y-5">
              {submitError && (
                <div className="p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-xs text-rose-700 font-medium">
                  {submitError}
                </div>
              )}

              {/* Identitas Pemohon (Manual Input) */}
              <div className="p-4 bg-slate-50/80 rounded-xl border border-slate-200 space-y-3">
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-slate-900">
                    <User className="w-4 h-4 text-[#065F46]" />
                    <span>{isIndonesian ? 'Identitas Pemohon' : 'Requester Identity'}</span>
                  </div>
                  {config && config.allowedEmailDomains.length > 0 && (
                    <span className="text-[11px] font-mono text-[#065F46] bg-[#D1FAE5]/60 px-2 py-0.5 rounded border border-[#A7F3D0]">
                      {isIndonesian ? 'Domain diizinkan:' : 'Allowed domain:'}{' '}
                      {config.allowedEmailDomains.map((d) => `@${d}`).join(', ')}
                    </span>
                  )}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label htmlFor="pubRequesterName" className="block text-xs font-bold text-slate-900 mb-1">
                      {isIndonesian ? 'Nama Lengkap Pemohon' : 'Requester Full Name'}{' '}
                      <span className="text-rose-500">*</span>
                    </label>
                    <input
                      id="pubRequesterName"
                      type="text"
                      value={requesterName}
                      onChange={(e) => setRequesterName(e.target.value)}
                      placeholder={isIndonesian ? 'Contoh: Budi Santoso' : 'e.g., Budi Santoso'}
                      className={`w-full px-3.5 py-2 text-xs bg-white border rounded-xl focus:outline-none focus:ring-2 focus:ring-[#065F46]/20 ${
                        formErrors.requesterName ? 'border-rose-500' : 'border-slate-300 focus:border-[#065F46]'
                      }`}
                    />
                    {formErrors.requesterName && (
                      <p className="text-[11px] text-rose-600 mt-1">{formErrors.requesterName}</p>
                    )}
                  </div>

                  <div>
                    <label htmlFor="pubRequesterEmail" className="block text-xs font-bold text-slate-900 mb-1">
                      {isIndonesian ? 'Email Pemohon' : 'Requester Email'}{' '}
                      <span className="text-rose-500">*</span>
                    </label>
                    <div className="relative">
                      <Mail className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                      <input
                        id="pubRequesterEmail"
                        type="email"
                        value={requesterEmail}
                        onChange={(e) => setRequesterEmail(e.target.value)}
                        placeholder={
                          config && config.allowedEmailDomains.length > 0
                            ? `nama@${config.allowedEmailDomains[0]}`
                            : 'nama@lyman.co.id'
                        }
                        className={`w-full pl-8 pr-3.5 py-2 text-xs bg-white border rounded-xl focus:outline-none focus:ring-2 focus:ring-[#065F46]/20 ${
                          formErrors.requesterEmail ? 'border-rose-500' : 'border-slate-300 focus:border-[#065F46]'
                        }`}
                      />
                    </div>
                    {formErrors.requesterEmail && (
                      <p className="text-[11px] text-rose-600 mt-1">{formErrors.requesterEmail}</p>
                    )}
                  </div>
                </div>
              </div>

              {/* Judul Pekerjaan */}
              <div>
                <label htmlFor="pubTitle" className="block text-xs font-bold text-slate-900 mb-1">
                  {isIndonesian ? 'Judul Pekerjaan' : 'Task Title'} <span className="text-rose-500">*</span>
                </label>
                <input
                  id="pubTitle"
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder={
                    isIndonesian
                      ? 'Contoh: Desain Brosur Cetak Promo Ramadhan 2026'
                      : 'e.g., Ramadhan Promo 2026 Print Brochure Design'
                  }
                  className={`w-full px-3.5 py-2 text-xs bg-white border rounded-xl focus:outline-none focus:ring-2 focus:ring-[#065F46]/20 ${
                    formErrors.title ? 'border-rose-500' : 'border-slate-300 focus:border-[#065F46]'
                  }`}
                />
                {formErrors.title && <p className="text-[11px] text-rose-600 mt-1">{formErrors.title}</p>}
              </div>

              {/* Wilayah, Brand, Unit Bisnis */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div>
                  <label htmlFor="pubRegion" className="block text-xs font-bold text-slate-900 mb-1">
                    {isIndonesian ? 'Wilayah' : 'Region'} <span className="text-rose-500">*</span>
                  </label>
                  <select
                    id="pubRegion"
                    value={regionId}
                    onChange={(e) => {
                      setRegionId(e.target.value);
                      setBrandId('');
                      setBrandQuotaSummary(null);
                      setUnitId('');
                    }}
                    className={`w-full px-3 py-2 text-xs bg-white border rounded-xl focus:outline-none ${
                      formErrors.regionId ? 'border-rose-500' : 'border-slate-300 focus:border-[#065F46]'
                    }`}
                  >
                    <option value="">{isIndonesian ? 'Pilih Wilayah' : 'Select Region'}</option>
                    {masterData.regions.map((reg) => (
                      <option key={reg.id} value={reg.id}>
                        {reg.name}
                      </option>
                    ))}
                  </select>
                  {formErrors.regionId && <p className="text-[11px] text-rose-600 mt-1">{formErrors.regionId}</p>}
                </div>

                <div>
                  <label htmlFor="pubBrand" className="block text-xs font-bold text-slate-900 mb-1">
                    {isIndonesian ? 'Brand / Entitas' : 'Brand / Entity'} <span className="text-rose-500">*</span>
                  </label>
                  <select
                    id="pubBrand"
                    value={brandId}
                    disabled={!regionId}
                    onChange={(e) => {
                      setBrandId(e.target.value);
                      setBrandQuotaSummary(null);
                      setUnitId('');
                    }}
                    className={`w-full px-3 py-2 text-xs bg-white border rounded-xl focus:outline-none disabled:bg-slate-100 ${
                      formErrors.brandId ? 'border-rose-500' : 'border-slate-300 focus:border-[#065F46]'
                    }`}
                  >
                    <option value="">{isIndonesian ? 'Pilih Brand' : 'Select Brand'}</option>
                    {availableBrands.map((b) => (
                      <option key={b.id} value={b.id}>
                        {b.name}
                      </option>
                    ))}
                  </select>
                  {formErrors.brandId && <p className="text-[11px] text-rose-600 mt-1">{formErrors.brandId}</p>}
                </div>

                <div>
                  <label htmlFor="pubUnit" className="block text-xs font-bold text-slate-900 mb-1">
                    {isIndonesian ? 'Unit Bisnis Internal (Opsional)' : 'Internal Business Unit (Optional)'}
                  </label>
                  <select
                    id="pubUnit"
                    value={unitId}
                    disabled={availableUnits.length === 0}
                    onChange={(e) => setUnitId(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-xl focus:outline-none disabled:bg-slate-100"
                  >
                    <option value="">
                      {availableUnits.length > 0
                        ? isIndonesian
                          ? 'Pilih Unit Bisnis'
                          : 'Select Business Unit'
                        : isIndonesian
                        ? 'Tidak ada unit khusus'
                        : 'No dedicated unit'}
                    </option>
                    {availableUnits.map((u) => (
                      <option key={u.id} value={u.id}>
                        {u.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Departemen & Kategori Tugas */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label htmlFor="pubDepartment" className="block text-xs font-bold text-slate-900 mb-1">
                    {isIndonesian ? 'Departemen' : 'Department'} <span className="text-rose-500">*</span>
                  </label>
                  <select
                    id="pubDepartment"
                    value={requesterDepartment}
                    onChange={(e) => setRequesterDepartment(e.target.value)}
                    className={`w-full px-3 py-2 text-xs bg-white border rounded-xl focus:outline-none ${
                      formErrors.requesterDepartment
                        ? 'border-rose-500'
                        : 'border-slate-300 focus:border-[#065F46]'
                    }`}
                  >
                    <option value="">{isIndonesian ? 'Pilih Departemen' : 'Select Department'}</option>
                    {masterData.departments.map((dept) => (
                      <option key={dept.id} value={dept.name}>
                        {dept.name}
                      </option>
                    ))}
                  </select>
                  {formErrors.requesterDepartment && (
                    <p className="text-[11px] text-rose-600 mt-1">{formErrors.requesterDepartment}</p>
                  )}
                </div>

                <div>
                  <label htmlFor="pubCategory" className="block text-xs font-bold text-slate-900 mb-1">
                    {isIndonesian ? 'Kategori Tugas' : 'Task Category'} <span className="text-rose-500">*</span>
                  </label>
                  <select
                    id="pubCategory"
                    value={categoryId}
                    onChange={(e) => setCategoryId(e.target.value)}
                    className={`w-full px-3 py-2 text-xs bg-white border rounded-xl focus:outline-none ${
                      formErrors.categoryId ? 'border-rose-500' : 'border-slate-300 focus:border-[#065F46]'
                    }`}
                  >
                    <option value="">{isIndonesian ? 'Pilih Kategori' : 'Select Category'}</option>
                    {masterData.categories.map((cat) => (
                      <option key={cat.id} value={cat.id}>
                        {cat.name}
                      </option>
                    ))}
                  </select>
                  {formErrors.categoryId && (
                    <p className="text-[11px] text-rose-600 mt-1">{formErrors.categoryId}</p>
                  )}
                </div>
              </div>

              {/* Deskripsi Brief & Ruang Lingkup */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label htmlFor="pubDescription" className="text-xs font-bold text-slate-900">
                    {isIndonesian ? 'Deskripsi Brief & Ruang Lingkup' : 'Brief Requirements & Scope'}{' '}
                    <span className="text-rose-500">*</span>
                  </label>
                  <span className="text-[10px] text-slate-400 font-mono tabular-nums">
                    {description.length}/5000
                  </span>
                </div>
                <textarea
                  id="pubDescription"
                  rows={4}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder={
                    isIndonesian
                      ? 'Jelaskan tujuan, pesan utama, target audiens, teks/copy wajib, dan referensi gaya visual secara rinci...'
                      : 'Provide detailed objectives, key messages, target audience, mandatory copy text, and visual references...'
                  }
                  className={`w-full px-3.5 py-2.5 text-xs bg-white border rounded-xl focus:outline-none focus:ring-2 focus:ring-[#065F46]/20 leading-relaxed ${
                    formErrors.description ? 'border-rose-500' : 'border-slate-300 focus:border-[#065F46]'
                  }`}
                />
                {formErrors.description && (
                  <p className="text-[11px] text-rose-600 mt-1">{formErrors.description}</p>
                )}
              </div>

              {/* Deliverable yang Diharapkan */}
              <div>
                <label htmlFor="pubDeliverables" className="block text-xs font-bold text-slate-900 mb-1">
                  {isIndonesian ? 'Deliverable yang Diharapkan' : 'Expected Deliverables'}{' '}
                  <span className="text-rose-500">*</span>
                </label>
                <input
                  id="pubDeliverables"
                  type="text"
                  value={deliverablesExpected}
                  onChange={(e) => setDeliverablesExpected(e.target.value)}
                  placeholder={
                    isIndonesian
                      ? 'Contoh: PDF siap cetak 300dpi, aset logo PNG transparan, dan video MP4 1080x1920'
                      : 'e.g., Print-ready 300dpi PDF, transparent PNG logo assets, and 1080x1920 MP4 video'
                  }
                  className={`w-full px-3.5 py-2 text-xs bg-white border rounded-xl focus:outline-none focus:ring-2 focus:ring-[#065F46]/20 ${
                    formErrors.deliverablesExpected ? 'border-rose-500' : 'border-slate-300 focus:border-[#065F46]'
                  }`}
                />
                {formErrors.deliverablesExpected && (
                  <p className="text-[11px] text-rose-600 mt-1">{formErrors.deliverablesExpected}</p>
                )}
              </div>

              {/* Prioritas & Komitmen SLA + Auto-Locked Deadline */}
              <div className="space-y-3">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-bold text-slate-900">
                      {isIndonesian ? 'Prioritas & Komitmen SLA' : 'Priority & SLA Commitment'}{' '}
                      <span className="text-rose-500">*</span>
                    </label>
                    {brandQuotaSummary && (
                      <span className="text-[10px] text-slate-500 font-mono">
                        {isIndonesian ? `Tahun ${brandQuotaSummary.year}` : `Year ${brandQuotaSummary.year}`}
                      </span>
                    )}
                  </div>

                  {allFastExhausted && (
                    <div className="p-2.5 bg-amber-50 border border-amber-200 rounded-xl text-amber-800 text-[11px] flex items-start gap-2">
                      <ShieldAlert className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                      <div className="leading-snug">
                        {isIndonesian
                          ? `Seluruh kuota prioritas cepat untuk ${selectedBrandName} tahun ini telah habis. Permintaan dialihkan ke prioritas Rendah (Standar 14 Hari).`
                          : `All expedited priority quotas for ${selectedBrandName} are exhausted this year. Requests default to Low Priority (14 Days).`}
                      </div>
                    </div>
                  )}

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                    {priorityOrder.map((prio) => {
                      const info: PriorityAvailability | undefined = brandQuotaSummary?.priorities[prio];
                      const isSelected = priority === prio;
                      const isExhausted = Boolean(info?.isExhausted);
                      const isUnlimited = info?.annualLimit === -1 || prio === 'low';

                      const prioTitle = isIndonesian
                        ? prio === 'urgent'
                          ? 'Mendesak'
                          : prio === 'high'
                          ? 'Tinggi'
                          : prio === 'medium'
                          ? 'Sedang'
                          : 'Rendah'
                        : prio.charAt(0).toUpperCase() + prio.slice(1);

                      const slaDays = info?.slaDays ?? PRIORITY_SLA_DAYS[prio];
                      const slaLabel = isIndonesian
                        ? `SLA ${slaDays} Hari`
                        : `${slaDays} ${slaDays === 1 ? 'Day' : 'Days'} SLA`;

                      let quotaText = isIndonesian ? 'Kapasitas Standar' : 'Standard Baseline';
                      if (!isUnlimited && info) {
                        quotaText = isIndonesian
                          ? `Sisa ${info.remaining}/${info.annualLimit}`
                          : `${info.remaining}/${info.annualLimit} Remaining`;
                      }

                      return (
                        <div
                          key={prio}
                          onClick={() => {
                            if (!isSubmitting && !isExhausted) {
                              setPriority(prio);
                            }
                          }}
                          className={`p-2.5 rounded-xl border transition-all flex flex-col justify-between ${
                            isExhausted
                              ? 'border-slate-200 bg-slate-50 opacity-60 cursor-not-allowed'
                              : isSelected
                              ? 'border-[#065F46] bg-emerald-50/70 ring-1 ring-[#065F46] shadow-2xs'
                              : 'border-slate-200 hover:border-slate-300 bg-white hover:bg-slate-50/60 cursor-pointer'
                          }`}
                        >
                          <div className="flex items-center justify-between gap-1 mb-1">
                            <div className="flex items-center gap-2">
                              <input
                                type="radio"
                                name="publicRequestPriority"
                                checked={isSelected}
                                disabled={isSubmitting || isExhausted}
                                onChange={() => setPriority(prio)}
                                className="accent-[#065F46] cursor-pointer disabled:cursor-not-allowed"
                              />
                              <span
                                className={`font-bold ${
                                  prio === 'urgent'
                                    ? 'text-rose-700'
                                    : prio === 'high'
                                    ? 'text-amber-700'
                                    : prio === 'medium'
                                    ? 'text-blue-700'
                                    : 'text-slate-700'
                                }`}
                              >
                                {prioTitle}
                              </span>
                            </div>
                            <span className="text-[10px] font-mono font-semibold px-1.5 py-0.5 rounded bg-slate-100 text-slate-700 tabular-nums">
                              {slaLabel}
                            </span>
                          </div>

                          <div className="flex items-center justify-between text-[11px] pt-1 border-t border-slate-100/80 gap-2">
                            <span className="text-slate-500 font-mono text-[10px] tabular-nums">
                              {quotaText}
                            </span>
                            {isExhausted ? (
                              <span className="text-[10px] font-bold text-rose-700 bg-rose-50 px-1.5 py-0.5 rounded border border-rose-200">
                                {isIndonesian ? 'Kuota Habis' : 'Quota Exhausted'}
                              </span>
                            ) : isUnlimited ? (
                              <span className="text-[10px] font-medium text-slate-500">
                                {isIndonesian ? 'Tanpa Batas' : 'Unlimited'}
                              </span>
                            ) : (
                              <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200">
                                {isIndonesian ? 'Tersedia' : 'Available'}
                              </span>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  <div className="text-[10px] text-slate-400 flex items-center justify-between">
                    <span>
                      {isIndonesian
                        ? `Kuota prioritas berlaku per Brand dan digunakan bersama pada ${selectedBrandName}.`
                        : `Priority quota applies per Brand and is shared across ${selectedBrandName}.`}
                    </span>
                    {isLoadingQuota && (
                      <span className="text-[#065F46]">
                        {isIndonesian ? 'Memuat kuota...' : 'Loading quota...'}
                      </span>
                    )}
                  </div>
                </div>

                {/* Locked Requested Deadline */}
                <div>
                  <div className="flex items-center justify-between mb-1 gap-2">
                    <label htmlFor="pubRequestedDeadline" className="text-xs font-bold text-slate-900">
                      {isIndonesian ? 'Tenggat Waktu yang Diminta' : 'Requested Deadline'}{' '}
                      <span className="text-rose-50">*</span>
                    </label>
                    <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-[#065F46] bg-[#D1FAE5]/70 px-2 py-0.5 rounded-full border border-[#A7F3D0]">
                      <Lock className="w-3 h-3 text-[#065F46]" />
                      <span>
                        {isIndonesian
                          ? `Otomatis sesuai SLA (+${effectiveSlaDays} Hari)`
                          : `Auto-locked to SLA (+${effectiveSlaDays} ${effectiveSlaDays === 1 ? 'Day' : 'Days'})`}
                      </span>
                    </span>
                  </div>
                  <input
                    id="pubRequestedDeadline"
                    type="date"
                    value={requestedDeadline}
                    readOnly
                    disabled
                    aria-readonly="true"
                    tabIndex={-1}
                    className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 text-slate-800 font-semibold rounded-xl font-mono tabular-nums cursor-not-allowed select-none focus:outline-none"
                  />
                  <p className="text-[11px] text-slate-500 mt-1">
                    {isIndonesian
                      ? 'Tanggal otomatis terisi, dikunci berdasarkan Prioritas & Komitmen SLA yang dipilih, serta diverifikasi oleh server saat pengiriman.'
                      : 'Date is automatically populated, locked based on the selected Priority & SLA Commitment, and verified server-side on submission.'}
                  </p>
                </div>
              </div>

              {/* Brief Attachments & Reference URL */}
              <div className="p-4 bg-slate-50/70 rounded-xl border border-slate-200 space-y-3">
                {config?.allowAttachments && (
                  <>
                    <div className="flex items-center justify-between">
                      <label className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                        <Paperclip className="w-3.5 h-3.5 text-slate-500" />
                        <span>
                          {isIndonesian
                            ? 'Lampiran Brief (PDF, DOCX, JPG, PNG, MP4, ZIP maks. 25MB)'
                            : 'Brief Attachments (PDF, DOCX, JPG, PNG, MP4, ZIP max 25MB)'}
                        </span>
                      </label>
                    </div>

                    <div className="flex items-center gap-3">
                      <label className="cursor-pointer inline-flex items-center gap-2 px-3 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-xl transition-colors shadow-2xs">
                        <Upload className="w-3.5 h-3.5 text-slate-500" />
                        <span>
                          {isUploadingFiles
                            ? isIndonesian
                              ? 'Mengunggah...'
                              : 'Uploading...'
                            : isIndonesian
                            ? 'Pilih File'
                            : 'Choose Files'}
                        </span>
                        <input
                          type="file"
                          multiple
                          disabled={isUploadingFiles || isSubmitting}
                          onChange={handleFileUpload}
                          className="hidden"
                          accept=".pdf,.jpg,.jpeg,.png,.webp,.docx,.xlsx,.pptx,.mp4,.zip"
                        />
                      </label>
                      <span className="text-[11px] text-slate-400 tabular-nums">
                        {isIndonesian
                          ? `${attachments.length} file dipilih`
                          : `${attachments.length} ${attachments.length === 1 ? 'file' : 'files'} selected`}
                      </span>
                    </div>

                    {uploadError && <p className="text-[11px] text-rose-600">{uploadError}</p>}

                    {attachments.length > 0 && (
                      <div className="space-y-1.5 pt-1">
                        {attachments.map((att) => (
                          <div
                            key={att.id}
                            className="flex items-center justify-between p-2 bg-white rounded-lg border border-slate-200 text-xs"
                          >
                            <div className="flex items-center gap-2 truncate">
                              <FileText className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                              <span className="truncate font-medium text-slate-800">{att.name}</span>
                              <span className="text-[10px] text-slate-400 font-mono tabular-nums">
                                ({Math.max(1, Math.round(att.size / 1024))} KB)
                              </span>
                            </div>
                            <button
                              type="button"
                              onClick={() => setAttachments((prev) => prev.filter((a) => a.id !== att.id))}
                              className="p-1 text-slate-400 hover:text-rose-600 transition-colors"
                              title={isIndonesian ? 'Hapus lampiran' : 'Remove attachment'}
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                  </>
                )}

                <div>
                  <label htmlFor="pubReferenceUrl" className="block text-xs font-medium text-slate-700 mb-1">
                    {isIndonesian
                      ? 'Tautan Referensi Eksternal (Google Drive / Figma / Pinterest / Dropbox)'
                      : 'External Reference Link (Google Drive / Figma / Pinterest / Dropbox)'}
                  </label>
                  <div className="relative">
                    <LinkIcon className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      id="pubReferenceUrl"
                      type="url"
                      value={referenceUrl}
                      onChange={(e) => setReferenceUrl(e.target.value)}
                      placeholder="https://drive.google.com/..."
                      className={`w-full pl-8 pr-3 py-1.5 text-xs bg-white border rounded-lg focus:outline-none ${
                        formErrors.referenceUrl ? 'border-rose-500' : 'border-slate-300 focus:border-[#065F46]'
                      }`}
                    />
                  </div>
                  {formErrors.referenceUrl && (
                    <p className="text-[11px] text-rose-600 mt-1">{formErrors.referenceUrl}</p>
                  )}
                </div>
              </div>

              {/* Footer Submit */}
              <div className="pt-3 border-t border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <span className="text-xs text-slate-500">
                  {isIndonesian ? (
                    <>
                      Tiket akan langsung masuk ke antrean <strong>Antrean (To Do)</strong> tim Marcomm.
                    </>
                  ) : (
                    <>
                      Your ticket will enter the Marcomm <strong>To Do / Backlog</strong> queue directly.
                    </>
                  )}
                </span>
                <button
                  type="submit"
                  disabled={isSubmitting || isUploadingFiles}
                  className="px-6 py-2.5 text-xs font-bold text-white bg-[#065F46] hover:bg-[#044e39] disabled:opacity-50 rounded-xl shadow-xs transition-colors active:scale-[0.98]"
                >
                  {isSubmitting
                    ? isIndonesian
                      ? 'Mengirim Permintaan...'
                      : 'Submitting Request...'
                    : isIndonesian
                    ? 'Kirim Permintaan'
                    : 'Submit Request'}
                </button>
              </div>
            </form>
          </div>
        )}
      </main>
    </div>
  );
};
