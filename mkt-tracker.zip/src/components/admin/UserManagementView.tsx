import React, { useState } from 'react';
import {
  Users,
  UserPlus,
  ShieldCheck,
  CheckCircle2,
  XCircle,
  Edit2,
  Lock,
  Mail,
  Building,
  Briefcase,
  Search,
  Filter,
  Check,
  AlertCircle,
  Trash2,
  AlertTriangle,
  KeyRound,
  Sparkles,
  ShieldAlert,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useRequests } from '../../context/RequestContext';
import { useLanguage } from '../../context/LanguageContext';
import { StorageService } from '../../services/storageService';
import { User, UserRole } from '../../types';
import { PasswordInput, generateStrongPassword } from '../common/PasswordInput';

export const UserManagementView: React.FC = () => {
  const {
    allUsers,
    currentUser,
    isSuperAdmin,
    isAdmin,
    updateUserAccount,
    deleteUserAccount,
    adminResetPassword,
  } = useAuth();
  const { regions, brands, teams, showToast, requests, categories } = useRequests();
  const { isIndonesian } = useLanguage();

  const [searchTerm, setSearchTerm] = useState('');
  const [roleFilter, setRoleFilter] = useState<UserRole | 'all'>('all');

  // Edit / Add / Delete Modal State
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [userToDelete, setUserToDelete] = useState<User | null>(null);
  const [isSavingUser, setIsSavingUser] = useState(false);

  // Administrative Reset Password State
  const [userForPasswordReset, setUserForPasswordReset] = useState<User | null>(null);
  const [resetNewPassword, setResetNewPassword] = useState('');
  const [resetConfirmPassword, setResetConfirmPassword] = useState('');
  const [resetMustChange, setResetMustChange] = useState(true);
  const [adminReauthPassword, setAdminReauthPassword] = useState('');
  const [isSubmittingReset, setIsSubmittingReset] = useState(false);
  const [resetError, setResetError] = useState('');


  const isProtectedSuperAdmin = (u: User) =>
    u.email === 'sosmeda217@gmail.com' || u.id === 'user-superadmin';
  const isCurrentActiveUser = (u: User) => u.id === currentUser.id;
  const canDeleteUser = (u: User) => {
    if (isProtectedSuperAdmin(u)) return false;
    if (isCurrentActiveUser(u)) return false;
    if (isSuperAdmin) return true;
    if (isAdmin && u.role !== 'super_admin') return true;
    return false;
  };

  const handleConfirmDelete = async () => {
    if (!userToDelete || isSavingUser) return;
    setIsSavingUser(true);
    try {
      const res = await deleteUserAccount(userToDelete.id);
      if (res.success) {
        showToast(res.message, 'success');
        setUserToDelete(null);
      } else {
        showToast(res.message, 'error');
      }
    } finally {
      setIsSavingUser(false);
    }
  };

  const handleOpenPasswordReset = (user: User) => {
    setUserForPasswordReset(user);
    setResetNewPassword('');
    setResetConfirmPassword('');
    setResetMustChange(true);
    setAdminReauthPassword('');
    setResetError('');
  };

  const handleGenerateResetPassword = () => {
    const generated = generateStrongPassword();
    setResetNewPassword(generated);
    setResetConfirmPassword(generated);
    setResetError('');
  };

  const handleConfirmPasswordReset = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!userForPasswordReset) return;
    setResetError('');

    if (!resetNewPassword || !resetConfirmPassword || !adminReauthPassword) {
      setResetError(
        isIndonesian
          ? 'Semua kolom wajib diisi (Password Baru, Konfirmasi, dan Password Super Admin).'
          : 'All fields are required (New Password, Confirmation, and Super Admin Password).'
      );
      return;
    }

    if (resetNewPassword.length < 12) {
      setResetError(
        isIndonesian
          ? 'Password baru minimal 12 karakter untuk standar enterprise PT Lyman Devindo.'
          : 'New password must be at least 12 characters per PT Lyman Devindo enterprise standard.'
      );
      return;
    }

    if (resetNewPassword !== resetConfirmPassword) {
      setResetError(
        isIndonesian
          ? 'Konfirmasi password baru tidak cocok.'
          : 'New password confirmation does not match.'
      );
      return;
    }

    setIsSubmittingReset(true);
    try {
      const res = await adminResetPassword(
        userForPasswordReset.id,
        resetNewPassword,
        resetConfirmPassword,
        resetMustChange,
        adminReauthPassword
      );
      if (res.success) {
        showToast(
          res.message ||
            (isIndonesian
              ? `Password untuk ${userForPasswordReset.fullName} berhasil direset!`
              : `Password for ${userForPasswordReset.fullName} reset successfully!`),
          'success'
        );
        setUserForPasswordReset(null);
      } else {
        setResetError(res.error || (isIndonesian ? 'Gagal mereset password pengguna.' : 'Failed to reset user password.'));
      }
    } catch {
      setResetError(
        isIndonesian
          ? 'Koneksi bermasalah. Silakan coba kembali.'
          : 'Connection issue. Please try again.'
      );
    } finally {
      setIsSubmittingReset(false);
    }
  };


  // Form fields
  const [formName, setFormName] = useState('');
  const [formEmail, setFormEmail] = useState('');
  const [formJobTitle, setFormJobTitle] = useState('');
  const [formDepartment, setFormDepartment] = useState('');
  const [formRole, setFormRole] = useState<UserRole>('requester');
  const [formIsReviewer, setFormIsReviewer] = useState(false);
  const [formTeams, setFormTeams] = useState<string[]>([]);
  const [formCompetencies, setFormCompetencies] = useState<string[]>([]);
  const [formIsActive, setFormIsActive] = useState(true);

  const filteredUsers = allUsers.filter((u) => {
    if (roleFilter !== 'all' && u.role !== roleFilter) return false;
    if (searchTerm) {
      const q = searchTerm.toLowerCase();
      const matchName = u.fullName.toLowerCase().includes(q);
      const matchEmail = u.email.toLowerCase().includes(q);
      const matchJob = u.jobTitle.toLowerCase().includes(q);
      if (!matchName && !matchEmail && !matchJob) return false;
    }
    return true;
  });

  const handleOpenEdit = (user: User) => {
    setEditingUser(user);
    setFormName(user.fullName);
    setFormEmail(user.email);
    setFormJobTitle(user.jobTitle);
    setFormDepartment(user.department);
    setFormRole(user.role);
    setFormIsReviewer(user.isReviewer);
    setFormTeams(Array.from(new Set(user.teams || [])));
    setFormCompetencies(StorageService.normalizeCompetencies(user.competencies));
    setFormIsActive(user.isActive);
  };

  const handleSaveEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingUser || isSavingUser) return;

    // Prevent non-superadmin from elevating to super_admin or demoting current super_admin
    if (editingUser.role === 'super_admin' && !isSuperAdmin) {
      showToast(
        isIndonesian
          ? 'Hanya Super Admin yang berwenang mengubah akun Super Admin.'
          : 'Only Super Admin is authorized to modify a Super Admin account.',
        'error'
      );
      return;
    }

    setIsSavingUser(true);
    try {
      const updated: User = {
        ...editingUser,
        fullName: formName.trim(),
        jobTitle: formJobTitle.trim(),
        department: formDepartment.trim(),
        role: formRole,
        isReviewer: formIsReviewer,
        teams: Array.from(new Set(formTeams)),
        competencies: StorageService.normalizeCompetencies(formCompetencies),
        isActive: formIsActive,
      };

      const res = await updateUserAccount(updated);
      if (!res.success) {
        showToast(
          res.error || (isIndonesian ? 'Gagal memperbarui akun pengguna.' : 'Failed to update user account.'),
          'error'
        );
        return;
      }

      setEditingUser(null);
      showToast(
        isIndonesian
          ? `Akun ${updated.fullName} berhasil diperbarui!`
          : `Account for ${updated.fullName} successfully updated!`,
        'success'
      );
    } finally {
      setIsSavingUser(false);
    }
  };

  const handleSaveNewUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isSavingUser) return;
    if (!formEmail || !formName) {
      showToast(isIndonesian ? 'Nama dan Email wajib diisi.' : 'Name and Email are required.', 'error');
      return;
    }

    setIsSavingUser(true);
    try {
      const newUser: User = {
        id: `user-${Date.now()}`,
        email: formEmail.trim().toLowerCase(),
        fullName: formName.trim(),
        avatarUrl: `https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80`,
        jobTitle: formJobTitle.trim() || 'Staff',
        department: formDepartment.trim() || 'General Affairs',
        role: formRole,
        isReviewer: formIsReviewer,
        teams: Array.from(new Set(formTeams)),
        competencies: StorageService.normalizeCompetencies(formCompetencies),
        assignedRegions: ['all'],
        assignedBrands: ['all'],
        isActive: true,
        createdAt: new Date().toISOString(),
      };

      const res = await updateUserAccount(newUser);
      if (!res.success) {
        showToast(
          res.error || (isIndonesian ? 'Gagal mendaftarkan pengguna baru.' : 'Failed to register new user.'),
          'error'
        );
        return;
      }

      setIsAddModalOpen(false);
      showToast(
        isIndonesian
          ? `Pengguna baru ${newUser.fullName} berhasil didaftarkan!`
          : `New user ${newUser.fullName} successfully registered!`,
        'success'
      );
    } finally {
      setIsSavingUser(false);
    }
  };

  const toggleTeam = (teamId: string) => {
    setFormTeams((prev) =>
      prev.includes(teamId) ? prev.filter((t) => t !== teamId) : [...prev, teamId]
    );
  };

  const toggleCompetency = (comp: string) => {
    setFormCompetencies((prev) => {
      const exists = prev.includes(comp);
      const next = exists ? prev.filter((c) => c !== comp) : [...prev, comp];
      return StorageService.normalizeCompetencies(next);
    });
  };

  // Synchronized directly with Task Categories to prevent duplicate or conflicting labels
  const availableCompetencies = React.useMemo(() => {
    const fromCats = (categories || []).map((c) => c.name.trim()).filter(Boolean);
    const standard = [
      'Graphic Design',
      'Motion Graphics & Video Editing',
      'Social Media Management',
      'Photo & Video Documentation',
      'Digital Marketing',
      'IT Support',
      'Other Requests',
    ];
    return Array.from(new Set(StorageService.normalizeCompetencies([...standard, ...fromCats])));
  }, [categories]);

  const roleLabel = (role: UserRole) => {
    if (role === 'super_admin') return 'Super Admin';
    if (role === 'admin') return 'Marcomm Admin';
    if (role === 'team_member') return isIndonesian ? 'Anggota Tim' : 'Team Member';
    return isIndonesian ? 'Pemohon' : 'Requester';
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="p-6 bg-white rounded-2xl border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-slate-900">
            {isIndonesian ? 'Manajemen Pengguna & Kontrol Akses (RBAC)' : 'User Management & Access Control (RBAC)'}
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            {isIndonesian
              ? 'Kelola akun tim, delegasikan persetujuan Reviewer, atur batasan wilayah/brand, dan pantau status akun aktif.'
              : 'Manage team accounts, delegate Reviewer approvals, configure regional/brand boundaries, and oversee active account statuses.'}
          </p>
        </div>

        {isSuperAdmin && (
          <button
            onClick={() => {
              setFormName('');
              setFormEmail('');
              setFormJobTitle('');
              setFormDepartment('');
              setFormRole('requester');
              setFormIsReviewer(false);
              setFormTeams([]);
              setFormCompetencies([]);
              setIsAddModalOpen(true);
            }}
            className="flex items-center gap-1.5 px-4 py-2 text-xs font-bold text-white bg-[#065F46] hover:bg-[#044e39] rounded-xl transition-colors shadow-xs active:scale-[0.98]"
          >
            <UserPlus className="w-4 h-4" />
            <span>{isIndonesian ? 'Tambah Pengguna Baru' : 'Add New User'}</span>
          </button>
        )}
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3 shadow-xs">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder={isIndonesian ? 'Cari nama, email, atau jabatan...' : 'Search by name, email, or job title...'}
            className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-[#065F46]/20 focus:border-[#065F46]"
          />
        </div>

        <div className="flex items-center gap-2 self-end sm:self-auto text-xs">
          <span className="text-slate-500">{isIndonesian ? 'Filter Peran:' : 'Filter Role:'}</span>
          <select
            value={roleFilter}
            onChange={(e) => setRoleFilter(e.target.value as UserRole | 'all')}
            className="px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 font-medium"
          >
            <option value="all">{isIndonesian ? 'Semua Peran' : 'All Roles'}</option>
            <option value="super_admin">Super Admin</option>
            <option value="admin">Marcomm Admin</option>
            <option value="team_member">{isIndonesian ? 'Anggota Tim' : 'Team Member'}</option>
            <option value="requester">{isIndonesian ? 'Pemohon (Requester)' : 'Requester'}</option>
          </select>
        </div>
      </div>

      {/* 1. Mobile & Small Tablet User Cards View (Screens < md) */}
      <div className="block md:hidden space-y-3">
        {filteredUsers.map((user) => (
          <div
            key={user.id}
            className="p-4 bg-white rounded-2xl border border-slate-200 shadow-2xs space-y-3"
          >
            <div className="flex items-center gap-3">
              <img
                src={
                  user.avatarUrl ||
                  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80'
                }
                alt={user.fullName}
                className="w-11 h-11 rounded-full object-cover border border-slate-200 shrink-0"
              />
              <div className="min-w-0 flex-1">
                <div className="font-bold text-slate-900 text-sm truncate">{user.fullName}</div>
                <div className="text-[11px] text-slate-500 font-mono truncate">{user.email}</div>
                <div className="text-xs text-slate-600 mt-0.5 truncate">
                  {user.jobTitle} · <span className="font-medium text-slate-800">{user.department}</span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-1.5 flex-wrap pt-2 border-t border-slate-100 text-xs">
              <span
                className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-semibold ${
                  user.role === 'super_admin'
                    ? 'bg-purple-100 text-purple-800'
                    : user.role === 'admin'
                    ? 'bg-blue-100 text-blue-800'
                    : user.role === 'team_member'
                    ? 'bg-emerald-100 text-emerald-800'
                    : 'bg-slate-100 text-slate-700'
                }`}
              >
                {roleLabel(user.role)}
              </span>

              {user.isReviewer && (
                <span className="text-[11px] text-amber-800 bg-amber-50 px-2 py-0.5 rounded-md font-semibold border border-amber-200">
                  Reviewer
                </span>
              )}

              <span
                className={`text-[11px] px-2 py-0.5 rounded-md font-semibold ${
                  user.isActive
                    ? 'text-emerald-700 bg-emerald-50'
                    : 'text-slate-500 bg-slate-100'
                }`}
              >
                {user.isActive ? (isIndonesian ? 'Aktif' : 'Active') : (isIndonesian ? 'Nonaktif' : 'Inactive')}
              </span>
            </div>

            {/* Actions on mobile */}
            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => handleOpenEdit(user)}
                className="px-3 py-1.5 text-xs font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-lg transition-colors inline-flex items-center gap-1"
              >
                <Edit2 className="w-3 h-3" />
                <span>{isIndonesian ? 'Ubah Akses' : 'Edit Access'}</span>
              </button>

              {canDeleteUser(user) && (
                <button
                  type="button"
                  onClick={() => setUserToDelete(user)}
                  className="px-3 py-1.5 text-xs font-semibold text-rose-700 bg-rose-50 hover:bg-rose-100 border border-rose-200 rounded-lg transition-colors inline-flex items-center gap-1"
                >
                  <Trash2 className="w-3 h-3" />
                  <span>{isIndonesian ? 'Hapus' : 'Delete'}</span>
                </button>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* 2. Tablet Landscape & Desktop Users Table (Screens >= md) */}
      <div className="hidden md:block bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs min-w-[1000px]">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold select-none">
              <tr>
                <th className="py-3.5 px-4 w-60 whitespace-nowrap">{isIndonesian ? 'Nama & Akun' : 'Name & Account'}</th>
                <th className="py-3.5 px-4 w-44 whitespace-nowrap">{isIndonesian ? 'Jabatan & Departemen' : 'Job Title & Department'}</th>
                <th className="py-3.5 px-4 w-32 whitespace-nowrap">{isIndonesian ? 'Peran Akses' : 'Access Role'}</th>
                <th className="py-3.5 px-4 w-32 whitespace-nowrap">{isIndonesian ? 'Izin Reviewer' : 'Reviewer Permission'}</th>
                <th className="py-3.5 px-4 w-52 whitespace-nowrap">{isIndonesian ? 'Tim & Kompetensi' : 'Teams & Competencies'}</th>
                <th className="py-3.5 px-4 w-28 whitespace-nowrap">{isIndonesian ? 'Status Akun' : 'Account Status'}</th>
                <th className="py-3.5 px-4 w-36 text-right whitespace-nowrap">{isIndonesian ? 'Aksi' : 'Actions'}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredUsers.map((user) => (
                <tr key={user.id} className="hover:bg-blue-50/40 transition-colors">
                  <td className="py-3.5 px-4 align-top">
                    <div className="flex items-center gap-3">
                      <img
                        src={
                          user.avatarUrl ||
                          'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80'
                        }
                        alt={user.fullName}
                        className="w-10 h-10 rounded-full object-cover border border-slate-200 shrink-0"
                      />
                      <div className="min-w-0">
                        <strong className="font-bold text-slate-900 block text-xs truncate">
                          {user.fullName}
                        </strong>
                        <span className="text-[11px] text-slate-500 font-mono block truncate">
                          {user.email}
                        </span>
                      </div>
                    </div>
                  </td>

                  <td className="py-3.5 px-4 align-top">
                    <div className="text-slate-800 font-semibold text-xs">{user.jobTitle}</div>
                    <div className="text-[11px] text-slate-500 mt-0.5">{user.department}</div>
                  </td>

                  <td className="py-3.5 px-4 align-top">
                    <span
                      className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-[11px] font-semibold whitespace-nowrap ${
                        user.role === 'super_admin'
                          ? 'bg-purple-100/90 text-purple-800 border border-purple-200'
                          : user.role === 'admin'
                          ? 'bg-blue-100/90 text-blue-800 border border-blue-200'
                          : user.role === 'team_member'
                          ? 'bg-emerald-100/90 text-emerald-800 border border-emerald-200'
                          : 'bg-slate-100 text-slate-700 border border-slate-200'
                      }`}
                    >
                      <span
                        className={`w-1.5 h-1.5 rounded-full ${
                          user.role === 'super_admin'
                            ? 'bg-purple-600'
                            : user.role === 'admin'
                            ? 'bg-blue-600'
                            : user.role === 'team_member'
                            ? 'bg-emerald-600'
                            : 'bg-slate-400'
                        }`}
                      />
                      <span>{roleLabel(user.role)}</span>
                    </span>
                  </td>

                  <td className="py-3.5 px-4 align-top whitespace-nowrap">
                    {user.isReviewer ? (
                      <span className="inline-flex items-center gap-1.5 text-[11px] font-semibold text-amber-800 bg-amber-50 px-2.5 py-1 rounded-md border border-amber-200/90">
                        <CheckCircle2 className="w-3 h-3 text-amber-600 shrink-0" />
                        <span>Reviewer</span>
                      </span>
                    ) : (
                      <span className="text-[11px] text-slate-400 pl-2">—</span>
                    )}
                  </td>

                  <td className="py-3.5 px-4 align-top">
                    <div className="flex items-center gap-1.5 flex-wrap max-w-sm">
                      {user.competencies && user.competencies.length > 0 ? (
                        StorageService.normalizeCompetencies(user.competencies).map((comp) => (
                          <span
                            key={comp}
                            className="text-[10px] bg-slate-100 text-slate-700 px-2 py-0.5 rounded-md font-medium whitespace-nowrap border border-slate-200/70"
                          >
                            {comp}
                          </span>
                        ))
                      ) : (
                        <span className="text-[11px] text-slate-400 italic">
                          {isIndonesian ? 'Non-kreatif / Pemohon' : 'Non-creative / Requester'}
                        </span>
                      )}
                    </div>
                  </td>

                  <td className="py-3.5 px-4 align-top whitespace-nowrap">
                    {user.isActive ? (
                      <span className="inline-flex items-center gap-1.5 text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-md border border-emerald-200/80">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                        <span>{isIndonesian ? 'Aktif' : 'Active'}</span>
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1.5 text-[11px] font-semibold text-slate-500 bg-slate-100 px-2.5 py-1 rounded-md border border-slate-200">
                        <XCircle className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                        <span>{isIndonesian ? 'Nonaktif' : 'Inactive'}</span>
                      </span>
                    )}
                  </td>

                  <td className="py-3.5 px-4 text-right align-middle whitespace-nowrap">
                    <div className="flex items-center justify-end gap-1.5">
                      <button
                        onClick={() => handleOpenEdit(user)}
                        className="px-2.5 py-1 text-xs font-semibold text-blue-700 hover:text-blue-900 bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-lg transition-colors inline-flex items-center gap-1"
                        title={isIndonesian ? 'Ubah Profil & Izin' : 'Edit Profile & Permissions'}
                      >
                        <Edit2 className="w-3 h-3" />
                        <span>{isIndonesian ? 'Ubah Akses' : 'Edit Access'}</span>
                      </button>

                      {isSuperAdmin && (
                        <button
                          onClick={() => handleOpenPasswordReset(user)}
                          className="px-2.5 py-1 text-xs font-semibold text-emerald-800 hover:text-emerald-950 bg-emerald-50 hover:bg-emerald-100 border border-emerald-300 rounded-lg transition-colors inline-flex items-center gap-1"
                          title={isIndonesian ? 'Reset Password Pengguna' : 'Reset User Password'}
                        >
                          <KeyRound className="w-3 h-3" />
                          <span>{isIndonesian ? 'Reset Password' : 'Reset Password'}</span>
                        </button>
                      )}


                      {canDeleteUser(user) ? (
                        <button
                          onClick={() => setUserToDelete(user)}
                          className="px-2.5 py-1 text-xs font-semibold text-rose-700 hover:text-rose-900 bg-rose-50 hover:bg-rose-100 border border-rose-200 rounded-lg transition-colors inline-flex items-center gap-1"
                          title={isIndonesian ? `Hapus pengguna ${user.fullName}` : `Delete user ${user.fullName}`}
                        >
                          <Trash2 className="w-3 h-3" />
                          <span>{isIndonesian ? 'Hapus' : 'Delete'}</span>
                        </button>
                      ) : isCurrentActiveUser(user) ? (
                        <span
                          className="px-2 py-1 text-[11px] font-medium text-slate-500 bg-slate-100 border border-slate-200 rounded-lg inline-flex items-center gap-1"
                          title={isIndonesian ? 'Pengguna yang sedang login' : 'Currently logged in user'}
                        >
                          <Lock className="w-2.5 h-2.5 text-slate-400" />
                          <span>{isIndonesian ? 'Akun Aktif' : 'Current User'}</span>
                        </span>
                      ) : isProtectedSuperAdmin(user) ? (
                        <span
                          className="px-2 py-1 text-[11px] font-medium text-purple-700 bg-purple-50 rounded-lg inline-flex items-center gap-1 border border-purple-200"
                          title={isIndonesian ? 'Super Admin Utama (Dilindungi Sistem)' : 'Primary Super Admin (System protected)'}
                        >
                          <ShieldCheck className="w-2.5 h-2.5 text-purple-600" />
                          <span>{isIndonesian ? 'Dilindungi' : 'Protected'}</span>
                        </span>
                      ) : null}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Edit User Modal */}
      {editingUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl p-6 max-w-lg w-full border border-slate-200 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <h3 className="text-sm font-bold text-slate-900">
                {isIndonesian ? `Kelola Profil & Izin: ${editingUser.fullName}` : `Manage Profile & Permissions: ${editingUser.fullName}`}
              </h3>
              <button onClick={() => setEditingUser(null)} className="text-slate-400 hover:text-slate-600">
                <XCircle className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveEdit} className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-800 mb-1">
                  {isIndonesian ? 'Nama Lengkap' : 'Full Name'}
                </label>
                <input
                  type="text"
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-800 mb-1">
                  {isIndonesian ? 'Jabatan & Posisi' : 'Job Title & Position'}
                </label>
                <input
                  type="text"
                  value={formJobTitle}
                  onChange={(e) => setFormJobTitle(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-800 mb-1">
                  {isIndonesian ? 'Departemen Organisasi' : 'Organizational Department'}
                </label>
                <input
                  type="text"
                  value={formDepartment}
                  onChange={(e) => setFormDepartment(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg"
                />
              </div>

              {/* Role selector (Only Super Admin can change role) */}
              <div>
                <label className="block font-bold text-slate-800 mb-1">
                  {isIndonesian ? 'Peran Sistem' : 'System Role'}
                </label>
                <select
                  value={formRole}
                  disabled={!isSuperAdmin}
                  onChange={(e) => setFormRole(e.target.value as UserRole)}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg disabled:bg-slate-100"
                >
                  <option value="requester">{isIndonesian ? 'Pemohon (Requester)' : 'Requester'}</option>
                  <option value="team_member">{isIndonesian ? 'Anggota Tim (Kreatif / Spesialis)' : 'Team Member (Creative / Specialist)'}</option>
                  <option value="admin">Marcomm Admin</option>
                  {isSuperAdmin && <option value="super_admin">Super Admin</option>}
                </select>
                {!isSuperAdmin && (
                  <p className="text-[10px] text-slate-400 mt-1">
                    {isIndonesian
                      ? 'Hanya Super Admin yang memiliki wewenang mengubah level peran sistem.'
                      : 'Only Super Admin has authority to modify system role levels.'}
                  </p>
                )}
              </div>

              {/* Reviewer permission toggle */}
              <div className="p-3 bg-amber-50/60 rounded-xl border border-amber-200 flex items-center justify-between">
                <div>
                  <strong className="block text-slate-900 font-bold">
                    {isIndonesian ? 'Izin Persetujuan Reviewer' : 'Reviewer Approval Permission'}
                  </strong>
                  <span className="text-[11px] text-slate-500">
                    {isIndonesian
                      ? 'Memberi wewenang akun ini untuk menyetujui deliverable atau meminta revisi kreatif.'
                      : 'Authorizes this account to approve deliverables or request creative revisions.'}
                  </span>
                </div>
                <input
                  type="checkbox"
                  checked={formIsReviewer}
                  onChange={(e) => setFormIsReviewer(e.target.checked)}
                  className="w-4 h-4 text-blue-600 rounded"
                />
              </div>

              {/* Competencies multi-select */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="block font-bold text-slate-800 text-xs">
                    {isIndonesian ? 'Kompetensi Tim' : 'Team Competencies'}
                  </label>
                  <span className="text-[11px] text-slate-500 font-medium">
                    {isIndonesian ? 'Selaras dengan Kategori Tugas (Tanpa duplikasi)' : 'Aligned with Task Categories (No duplicates)'}
                  </span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {availableCompetencies.map((comp) => {
                    const isChecked = formCompetencies.includes(comp);
                    return (
                      <label
                        key={comp}
                        className={`flex items-center gap-2 p-2 rounded-xl border cursor-pointer text-[11px] transition-colors ${
                          isChecked
                            ? 'bg-[#D1FAE5]/60 border-[#A7F3D0] text-[#065F46] font-semibold shadow-2xs'
                            : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                        }`}
                      >
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={() => toggleCompetency(comp)}
                          className="rounded text-[#065F46] focus:ring-[#065F46]"
                        />
                        <span className="truncate">{comp}</span>
                      </label>
                    );
                  })}
                </div>
              </div>

              {/* Active / Inactive switch */}
              <div className="flex items-center justify-between p-3 bg-slate-50 rounded-xl border border-slate-200">
                <div>
                  <strong className="block text-slate-900 font-bold">
                    {isIndonesian ? 'Status Akun Aktif' : 'Active Account Status'}
                  </strong>
                  <span className="text-[11px] text-slate-500">
                    {isIndonesian
                      ? 'Menonaktifkan akun tetap mempertahankan seluruh riwayat tugas, audit, dan deliverable terdahulu.'
                      : 'Deactivating an account preserves all past task history, audits, and deliverables.'}
                  </span>
                </div>
                <input
                  type="checkbox"
                  checked={formIsActive}
                  onChange={(e) => setFormIsActive(e.target.checked)}
                  className="w-4 h-4 text-blue-600 rounded"
                />
              </div>

              {/* Security & Password Section */}
              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-[#065F46]" />
                    <div>
                      <strong className="block text-slate-900 font-bold text-xs">
                        {isIndonesian ? 'Keamanan & Kata Sandi' : 'Security & Password'}
                      </strong>
                      <span className="text-[11px] text-slate-500">
                        {isIndonesian
                          ? 'Status kredensial, wajib rotasi kata sandi, dan reset administratif.'
                          : 'Credential status, force rotation flag, and administrative reset.'}
                      </span>
                    </div>
                  </div>
                  {editingUser.mustChangePassword && (
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-100 text-amber-800 border border-amber-300">
                      {isIndonesian ? 'Wajib Ubah Password' : 'Password Change Required'}
                    </span>
                  )}
                </div>

                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 pt-1">
                  <p className="text-[11px] text-slate-600 leading-relaxed max-w-sm">
                    {isSuperAdmin
                      ? (isIndonesian
                        ? 'Super Admin dapat mereset kata sandi akun ini secara administratif dengan verifikasi otentikasi.'
                        : 'Super Admin can administratively reset this account password with authentication verification.')
                      : (isIndonesian
                        ? 'Hanya Super Admin yang memiliki wewenang mereset kata sandi pengguna lain.'
                        : 'Only Super Admin is authorized to reset another user password.')}
                  </p>

                  {isSuperAdmin && (
                    <button
                      type="button"
                      onClick={() => {
                        const target = editingUser;
                        setEditingUser(null);
                        handleOpenPasswordReset(target);
                      }}
                      className="px-3.5 py-1.5 text-xs font-bold text-white bg-[#065F46] hover:bg-[#044e39] rounded-xl transition-all shadow-xs flex items-center gap-1.5 shrink-0 self-start sm:self-auto"
                    >
                      <KeyRound className="w-3.5 h-3.5" />
                      <span>Reset Password</span>
                    </button>
                  )}
                </div>
              </div>

              <div className="flex items-center justify-between pt-3 border-t border-slate-200">
                {canDeleteUser(editingUser) ? (
                  <button
                    type="button"
                    onClick={() => {
                      const target = editingUser;
                      setEditingUser(null);
                      setUserToDelete(target);
                    }}
                    className="px-3 py-2 text-xs font-semibold text-rose-700 hover:text-rose-900 bg-rose-50 hover:bg-rose-100 border border-rose-200 rounded-lg transition-colors inline-flex items-center gap-1.5"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>{isIndonesian ? 'Hapus Pengguna' : 'Delete User'}</span>
                  </button>
                ) : (
                  <div />
                )}

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setEditingUser(null)}
                    className="px-4 py-2 font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
                  >
                    {isIndonesian ? 'Batal' : 'Cancel'}
                  </button>
                  <button
                    type="submit"
                    disabled={isSavingUser}
                    className="px-4 py-2 font-bold text-white bg-blue-600 hover:bg-blue-700 disabled:opacity-60 rounded-lg shadow-2xs"
                  >
                    {isSavingUser
                      ? isIndonesian ? 'Menyimpan...' : 'Saving...'
                      : isIndonesian ? 'Simpan Perubahan' : 'Save Changes'}
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add User Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl p-6 max-w-lg w-full border border-slate-200 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <h3 className="text-sm font-bold text-slate-900">
                {isIndonesian ? 'Undang / Daftarkan Pengguna Baru' : 'Invite / Register New User'}
              </h3>
              <button onClick={() => setIsAddModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                <XCircle className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveNewUser} className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-800 mb-1">
                  {isIndonesian ? 'Nama Lengkap *' : 'Full Name *'}
                </label>
                <input
                  type="text"
                  required
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  placeholder={isIndonesian ? 'Contoh: Johnathan Doe' : 'e.g. Johnathan Doe'}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-800 mb-1">
                  {isIndonesian ? 'Alamat Email Perusahaan *' : 'Company Email Address *'}
                </label>
                <input
                  type="email"
                  required
                  value={formEmail}
                  onChange={(e) => setFormEmail(e.target.value)}
                  placeholder="john.doe@lyman.co.id"
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-800 mb-1">
                  {isIndonesian ? 'Jabatan' : 'Job Title'}
                </label>
                <input
                  type="text"
                  value={formJobTitle}
                  onChange={(e) => setFormJobTitle(e.target.value)}
                  placeholder={isIndonesian ? 'Contoh: Senior Motion Designer' : 'e.g. Senior Motion Designer'}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-800 mb-1">
                  {isIndonesian ? 'Departemen' : 'Department'}
                </label>
                <input
                  type="text"
                  value={formDepartment}
                  onChange={(e) => setFormDepartment(e.target.value)}
                  placeholder={isIndonesian ? 'Contoh: Marketing Communications' : 'e.g. Marketing Communications'}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-800 mb-1">
                  {isIndonesian ? 'Peran Akses' : 'Access Role'}
                </label>
                <select
                  value={formRole}
                  onChange={(e) => setFormRole(e.target.value as UserRole)}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg text-xs"
                >
                  <option value="requester">{isIndonesian ? 'Pemohon (Requester)' : 'Requester'}</option>
                  <option value="team_member">{isIndonesian ? 'Anggota Tim (Kreatif / Spesialis)' : 'Team Member (Creative / Specialist)'}</option>
                  <option value="admin">Marcomm Admin</option>
                </select>
              </div>

              {/* Competencies multi-select for Creative / Specialist or Admin */}
              {(formRole === 'team_member' || formRole === 'admin') && (
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="block font-bold text-slate-800 text-xs">
                      {isIndonesian ? 'Kompetensi Tim' : 'Team Competencies'}
                    </label>
                    <span className="text-[11px] text-slate-500 font-medium">
                      {isIndonesian ? 'Selaras dengan Kategori Tugas (Tanpa duplikasi)' : 'Aligned with Task Categories (No duplicates)'}
                    </span>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-48 overflow-y-auto pr-1">
                    {availableCompetencies.map((comp) => {
                      const isChecked = formCompetencies.includes(comp);
                      return (
                        <label
                          key={comp}
                          className={`flex items-center gap-2 p-2 rounded-xl border cursor-pointer text-[11px] transition-colors ${
                            isChecked
                              ? 'bg-[#D1FAE5]/60 border-[#A7F3D0] text-[#065F46] font-semibold shadow-2xs'
                              : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                          }`}
                        >
                          <input
                            type="checkbox"
                            checked={isChecked}
                            onChange={() => toggleCompetency(comp)}
                            className="rounded text-[#065F46] focus:ring-[#065F46]"
                          />
                          <span className="truncate">{comp}</span>
                        </label>
                      );
                    })}
                  </div>
                </div>
              )}

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 font-semibold text-slate-700 bg-white border border-slate-300 rounded-xl hover:bg-slate-50 text-xs"
                >
                  {isIndonesian ? 'Batal' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  disabled={isSavingUser}
                  className="px-4 py-2 font-bold text-white bg-[#065F46] hover:bg-[#044e39] disabled:opacity-60 rounded-xl shadow-xs text-xs active:scale-[0.98]"
                >
                  {isSavingUser
                    ? isIndonesian ? 'Mendaftarkan...' : 'Registering...'
                    : isIndonesian ? 'Daftarkan Akun' : 'Register Account'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete User Confirmation Modal */}
      {userToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl p-6 max-w-md w-full border border-slate-200 shadow-2xl space-y-4">
            <div className="flex items-start gap-3.5">
              <div className="w-10 h-10 rounded-xl bg-rose-100 text-rose-600 flex items-center justify-center shrink-0">
                <Trash2 className="w-5 h-5" />
              </div>
              <div className="space-y-1">
                <h3 className="text-base font-bold text-slate-900">
                  {isIndonesian ? 'Hapus Akun Pengguna?' : 'Delete User Account?'}
                </h3>
                <p className="text-xs text-slate-500">
                  {isIndonesian
                    ? 'Tindakan ini menghapus akun pengguna dari daftar sistem aktif dan daftar penugasan mendatang.'
                    : 'This action removes the user account from active system rosters and future assignment lists.'}
                </p>
              </div>
            </div>

            {/* User Info Card */}
            <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 space-y-2.5">
              <div className="flex items-center gap-3">
                <img
                  src={
                    userToDelete.avatarUrl ||
                    'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80'
                  }
                  alt={userToDelete.fullName}
                  className="w-10 h-10 rounded-full object-cover border border-slate-200 shrink-0"
                />
                <div className="min-w-0">
                  <div className="font-bold text-slate-900 text-sm truncate">
                    {userToDelete.fullName}
                  </div>
                  <div className="text-xs text-slate-500 font-mono truncate">
                    {userToDelete.email}
                  </div>
                  <div className="text-[11px] text-slate-600 mt-0.5">
                    {userToDelete.jobTitle} &bull; {userToDelete.department}
                  </div>
                </div>
              </div>

              {/* Related requests stats */}
              {(() => {
                const createdCount = requests.filter(
                  (r) => r.requesterId === userToDelete.id
                ).length;
                const assignedCount = requests.filter(
                  (r) =>
                    r.primaryAssigneeId === userToDelete.id ||
                    (r.collaboratorIds && r.collaboratorIds.includes(userToDelete.id))
                ).length;

                return (
                  <div className="pt-2 border-t border-slate-200/80 flex items-center gap-2 flex-wrap text-[11px]">
                    <span className="text-slate-500 font-medium">
                      {isIndonesian ? 'Riwayat Terkait:' : 'Associated History:'}
                    </span>
                    <span className="px-2 py-0.5 bg-blue-50 text-blue-700 rounded-md font-semibold border border-blue-200">
                      {createdCount} {isIndonesian ? 'Diajukan' : 'Submitted'}
                    </span>
                    <span className="px-2 py-0.5 bg-emerald-50 text-emerald-700 rounded-md font-semibold border border-emerald-200">
                      {assignedCount} {isIndonesian ? 'Ditugaskan' : 'Assigned'}
                    </span>
                  </div>
                );
              })()}
            </div>

            {/* Note banner */}
            <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 flex items-start gap-2.5 text-xs text-amber-900">
              <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
              <div>
                <strong>{isIndonesian ? 'Integritas Data Terjaga:' : 'Data Integrity Preserved:'}</strong>{' '}
                {isIndonesian
                  ? 'Riwayat kerja terdahulu, log audit, komentar, dan deliverable yang dikirim oleh pengguna ini tetap utuh dan tersimpan secara historis.'
                  : 'Past work history, audit logs, comments, and deliverables submitted by this user will remain fully intact and historically preserved.'}
              </div>
            </div>

            {/* Actions */}
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setUserToDelete(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-xl hover:bg-slate-50 transition-colors"
              >
                {isIndonesian ? 'Batal' : 'Cancel'}
              </button>
              <button
                type="button"
                disabled={isSavingUser}
                onClick={handleConfirmDelete}
                className="px-4 py-2 text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 disabled:opacity-60 rounded-xl shadow-xs transition-colors inline-flex items-center gap-1.5"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>
                  {isSavingUser
                    ? isIndonesian ? 'Menghapus...' : 'Deleting...'
                    : isIndonesian ? 'Ya, Hapus Pengguna' : 'Yes, Delete User'}
                </span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Super Admin Administrative Password Reset Modal */}
      {userForPasswordReset && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 space-y-5 max-h-[90vh] overflow-y-auto">
            {/* Header */}
            <div className="flex items-start justify-between pb-3 border-b border-slate-200">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-xl bg-emerald-50 text-[#065F46] flex items-center justify-center border border-emerald-200">
                  <KeyRound className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900">
                    {isIndonesian ? 'Reset Password Administratif' : 'Administrative Password Reset'}
                  </h3>
                  <p className="text-xs text-slate-500">
                    {isIndonesian ? 'Pembaruan & Rotasi Kredensial Super Admin' : 'Super Admin Credential Override & Rotation'}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setUserForPasswordReset(null)}
                className="text-slate-400 hover:text-slate-600 p-1"
              >
                ✕
              </button>
            </div>

            {/* Target User Summary Card */}
            <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200 flex items-center justify-between text-xs">
              <div className="flex items-center gap-3 min-w-0">
                <img
                  src={
                    userForPasswordReset.avatarUrl ||
                    'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80'
                  }
                  alt={userForPasswordReset.fullName}
                  className="w-10 h-10 rounded-full object-cover border border-slate-200 shrink-0"
                />
                <div className="min-w-0">
                  <strong className="font-bold text-slate-900 block truncate">
                    {userForPasswordReset.fullName}
                  </strong>
                  <span className="text-[11px] text-slate-500 font-mono block truncate">
                    {userForPasswordReset.email}
                  </span>
                </div>
              </div>

              <span className="text-[10px] font-bold px-2.5 py-1 rounded-full uppercase bg-purple-50 text-purple-700 border border-purple-200 shrink-0">
                {roleLabel(userForPasswordReset.role)}
              </span>
            </div>

            {resetError && (
              <div className="p-3.5 bg-rose-50 text-rose-700 text-xs font-semibold rounded-xl border border-rose-200 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                <span>{resetError}</span>
              </div>
            )}

            <form onSubmit={handleConfirmPasswordReset} className="space-y-4 text-xs">
              {/* New Password & Generator */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-bold text-slate-700">
                    {isIndonesian ? 'Password Baru untuk Pengguna:' : 'New Password for User:'}
                  </span>
                  <button
                    type="button"
                    onClick={handleGenerateResetPassword}
                    className="text-[11px] font-bold text-emerald-700 hover:text-emerald-900 flex items-center gap-1 hover:underline"
                  >
                    <Sparkles className="w-3 h-3 text-emerald-600" />
                    <span>{isIndonesian ? 'Buat Password Kuat' : 'Generate Strong Password'}</span>
                  </button>
                </div>

                <PasswordInput
                  id="admin-reset-new-password"
                  label={isIndonesian ? 'Password Baru' : 'New Password'}
                  value={resetNewPassword}
                  onChange={setResetNewPassword}
                  placeholder={isIndonesian ? 'Minimal 12 karakter' : 'Minimum 12 characters'}
                  required
                  showStrength
                  disabled={isSubmittingReset}
                />
              </div>

              <PasswordInput
                id="admin-reset-confirm-password"
                label={isIndonesian ? 'Konfirmasi Password Baru' : 'Confirm New Password'}
                value={resetConfirmPassword}
                onChange={setResetConfirmPassword}
                placeholder={isIndonesian ? 'Ulangi password baru' : 'Repeat new password'}
                required
                disabled={isSubmittingReset}
                error={
                  resetConfirmPassword && resetNewPassword !== resetConfirmPassword
                    ? (isIndonesian ? 'Konfirmasi password tidak cocok' : 'Password confirmation does not match')
                    : undefined
                }
              />

              {/* Require Password Change on Next Login */}
              <div className="p-3 bg-emerald-50/50 rounded-xl border border-emerald-200/80 flex items-center justify-between">
                <div>
                  <strong className="block text-slate-900 font-bold text-xs">
                    {isIndonesian ? 'Wajibkan Ubah Password Saat Login Berikutnya' : 'Require Password Change on Next Login'}
                  </strong>
                  <span className="text-[11px] text-slate-500">
                    {isIndonesian
                      ? 'Pengguna akan dialihkan ke layar ganti password wajib setelah masuk.'
                      : 'The user will be redirected to the forced password change screen upon login.'}
                  </span>
                </div>
                <input
                  type="checkbox"
                  checked={resetMustChange}
                  onChange={(e) => setResetMustChange(e.target.checked)}
                  className="w-4 h-4 text-emerald-700 rounded focus:ring-emerald-600"
                />
              </div>

              {/* Super Admin Reauthentication Box */}
              <div className="p-4 bg-amber-50/70 rounded-2xl border border-amber-200 space-y-2.5">
                <div className="flex items-center gap-2">
                  <ShieldAlert className="w-4 h-4 text-amber-700 shrink-0" />
                  <strong className="text-xs font-bold text-amber-900">
                    {isIndonesian ? 'Verifikasi Otoritas Super Admin (Re-autentikasi)' : 'Super Admin Authority Verification (Re-authentication)'}
                  </strong>
                </div>
                <p className="text-[11px] text-amber-800 leading-relaxed">
                  {isIndonesian ? (
                    <>
                      Untuk mencegah penyalahgunaan sesi, masukkan password akun Super Admin Anda (<strong>{currentUser.email}</strong>) guna mengonfirmasi reset password ini:
                    </>
                  ) : (
                    <>
                      To prevent session misuse, enter your Super Admin account password (<strong>{currentUser.email}</strong>) to confirm this password reset:
                    </>
                  )}
                </p>

                <PasswordInput
                  id="admin-reauth-password"
                  label={isIndonesian ? 'Password Super Admin Anda' : 'Your Super Admin Password'}
                  value={adminReauthPassword}
                  onChange={setAdminReauthPassword}
                  placeholder={isIndonesian ? 'Masukkan password akun Anda saat ini' : 'Enter your current account password'}
                  required
                  disabled={isSubmittingReset}
                />
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setUserForPasswordReset(null)}
                  disabled={isSubmittingReset}
                  className="px-4 py-2 font-semibold text-slate-700 bg-white border border-slate-300 rounded-xl hover:bg-slate-50"
                >
                  {isIndonesian ? 'Batal' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  disabled={
                    isSubmittingReset ||
                    (resetConfirmPassword.length > 0 && resetNewPassword !== resetConfirmPassword)
                  }
                  className="px-5 py-2 font-bold text-white bg-[#065F46] hover:bg-[#044e39] disabled:bg-slate-300 rounded-xl transition-all shadow-xs flex items-center gap-1.5"
                >
                  <KeyRound className="w-3.5 h-3.5" />
                  <span>
                    {isSubmittingReset
                      ? (isIndonesian ? 'Mereset Password...' : 'Resetting Password...')
                      : (isIndonesian ? 'Konfirmasi Reset Password' : 'Confirm Password Reset')}
                  </span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

