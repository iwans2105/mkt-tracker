import React, { useState, useEffect } from 'react';
import {
  Database,
  Building,
  MapPin,
  FolderTree,
  Tag,
  Users,
  Plus,
  Edit2,
  Trash2,
  CheckCircle2,
  XCircle,
  HelpCircle,
} from 'lucide-react';
import { useRequests } from '../../context/RequestContext';
import { useAuth } from '../../context/AuthContext';
import { useLanguage } from '../../context/LanguageContext';
import { Region, Brand, Unit, Department, Category, Team } from '../../types';

export const MasterDataView: React.FC = () => {
  const { regions, brands, units, departments, categories, teams, saveMasterData } = useRequests();
  const { allUsers } = useAuth();
  const { isIndonesian } = useLanguage();

  const [activeTab, setActiveTab] = useState<
    'brands' | 'units' | 'regions' | 'departments' | 'categories' | 'teams'
  >('brands');

  // Modals state
  const [isAddRegionOpen, setIsAddRegionOpen] = useState(false);
  const [newRegionName, setNewRegionName] = useState('');
  const [newRegionCode, setNewRegionCode] = useState('');

  const [isAddBrandOpen, setIsAddBrandOpen] = useState(false);
  const [newBrandName, setNewBrandName] = useState('');
  const [newBrandCode, setNewBrandCode] = useState('');
  const [newBrandRegionId, setNewBrandRegionId] = useState('reg-jkt');

  const [isAddUnitOpen, setIsAddUnitOpen] = useState(false);
  const [newUnitName, setNewUnitName] = useState('');
  const [newUnitCode, setNewUnitCode] = useState('');
  const [newUnitBrandId, setNewUnitBrandId] = useState('brand-lyman');

  const [isAddDeptOpen, setIsAddDeptOpen] = useState(false);
  const [newDeptName, setNewDeptName] = useState('');

  const [isAddCatOpen, setIsAddCatOpen] = useState(false);
  const [newCatName, setNewCatName] = useState('');
  const [newCatSla, setNewCatSla] = useState(3);

  // Teams modal state
  const [isAddTeamOpen, setIsAddTeamOpen] = useState(false);
  const [newTeamName, setNewTeamName] = useState('');
  const [newTeamDesc, setNewTeamDesc] = useState('');
  const [newTeamColor, setNewTeamColor] = useState('#065F46');

  const [editingTeam, setEditingTeam] = useState<Team | null>(null);
  const [editTeamName, setEditTeamName] = useState('');
  const [editTeamDesc, setEditTeamDesc] = useState('');
  const [editTeamColor, setEditTeamColor] = useState('#065F46');

  const [isSaving, setIsSaving] = useState(false);

  const [deleteTarget, setDeleteTarget] = useState<{
    type: 'brand' | 'unit' | 'region' | 'department' | 'category' | 'team';
    id: string;
    name: string;
    label: string;
  } | null>(null);

  useEffect(() => {
    if (regions.length > 0 && !regions.some((r) => r.id === newBrandRegionId)) {
      setNewBrandRegionId(regions[0].id);
    }
  }, [regions, newBrandRegionId]);

  useEffect(() => {
    if (brands.length > 0 && !brands.some((b) => b.id === newUnitBrandId)) {
      setNewUnitBrandId(brands[0].id);
    }
  }, [brands, newUnitBrandId]);

  const handleCreateRegion = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRegionName.trim() || isSaving) return;
    setIsSaving(true);
    try {
      const ok = await saveMasterData.addRegion({
        name: newRegionName.trim(),
        code: newRegionCode.trim().toUpperCase() || 'REG',
        isActive: true,
      });
      if (ok) {
        setNewRegionName('');
        setNewRegionCode('');
        setIsAddRegionOpen(false);
      }
    } finally {
      setIsSaving(false);
    }
  };

  const handleDeleteBrand = (id: string, name: string) => {
    setDeleteTarget({ type: 'brand', id, name, label: isIndonesian ? 'Brand / Entitas' : 'Brand / Entity' });
  };

  const handleDeleteUnit = (id: string, name: string) => {
    setDeleteTarget({ type: 'unit', id, name, label: isIndonesian ? 'Unit Bisnis' : 'Business Unit' });
  };

  const handleDeleteRegion = (id: string, name: string) => {
    setDeleteTarget({ type: 'region', id, name, label: isIndonesian ? 'Wilayah' : 'Region' });
  };

  const handleDeleteDept = (id: string, name: string) => {
    setDeleteTarget({ type: 'department', id, name, label: isIndonesian ? 'Departemen' : 'Department' });
  };

  const handleDeleteCategory = (id: string, name: string) => {
    setDeleteTarget({ type: 'category', id, name, label: isIndonesian ? 'Kategori Tugas' : 'Task Category' });
  };

  const handleDeleteTeam = (id: string, name: string) => {
    setDeleteTarget({ type: 'team', id, name, label: isIndonesian ? 'Tim Eksekusi' : 'Execution Team' });
  };

  const handleConfirmDelete = async () => {
    if (!deleteTarget || isSaving) return;
    setIsSaving(true);
    try {
      const { type, id } = deleteTarget;
      let ok = false;
      if (type === 'brand') ok = await saveMasterData.deleteBrand(id);
      else if (type === 'unit') ok = await saveMasterData.deleteUnit(id);
      else if (type === 'region') ok = await saveMasterData.deleteRegion(id);
      else if (type === 'department') ok = await saveMasterData.deleteDepartment(id);
      else if (type === 'category') ok = await saveMasterData.deleteCategory(id);
      else if (type === 'team') ok = await saveMasterData.deleteTeam(id);
      if (ok) {
        setDeleteTarget(null);
      }
    } finally {
      setIsSaving(false);
    }
  };

  const handleCreateBrand = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newBrandName.trim() || isSaving) return;
    setIsSaving(true);
    try {
      const ok = await saveMasterData.addBrand({
        name: newBrandName.trim(),
        code: newBrandCode.trim().toUpperCase() || 'BRD',
        regionId: newBrandRegionId,
        isActive: true,
      });
      if (ok) {
        setNewBrandName('');
        setNewBrandCode('');
        setIsAddBrandOpen(false);
      }
    } finally {
      setIsSaving(false);
    }
  };

  const handleCreateUnit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUnitName.trim() || isSaving) return;
    setIsSaving(true);
    try {
      const ok = await saveMasterData.addUnit({
        name: newUnitName.trim(),
        code: newUnitCode.trim().toUpperCase() || 'UNT',
        brandId: newUnitBrandId,
        isActive: true,
      });
      if (ok) {
        setNewUnitName('');
        setNewUnitCode('');
        setIsAddUnitOpen(false);
      }
    } finally {
      setIsSaving(false);
    }
  };

  const handleCreateDept = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDeptName.trim() || isSaving) return;
    setIsSaving(true);
    try {
      const ok = await saveMasterData.addDepartment({
        name: newDeptName.trim(),
        isActive: true,
      });
      if (ok) {
        setNewDeptName('');
        setIsAddDeptOpen(false);
      }
    } finally {
      setIsSaving(false);
    }
  };

  const handleCreateCategory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCatName.trim() || isSaving) return;
    setIsSaving(true);
    try {
      const ok = await saveMasterData.addCategory({
        name: newCatName.trim(),
        slaDaysDefault: Number(newCatSla) || 3,
        isActive: true,
      });
      if (ok) {
        setNewCatName('');
        setIsAddCatOpen(false);
      }
    } finally {
      setIsSaving(false);
    }
  };

  const handleCreateTeam = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTeamName.trim() || isSaving) return;
    setIsSaving(true);
    try {
      const ok = await saveMasterData.addTeam({
        name: newTeamName.trim(),
        description: newTeamDesc.trim() || (isIndonesian ? 'Tim eksekusi komunikasi pemasaran.' : 'Marketing communications execution team.'),
        color: newTeamColor,
        isActive: true,
      });
      if (ok) {
        setNewTeamName('');
        setNewTeamDesc('');
        setNewTeamColor('#065F46');
        setIsAddTeamOpen(false);
      }
    } finally {
      setIsSaving(false);
    }
  };

  const handleOpenEditTeam = (team: Team) => {
    setEditingTeam(team);
    setEditTeamName(team.name);
    setEditTeamDesc(team.description);
    setEditTeamColor(team.color || '#065F46');
  };

  const handleUpdateTeam = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingTeam || !editTeamName.trim() || isSaving) return;
    setIsSaving(true);
    try {
      const ok = await saveMasterData.updateTeam({
        ...editingTeam,
        name: editTeamName.trim(),
        description: editTeamDesc.trim(),
        color: editTeamColor,
      });
      if (ok) {
        setEditingTeam(null);
      }
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="p-6 bg-white rounded-2xl border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-slate-900">
            {isIndonesian ? 'Manajemen Data Induk Organisasi' : 'Organizational Master Data Management'}
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            {isIndonesian
              ? 'Struktur hierarki: Wilayah → Brand/Entitas → Unit Bisnis/Departemen. Penonaktifan entitas menjaga integritas data historis.'
              : 'Hierarchical structure: Region → Brand/Entity → Business Unit/Department. Entity deactivation preserves historical data integrity.'}
          </p>
        </div>

        <div className="flex items-center gap-2">
          {activeTab === 'brands' && (
            <button
              type="button"
              onClick={() => {
                if (!regions.some((r) => r.id === newBrandRegionId)) {
                  setNewBrandRegionId(regions[0]?.id || '');
                }
                setIsAddBrandOpen(true);
              }}
              className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold text-white bg-[#065F46] hover:bg-[#044e39] rounded-xl transition-colors shadow-xs"
            >
              <Plus className="w-4 h-4" />
              <span>{isIndonesian ? 'Tambah Brand' : 'Add Brand'}</span>
            </button>
          )}
          {activeTab === 'units' && (
            <button
              type="button"
              onClick={() => {
                if (!brands.some((b) => b.id === newUnitBrandId)) {
                  setNewUnitBrandId(brands[0]?.id || '');
                }
                setIsAddUnitOpen(true);
              }}
              className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold text-white bg-[#065F46] hover:bg-[#044e39] rounded-xl transition-colors shadow-xs"
            >
              <Plus className="w-4 h-4" />
              <span>{isIndonesian ? 'Tambah Unit Bisnis' : 'Add Business Unit'}</span>
            </button>
          )}
          {activeTab === 'regions' && (
            <button
              onClick={() => setIsAddRegionOpen(true)}
              className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold text-white bg-[#065F46] hover:bg-[#044e39] rounded-xl transition-colors shadow-xs"
            >
              <Plus className="w-4 h-4" />
              <span>{isIndonesian ? 'Tambah Wilayah' : 'Add Region'}</span>
            </button>
          )}
          {activeTab === 'departments' && (
            <button
              onClick={() => setIsAddDeptOpen(true)}
              className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold text-white bg-[#065F46] hover:bg-[#044e39] rounded-xl transition-colors shadow-xs"
            >
              <Plus className="w-4 h-4" />
              <span>{isIndonesian ? 'Tambah Departemen' : 'Add Department'}</span>
            </button>
          )}
          {activeTab === 'categories' && (
            <button
              onClick={() => setIsAddCatOpen(true)}
              className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold text-white bg-[#065F46] hover:bg-[#044e39] rounded-xl transition-colors shadow-xs"
            >
              <Plus className="w-4 h-4" />
              <span>{isIndonesian ? 'Tambah Kategori' : 'Add Category'}</span>
            </button>
          )}
          {activeTab === 'teams' && (
            <button
              onClick={() => setIsAddTeamOpen(true)}
              className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold text-white bg-[#065F46] hover:bg-[#044e39] rounded-xl transition-colors shadow-xs"
            >
              <Plus className="w-4 h-4" />
              <span>{isIndonesian ? 'Tambah Tim Eksekusi' : 'Add Execution Team'}</span>
            </button>
          )}
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-1 border-b border-slate-200 bg-white px-4 rounded-xl shadow-xs overflow-x-auto text-xs font-semibold">
        <button
          onClick={() => setActiveTab('brands')}
          className={`py-3 px-3.5 border-b-2 whitespace-nowrap transition-colors flex items-center gap-2 ${
            activeTab === 'brands' ? 'border-[#065F46] text-[#065F46] font-bold' : 'border-transparent text-slate-500 hover:text-slate-900'
          }`}
        >
          <Building className="w-4 h-4" />
          <span>{isIndonesian ? `Brand & Entitas (${brands.length})` : `Brands & Entities (${brands.length})`}</span>
        </button>

        <button
          onClick={() => setActiveTab('units')}
          className={`py-3 px-3.5 border-b-2 whitespace-nowrap transition-colors flex items-center gap-2 ${
            activeTab === 'units' ? 'border-[#065F46] text-[#065F46] font-bold' : 'border-transparent text-slate-500 hover:text-slate-900'
          }`}
        >
          <FolderTree className="w-4 h-4" />
          <span>{isIndonesian ? `Unit Bisnis (${units.length})` : `Business Units (${units.length})`}</span>
        </button>

        <button
          onClick={() => setActiveTab('regions')}
          className={`py-3 px-3.5 border-b-2 whitespace-nowrap transition-colors flex items-center gap-2 ${
            activeTab === 'regions' ? 'border-[#065F46] text-[#065F46] font-bold' : 'border-transparent text-slate-500 hover:text-slate-900'
          }`}
        >
          <MapPin className="w-4 h-4" />
          <span>{isIndonesian ? `Wilayah (${regions.length})` : `Regions (${regions.length})`}</span>
        </button>

        <button
          onClick={() => setActiveTab('departments')}
          className={`py-3 px-3.5 border-b-2 whitespace-nowrap transition-colors flex items-center gap-2 ${
            activeTab === 'departments' ? 'border-[#065F46] text-[#065F46] font-bold' : 'border-transparent text-slate-500 hover:text-slate-900'
          }`}
        >
          <Building className="w-4 h-4" />
          <span>{isIndonesian ? `Departemen Pemohon (${departments.length})` : `Requester Departments (${departments.length})`}</span>
        </button>

        <button
          onClick={() => setActiveTab('categories')}
          className={`py-3 px-3.5 border-b-2 whitespace-nowrap transition-colors flex items-center gap-2 ${
            activeTab === 'categories' ? 'border-[#065F46] text-[#065F46] font-bold' : 'border-transparent text-slate-500 hover:text-slate-900'
          }`}
        >
          <Tag className="w-4 h-4" />
          <span>{isIndonesian ? `Kategori Tugas (${categories.length})` : `Task Categories (${categories.length})`}</span>
        </button>

        <button
          onClick={() => setActiveTab('teams')}
          className={`py-3 px-3.5 border-b-2 whitespace-nowrap transition-colors flex items-center gap-2 ${
            activeTab === 'teams' ? 'border-[#065F46] text-[#065F46] font-bold' : 'border-transparent text-slate-500 hover:text-slate-900'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>{isIndonesian ? `Tim Eksekusi (${teams.length})` : `Execution Teams (${teams.length})`}</span>
        </button>
      </div>

      {/* Tab Panels */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        {/* Brand Tab */}
        {activeTab === 'brands' && (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold">
                <tr>
                  <th className="py-3 px-4">{isIndonesian ? 'Kode' : 'Code'}</th>
                  <th className="py-3 px-4">{isIndonesian ? 'Nama Brand / Entitas' : 'Brand / Entity Name'}</th>
                  <th className="py-3 px-4">{isIndonesian ? 'Wilayah Operasional' : 'Operational Region'}</th>
                  <th className="py-3 px-4">{isIndonesian ? 'Status Master' : 'Master Status'}</th>
                  <th className="py-3 px-4 text-right">{isIndonesian ? 'Aksi' : 'Action'}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-mono">
                {brands.map((b) => {
                  const reg = regions.find((r) => r.id === b.regionId);
                  return (
                    <tr key={b.id} className="hover:bg-slate-50/70 font-sans">
                      <td className="py-3 px-4 font-mono font-bold text-slate-900">{b.code}</td>
                      <td className="py-3 px-4 font-semibold text-slate-900">{b.name}</td>
                      <td className="py-3 px-4 text-slate-600">{reg?.name || b.regionId}</td>
                      <td className="py-3 px-4">
                        {b.isActive ? (
                          <span className="text-emerald-700 font-medium inline-flex items-center gap-1">
                            <CheckCircle2 className="w-3.5 h-3.5" /> {isIndonesian ? 'Aktif' : 'Active'}
                          </span>
                        ) : (
                          <span className="text-slate-400 font-medium inline-flex items-center gap-1">
                            <XCircle className="w-3.5 h-3.5" /> {isIndonesian ? 'Nonaktif' : 'Inactive'}
                          </span>
                        )}
                      </td>
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <button
                            type="button"
                            disabled={isSaving}
                            onClick={() => void saveMasterData.updateBrand({ ...b, isActive: !b.isActive })}
                            className="text-[11px] font-semibold text-blue-600 hover:text-blue-800 disabled:opacity-50"
                          >
                            {b.isActive ? (isIndonesian ? 'Nonaktifkan' : 'Deactivate') : (isIndonesian ? 'Aktifkan' : 'Activate')}
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDeleteBrand(b.id, b.name)}
                            className="text-[11px] font-semibold text-rose-600 hover:text-rose-800 flex items-center gap-1 p-1 hover:bg-rose-50 rounded cursor-pointer"
                            title={isIndonesian ? 'Hapus Brand' : 'Delete Brand'}
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                            <span className="hidden sm:inline">{isIndonesian ? 'Hapus' : 'Delete'}</span>
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {/* Units Tab */}
        {activeTab === 'units' && (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold">
                <tr>
                  <th className="py-3 px-4">{isIndonesian ? 'Kode' : 'Code'}</th>
                  <th className="py-3 px-4">{isIndonesian ? 'Nama Unit Bisnis' : 'Business Unit Name'}</th>
                  <th className="py-3 px-4">{isIndonesian ? 'Entitas Induk' : 'Parent Entity'}</th>
                  <th className="py-3 px-4">{isIndonesian ? 'Status Master' : 'Master Status'}</th>
                  <th className="py-3 px-4 text-right">{isIndonesian ? 'Aksi' : 'Action'}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {units.map((u) => {
                  const parentBrand = brands.find((b) => b.id === u.brandId);
                  return (
                    <tr key={u.id} className="hover:bg-slate-50/70">
                      <td className="py-3 px-4 font-mono font-bold text-slate-900">{u.code}</td>
                      <td className="py-3 px-4 font-semibold text-slate-900">{u.name}</td>
                      <td className="py-3 px-4 text-slate-600">{parentBrand?.name || u.brandId}</td>
                      <td className="py-3 px-4">
                        {u.isActive ? (
                          <span className="text-emerald-700 font-medium inline-flex items-center gap-1">
                            <CheckCircle2 className="w-3.5 h-3.5" /> {isIndonesian ? 'Aktif' : 'Active'}
                          </span>
                        ) : (
                          <span className="text-slate-400 font-medium inline-flex items-center gap-1">
                            <XCircle className="w-3.5 h-3.5" /> {isIndonesian ? 'Nonaktif' : 'Inactive'}
                          </span>
                        )}
                      </td>
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <button
                            type="button"
                            disabled={isSaving}
                            onClick={() => void saveMasterData.updateUnit({ ...u, isActive: !u.isActive })}
                            className="text-[11px] font-semibold text-blue-600 hover:text-blue-800 disabled:opacity-50"
                          >
                            {u.isActive ? (isIndonesian ? 'Nonaktifkan' : 'Deactivate') : (isIndonesian ? 'Aktifkan' : 'Activate')}
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDeleteUnit(u.id, u.name)}
                            className="text-[11px] font-semibold text-rose-600 hover:text-rose-800 flex items-center gap-1 p-1 hover:bg-rose-50 rounded cursor-pointer"
                            title={isIndonesian ? 'Hapus Unit Bisnis' : 'Delete Business Unit'}
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                            <span className="hidden sm:inline">{isIndonesian ? 'Hapus' : 'Delete'}</span>
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {/* Regions Tab */}
        {activeTab === 'regions' && (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold">
                <tr>
                  <th className="py-3 px-4">{isIndonesian ? 'Kode' : 'Code'}</th>
                  <th className="py-3 px-4">{isIndonesian ? 'Nama Wilayah' : 'Region Name'}</th>
                  <th className="py-3 px-4">{isIndonesian ? 'Brand Terdaftar' : 'Registered Brands'}</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">{isIndonesian ? 'Aksi' : 'Action'}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {regions.map((r) => {
                  const count = brands.filter((b) => b.regionId === r.id).length;
                  return (
                    <tr key={r.id} className="hover:bg-slate-50/70">
                      <td className="py-3 px-4 font-mono font-bold text-slate-900">{r.code}</td>
                      <td className="py-3 px-4 font-semibold text-slate-900">{r.name}</td>
                      <td className="py-3 px-4 text-slate-600 font-mono tabular-nums">{count} {isIndonesian ? 'Brand' : (count === 1 ? 'Brand' : 'Brands')}</td>
                      <td className="py-3 px-4 text-emerald-700 font-medium">{isIndonesian ? 'Aktif' : 'Active'}</td>
                      <td className="py-3 px-4 text-right">
                        <button
                          type="button"
                          onClick={() => handleDeleteRegion(r.id, r.name)}
                          className="text-[11px] font-semibold text-rose-600 hover:text-rose-800 flex items-center gap-1 p-1 hover:bg-rose-50 rounded ml-auto cursor-pointer"
                          title={isIndonesian ? 'Hapus Wilayah' : 'Delete Region'}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>{isIndonesian ? 'Hapus' : 'Delete'}</span>
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {/* Departments Tab */}
        {activeTab === 'departments' && (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold">
                <tr>
                  <th className="py-3 px-4">ID</th>
                  <th className="py-3 px-4">{isIndonesian ? 'Departemen Pemohon Resmi' : 'Official Requester Department'}</th>
                  <th className="py-3 px-4">{isIndonesian ? 'Status Master' : 'Master Status'}</th>
                  <th className="py-3 px-4 text-right">{isIndonesian ? 'Aksi' : 'Action'}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {departments.map((d) => (
                  <tr key={d.id} className="hover:bg-slate-50/70">
                    <td className="py-3 px-4 font-mono text-slate-500">{d.id}</td>
                    <td className="py-3 px-4 font-semibold text-slate-900">{d.name}</td>
                    <td className="py-3 px-4">
                      {d.isActive ? (
                        <span className="text-emerald-700 font-medium inline-flex items-center gap-1">
                          <CheckCircle2 className="w-3.5 h-3.5" /> {isIndonesian ? 'Aktif' : 'Active'}
                        </span>
                      ) : (
                        <span className="text-slate-400 font-medium inline-flex items-center gap-1">
                          <XCircle className="w-3.5 h-3.5" /> {isIndonesian ? 'Nonaktif' : 'Inactive'}
                        </span>
                      )}
                    </td>
                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <button
                          type="button"
                          disabled={isSaving}
                          onClick={() => void saveMasterData.updateDepartment({ ...d, isActive: !d.isActive })}
                          className="text-[11px] font-semibold text-blue-600 hover:text-blue-800 disabled:opacity-50"
                        >
                          {d.isActive ? (isIndonesian ? 'Nonaktifkan' : 'Deactivate') : (isIndonesian ? 'Aktifkan' : 'Activate')}
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDeleteDept(d.id, d.name)}
                          className="text-[11px] font-semibold text-rose-600 hover:text-rose-800 flex items-center gap-1 p-1 hover:bg-rose-50 rounded cursor-pointer"
                          title={isIndonesian ? 'Hapus Departemen' : 'Delete Department'}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span className="hidden sm:inline">{isIndonesian ? 'Hapus' : 'Delete'}</span>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Categories Tab */}
        {activeTab === 'categories' && (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold">
                <tr>
                  <th className="py-3 px-4">ID</th>
                  <th className="py-3 px-4">{isIndonesian ? 'Kategori Tugas' : 'Task Category'}</th>
                  <th className="py-3 px-4">{isIndonesian ? 'SLA Penyelesaian Standar' : 'Default Turnaround SLA'}</th>
                  <th className="py-3 px-4">{isIndonesian ? 'Status Master' : 'Master Status'}</th>
                  <th className="py-3 px-4 text-right">{isIndonesian ? 'Aksi' : 'Action'}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {categories.map((c) => (
                  <tr key={c.id} className="hover:bg-slate-50/70">
                    <td className="py-3 px-4 font-mono text-slate-500">{c.id}</td>
                    <td className="py-3 px-4 font-semibold text-slate-900">{c.name}</td>
                    <td className="py-3 px-4 font-mono text-slate-700">
                      {c.slaDaysDefault} {isIndonesian ? 'Hari Kerja' : 'Working Days'}
                    </td>
                    <td className="py-3 px-4">
                      {c.isActive ? (
                        <span className="text-emerald-700 font-medium inline-flex items-center gap-1">
                          <CheckCircle2 className="w-3.5 h-3.5" /> {isIndonesian ? 'Aktif' : 'Active'}
                        </span>
                      ) : (
                        <span className="text-slate-400 font-medium inline-flex items-center gap-1">
                          <XCircle className="w-3.5 h-3.5" /> {isIndonesian ? 'Nonaktif' : 'Inactive'}
                        </span>
                      )}
                    </td>
                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <button
                          type="button"
                          disabled={isSaving}
                          onClick={() => void saveMasterData.updateCategory({ ...c, isActive: !c.isActive })}
                          className="text-[11px] font-semibold text-blue-600 hover:text-blue-800 disabled:opacity-50"
                        >
                          {c.isActive ? (isIndonesian ? 'Nonaktifkan' : 'Deactivate') : (isIndonesian ? 'Aktifkan' : 'Activate')}
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDeleteCategory(c.id, c.name)}
                          className="text-[11px] font-semibold text-rose-600 hover:text-rose-800 flex items-center gap-1 p-1 hover:bg-rose-50 rounded cursor-pointer"
                          title={isIndonesian ? 'Hapus Kategori' : 'Delete Category'}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span className="hidden sm:inline">{isIndonesian ? 'Hapus' : 'Delete'}</span>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Teams Tab */}
        {activeTab === 'teams' && (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold">
                <tr>
                  <th className="py-3 px-4">{isIndonesian ? 'Tim Eksekusi' : 'Execution Team'}</th>
                  <th className="py-3 px-4">{isIndonesian ? 'Fokus Lingkup & Tanggung Jawab' : 'Scope Focus & Responsibilities'}</th>
                  <th className="py-3 px-4">{isIndonesian ? 'Anggota Tim Ditugaskan' : 'Assigned Team Members'}</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">{isIndonesian ? 'Aksi' : 'Actions'}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {teams.map((t) => {
                  const assignedMembers = allUsers.filter(
                    (u) => u.teams && u.teams.includes(t.id)
                  );

                  return (
                    <tr key={t.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="py-3.5 px-4 align-top">
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <span
                              className="w-3 h-3 rounded-full shrink-0 shadow-2xs ring-2 ring-white"
                              style={{ backgroundColor: t.color || '#065F46' }}
                            />
                            <strong className="font-bold text-slate-900 text-xs">{t.name}</strong>
                          </div>
                          <span className="text-[10px] font-mono text-slate-400 block pl-5">
                            {t.id}
                          </span>
                        </div>
                      </td>
                      <td className="py-3.5 px-4 align-top text-slate-600 max-w-md leading-relaxed text-xs">
                        {t.description}
                      </td>
                      <td className="py-3.5 px-4 align-top">
                        <div className="flex flex-wrap gap-1.5 max-w-xs">
                          {assignedMembers.length > 0 ? (
                            assignedMembers.map((m) => (
                              <span
                                key={m.id}
                                className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-slate-100 border border-slate-200 text-slate-700 text-[11px] font-medium"
                              >
                                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                                <span className="truncate max-w-[120px]">{m.fullName}</span>
                              </span>
                            ))
                          ) : (
                            <span className="text-[11px] text-slate-400 italic">
                              {isIndonesian ? 'Belum ada anggota tim' : 'No assigned members yet'}
                            </span>
                          )}
                        </div>
                      </td>
                      <td className="py-3.5 px-4 align-top whitespace-nowrap">
                        <span className="inline-flex items-center gap-1.5 text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-md border border-emerald-200/80">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                          <span>{isIndonesian ? 'Aktif' : 'Active'}</span>
                        </span>
                      </td>
                      <td className="py-3.5 px-4 align-top text-right whitespace-nowrap">
                        <div className="flex items-center justify-end gap-2">
                          <button
                            type="button"
                            onClick={() => handleOpenEditTeam(t)}
                            className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-semibold text-slate-700 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 border border-slate-200 rounded-lg transition-colors cursor-pointer"
                          >
                            <Edit2 className="w-3 h-3 text-slate-500" />
                            <span>{isIndonesian ? 'Ubah Tim' : 'Edit Team'}</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDeleteTeam(t.id, t.name)}
                            className="inline-flex items-center gap-1 px-2 py-1 text-xs font-semibold text-rose-600 hover:text-rose-800 bg-rose-50 hover:bg-rose-100 border border-rose-200 rounded-lg transition-colors cursor-pointer"
                            title={isIndonesian ? 'Hapus Tim Eksekusi' : 'Delete Execution Team'}
                          >
                            <Trash2 className="w-3.5 h-3.5 text-rose-500" />
                            <span>{isIndonesian ? 'Hapus' : 'Delete'}</span>
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Add Region Modal */}
      {isAddRegionOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl p-6 max-w-md w-full border border-slate-200 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <MapPin className="w-4 h-4 text-[#065F46]" />
                <span>{isIndonesian ? 'Tambah Wilayah Operasional' : 'Add Operational Region'}</span>
              </h3>
              <button onClick={() => setIsAddRegionOpen(false)} className="text-slate-400 hover:text-slate-600">
                <XCircle className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleCreateRegion} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-bold text-slate-800 mb-1">
                  {isIndonesian ? 'Nama Wilayah *' : 'Region Name *'}
                </label>
                <input
                  type="text"
                  required
                  value={newRegionName}
                  onChange={(e) => setNewRegionName(e.target.value)}
                  placeholder={isIndonesian ? 'Contoh: Surabaya, Bali' : 'e.g. Surabaya, Bali'}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#065F46]"
                />
              </div>
              <div>
                <label className="block font-bold text-slate-800 mb-1">
                  {isIndonesian ? 'Kode Wilayah (Awalan)' : 'Region Code (Prefix)'}
                </label>
                <input
                  type="text"
                  value={newRegionCode}
                  onChange={(e) => setNewRegionCode(e.target.value)}
                  placeholder={isIndonesian ? 'Contoh: REG-SBY, SBY' : 'e.g. REG-SBY, SBY'}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg font-mono uppercase focus:outline-none focus:ring-2 focus:ring-[#065F46]"
                />
              </div>
              <div className="flex justify-end gap-2 pt-2 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsAddRegionOpen(false)}
                  className="px-3.5 py-2 font-semibold text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
                >
                  {isIndonesian ? 'Batal' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  disabled={isSaving}
                  className="px-4 py-2 font-bold text-white bg-[#065F46] hover:bg-[#044e39] disabled:opacity-60 rounded-lg transition-colors shadow-xs"
                >
                  {isSaving
                    ? isIndonesian ? 'Menyimpan...' : 'Saving...'
                    : isIndonesian ? 'Buat Wilayah' : 'Create Region'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add Brand Modal */}
      {isAddBrandOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl p-6 max-w-md w-full border border-slate-200 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <h3 className="text-sm font-bold text-slate-900">
                {isIndonesian ? 'Tambah Brand / Entitas Baru' : 'Add New Brand / Entity'}
              </h3>
              <button onClick={() => setIsAddBrandOpen(false)} className="text-slate-400 hover:text-slate-600">
                <XCircle className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleCreateBrand} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-bold text-slate-800 mb-1">
                  {isIndonesian ? 'Nama Brand *' : 'Brand Name *'}
                </label>
                <input
                  type="text"
                  required
                  value={newBrandName}
                  onChange={(e) => setNewBrandName(e.target.value)}
                  placeholder={isIndonesian ? 'Contoh: Parahyangan Golf' : 'e.g. Parahyangan Golf'}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg"
                />
              </div>
              <div>
                <label className="block font-bold text-slate-800 mb-1">
                  {isIndonesian ? 'Kode Singkat' : 'Short Code'}
                </label>
                <input
                  type="text"
                  value={newBrandCode}
                  onChange={(e) => setNewBrandCode(e.target.value)}
                  placeholder="PG"
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg font-mono uppercase"
                />
              </div>
              <div>
                <label className="block font-bold text-slate-800 mb-1">
                  {isIndonesian ? 'Wilayah' : 'Region'}
                </label>
                <select
                  value={newBrandRegionId}
                  onChange={(e) => setNewBrandRegionId(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg"
                >
                  {regions.map((r) => (
                    <option key={r.id} value={r.id}>
                      {r.name}
                    </option>
                  ))}
                </select>
              </div>
              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsAddBrandOpen(false)}
                  className="px-4 py-2 font-semibold text-slate-700 bg-white border border-slate-300 rounded-xl hover:bg-slate-50"
                >
                  {isIndonesian ? 'Batal' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  disabled={isSaving}
                  className="px-4 py-2 font-bold text-white bg-[#065F46] hover:bg-[#044e39] disabled:opacity-60 rounded-xl shadow-xs"
                >
                  {isSaving
                    ? isIndonesian ? 'Menyimpan...' : 'Saving...'
                    : isIndonesian ? 'Simpan Brand' : 'Save Brand'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add Unit Modal */}
      {isAddUnitOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl p-6 max-w-md w-full border border-slate-200 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <h3 className="text-sm font-bold text-slate-900">
                {isIndonesian ? 'Tambah Unit Bisnis Baru' : 'Add New Business Unit'}
              </h3>
              <button onClick={() => setIsAddUnitOpen(false)} className="text-slate-400 hover:text-slate-600">
                <XCircle className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleCreateUnit} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-bold text-slate-800 mb-1">
                  {isIndonesian ? 'Nama Unit Bisnis *' : 'Business Unit Name *'}
                </label>
                <input
                  type="text"
                  required
                  value={newUnitName}
                  onChange={(e) => setNewUnitName(e.target.value)}
                  placeholder={isIndonesian ? 'Contoh: HRD — Human Resources Development' : 'e.g. HRD — Human Resources Development'}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg"
                />
              </div>
              <div>
                <label className="block font-bold text-slate-800 mb-1">
                  {isIndonesian ? 'Kode Unit' : 'Unit Code'}
                </label>
                <input
                  type="text"
                  value={newUnitCode}
                  onChange={(e) => setNewUnitCode(e.target.value)}
                  placeholder="HRD"
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg font-mono uppercase"
                />
              </div>
              <div>
                <label className="block font-bold text-slate-800 mb-1">
                  {isIndonesian ? 'Entitas Induk' : 'Parent Entity'}
                </label>
                <select
                  value={newUnitBrandId}
                  onChange={(e) => setNewUnitBrandId(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg"
                >
                  {brands.map((b) => (
                    <option key={b.id} value={b.id}>
                      {b.name}
                    </option>
                  ))}
                </select>
              </div>
              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsAddUnitOpen(false)}
                  className="px-4 py-2 font-semibold text-slate-700 bg-white border border-slate-300 rounded-xl hover:bg-slate-50"
                >
                  {isIndonesian ? 'Batal' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  disabled={isSaving}
                  className="px-4 py-2 font-bold text-white bg-[#065F46] hover:bg-[#044e39] disabled:opacity-60 rounded-xl shadow-xs"
                >
                  {isSaving
                    ? isIndonesian ? 'Menyimpan...' : 'Saving...'
                    : isIndonesian ? 'Simpan Unit' : 'Save Unit'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add Department Modal */}
      {isAddDeptOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl p-6 max-w-md w-full border border-slate-200 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <h3 className="text-sm font-bold text-slate-900">
                {isIndonesian ? 'Tambah Departemen Pemohon' : 'Add Requester Department'}
              </h3>
              <button onClick={() => setIsAddDeptOpen(false)} className="text-slate-400 hover:text-slate-600">
                <XCircle className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleCreateDept} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-bold text-slate-800 mb-1">
                  {isIndonesian ? 'Nama Departemen Resmi *' : 'Official Department Name *'}
                </label>
                <input
                  type="text"
                  required
                  value={newDeptName}
                  onChange={(e) => setNewDeptName(e.target.value)}
                  placeholder={isIndonesian ? 'Contoh: Tenant Relations & Property Management' : 'e.g. Tenant Relations & Property Management'}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg"
                />
              </div>
              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsAddDeptOpen(false)}
                  className="px-4 py-2 font-semibold text-slate-700 bg-white border border-slate-300 rounded-xl hover:bg-slate-50"
                >
                  {isIndonesian ? 'Batal' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  disabled={isSaving}
                  className="px-4 py-2 font-bold text-white bg-[#065F46] hover:bg-[#044e39] disabled:opacity-60 rounded-xl shadow-xs"
                >
                  {isSaving
                    ? isIndonesian ? 'Menyimpan...' : 'Saving...'
                    : isIndonesian ? 'Simpan Departemen' : 'Save Department'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add Category Modal */}
      {isAddCatOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl p-6 max-w-md w-full border border-slate-200 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <h3 className="text-sm font-bold text-slate-900">
                {isIndonesian ? 'Tambah Kategori Tugas' : 'Add Task Category'}
              </h3>
              <button onClick={() => setIsAddCatOpen(false)} className="text-slate-400 hover:text-slate-600">
                <XCircle className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleCreateCategory} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-bold text-slate-800 mb-1">
                  {isIndonesian ? 'Nama Kategori *' : 'Category Name *'}
                </label>
                <input
                  type="text"
                  required
                  value={newCatName}
                  onChange={(e) => setNewCatName(e.target.value)}
                  placeholder={isIndonesian ? 'Contoh: 3D Architectural Rendering' : 'e.g. 3D Architectural Rendering'}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg"
                />
              </div>
              <div>
                <label className="block font-bold text-slate-800 mb-1">
                  {isIndonesian ? 'SLA Penyelesaian Standar (Hari Kerja)' : 'Standard Turnaround SLA (Working Days)'}
                </label>
                <input
                  type="number"
                  min="1"
                  max="30"
                  value={newCatSla}
                  onChange={(e) => setNewCatSla(Number(e.target.value))}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg font-mono"
                />
              </div>
              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsAddCatOpen(false)}
                  className="px-4 py-2 font-semibold text-slate-700 bg-white border border-slate-300 rounded-xl hover:bg-slate-50"
                >
                  {isIndonesian ? 'Batal' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  disabled={isSaving}
                  className="px-4 py-2 font-bold text-white bg-[#065F46] hover:bg-[#044e39] disabled:opacity-60 rounded-xl shadow-xs"
                >
                  {isSaving
                    ? isIndonesian ? 'Menyimpan...' : 'Saving...'
                    : isIndonesian ? 'Simpan Kategori' : 'Save Category'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add Execution Team Modal */}
      {isAddTeamOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl p-6 max-w-md w-full border border-slate-200 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <h3 className="text-sm font-bold text-slate-900">
                {isIndonesian ? 'Tambah Tim Eksekusi' : 'Add Execution Team'}
              </h3>
              <button
                type="button"
                onClick={() => setIsAddTeamOpen(false)}
                className="text-slate-400 hover:text-slate-600"
              >
                <XCircle className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleCreateTeam} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-bold text-slate-800 mb-1">
                  {isIndonesian ? 'Nama Tim *' : 'Team Name *'}
                </label>
                <input
                  type="text"
                  required
                  value={newTeamName}
                  onChange={(e) => setNewTeamName(e.target.value)}
                  placeholder={isIndonesian ? 'Contoh: Motion Graphics & 3D Animation' : 'e.g. Motion Graphics & 3D Animation'}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded-xl focus:ring-2 focus:ring-[#065F46]/20 focus:border-[#065F46]"
                />
              </div>
              <div>
                <label className="block font-bold text-slate-800 mb-1">
                  {isIndonesian ? 'Fokus Lingkup & Tanggung Jawab *' : 'Scope Focus & Responsibilities *'}
                </label>
                <textarea
                  rows={3}
                  required
                  value={newTeamDesc}
                  onChange={(e) => setNewTeamDesc(e.target.value)}
                  placeholder={isIndonesian ? 'Jelaskan tanggung jawab operasional, deliverable, dan cakupan layanan...' : 'Describe operational responsibilities, deliverables, and service scope...'}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded-xl focus:ring-2 focus:ring-[#065F46]/20 focus:border-[#065F46]"
                />
              </div>
              <div>
                <label className="block font-bold text-slate-800 mb-1">
                  {isIndonesian ? 'Warna Aksen Brand' : 'Brand Accent Color'}
                </label>
                <div className="flex items-center gap-3">
                  <input
                    type="color"
                    value={newTeamColor}
                    onChange={(e) => setNewTeamColor(e.target.value)}
                    className="w-9 h-9 p-0.5 rounded-lg border border-slate-300 cursor-pointer"
                  />
                  <input
                    type="text"
                    value={newTeamColor}
                    onChange={(e) => setNewTeamColor(e.target.value)}
                    className="w-28 p-2 bg-slate-50 border border-slate-300 rounded-xl font-mono uppercase text-xs"
                  />
                </div>
              </div>
              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsAddTeamOpen(false)}
                  className="px-4 py-2 font-semibold text-slate-700 bg-white border border-slate-300 rounded-xl hover:bg-slate-50"
                >
                  {isIndonesian ? 'Batal' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  disabled={isSaving}
                  className="px-4 py-2 font-bold text-white bg-[#065F46] hover:bg-[#044e39] disabled:opacity-60 rounded-xl shadow-xs"
                >
                  {isSaving
                    ? isIndonesian ? 'Menyimpan...' : 'Saving...'
                    : isIndonesian ? 'Daftarkan Tim Eksekusi' : 'Register Execution Team'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit Execution Team Modal */}
      {editingTeam && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl p-6 max-w-md w-full border border-slate-200 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <h3 className="text-sm font-bold text-slate-900">
                {isIndonesian ? 'Ubah Tim Eksekusi' : 'Edit Execution Team'}
              </h3>
              <button
                type="button"
                onClick={() => setEditingTeam(null)}
                className="text-slate-400 hover:text-slate-600"
              >
                <XCircle className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleUpdateTeam} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-bold text-slate-800 mb-1">
                  {isIndonesian ? 'Nama Tim *' : 'Team Name *'}
                </label>
                <input
                  type="text"
                  required
                  value={editTeamName}
                  onChange={(e) => setEditTeamName(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded-xl focus:ring-2 focus:ring-[#065F46]/20 focus:border-[#065F46]"
                />
              </div>
              <div>
                <label className="block font-bold text-slate-800 mb-1">
                  {isIndonesian ? 'Fokus Lingkup & Tanggung Jawab *' : 'Scope Focus & Responsibilities *'}
                </label>
                <textarea
                  rows={3}
                  required
                  value={editTeamDesc}
                  onChange={(e) => setEditTeamDesc(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded-xl focus:ring-2 focus:ring-[#065F46]/20 focus:border-[#065F46]"
                />
              </div>
              <div>
                <label className="block font-bold text-slate-800 mb-1">
                  {isIndonesian ? 'Warna Aksen Brand' : 'Brand Accent Color'}
                </label>
                <div className="flex items-center gap-3">
                  <input
                    type="color"
                    value={editTeamColor}
                    onChange={(e) => setEditTeamColor(e.target.value)}
                    className="w-9 h-9 p-0.5 rounded-lg border border-slate-300 cursor-pointer"
                  />
                  <input
                    type="text"
                    value={editTeamColor}
                    onChange={(e) => setEditTeamColor(e.target.value)}
                    className="w-28 p-2 bg-slate-50 border border-slate-300 rounded-xl font-mono uppercase text-xs"
                  />
                </div>
              </div>
              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setEditingTeam(null)}
                  className="px-4 py-2 font-semibold text-slate-700 bg-white border border-slate-300 rounded-xl hover:bg-slate-50"
                >
                  {isIndonesian ? 'Batal' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  disabled={isSaving}
                  className="px-4 py-2 font-bold text-white bg-[#065F46] hover:bg-[#044e39] disabled:opacity-60 rounded-xl shadow-xs"
                >
                  {isSaving
                    ? isIndonesian ? 'Menyimpan...' : 'Saving...'
                    : isIndonesian ? 'Simpan Perubahan' : 'Save Changes'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal (Replaces native window.confirm blocked in iframe) */}
      {deleteTarget && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs"
          role="dialog"
          aria-modal="true"
          aria-labelledby="delete-master-data-title"
        >
          <div className="bg-white rounded-2xl p-6 max-w-md w-full border border-slate-200 shadow-2xl space-y-4">
            <div className="flex items-start justify-between gap-3 pb-3 border-b border-slate-200">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-rose-50 border border-rose-200 flex items-center justify-center shrink-0">
                  <Trash2 className="w-4 h-4 text-rose-600" />
                </div>
                <div>
                  <h3 id="delete-master-data-title" className="text-sm font-bold text-slate-900">
                    {isIndonesian ? `Hapus ${deleteTarget.label}` : `Delete ${deleteTarget.label}`}
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    {isIndonesian ? 'Penghapusan Data Induk Permanen' : 'Permanent Master Data Removal'}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setDeleteTarget(null)}
                className="text-slate-400 hover:text-slate-600 p-1"
                aria-label={isIndonesian ? 'Tutup dialog konfirmasi' : 'Close confirmation dialog'}
              >
                <XCircle className="w-5 h-5" />
              </button>
            </div>

            <div className="text-xs text-slate-600 leading-relaxed space-y-2">
              <p>
                {isIndonesian ? (
                  <>
                    Apakah Anda yakin ingin menghapus <strong className="text-slate-900">"{deleteTarget.name}"</strong>?
                  </>
                ) : (
                  <>
                    Are you sure you want to delete <strong className="text-slate-900">"{deleteTarget.name}"</strong>?
                  </>
                )}
              </p>
              <p className="text-[11px] text-slate-500">
                {isIndonesian
                  ? 'Tindakan ini tidak dapat dibatalkan. Permintaan historis yang merujuk pada data ini tetap menyimpan salinannya, sedangkan entitas ini tidak lagi muncul di pilihan dropdown aktif.'
                  : 'This action cannot be undone. Existing historical requests referencing this record will keep their snapshots, while this entity will no longer appear in active dropdowns.'}
              </p>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200">
              <button
                type="button"
                onClick={() => setDeleteTarget(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-xl hover:bg-slate-50 cursor-pointer"
              >
                {isIndonesian ? 'Batal' : 'Cancel'}
              </button>
              <button
                type="button"
                disabled={isSaving}
                onClick={handleConfirmDelete}
                className="px-4 py-2 text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 disabled:opacity-60 rounded-xl shadow-xs cursor-pointer"
              >
                {isSaving
                  ? isIndonesian ? 'Menghapus...' : 'Deleting...'
                  : isIndonesian ? 'Konfirmasi Hapus' : 'Confirm Delete'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
