import React, { useState, useEffect, useCallback } from 'react';
import {
  ShieldCheck,
  Database,
  CheckCircle2,
  AlertTriangle,
  Server,
  Clock,
  Download,
  RefreshCw,
  FileCheck,
  Layers,
  UploadCloud,
  GitMerge,
  HardDriveDownload,
  Link2,
  Copy,
  KeyRound,
  ExternalLink,
  Check,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useRequests } from '../../context/RequestContext';
import { useLanguage } from '../../context/LanguageContext';
import { StorageService } from '../../services/storageService';
import { PRIORITY_SLA_DAYS } from '../../types';
import { PriorityQuotaManagementView } from './PriorityQuotaManagementView';

interface ServiceStatus {
  service: string;
  name: string;
  configured: boolean;
  status: 'connected' | 'blocked' | 'error' | 'not_configured';
  message: string;
  tlsEnforced: boolean;
  missingEnvVars: string[];
  lastChecked: string;
}

interface BackupMeta {
  id: string;
  createdAt: string;
  filename: string;
  r2Key?: string;
  checksumSha256: string;
  recordCounts: {
    users?: number;
    requests?: number;
    subItems?: number;
    quotaLedger?: number;
    attachments?: number;
    activityLogs?: number;
  };
  integrityStatus: 'valid' | 'corrupted';
}

interface MigrationRunSummary {
  id: string;
  environment: string;
  deviceLabel: string;
  status: string;
  sourceChecksum?: string;
  summary: {
    inserted?: number;
    skippedIdentical?: number;
    conflictsLogged?: number;
    attachmentsUploadedToR2?: number;
    errors?: string[];
  };
  startedBy: string;
  startedAt: string;
  completedAt?: string;
}

interface MigrationConflictItem {
  id: string;
  runId: string;
  tableName: string;
  recordId: string;
  conflictType: string;
  deviceLabel: string;
  resolutionStatus: string;
  resolvedBy?: string;
  resolvedAt?: string;
  createdAt: string;
  sourcePayload: Record<string, unknown>;
  existingPayload: Record<string, unknown>;
}

interface ReconciliationReport {
  tableCounts: {
    users: number;
    requests: number;
    subItems: number;
    quotaLedger: number;
    attachments: number;
  };
  runs: MigrationRunSummary[];
  conflicts: MigrationConflictItem[];
}

export const SettingsView: React.FC = () => {
  const { isSuperAdmin, isAdmin, csrfToken } = useAuth();
  const { showToast, syncNow } = useRequests();
  const { isIndonesian } = useLanguage();

  const [services, setServices] = useState<ServiceStatus[]>([]);
  const [backups, setBackups] = useState<BackupMeta[]>([]);
  const [reconciliation, setReconciliation] = useState<ReconciliationReport | null>(null);
  const [isLoadingServices, setIsLoadingServices] = useState(false);
  const [isCreatingBackup, setIsCreatingBackup] = useState(false);
  const [isImportingMigration, setIsImportingMigration] = useState(false);
  const [migrationDeviceLabel, setMigrationDeviceLabel] = useState('browser-workstation');
  const [purgeConfirmInput, setPurgeConfirmInput] = useState('');
  const [isPurging, setIsPurging] = useState(false);
  const [activeTab, setActiveTab] = useState<'quota' | 'sla' | 'public_link' | 'system'>('quota');

  // Public Request Form Link Config State
  const [publicConfig, setPublicConfig] = useState<{
    enabled: boolean;
    requireToken: boolean;
    allowAttachments: boolean;
    accessToken: string;
    allowedEmailDomains: string[];
    updatedBy?: string | null;
    updatedAt?: string;
  } | null>(null);
  const [domainsInput, setDomainsInput] = useState('');
  const [isLoadingPublicConfig, setIsLoadingPublicConfig] = useState(false);
  const [isSavingPublicConfig, setIsSavingPublicConfig] = useState(false);
  const [isRotatingToken, setIsRotatingToken] = useState(false);
  const [confirmRotateToken, setConfirmRotateToken] = useState(false);
  const [copiedPublicLink, setCopiedPublicLink] = useState(false);

  const fetchServiceStatus = useCallback(async () => {
    if (!isSuperAdmin && !isAdmin) return;
    setIsLoadingServices(true);
    try {
      const res = await fetch('/api/system/services-status', { credentials: 'include', cache: 'no-store' });
      const data = await res.json().catch(() => ({}));
      if (!res.ok || !data.success || !data.services) return;

      const s = data.services as Record<string, any>;
      const checkedAt = data.checkedAt || new Date().toISOString();
      const secretsObj = s.secrets || {};
      const missingSecrets: string[] = [];
      if (!secretsObj.session_secret) missingSecrets.push('SESSION_SECRET');
      if (!secretsObj.password_pepper) missingSecrets.push('PASSWORD_PEPPER');
      if (!secretsObj.bootstrap_admin_token) missingSecrets.push('BOOTSTRAP_ADMIN_TOKEN');

      const mapped: ServiceStatus[] = [
        {
          service: 'workers_api',
          name: 'Cloudflare Workers + Hono API',
          configured: true,
          status: s.workers_api?.status === 'CONNECTED' ? 'connected' : 'error',
          message: s.workers_api?.runtime || 'Cloudflare Workers API runtime active',
          tlsEnforced: true,
          missingEnvVars: [],
          lastChecked: checkedAt,
        },
        {
          service: 'cloudflare_d1',
          name: 'Cloudflare D1 (Authoritative SQLite)',
          configured: s.cloudflare_d1?.status === 'CONNECTED',
          status: s.cloudflare_d1?.status === 'CONNECTED' ? 'connected' : 'error',
          message: `${s.cloudflare_d1?.detail || 'D1 SQLite'} (${s.cloudflare_d1?.latencyMs ?? 0}ms)`,
          tlsEnforced: true,
          missingEnvVars: [],
          lastChecked: checkedAt,
        },
        {
          service: 'cloudflare_r2',
          name: 'Cloudflare R2 (Private Object Storage)',
          configured: s.cloudflare_r2?.status === 'CONNECTED',
          status: s.cloudflare_r2?.status === 'CONNECTED' ? 'connected' : 'error',
          message: `${s.cloudflare_r2?.detail || 'FILES_BUCKET'} (${s.cloudflare_r2?.latencyMs ?? 0}ms)`,
          tlsEnforced: true,
          missingEnvVars: [],
          lastChecked: checkedAt,
        },
        {
          service: 'gemini_ai',
          name: 'Gemini AI (Server-Side Proxy)',
          configured: s.gemini_ai?.status === 'CONFIGURED',
          status: s.gemini_ai?.status === 'CONFIGURED' ? 'connected' : 'not_configured',
          message: s.gemini_ai?.detail || 'Server-side AI service',
          tlsEnforced: true,
          missingEnvVars: s.gemini_ai?.status === 'CONFIGURED' ? [] : ['GEMINI_API_KEY'],
          lastChecked: checkedAt,
        },
        {
          service: 'secrets',
          name: 'Workers Auth Secrets',
          configured: missingSecrets.length === 0,
          status: missingSecrets.length === 0 ? 'connected' : 'blocked',
          message:
            missingSecrets.length === 0
              ? isIndonesian
                ? 'Semua Worker Secrets keamanan aktif.'
                : 'All security Worker Secrets active.'
              : isIndonesian
              ? 'Sebagian Worker Secrets menggunakan fallback dev.'
              : 'Some Worker Secrets require production provisioning.',
          tlsEnforced: true,
          missingEnvVars: missingSecrets,
          lastChecked: checkedAt,
        },
        {
          service: 'custom_domain',
          name: 'Custom Domain / APP_ORIGIN',
          configured: true,
          status:
            String(s.custom_domain?.status || '').includes('active') ? 'connected' : 'not_configured',
          message: `${s.custom_domain?.origin || 'Placeholder'} (${s.custom_domain?.status || 'placeholder'})`,
          tlsEnforced: true,
          missingEnvVars: [],
          lastChecked: checkedAt,
        },
        {
          service: 'smtp_email',
          name: 'Outbound Email (SMTP Relay)',
          configured: s.smtp_email?.status === 'CONFIGURED',
          status: s.smtp_email?.status === 'CONFIGURED' ? 'connected' : 'blocked',
          message: s.smtp_email?.detail || 'No SMTP relay credentials configured.',
          tlsEnforced: true,
          missingEnvVars:
            s.smtp_email?.status === 'CONFIGURED' ? [] : ['SMTP_HOST', 'SMTP_USER', 'SMTP_PASS'],
          lastChecked: checkedAt,
        },
      ];
      setServices(mapped);
    } catch (e) {
      console.error('Failed to fetch service status:', e);
    } finally {
      setIsLoadingServices(false);
    }
  }, [isSuperAdmin, isAdmin, isIndonesian]);

  const fetchBackups = useCallback(async () => {
    if (!isSuperAdmin && !isAdmin) return;
    try {
      const res = await fetch('/api/system/backups', { credentials: 'include', cache: 'no-store' });
      const data = await res.json().catch(() => ({}));
      if (res.ok && data.success && Array.isArray(data.backups)) {
        setBackups(data.backups);
      }
    } catch (e) {
      console.error('Failed to fetch backups:', e);
    }
  }, [isSuperAdmin, isAdmin]);

  const fetchReconciliationReport = useCallback(async () => {
    if (!isSuperAdmin) return;
    try {
      const res = await fetch('/api/migration/reconciliation-report', { credentials: 'include', cache: 'no-store' });
      const data = await res.json().catch(() => ({}));
      if (res.ok && data.success) {
        setReconciliation({
          tableCounts: data.tableCounts,
          runs: data.runs || [],
          conflicts: data.conflicts || [],
        });
      }
    } catch (e) {
      console.error('Failed to fetch reconciliation report:', e);
    }
  }, [isSuperAdmin]);

  const fetchPublicFormConfig = useCallback(async () => {
    if (!isSuperAdmin && !isAdmin) return;
    setIsLoadingPublicConfig(true);
    try {
      const res = await fetch('/api/system/public-form-config', {
        credentials: 'include',
        cache: 'no-store',
      });
      const data = await res.json().catch(() => ({}));
      if (res.ok && data.success && data.config) {
        setPublicConfig(data.config);
        setDomainsInput(
          Array.isArray(data.config.allowedEmailDomains)
            ? data.config.allowedEmailDomains.join(', ')
            : ''
        );
      }
    } catch (e) {
      console.error('Failed to fetch public form config:', e);
    } finally {
      setIsLoadingPublicConfig(false);
    }
  }, [isSuperAdmin, isAdmin]);

  useEffect(() => {
    fetchServiceStatus();
    fetchBackups();
    fetchPublicFormConfig();
    if (isSuperAdmin) {
      fetchReconciliationReport();
    }
  }, [fetchServiceStatus, fetchBackups, fetchPublicFormConfig, fetchReconciliationReport, isSuperAdmin]);

  const handleCreateBackup = async () => {
    setIsCreatingBackup(true);
    try {
      const res = await fetch('/api/system/backup', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRF-Token': csrfToken || '',
        },
        credentials: 'include',
        cache: 'no-store',
      });
      const data = await res.json().catch(() => ({}));
      if (res.ok && data.success && data.backup) {
        showToast(
          isIndonesian
            ? `Cadangan D1 terverifikasi berhasil disimpan ke R2: ${data.backup.filename}`
            : `Verified D1 backup saved to R2: ${data.backup.filename}`,
          'success'
        );
        await fetchBackups();
      } else {
        showToast(
          data.error || (isIndonesian ? 'Gagal membuat cadangan.' : 'Failed to create backup.'),
          'error'
        );
      }
    } catch (err: any) {
      showToast(
        err.message || (isIndonesian ? 'Terjadi kesalahan saat membuat cadangan.' : 'Error creating backup.'),
        'error'
      );
    } finally {
      setIsCreatingBackup(false);
    }
  };

  const handleDownloadBackup = async (backup: BackupMeta) => {
    try {
      const res = await fetch(`/api/system/backups/${encodeURIComponent(backup.id)}/download`, {
        credentials: 'include',
        cache: 'no-store',
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        showToast(
          err.error || (isIndonesian ? 'Gagal mengunduh cadangan terverifikasi.' : 'Failed to download verified backup.'),
          'error'
        );
        return;
      }
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = backup.filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setTimeout(() => URL.revokeObjectURL(url), 1000);
    } catch {
      showToast(
        isIndonesian ? 'Gagal mengunduh file cadangan.' : 'Failed to download backup file.',
        'error'
      );
    }
  };

  const handleExportBrowserSnapshot = () => {
    const snapshot = StorageService.exportLocalStorageSnapshot(migrationDeviceLabel || 'browser-snapshot');
    const json = JSON.stringify(snapshot, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `marcomm_browser_snapshot_${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 1000);

    showToast(
      isIndonesian
        ? `Snapshot browser berhasil diekspor (${snapshot.recordCounts.requests} permintaan, ${snapshot.recordCounts.users} pengguna).`
        : `Browser snapshot exported (${snapshot.recordCounts.requests} requests, ${snapshot.recordCounts.users} users).`,
      'success'
    );
  };

  const handleImportSnapshotFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;

    setIsImportingMigration(true);
    try {
      const rawText = await file.text();
      const parsed = JSON.parse(rawText);
      const payload = parsed?.data
        ? { deviceLabel: parsed.deviceLabel || migrationDeviceLabel, data: parsed.data }
        : { deviceLabel: migrationDeviceLabel, data: parsed };

      const res = await fetch('/api/migration/import', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRF-Token': csrfToken || '',
        },
        credentials: 'include',
        cache: 'no-store',
        body: JSON.stringify(payload),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok || !data.success) {
        showToast(
          data.error || (isIndonesian ? 'Gagal mengimpor data migrasi.' : 'Failed to import migration bundle.'),
          'error'
        );
        return;
      }

      showToast(
        isIndonesian
          ? `Migrasi selesai (${data.status}): +${data.stats?.inserted ?? 0} baru, ${data.stats?.skippedIdentical ?? 0} identik, ${data.stats?.conflictsLogged ?? 0} konflik.`
          : `Migration finished (${data.status}): +${data.stats?.inserted ?? 0} inserted, ${data.stats?.skippedIdentical ?? 0} identical, ${data.stats?.conflictsLogged ?? 0} conflicts.`,
        data.stats?.conflictsLogged > 0 ? 'info' : 'success'
      );
      await Promise.all([fetchReconciliationReport(), syncNow()]);
    } catch {
      showToast(
        isIndonesian ? 'File JSON migrasi tidak valid.' : 'Invalid migration JSON file.',
        'error'
      );
    } finally {
      setIsImportingMigration(false);
    }
  };

  const handleResolveConflict = async (
    conflictId: string,
    decision: 'keep_existing' | 'accept_incoming'
  ) => {
    try {
      const res = await fetch(`/api/migration/conflicts/${encodeURIComponent(conflictId)}/resolve`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRF-Token': csrfToken || '',
        },
        credentials: 'include',
        cache: 'no-store',
        body: JSON.stringify({ decision }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok || !data.success) {
        showToast(
          data.error || (isIndonesian ? 'Gagal menyelesaikan konflik.' : 'Failed to resolve conflict.'),
          'error'
        );
        return;
      }
      showToast(
        isIndonesian ? 'Konflik migrasi berhasil diselesaikan.' : 'Migration conflict resolved.',
        'success'
      );
      await Promise.all([fetchReconciliationReport(), syncNow()]);
    } catch {
      showToast(
        isIndonesian ? 'Koneksi bermasalah saat menyelesaikan konflik.' : 'Connection error resolving conflict.',
        'error'
      );
    }
  };

  const handlePurgeOperationalData = async (e: React.FormEvent) => {
    e.preventDefault();
    if (purgeConfirmInput !== 'RESET') {
      showToast(
        isIndonesian
          ? 'Ketik "RESET" pada kolom konfirmasi sebelum mengosongkan data operasional.'
          : 'Type "RESET" in the confirmation box before purging operational data.',
        'error'
      );
      return;
    }

    setIsPurging(true);
    try {
      const res = await fetch('/api/system/purge-operational', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRF-Token': csrfToken || '',
        },
        credentials: 'include',
        cache: 'no-store',
        body: JSON.stringify({ confirmText: purgeConfirmInput }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok || !data.success) {
        showToast(
          data.error || (isIndonesian ? 'Gagal mengosongkan data operasional.' : 'Failed to purge operational data.'),
          'error'
        );
        return;
      }
      setPurgeConfirmInput('');
      showToast(
        data.message ||
          (isIndonesian
            ? 'Seluruh catatan operasional D1 telah dikosongkan ke nol.'
            : 'All D1 operational records have been purged to zero.'),
        'success'
      );
      await syncNow();
    } catch {
      showToast(
        isIndonesian ? 'Koneksi bermasalah saat mengosongkan data.' : 'Connection error purging operational data.',
        'error'
      );
    } finally {
      setIsPurging(false);
    }
  };

  const handleSavePublicConfig = async (overrides?: Partial<{
    enabled: boolean;
    requireToken: boolean;
    allowAttachments: boolean;
  }>) => {
    if (!publicConfig) return;
    setIsSavingPublicConfig(true);
    try {
      const payload = {
        enabled: overrides?.enabled ?? publicConfig.enabled,
        requireToken: overrides?.requireToken ?? publicConfig.requireToken,
        allowAttachments: overrides?.allowAttachments ?? publicConfig.allowAttachments,
        allowedEmailDomains: domainsInput,
      };
      const res = await fetch('/api/system/public-form-config', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRF-Token': csrfToken || '',
        },
        credentials: 'include',
        cache: 'no-store',
        body: JSON.stringify(payload),
      });
      const data = await res.json().catch(() => ({}));
      if (res.ok && data.success && data.config) {
        setPublicConfig(data.config);
        setDomainsInput((data.config.allowedEmailDomains || []).join(', '));
        showToast(
          isIndonesian
            ? 'Pengaturan tautan formulir publik berhasil disimpan.'
            : 'Public request form settings saved.',
          'success'
        );
      } else {
        showToast(
          data.error || (isIndonesian ? 'Gagal menyimpan pengaturan tautan publik.' : 'Failed to save public link settings.'),
          'error'
        );
      }
    } catch {
      showToast(
        isIndonesian ? 'Koneksi bermasalah saat menyimpan pengaturan.' : 'Connection error saving settings.',
        'error'
      );
    } finally {
      setIsSavingPublicConfig(false);
    }
  };

  const handleRotatePublicToken = async () => {
    setIsRotatingToken(true);
    try {
      const res = await fetch('/api/system/public-form-config/rotate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRF-Token': csrfToken || '',
        },
        credentials: 'include',
        cache: 'no-store',
      });
      const data = await res.json().catch(() => ({}));
      if (res.ok && data.success && data.config) {
        setPublicConfig(data.config);
        setConfirmRotateToken(false);
        showToast(
          isIndonesian
            ? 'Token akses tautan publik berhasil diperbarui. Tautan lama kini tidak berlaku.'
            : 'Public access token rotated. The previous link is now invalid.',
          'success'
        );
      } else {
        showToast(
          data.error || (isIndonesian ? 'Gagal memperbarui token akses.' : 'Failed to rotate access token.'),
          'error'
        );
      }
    } catch {
      showToast(
        isIndonesian ? 'Koneksi bermasalah saat memperbarui token.' : 'Connection error rotating token.',
        'error'
      );
    } finally {
      setIsRotatingToken(false);
    }
  };

  const publicShareUrl =
    typeof window !== 'undefined' && publicConfig
      ? publicConfig.requireToken
        ? `${window.location.origin}/submit-request?token=${encodeURIComponent(publicConfig.accessToken)}`
        : `${window.location.origin}/submit-request`
      : '';

  const handleCopyPublicShareUrl = async () => {
    if (!publicShareUrl) return;
    try {
      await navigator.clipboard.writeText(publicShareUrl);
      setCopiedPublicLink(true);
      setTimeout(() => setCopiedPublicLink(false), 2000);
      showToast(
        isIndonesian ? 'Tautan formulir publik disalin ke clipboard.' : 'Public form link copied to clipboard.',
        'success'
      );
    } catch {
      showToast(
        isIndonesian ? 'Gagal menyalin tautan ke clipboard.' : 'Failed to copy link to clipboard.',
        'error'
      );
    }
  };

  const getServiceStatusLabel = (status: ServiceStatus['status']) => {
    if (!isIndonesian) return status.toUpperCase();
    switch (status) {
      case 'connected':
        return 'TERHUBUNG';
      case 'blocked':
        return 'DIBLOKIR';
      case 'not_configured':
        return 'PLACEHOLDER / OPSIONAL';
      default:
        return 'GALAT';
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner & Tab Navigation */}
      <div className="p-6 bg-white rounded-2xl border border-slate-200 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h2 className="text-lg font-bold text-slate-900">
              {isIndonesian ? 'Pengaturan Sistem & Tata Kelola' : 'System Settings & Governance'}
            </h2>
            <p className="text-xs text-slate-500 mt-1">
              {isIndonesian
                ? 'Tinjauan Klien PT Lyman Devindo — Tata Kelola Kuota Prioritas, SLA, Infrastruktur Cloudflare D1/R2 & Kepatuhan.'
                : 'PT Lyman Devindo Client Review — Priority Quota Governance, SLAs, Cloudflare D1/R2 Infrastructure & Compliance.'}
            </p>
          </div>
          {activeTab === 'system' && (
            <button
              onClick={() => {
                fetchServiceStatus();
                fetchBackups();
                if (isSuperAdmin) fetchReconciliationReport();
              }}
              disabled={isLoadingServices}
              className="self-start sm:self-auto px-3.5 py-1.5 text-xs font-semibold text-slate-700 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-xl transition-colors flex items-center gap-2"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isLoadingServices ? 'animate-spin text-emerald-600' : ''}`} />
              <span>{isIndonesian ? 'Segarkan Diagnostik' : 'Refresh Diagnostics'}</span>
            </button>
          )}
        </div>

        {/* Tab Switcher */}
        <div className="flex items-center gap-1.5 border-t border-slate-100 pt-3 flex-wrap">
          <button
            type="button"
            onClick={() => setActiveTab('quota')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
              activeTab === 'quota'
                ? 'bg-[#065F46] text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>{isIndonesian ? 'Manajemen Kuota Prioritas' : 'Priority Quota Management'}</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('sla')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
              activeTab === 'sla'
                ? 'bg-[#065F46] text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <Clock className="w-3.5 h-3.5" />
            <span>{isIndonesian ? 'Standar Operasional SLA' : 'Standard Operating SLA'}</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('public_link')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
              activeTab === 'public_link'
                ? 'bg-[#065F46] text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <Link2 className="w-3.5 h-3.5" />
            <span>{isIndonesian ? 'Tautan Form Publik' : 'Public Form Link'}</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('system')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
              activeTab === 'system'
                ? 'bg-[#065F46] text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <Server className="w-3.5 h-3.5" />
            <span>{isIndonesian ? 'Infrastruktur & Cadangan Data' : 'Infrastructure & Backups'}</span>
          </button>
        </div>
      </div>

      {/* Tab 1: Priority Quota Management */}
      {activeTab === 'quota' && <PriorityQuotaManagementView />}

      {/* Tab 2: Standard Service Level Agreement (SLA) by Priority */}
      {activeTab === 'sla' && (
        <div className="p-6 bg-white rounded-2xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-200 flex-wrap gap-2">
            <div className="flex items-center gap-2.5">
              <Clock className="w-5 h-5 text-amber-600" />
              <div>
                <h3 className="text-sm font-bold text-slate-900">
                  {isIndonesian
                    ? 'Standar Perjanjian Tingkat Layanan (SLA) Komunikasi Pemasaran'
                    : 'Marketing Communications Standard Service Level Agreement (SLA)'}
                </h3>
                <p className="text-xs text-slate-500">
                  {isIndonesian
                    ? 'Durasi penyelesaian standar yang dikomitmenkan sejak pengajuan tiket hingga persetujuan selesai.'
                    : 'Standard committed turnaround duration from ticket submission to completed sign-off.'}
                </p>
              </div>
            </div>
            <span className="text-xs font-bold text-blue-700 bg-blue-50 px-2.5 py-1 rounded-lg border border-blue-200 font-mono">
              {isIndonesian ? 'Standar Operasional SLA' : 'Standard Operating SLA'}
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
            <div className="p-4 bg-rose-50/50 rounded-xl border border-rose-200 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-bold text-rose-800 text-sm">
                  {isIndonesian ? 'Prioritas: Mendesak' : 'Priority: Urgent'}
                </span>
                <span className="px-2 py-0.5 rounded font-mono font-extrabold text-xs bg-rose-100 text-rose-800 border border-rose-300">
                  {PRIORITY_SLA_DAYS.urgent} {isIndonesian ? 'Hari' : 'Day'}
                </span>
              </div>
              <p className="text-[11px] text-slate-600 leading-relaxed">
                {isIndonesian
                  ? 'Materi komunikasi kritis berurgensi tinggi. Triase langsung dan pengiriman di hari yang sama dalam 24 jam. Diatur oleh kuota tahunan brand.'
                  : 'Critical, high-urgency communication deliverables. Immediate triage and same-day delivery within 24 hours. Governed by brand annual quota.'}
              </p>
            </div>

            <div className="p-4 bg-amber-50/50 rounded-xl border border-amber-200 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-bold text-amber-800 text-sm">
                  {isIndonesian ? 'Prioritas: Tinggi' : 'Priority: High'}
                </span>
                <span className="px-2 py-0.5 rounded font-mono font-extrabold text-xs bg-amber-100 text-amber-800 border border-amber-300">
                  {PRIORITY_SLA_DAYS.high} {isIndonesian ? 'Hari' : 'Days'}
                </span>
              </div>
              <p className="text-[11px] text-slate-600 leading-relaxed">
                {isIndonesian
                  ? 'Promosi peluncuran utama, kampanye mendesak, atau materi acara penting dengan tanggal publikasi dekat. Diatur oleh kuota tahunan brand.'
                  : 'Major launch promotions, urgent campaigns, or key event collaterals with impending publishing dates. Governed by brand annual quota.'}
              </p>
            </div>

            <div className="p-4 bg-blue-50/50 rounded-xl border border-blue-200 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-bold text-blue-800 text-sm">
                  {isIndonesian ? 'Prioritas: Sedang' : 'Priority: Medium'}
                </span>
                <span className="px-2 py-0.5 rounded font-mono font-extrabold text-xs bg-blue-100 text-blue-800 border border-blue-300">
                  {PRIORITY_SLA_DAYS.medium} {isIndonesian ? 'Hari' : 'Days'}
                </span>
              </div>
              <p className="text-[11px] text-slate-600 leading-relaxed">
                {isIndonesian
                  ? 'Kampanye pemasaran divisi standar, siklus desain kreatif rutin, dan produksi terstruktur. Diatur oleh kuota tahunan brand.'
                  : 'Standard division marketing campaigns, routine creative design cycles, and ordered production. Governed by brand annual quota.'}
              </p>
            </div>

            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-800 text-sm">
                  {isIndonesian ? 'Prioritas: Rendah' : 'Priority: Low'}
                </span>
                <span className="px-2 py-0.5 rounded font-mono font-extrabold text-xs bg-slate-200 text-slate-800 border border-slate-300">
                  {PRIORITY_SLA_DAYS.low} {isIndonesian ? 'Hari' : 'Days'}
                </span>
              </div>
              <p className="text-[11px] text-slate-600 leading-relaxed">
                {isIndonesian
                  ? 'Aset pendukung rutin, eksplorasi konsep, dan materi branding umum dengan lini masa fleksibel. Standar dasar tanpa batas kuota.'
                  : 'Routine support assets, conceptual exploration, and general branding collateral with flexible timelines. Standard unlimited baseline.'}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2b: Public Request Form Link & Security Controls */}
      {activeTab === 'public_link' && (
        <div className="p-6 bg-white rounded-2xl border border-slate-200 shadow-xs space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 pb-4 border-b border-slate-200">
            <div className="flex items-center gap-2.5">
              <Link2 className="w-5 h-5 text-[#065F46]" />
              <div>
                <h3 className="text-sm font-bold text-slate-900">
                  {isIndonesian
                    ? 'Tautan Publik Form "Buat Permintaan Kerja Baru" (Tanpa Login)'
                    : 'Public Request Submission Link (No Login Required)'}
                </h3>
                <p className="text-xs text-slate-500">
                  {isIndonesian
                    ? 'Bagikan tautan khusus ini agar pemohon internal maupun mitra dapat mengajukan permintaan kerja langsung tanpa masuk ke dashboard internal.'
                    : 'Share this dedicated link so internal teams or partners can submit work requests directly without logging into the internal dashboard.'}
                </p>
              </div>
            </div>
            {publicConfig && (
              <span
                className={`text-xs font-bold px-3 py-1 rounded-lg border shrink-0 self-start sm:self-auto ${
                  publicConfig.enabled
                    ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                    : 'bg-rose-50 text-rose-800 border-rose-200'
                }`}
              >
                {publicConfig.enabled
                  ? isIndonesian
                    ? 'Status: Aktif'
                    : 'Status: Active'
                  : isIndonesian
                  ? 'Status: Nonaktif'
                  : 'Status: Disabled'}
              </span>
            )}
          </div>

          {isLoadingPublicConfig || !publicConfig ? (
            <div className="py-8 text-center text-xs text-slate-500">
              {isIndonesian ? 'Memuat konfigurasi tautan publik...' : 'Loading public link configuration...'}
            </div>
          ) : (
            <div className="space-y-5">
              {/* Shareable URL Box */}
              <div className="p-4 bg-[#F7FAF8] rounded-xl border border-emerald-200/80 space-y-2.5">
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <label className="text-xs font-bold text-slate-900">
                    {isIndonesian ? 'URL Formulir Publik Resmi' : 'Official Public Form URL'}
                  </label>
                  <span className="text-[11px] font-mono text-[#065F46]">
                    {publicConfig.requireToken
                      ? isIndonesian
                        ? 'Dilindungi Token Akses'
                        : 'Token-Protected Link'
                      : isIndonesian
                      ? 'Akses Terbuka (Tanpa Token)'
                      : 'Open Access (No Token)'}
                  </span>
                </div>
                <div className="flex flex-col sm:flex-row gap-2">
                  <input
                    type="text"
                    readOnly
                    value={publicShareUrl}
                    className="flex-1 px-3 py-2 text-xs font-mono bg-white border border-slate-300 rounded-xl text-slate-800 select-all focus:outline-none"
                  />
                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      type="button"
                      onClick={handleCopyPublicShareUrl}
                      className="px-3.5 py-2 text-xs font-bold text-white bg-[#065F46] hover:bg-[#044e39] rounded-xl transition-colors flex items-center gap-1.5 shadow-xs"
                    >
                      {copiedPublicLink ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>
                        {copiedPublicLink
                          ? isIndonesian
                            ? 'Tersalin'
                            : 'Copied'
                          : isIndonesian
                          ? 'Salin Tautan'
                          : 'Copy Link'}
                      </span>
                    </button>
                    <a
                      href={publicShareUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-3.5 py-2 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-100 border border-slate-300 rounded-xl transition-colors flex items-center gap-1.5"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                      <span>{isIndonesian ? 'Buka' : 'Open'}</span>
                    </a>
                  </div>
                </div>
              </div>

              {/* Security & Behavior Toggles */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
                <label className="p-3.5 rounded-xl border border-slate-200 bg-slate-50/60 flex items-start gap-3 cursor-pointer hover:bg-slate-50">
                  <input
                    type="checkbox"
                    checked={publicConfig.enabled}
                    disabled={isSavingPublicConfig}
                    onChange={(e) => {
                      const next = e.target.checked;
                      setPublicConfig((prev) => (prev ? { ...prev, enabled: next } : prev));
                      handleSavePublicConfig({ enabled: next });
                    }}
                    className="mt-0.5 accent-[#065F46] cursor-pointer"
                  />
                  <div>
                    <div className="font-bold text-slate-900">
                      {isIndonesian ? 'Aktifkan Tautan Publik' : 'Enable Public Link'}
                    </div>
                    <p className="text-[11px] text-slate-500 mt-0.5">
                      {isIndonesian
                        ? 'Izinkan pengajuan tiket via tautan tanpa perlu login ke akun.'
                        : 'Allow submitting requests via link without account login.'}
                    </p>
                  </div>
                </label>

                <label className="p-3.5 rounded-xl border border-slate-200 bg-slate-50/60 flex items-start gap-3 cursor-pointer hover:bg-slate-50">
                  <input
                    type="checkbox"
                    checked={publicConfig.requireToken}
                    disabled={isSavingPublicConfig}
                    onChange={(e) => {
                      const next = e.target.checked;
                      setPublicConfig((prev) => (prev ? { ...prev, requireToken: next } : prev));
                      handleSavePublicConfig({ requireToken: next });
                    }}
                    className="mt-0.5 accent-[#065F46] cursor-pointer"
                  />
                  <div>
                    <div className="font-bold text-slate-900">
                      {isIndonesian ? 'Wajib Kode Akses (Token)' : 'Require Access Token'}
                    </div>
                    <p className="text-[11px] text-slate-500 mt-0.5">
                      {isIndonesian
                        ? 'Hanya pemilik tautan dengan token valid yang dapat mengakses formulir.'
                        : 'Only link holders with a valid token can open and submit the form.'}
                    </p>
                  </div>
                </label>

                <label className="p-3.5 rounded-xl border border-slate-200 bg-slate-50/60 flex items-start gap-3 cursor-pointer hover:bg-slate-50">
                  <input
                    type="checkbox"
                    checked={publicConfig.allowAttachments}
                    disabled={isSavingPublicConfig}
                    onChange={(e) => {
                      const next = e.target.checked;
                      setPublicConfig((prev) => (prev ? { ...prev, allowAttachments: next } : prev));
                      handleSavePublicConfig({ allowAttachments: next });
                    }}
                    className="mt-0.5 accent-[#065F46] cursor-pointer"
                  />
                  <div>
                    <div className="font-bold text-slate-900">
                      {isIndonesian ? 'Izinkan Unggah Lampiran Brief' : 'Allow Brief File Uploads'}
                    </div>
                    <p className="text-[11px] text-slate-500 mt-0.5">
                      {isIndonesian
                        ? 'Simpan file brief pengaju ke R2 privat (maks. 25 MB/file).'
                        : 'Store submitter brief attachments in private R2 storage (max 25 MB/file).'}
                    </p>
                  </div>
                </label>
              </div>

              {/* Domain Restriction & Token Rotation */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                <div className="p-4 rounded-xl border border-slate-200 space-y-2.5">
                  <label className="block text-xs font-bold text-slate-900">
                    {isIndonesian
                      ? 'Pembatasan Domain Email Pemohon (Opsional)'
                      : 'Allowed Submitter Email Domains (Optional)'}
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={domainsInput}
                      onChange={(e) => setDomainsInput(e.target.value)}
                      placeholder="lyman.co.id, masonpinehotel.com"
                      className="flex-1 px-3 py-2 text-xs font-mono bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:outline-none focus:border-[#065F46]"
                    />
                    <button
                      type="button"
                      onClick={() => handleSavePublicConfig()}
                      disabled={isSavingPublicConfig}
                      className="px-3.5 py-2 text-xs font-bold text-white bg-[#065F46] hover:bg-[#044e39] disabled:opacity-50 rounded-xl transition-colors shrink-0"
                    >
                      {isSavingPublicConfig
                        ? isIndonesian
                          ? 'Menyimpan...'
                          : 'Saving...'
                        : isIndonesian
                        ? 'Simpan Domain'
                        : 'Save Domains'}
                    </button>
                  </div>
                  <p className="text-[11px] text-slate-500">
                    {isIndonesian
                      ? 'Pisahkan dengan koma (contoh: lyman.co.id). Kosongkan jika semua alamat email valid diperbolehkan.'
                      : 'Comma-separated (e.g., lyman.co.id). Leave empty to allow any valid corporate or external email.'}
                  </p>
                </div>

                <div className="p-4 rounded-xl border border-amber-200 bg-amber-50/40 space-y-2.5">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                      <KeyRound className="w-3.5 h-3.5 text-amber-700" />
                      <span>{isIndonesian ? 'Rotasi Token Akses Publik' : 'Public Access Token Rotation'}</span>
                    </span>
                    <span className="text-[10px] font-mono text-slate-500">
                      {publicConfig.accessToken.slice(0, 6)}••••{publicConfig.accessToken.slice(-4)}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-600">
                    {isIndonesian
                      ? 'Jika tautan publik tersebar ke pihak yang tidak berwenang, buat token baru. Tautan lama akan langsung ditolak.'
                      : 'If the public link is shared outside intended teams, rotate the token. Existing links stop working immediately.'}
                  </p>
                  {!confirmRotateToken ? (
                    <button
                      type="button"
                      onClick={() => setConfirmRotateToken(true)}
                      className="px-3.5 py-2 text-xs font-bold text-amber-900 bg-white hover:bg-amber-100 border border-amber-300 rounded-xl transition-colors"
                    >
                      {isIndonesian ? 'Buat Token Baru (Cabut Tautan Lama)' : 'Generate New Token (Revoke Old Link)'}
                    </button>
                  ) : (
                    <div className="flex items-center gap-2 flex-wrap">
                      <button
                        type="button"
                        onClick={handleRotatePublicToken}
                        disabled={isRotatingToken}
                        className="px-3.5 py-2 text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 disabled:opacity-50 rounded-xl transition-colors"
                      >
                        {isRotatingToken
                          ? isIndonesian
                            ? 'Memperbarui...'
                            : 'Rotating...'
                          : isIndonesian
                          ? 'Konfirmasi Rotasi Token'
                          : 'Confirm Token Rotation'}
                      </button>
                      <button
                        type="button"
                        onClick={() => setConfirmRotateToken(false)}
                        disabled={isRotatingToken}
                        className="px-3 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-xl hover:bg-slate-100"
                      >
                        {isIndonesian ? 'Batal' : 'Cancel'}
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Tab 3: Infrastructure, Security, Backups & Legacy Migration */}
      {activeTab === 'system' && (
        <>
          <div className="p-6 bg-white rounded-2xl border border-slate-200 shadow-xs space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 flex-wrap gap-2">
              <div className="flex items-center gap-2.5">
                <Server className="w-5 h-5 text-emerald-700" />
                <div>
                  <h3 className="text-sm font-bold text-slate-900">
                    {isIndonesian ? 'Matriks Kesiapan Layanan Cloudflare & Eksternal' : 'Cloudflare & External Services Readiness Matrix'}
                  </h3>
                  <p className="text-xs text-slate-500">
                    {isIndonesian
                      ? 'Kebijakan tanpa simulasi — probe langsung ke D1, R2, Worker Secrets, dan SMTP relay'
                      : 'Zero simulation policy — live runtime probes for D1, R2, Worker Secrets, and SMTP relay'}
                  </p>
                </div>
              </div>
              <span className="text-xs font-mono font-bold px-2.5 py-1 rounded-lg bg-emerald-50 text-emerald-800 border border-emerald-200">
                Cloudflare Workers + D1 + R2
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
              {services.map((svc) => {
                const isBlocked = svc.status === 'blocked';
                const isConnected = svc.status === 'connected';
                const isPlaceholder = svc.status === 'not_configured';

                return (
                  <div
                    key={svc.service}
                    className={`p-4 rounded-xl border space-y-2.5 transition-all ${
                      isBlocked
                        ? 'bg-amber-50/40 border-amber-200'
                        : isConnected
                        ? 'bg-emerald-50/40 border-emerald-200'
                        : isPlaceholder
                        ? 'bg-slate-50 border-slate-200'
                        : 'bg-rose-50/40 border-rose-200'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <strong className="text-slate-900 font-bold">{svc.name}</strong>
                      <span
                        className={`text-[10px] font-mono font-extrabold px-2 py-0.5 rounded-full uppercase shrink-0 ${
                          isBlocked
                            ? 'bg-amber-100 text-amber-800 border border-amber-300'
                            : isConnected
                            ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                            : isPlaceholder
                            ? 'bg-slate-200 text-slate-700 border border-slate-300'
                            : 'bg-rose-100 text-rose-800 border border-rose-300'
                        }`}
                      >
                        {getServiceStatusLabel(svc.status)}
                      </span>
                    </div>

                    <p className="text-slate-600 text-[11px] leading-relaxed">{svc.message}</p>

                    {svc.missingEnvVars && svc.missingEnvVars.length > 0 && (
                      <div className="pt-2 border-t border-slate-200/60">
                        <span className="text-[10px] font-bold text-slate-500 block mb-1">
                          {isIndonesian ? 'Worker Secrets / Variabel:' : 'Required Secrets / Vars:'}
                        </span>
                        <div className="flex flex-wrap gap-1">
                          {svc.missingEnvVars.map((v) => (
                            <code key={v} className="text-[10px] px-1.5 py-0.5 bg-white border border-slate-300 rounded font-mono text-rose-700">
                              {v}
                            </code>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Verified D1 -> R2 Database Backups (Super Admin & Admin) */}
          {(isSuperAdmin || isAdmin) && (
            <div className="p-6 bg-white rounded-2xl border border-slate-200 shadow-xs space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 pb-3 border-b border-slate-200">
                <div className="flex items-center gap-2.5">
                  <Database className="w-5 h-5 text-blue-600" />
                  <div>
                    <h3 className="text-sm font-bold text-slate-900">
                      {isIndonesian ? 'Cadangan Database D1 ke R2 & Integritas SHA-256' : 'D1 Database Backups to R2 & SHA-256 Integrity'}
                    </h3>
                    <p className="text-xs text-slate-500">
                      {isIndonesian
                        ? 'Snapshot JSON terverifikasi disimpan di Cloudflare R2 privat dengan verifikasi checksum SHA-256 saat diunduh.'
                        : 'Verified JSON snapshots stored in private Cloudflare R2 with SHA-256 checksum verification on download.'}
                    </p>
                  </div>
                </div>
                <button
                  onClick={handleCreateBackup}
                  disabled={isCreatingBackup}
                  className="px-4 py-2 text-xs font-bold text-white bg-emerald-700 hover:bg-emerald-800 rounded-xl transition-colors flex items-center gap-2 shadow-xs"
                >
                  <FileCheck className="w-3.5 h-3.5" />
                  <span>
                    {isCreatingBackup
                      ? isIndonesian
                        ? 'Membuat Cadangan D1...'
                        : 'Generating D1 Backup...'
                      : isIndonesian
                      ? 'Buat Cadangan Terverifikasi (SHA-256)'
                      : 'Create Verified Backup (SHA-256)'}
                  </span>
                </button>
              </div>

              <div className="space-y-2">
                <h4 className="text-xs font-bold text-slate-700">
                  {isIndonesian ? 'Riwayat Cadangan Terverifikasi' : 'Verified Backup History'}
                </h4>
                {backups.length === 0 ? (
                  <p className="text-xs text-slate-400 italic">
                    {isIndonesian ? 'Belum ada cadangan yang tersimpan di R2.' : 'No backups generated in R2 yet.'}
                  </p>
                ) : (
                  <div className="divide-y divide-slate-100 border border-slate-200 rounded-xl overflow-hidden">
                    {backups.map((b) => (
                      <div key={b.id} className="p-3 bg-slate-50/50 hover:bg-slate-50 flex flex-col sm:flex-row sm:items-center justify-between text-xs gap-3">
                        <div className="space-y-1">
                          <div className="flex items-center gap-2 flex-wrap">
                            <strong className="text-slate-800 font-semibold">{b.filename}</strong>
                            <span
                              className={`text-[10px] px-2 py-0.5 rounded-full font-bold border ${
                                b.integrityStatus === 'valid'
                                  ? 'bg-emerald-100 text-emerald-800 border-emerald-200'
                                  : 'bg-rose-100 text-rose-800 border-rose-200'
                              }`}
                            >
                              {isIndonesian ? 'Integritas:' : 'Integrity:'}{' '}
                              {b.integrityStatus === 'valid'
                                ? isIndonesian
                                  ? 'Valid'
                                  : 'Valid'
                                : isIndonesian
                                ? 'Rusak'
                                : 'Corrupted'}
                            </span>
                          </div>
                          <div className="text-[11px] text-slate-500 font-mono">
                            SHA-256: {b.checksumSha256.slice(0, 32)}...
                          </div>
                          <div className="text-[10px] text-slate-400">
                            {isIndonesian ? 'Dibuat:' : 'Created:'} {new Date(b.createdAt).toLocaleString(isIndonesian ? 'id-ID' : 'en-GB')} |{' '}
                            {isIndonesian ? 'Pengguna:' : 'Users:'} {b.recordCounts.users ?? 0} |{' '}
                            {isIndonesian ? 'Permintaan:' : 'Requests:'} {b.recordCounts.requests ?? 0} |{' '}
                            {isIndonesian ? 'Sub Item:' : 'Sub Items:'} {b.recordCounts.subItems ?? 0}
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={() => handleDownloadBackup(b)}
                          className="self-start sm:self-center px-3 py-1.5 text-xs font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-lg transition-colors flex items-center gap-1.5 shrink-0"
                        >
                          <Download className="w-3.5 h-3.5" />
                          <span>{isIndonesian ? 'Unduh & Verifikasi' : 'Download & Verify'}</span>
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Legacy Data Migration & Conflict Reconciliation (Super Admin Only) */}
          {isSuperAdmin && (
            <div className="p-6 bg-white rounded-2xl border border-slate-200 shadow-xs space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 pb-3 border-b border-slate-200">
                <div className="flex items-center gap-2.5">
                  <GitMerge className="w-5 h-5 text-indigo-600" />
                  <div>
                    <h3 className="text-sm font-bold text-slate-900">
                      {isIndonesian
                        ? 'Migrasi Data Multi-Perangkat & Rekonsiliasi Konflik D1'
                        : 'Multi-Device Legacy Data Migration & D1 Conflict Reconciliation'}
                    </h3>
                    <p className="text-xs text-slate-500">
                      {isIndonesian
                        ? 'Ekspor snapshot browser lama secara aman (read-only) dan impor secara idempoten ke Cloudflare D1 + R2 tanpa menimpa data konflik.'
                        : 'Safely export legacy browser snapshots (read-only) and import idempotently into Cloudflare D1 + R2 without overwriting conflicts.'}
                    </p>
                  </div>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 flex-wrap">
                <input
                  type="text"
                  value={migrationDeviceLabel}
                  onChange={(e) => setMigrationDeviceLabel(e.target.value)}
                  placeholder={isIndonesian ? 'Label perangkat sumber...' : 'Source device label...'}
                  className="px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-xl font-mono focus:bg-white"
                />
                <button
                  type="button"
                  onClick={handleExportBrowserSnapshot}
                  className="px-4 py-2 text-xs font-bold text-slate-800 bg-slate-100 hover:bg-slate-200 border border-slate-300 rounded-xl transition-colors flex items-center justify-center gap-2"
                >
                  <HardDriveDownload className="w-3.5 h-3.5" />
                  <span>{isIndonesian ? 'Ekspor Snapshot Browser (.json)' : 'Export Browser Snapshot (.json)'}</span>
                </button>
                <label className="cursor-pointer px-4 py-2 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl transition-colors flex items-center justify-center gap-2">
                  <UploadCloud className="w-3.5 h-3.5" />
                  <span>
                    {isImportingMigration
                      ? isIndonesian
                        ? 'Mengimpor ke D1...'
                        : 'Importing to D1...'
                      : isIndonesian
                      ? 'Impor JSON ke D1 & R2 (Idempoten)'
                      : 'Import JSON to D1 & R2 (Idempotent)'}
                  </span>
                  <input
                    type="file"
                    accept=".json,application/json"
                    disabled={isImportingMigration}
                    onChange={handleImportSnapshotFile}
                    className="hidden"
                  />
                </label>
              </div>

              {reconciliation && (
                <div className="space-y-4 pt-2">
                  <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 text-xs">
                    {[
                      { label: isIndonesian ? 'Pengguna' : 'Users', val: reconciliation.tableCounts.users },
                      { label: isIndonesian ? 'Permintaan' : 'Requests', val: reconciliation.tableCounts.requests },
                      { label: 'Sub Items', val: reconciliation.tableCounts.subItems },
                      { label: isIndonesian ? 'Buku Besar Kuota' : 'Quota Ledger', val: reconciliation.tableCounts.quotaLedger },
                      { label: isIndonesian ? 'Lampiran R2' : 'R2 Attachments', val: reconciliation.tableCounts.attachments },
                    ].map((stat) => (
                      <div key={stat.label} className="p-2.5 bg-slate-50 rounded-xl border border-slate-200">
                        <div className="text-[11px] text-slate-500">{stat.label}</div>
                        <div className="text-base font-extrabold font-mono text-slate-900">{stat.val}</div>
                      </div>
                    ))}
                  </div>

                  {reconciliation.conflicts.filter((c) => c.resolutionStatus === 'pending').length > 0 && (
                    <div className="space-y-2">
                      <h4 className="text-xs font-bold text-amber-800">
                        {isIndonesian
                          ? 'Konflik Data Menunggu Resolusi Manual'
                          : 'Pending Migration Conflicts Requiring Manual Resolution'}
                      </h4>
                      <div className="divide-y divide-amber-200 border border-amber-200 rounded-xl overflow-hidden bg-amber-50/30">
                        {reconciliation.conflicts
                          .filter((c) => c.resolutionStatus === 'pending')
                          .map((cf) => (
                            <div key={cf.id} className="p-3 text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                              <div>
                                <div className="font-bold text-slate-900">
                                  {cf.tableName} / <span className="font-mono">{cf.recordId}</span> ({cf.conflictType})
                                </div>
                                <div className="text-[11px] text-slate-500">
                                  {isIndonesian ? 'Perangkat:' : 'Device:'} {cf.deviceLabel} ·{' '}
                                  {new Date(cf.createdAt).toLocaleString(isIndonesian ? 'id-ID' : 'en-GB')}
                                </div>
                              </div>
                              <div className="flex items-center gap-2 shrink-0">
                                <button
                                  type="button"
                                  onClick={() => handleResolveConflict(cf.id, 'keep_existing')}
                                  className="px-3 py-1 text-[11px] font-bold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-100"
                                >
                                  {isIndonesian ? 'Pertahankan Data D1' : 'Keep D1 Existing'}
                                </button>
                                <button
                                  type="button"
                                  onClick={() => handleResolveConflict(cf.id, 'accept_incoming')}
                                  className="px-3 py-1 text-[11px] font-bold text-white bg-amber-600 hover:bg-amber-700 rounded-lg"
                                >
                                  {isIndonesian ? 'Terima Data Masuk' : 'Accept Incoming'}
                                </button>
                              </div>
                            </div>
                          ))}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {/* Dangerous Operations Zone */}
          {isSuperAdmin && (
            <div className="p-6 bg-white rounded-2xl border border-rose-200 shadow-xs space-y-3">
              <h3 className="text-sm font-bold text-rose-700 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-rose-600" />
                <span>{isIndonesian ? 'Zona Pemeliharaan Super Admin' : 'Super Admin Maintenance Zone'}</span>
              </h3>
              <p className="text-xs text-slate-600">
                {isIndonesian
                  ? 'Kosongkan seluruh transaksi tiket operasional, komentar, notifikasi, dan buku besar kuota pada D1 menjadi nol (sambil tetap mempertahankan akun pengguna dan data master). Buat cadangan terverifikasi sebelum melanjutkan.'
                  : 'Purge all operational D1 request tickets, comments, notifications, and quota ledger entries to zero (while preserving user accounts and master data). Create a verified backup before proceeding.'}
              </p>
              <form onSubmit={handlePurgeOperationalData} className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 flex-wrap">
                <input
                  type="text"
                  value={purgeConfirmInput}
                  onChange={(e) => setPurgeConfirmInput(e.target.value)}
                  placeholder={isIndonesian ? 'Ketik RESET untuk konfirmasi' : 'Type RESET to confirm'}
                  className="px-3 py-2 text-xs bg-rose-50/40 border border-rose-300 rounded-xl font-mono text-rose-900 focus:bg-white focus:outline-none"
                />
                <button
                  type="submit"
                  disabled={isPurging || purgeConfirmInput !== 'RESET'}
                  className="px-4 py-2 text-xs font-bold text-rose-800 bg-rose-50 hover:bg-rose-100 disabled:opacity-50 border border-rose-300 rounded-xl transition-colors flex items-center justify-center gap-2"
                >
                  <CheckCircle2 className="w-3.5 h-3.5 text-rose-600" />
                  <span>
                    {isPurging
                      ? isIndonesian
                        ? 'Mengosongkan D1...'
                        : 'Purging D1...'
                      : isIndonesian
                      ? 'Kosongkan Data Operasional D1 ke Nol'
                      : 'Purge D1 Operational Data to Zero'}
                  </span>
                </button>
              </form>
            </div>
          )}
        </>
      )}
    </div>
  );
};
