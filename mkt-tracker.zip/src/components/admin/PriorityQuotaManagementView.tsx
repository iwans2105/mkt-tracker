import React, { useState, useEffect, useCallback, useMemo } from 'react';
import {
  Layers,
  Edit2,
  Plus,
  Minus,
  CheckCircle2,
  AlertTriangle,
  History,
  RefreshCw,
  Clock,
  ArrowRight,
  X,
  FileCheck2,
  Calendar,
  Filter,
  BarChart3,
  Printer,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Info,
} from 'lucide-react';
import {
  BrandQuotaSummary,
  PriorityQuotaReconciliationPreview,
  PriorityQuotaLedgerEntry,
  PeriodReportingMetrics,
  ReportingPeriodMode,
  DatePreset,
  RequestPriority,
} from '../../types';
import { useAuth } from '../../context/AuthContext';
import { useRequests } from '../../context/RequestContext';
import { useLanguage } from '../../context/LanguageContext';

export const PriorityQuotaManagementView: React.FC = () => {
  const { currentUser, isSuperAdmin, isAdmin } = useAuth();
  const {
    brands,
    requests,
    fetchBrandQuota,
    fetchAllBrandQuotas,
    adjustBrandQuota,
    updateBrandQuotaLimits,
    fetchReconciliationPreview,
    applyReconciliation,
    fetchPeriodReportingMetrics,
    fetchAvailableQuotaYears,
    syncVersion,
    showToast,
  } = useRequests();
  const { language } = useLanguage();

  // Dynamic Asia/Jakarta (WIB) Active Year
  const currentWibYear = (() => {
    try {
      const formatter = new Intl.DateTimeFormat('en-CA', {
        timeZone: 'Asia/Jakarta',
        year: 'numeric',
      });
      return parseInt(formatter.format(new Date()), 10);
    } catch {
      return new Date().getFullYear();
    }
  })();

  // Core State
  const [selectedBrandId, setSelectedBrandId] = useState<string>(brands[0]?.id || 'brand-wahoo');

  useEffect(() => {
    if (brands.length > 0 && !brands.some((b) => b.id === selectedBrandId)) {
      setSelectedBrandId(brands[0].id);
    }
  }, [brands, selectedBrandId]);
  const [periodMode, setPeriodMode] = useState<ReportingPeriodMode>('calendar_year');
  const [selectedYear, setSelectedYear] = useState<number>(currentWibYear);
  const [serverYears, setServerYears] = useState<number[]>([]);
  const [isCustomYearInputOpen, setIsCustomYearInputOpen] = useState(false);
  const [customYearDraft, setCustomYearDraft] = useState<string>(String(currentWibYear));

  // Custom Date Range State
  const [startDate, setStartDate] = useState<string>(`${currentWibYear}-01-01`);
  const [endDate, setEndDate] = useState<string>(`${currentWibYear}-12-31`);
  const [activePreset, setActivePreset] = useState<DatePreset | ''>('this_year');

  // Multi-Year Tab for Annual Quota Balance
  const [activeBalanceYear, setActiveBalanceYear] = useState<number>(currentWibYear);

  // Data Stores
  const [currentSummary, setCurrentSummary] = useState<BrandQuotaSummary | null>(null);
  const [periodMetrics, setPeriodMetrics] = useState<PeriodReportingMetrics | null>(null);
  const [reconciliationPreview, setReconciliationPreview] = useState<PriorityQuotaReconciliationPreview | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  // Modals
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [editLimits, setEditLimits] = useState({ urgent: 3, high: 6, medium: 9 });
  const [isAdjustModalOpen, setIsAdjustModalOpen] = useState(false);
  const [adjustData, setAdjustData] = useState({
    priority: 'urgent' as RequestPriority,
    quantity: 1,
    reason: '',
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Unlimited dynamic year list: merges backend policies/ledger/reconciliations,
  // request dates, a sliding range around currentWibYear, and a sliding range around selectedYear
  const dynamicYearOptions = useMemo(() => {
    const yearSet = new Set<number>([currentWibYear, selectedYear]);

    for (let offset = -5; offset <= 5; offset++) {
      const wibY = currentWibYear + offset;
      if (wibY >= 1900 && wibY <= 9999) yearSet.add(wibY);
      const selY = selectedYear + offset;
      if (selY >= 1900 && selY <= 9999) yearSet.add(selY);
    }

    for (const sy of serverYears) {
      if (Number.isInteger(sy) && sy >= 1900 && sy <= 9999) {
        yearSet.add(sy);
      }
    }

    for (const req of requests) {
      if (req.deletedAt || !req.createdAt) continue;
      try {
        const y = parseInt(
          new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Jakarta', year: 'numeric' }).format(
            new Date(req.createdAt)
          ),
          10
        );
        if (Number.isInteger(y) && y >= 1900 && y <= 9999) {
          yearSet.add(y);
        }
      } catch {
        // Ignore malformed date
      }
    }

    return Array.from(yearSet).sort((a, b) => b - a);
  }, [currentWibYear, selectedYear, serverYears, requests]);

  const getYearRoleTag = (yr: number) => {
    if (yr === currentWibYear) return language === 'id' ? 'Tahun Aktif' : 'Active Year';
    if (yr > currentWibYear) return language === 'id' ? 'Mendatang' : 'Upcoming';
    return language === 'id' ? 'Historis' : 'Historical';
  };

  const selectedBrand = brands.find((b) => b.id === selectedBrandId) || brands[0];

  // Helper for WIB Date Presets
  const getPresetDates = (preset: DatePreset): { startDate: string; endDate: string } => {
    const now = new Date();
    const formatter = new Intl.DateTimeFormat('en-CA', {
      timeZone: 'Asia/Jakarta',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
    });
    const todayStr = formatter.format(now);
    const [yearStr, monthStr] = todayStr.split('-');
    const y = parseInt(yearStr, 10);
    const m = parseInt(monthStr, 10);
    const pad = (n: number) => String(n).padStart(2, '0');

    switch (preset) {
      case 'today':
        return { startDate: todayStr, endDate: todayStr };
      case 'last_7_days': {
        const prev = new Date(now.getTime() - 6 * 24 * 3600 * 1000);
        return { startDate: formatter.format(prev), endDate: todayStr };
      }
      case 'last_30_days': {
        const prev = new Date(now.getTime() - 29 * 24 * 3600 * 1000);
        return { startDate: formatter.format(prev), endDate: todayStr };
      }
      case 'this_month': {
        const lastDay = new Date(y, m, 0).getDate();
        return { startDate: `${y}-${pad(m)}-01`, endDate: `${y}-${pad(m)}-${pad(lastDay)}` };
      }
      case 'last_month': {
        const prevM = m === 1 ? 12 : m - 1;
        const prevY = m === 1 ? y - 1 : y;
        const lastDay = new Date(prevY, prevM, 0).getDate();
        return { startDate: `${prevY}-${pad(prevM)}-01`, endDate: `${prevY}-${pad(prevM)}-${pad(lastDay)}` };
      }
      case 'this_quarter': {
        const q = Math.floor((m - 1) / 3);
        const startM = q * 3 + 1;
        const endM = startM + 2;
        const lastDay = new Date(y, endM, 0).getDate();
        return { startDate: `${y}-${pad(startM)}-01`, endDate: `${y}-${pad(endM)}-${pad(lastDay)}` };
      }
      case 'this_year':
        return { startDate: `${y}-01-01`, endDate: `${y}-12-31` };
      case 'last_year':
        return { startDate: `${y - 1}-01-01`, endDate: `${y - 1}-12-31` };
    }
  };

  const handleApplyPreset = (preset: DatePreset) => {
    setActivePreset(preset);
    const dates = getPresetDates(preset);
    setStartDate(dates.startDate);
    setEndDate(dates.endDate);
  };

  // Load authoritative data
  const loadData = useCallback(async () => {
    if (!selectedBrand) return;
    setIsLoading(true);
    try {
      // 1. Fetch Authoritative Annual Quota Balance for active balance year
      // (Strict separation: query year quota from backend, never mutated by date filter)
      const spec = await fetchBrandQuota(selectedBrand.id, selectedBrand.name, activeBalanceYear);
      setCurrentSummary(spec);
      if (spec) {
        setEditLimits({
          urgent: spec.priorities.urgent?.annualLimit ?? 3,
          high: spec.priorities.high?.annualLimit ?? 6,
          medium: spec.priorities.medium?.annualLimit ?? 9,
        });
      }

      // 2. Fetch Period Reporting Metrics
      const metrics = await fetchPeriodReportingMetrics(
        selectedBrand.id,
        selectedBrand.name,
        periodMode === 'custom_range' ? startDate : undefined,
        periodMode === 'custom_range' ? endDate : undefined,
        periodMode === 'calendar_year' ? selectedYear : undefined,
        periodMode
      );
      setPeriodMetrics(metrics);

      // If custom range has affected years, keep activeBalanceYear within affected years if feasible
      if (periodMode === 'custom_range' && metrics && metrics.affectedYears.length > 0) {
        if (!metrics.affectedYears.includes(activeBalanceYear)) {
          setActiveBalanceYear(metrics.affectedYears[metrics.affectedYears.length - 1]);
        }
      } else if (periodMode === 'calendar_year') {
        setActiveBalanceYear(selectedYear);
      }

      // 3. Super Admin Reconciliation Preview
      if (isSuperAdmin) {
        const prev = await fetchReconciliationPreview(activeBalanceYear);
        setReconciliationPreview(prev);
      }

      // 4. Refresh discovered years from server policies/ledger/reconciliations
      const discovered = await fetchAvailableQuotaYears();
      if (discovered?.years) {
        setServerYears(discovered.years);
      }
    } finally {
      setIsLoading(false);
    }
  }, [
    selectedBrand,
    activeBalanceYear,
    periodMode,
    selectedYear,
    startDate,
    endDate,
    fetchBrandQuota,
    fetchPeriodReportingMetrics,
    fetchAvailableQuotaYears,
    isSuperAdmin,
    fetchReconciliationPreview,
  ]);

  useEffect(() => {
    loadData();
  }, [loadData, syncVersion]);

  // Handle switching calendar year in Mode A
  const handleCalendarYearChange = (yr: number) => {
    if (!Number.isInteger(yr) || yr < 1900 || yr > 9999) return;
    setSelectedYear(yr);
    setActiveBalanceYear(yr);
    setCustomYearDraft(String(yr));
    setIsCustomYearInputOpen(false);
  };

  const handleApplyCustomYear = (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = parseInt(customYearDraft.trim(), 10);
    if (!Number.isInteger(parsed) || parsed < 1900 || parsed > 9999) {
      showToast(
        language === 'id'
          ? 'Masukkan tahun kalender 4 digit yang valid (1900–9999).'
          : 'Please enter a valid 4-digit calendar year (1900–9999).',
        'error'
      );
      return;
    }
    handleCalendarYearChange(parsed);
  };

  // Handle manual date range submission
  const handleApplyCustomFilter = (e: React.FormEvent) => {
    e.preventDefault();
    if (!startDate || !endDate) {
      showToast(
        language === 'id'
          ? 'Tanggal Mulai dan Tanggal Akhir wajib diisi.'
          : 'Start Date and End Date are required.',
        'error'
      );
      return;
    }
    if (startDate > endDate) {
      showToast(
        language === 'id'
          ? 'Tanggal Mulai tidak boleh lebih besar dari Tanggal Akhir.'
          : 'Start Date cannot be later than End Date.',
        'error'
      );
      return;
    }
    setActivePreset('');
    loadData();
    showToast(
      language === 'id'
        ? 'Filter periode pelaporan berhasil diterapkan.'
        : 'Reporting period filter applied.',
      'success'
    );
  };

  const handleResetFilter = () => {
    setPeriodMode('calendar_year');
    setSelectedYear(currentWibYear);
    setActiveBalanceYear(currentWibYear);
    const thisYearDates = getPresetDates('this_year');
    setStartDate(thisYearDates.startDate);
    setEndDate(thisYearDates.endDate);
    setActivePreset('this_year');
    showToast(
      language === 'id'
        ? 'Filter periode dikembalikan ke Tahun Kalender aktif.'
        : 'Period filter reset to active Calendar Year.',
      'info'
    );
  };

  const handleSaveLimits = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedBrand) return;
    setIsSubmitting(true);
    try {
      const res = await updateBrandQuotaLimits(selectedBrand.id, editLimits, activeBalanceYear);
      if (res.success) {
        showToast(
          language === 'id'
            ? `Batas kuota tahunan untuk ${selectedBrand.name} (${activeBalanceYear}) berhasil diperbarui!`
            : `Annual quota limits for ${selectedBrand.name} (${activeBalanceYear}) updated!`,
          'success'
        );
        setIsEditModalOpen(false);
        loadData();
      } else {
        showToast(res.error || (language === 'id' ? 'Gagal memperbarui batas kuota.' : 'Failed to update quota limits.'), 'error');
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleAdjustQuota = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedBrand) return;
    if (!adjustData.reason || adjustData.reason.trim().length < 5) {
      showToast(
        language === 'id'
          ? 'Alasan penyesuaian wajib diisi minimal 5 karakter.'
          : 'Adjustment reason must be at least 5 characters.',
        'error'
      );
      return;
    }

    setIsSubmitting(true);
    try {
      const res = await adjustBrandQuota(
        selectedBrand.id,
        selectedBrand.name,
        adjustData.priority,
        adjustData.quantity,
        adjustData.reason.trim(),
        activeBalanceYear
      );
      if (res.success) {
        showToast(
          language === 'id'
            ? `Penyesuaian kuota (${adjustData.quantity > 0 ? `+${adjustData.quantity}` : adjustData.quantity}) berhasil dicatat di ledger.`
            : `Quota adjustment (${adjustData.quantity > 0 ? `+${adjustData.quantity}` : adjustData.quantity}) recorded in the ledger.`,
          'success'
        );
        setIsAdjustModalOpen(false);
        setAdjustData({ priority: 'urgent', quantity: 1, reason: '' });
        loadData();
      } else {
        showToast(res.error || (language === 'id' ? 'Gagal melakukan penyesuaian kuota.' : 'Failed to adjust quota.'), 'error');
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleApplyReconciliation = async () => {
    if (!isSuperAdmin) return;
    const confirmed = window.confirm(
      language === 'id'
        ? `Apakah Anda yakin ingin menerapkan Rekonsiliasi Kuota Historis Tahun ${activeBalanceYear}? Ini akan mencatat tiket ${activeBalanceYear} yang memenuhi syarat ke ledger kuota resmi.`
        : `Are you sure you want to apply Historical ${activeBalanceYear} Quota Reconciliation? This will record eligible ${activeBalanceYear} tickets into the official quota ledger.`
    );
    if (!confirmed) return;

    setIsSubmitting(true);
    try {
      const res = await applyReconciliation(activeBalanceYear);
      if (res.success) {
        showToast(
          language === 'id'
            ? `Rekonsiliasi kuota berhasil diterapkan! ${res.appliedCount} tiket tercatat.`
            : `Quota reconciliation applied! ${res.appliedCount} tickets recorded.`,
          'success'
        );
        loadData();
      } else {
        showToast(res.error || (language === 'id' ? 'Gagal menerapkan rekonsiliasi.' : 'Failed to apply reconciliation.'), 'error');
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  const handlePrintReport = () => {
    window.print();
  };

  const canManage = isSuperAdmin || isAdmin;

  // Determine affected years for multi-year tabs
  const affectedYears =
    periodMode === 'custom_range' && periodMetrics?.affectedYears && periodMetrics.affectedYears.length > 0
      ? periodMetrics.affectedYears
      : [selectedYear];

  const prioLabel = (prio: RequestPriority) => {
    if (language === 'id') {
      return prio === 'urgent' ? 'Mendesak' : prio === 'high' ? 'Tinggi' : prio === 'medium' ? 'Sedang' : 'Rendah';
    }
    return prio.charAt(0).toUpperCase() + prio.slice(1);
  };

  const txTypeLabel = (txType: string) => {
    if (language === 'id') {
      if (txType === 'deduction') return 'Pemakaian';
      if (txType === 'release') return 'Pengembalian';
      if (txType === 'reconciliation') return 'Rekonsiliasi';
      if (txType === 'adjustment') return 'Penyesuaian';
      return txType;
    }
    return txType;
  };

  return (
    <div className="space-y-6">
      {/* SECTION 1: HEADER & REPORTING PERIOD SELECTOR */}
      <div className="p-5 bg-white rounded-2xl border border-slate-200 shadow-xs space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <Layers className="w-5 h-5 text-[#065F46]" />
              <h3 className="text-base sm:text-lg font-bold text-slate-900">
                {language === 'id' ? 'Manajemen & Analitik Kuota Prioritas' : 'Priority Quota Management & Analytics'}
              </h3>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              {language === 'id'
                ? 'Mengatur jatah kuota prioritas tahunan untuk brand Lyman Group dan menganalisis pemakaian kuota berdasarkan periode.'
                : 'Governs annual priority allowances for Lyman Group brands and analyzes period-specific quota velocity.'}
            </p>
          </div>

          {/* Brand Selector & Action Controls */}
          <div className="flex items-center gap-2.5 flex-wrap">
            <div>
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">
                {language === 'id' ? 'Pilih Entitas Brand' : 'Select Brand Entity'}
              </label>
              <select
                value={selectedBrandId}
                onChange={(e) => setSelectedBrandId(e.target.value)}
                className="px-3 py-1.5 text-xs font-bold bg-slate-50 border border-slate-300 rounded-xl focus:bg-white text-slate-900 focus:outline-none focus:ring-1 focus:ring-[#065F46]"
              >
                {brands.map((b) => (
                  <option key={b.id} value={b.id}>
                    {b.name}
                  </option>
                ))}
              </select>
            </div>

            <button
              type="button"
              onClick={handlePrintReport}
              className="px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-300 rounded-xl transition-colors flex items-center gap-1.5 mt-auto"
              title={language === 'id' ? 'Cetak atau Ekspor Laporan PDF' : 'Print or Export PDF Report'}
            >
              <Printer className="w-3.5 h-3.5 text-slate-600" />
              <span>{language === 'id' ? 'Cetak Laporan' : 'Print Report'}</span>
            </button>

            {canManage && (
              <div className="flex items-end gap-1.5 pt-4 md:pt-0">
                <button
                  type="button"
                  onClick={() => setIsEditModalOpen(true)}
                  className="px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-300 rounded-xl transition-colors flex items-center gap-1.5"
                >
                  <Edit2 className="w-3.5 h-3.5 text-slate-600" />
                  <span>{language === 'id' ? 'Ubah Batas' : 'Edit Limits'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => setIsAdjustModalOpen(true)}
                  className="px-3 py-1.5 text-xs font-semibold text-white bg-[#065F46] hover:bg-[#044e39] rounded-xl shadow-xs transition-colors flex items-center gap-1.5"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>{language === 'id' ? 'Sesuaikan Kuota' : 'Adjust Quota'}</span>
                </button>
              </div>
            )}
          </div>
        </div>

        {/* REPORTING PERIOD (WIB) SELECTOR BAR */}
        <div className="pt-3 border-t border-slate-100 flex flex-col lg:flex-row lg:items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Calendar className="w-4 h-4 text-[#065F46]" />
            <span className="text-xs font-extrabold uppercase tracking-wider text-slate-700">
              {language === 'id' ? 'PERIODE PELAPORAN (WIB)' : 'Reporting Period (WIB)'}
            </span>

            {/* Mode Switcher Buttons */}
            <div className="flex items-center p-0.5 bg-slate-100 rounded-lg ml-2">
              <button
                type="button"
                onClick={() => {
                  setPeriodMode('calendar_year');
                  setActiveBalanceYear(selectedYear);
                }}
                className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-colors ${
                  periodMode === 'calendar_year'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {language === 'id' ? 'Tahun Kalender' : 'Calendar Year'}
              </button>
              <button
                type="button"
                onClick={() => setPeriodMode('custom_range')}
                className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-colors ${
                  periodMode === 'custom_range'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {language === 'id' ? 'Rentang Tanggal Kustom' : 'Custom Date Range'}
              </button>
            </div>
          </div>

          {/* Mode Controls */}
          <div className="flex items-center gap-2 flex-wrap">
            {periodMode === 'calendar_year' ? (
              <div className="flex items-center gap-1.5 flex-wrap">
                {!isCustomYearInputOpen ? (
                  <div className="flex items-center bg-slate-50 border border-slate-300 rounded-xl overflow-hidden">
                    <button
                      type="button"
                      onClick={() => handleCalendarYearChange(Math.max(1900, selectedYear - 1))}
                      disabled={selectedYear <= 1900}
                      className="px-2 py-1.5 text-slate-600 hover:text-slate-900 hover:bg-slate-200/70 disabled:opacity-40 transition-colors border-r border-slate-200"
                      title={language === 'id' ? `Tahun sebelumnya (${selectedYear - 1})` : `Previous year (${selectedYear - 1})`}
                      aria-label={language === 'id' ? 'Tahun sebelumnya' : 'Previous year'}
                    >
                      <ChevronLeft className="w-3.5 h-3.5" />
                    </button>
                    <select
                      value={selectedYear}
                      onChange={(e) => {
                        if (e.target.value === '__custom__') {
                          setCustomYearDraft(String(selectedYear));
                          setIsCustomYearInputOpen(true);
                          return;
                        }
                        handleCalendarYearChange(parseInt(e.target.value, 10));
                      }}
                      className="px-3 py-1.5 text-xs font-bold bg-transparent text-slate-900 focus:bg-white focus:outline-none cursor-pointer"
                      aria-label={language === 'id' ? 'Pilih Tahun Kalender' : 'Select Calendar Year'}
                    >
                      {dynamicYearOptions.map((yr) => (
                        <option key={yr} value={yr}>
                          {yr} ({getYearRoleTag(yr)})
                        </option>
                      ))}
                      <option value="__custom__">
                        {language === 'id' ? '+ Ketik Tahun Lain...' : '+ Enter Custom Year...'}
                      </option>
                    </select>
                    <button
                      type="button"
                      onClick={() => handleCalendarYearChange(Math.min(9999, selectedYear + 1))}
                      disabled={selectedYear >= 9999}
                      className="px-2 py-1.5 text-slate-600 hover:text-slate-900 hover:bg-slate-200/70 disabled:opacity-40 transition-colors border-l border-slate-200"
                      title={language === 'id' ? `Tahun berikutnya (${selectedYear + 1})` : `Next year (${selectedYear + 1})`}
                      aria-label={language === 'id' ? 'Tahun berikutnya' : 'Next year'}
                    >
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ) : (
                  <form onSubmit={handleApplyCustomYear} className="flex items-center gap-1.5">
                    <input
                      type="number"
                      min={1900}
                      max={9999}
                      step={1}
                      value={customYearDraft}
                      onChange={(e) => setCustomYearDraft(e.target.value)}
                      placeholder="YYYY"
                      autoFocus
                      className="w-24 px-2.5 py-1.5 text-xs font-mono font-bold bg-white border border-[#065F46] rounded-xl text-slate-900 focus:outline-none focus:ring-1 focus:ring-[#065F46]"
                      aria-label={language === 'id' ? 'Masukkan tahun kalender' : 'Enter calendar year'}
                    />
                    <button
                      type="submit"
                      className="px-2.5 py-1.5 text-xs font-bold text-white bg-[#065F46] hover:bg-[#044e39] rounded-xl transition-colors"
                    >
                      {language === 'id' ? 'Pilih' : 'Go'}
                    </button>
                    <button
                      type="button"
                      onClick={() => setIsCustomYearInputOpen(false)}
                      className="px-2 py-1.5 text-xs font-semibold text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors"
                    >
                      {language === 'id' ? 'Batal' : 'Cancel'}
                    </button>
                  </form>
                )}

                {selectedYear !== currentWibYear && (
                  <button
                    type="button"
                    onClick={() => handleCalendarYearChange(currentWibYear)}
                    className="px-2.5 py-1.5 text-[11px] font-semibold text-[#065F46] bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-xl transition-colors"
                    title={language === 'id' ? `Kembali ke tahun aktif ${currentWibYear}` : `Return to active year ${currentWibYear}`}
                  >
                    {language === 'id' ? `Tahun Aktif (${currentWibYear})` : `Active (${currentWibYear})`}
                  </button>
                )}

                <button
                  type="button"
                  onClick={() => loadData()}
                  className="p-1.5 text-slate-500 hover:text-slate-800 rounded-lg hover:bg-slate-100"
                  title={language === 'id' ? 'Muat ulang data' : 'Refresh data'}
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
                </button>
              </div>
            ) : (
              <form onSubmit={handleApplyCustomFilter} className="flex items-center gap-2 flex-wrap">
                {/* Compact Presets Dropdown */}
                <select
                  value={activePreset}
                  onChange={(e) => handleApplyPreset(e.target.value as DatePreset)}
                  className="px-2.5 py-1.5 text-xs font-medium bg-slate-50 border border-slate-300 rounded-xl text-slate-700 focus:bg-white"
                >
                  <option value="">{language === 'id' ? 'Preset Cepat...' : 'Quick Presets...'}</option>
                  <option value="today">{language === 'id' ? 'Hari Ini' : 'Today'}</option>
                  <option value="last_7_days">{language === 'id' ? '7 Hari Terakhir' : 'Last 7 Days'}</option>
                  <option value="last_30_days">{language === 'id' ? '30 Hari Terakhir' : 'Last 30 Days'}</option>
                  <option value="this_month">{language === 'id' ? 'Bulan Ini' : 'This Month'}</option>
                  <option value="last_month">{language === 'id' ? 'Bulan Lalu' : 'Last Month'}</option>
                  <option value="this_quarter">{language === 'id' ? 'Kuartal Ini' : 'This Quarter'}</option>
                  <option value="this_year">{language === 'id' ? 'Tahun Ini' : 'This Year'}</option>
                  <option value="last_year">{language === 'id' ? 'Tahun Lalu' : 'Last Year'}</option>
                </select>

                <div className="flex items-center gap-1 text-xs text-slate-500">
                  <span className="text-[10px] font-bold uppercase text-slate-400">
                    {language === 'id' ? 'Dari' : 'From'}
                  </span>
                  <input
                    type="date"
                    value={startDate}
                    onChange={(e) => {
                      setStartDate(e.target.value);
                      setActivePreset('');
                    }}
                    required
                    className="px-2.5 py-1 text-xs font-mono font-medium bg-white border border-slate-300 rounded-xl text-slate-800"
                  />
                  <span className="text-[10px] font-bold uppercase text-slate-400">
                    {language === 'id' ? 'S/d' : 'To'}
                  </span>
                  <input
                    type="date"
                    value={endDate}
                    onChange={(e) => {
                      setEndDate(e.target.value);
                      setActivePreset('');
                    }}
                    required
                    className="px-2.5 py-1 text-xs font-mono font-medium bg-white border border-slate-300 rounded-xl text-slate-800"
                  />
                </div>

                <button
                  type="submit"
                  disabled={isLoading}
                  className="px-3 py-1.5 text-xs font-bold text-white bg-[#065F46] hover:bg-[#044e39] rounded-xl transition-colors shadow-xs"
                >
                  {language === 'id' ? 'Terapkan' : 'Apply'}
                </button>
                <button
                  type="button"
                  onClick={handleResetFilter}
                  className="px-2.5 py-1.5 text-xs font-semibold text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors"
                >
                  {language === 'id' ? 'Atur Ulang' : 'Reset'}
                </button>
              </form>
            )}
          </div>
        </div>
      </div>

      {/* SECTION 2: ANNUAL QUOTA BALANCE CONTAINER (ARCHITECTURALLY SEPARATE) */}
      <div className="p-5 bg-white rounded-2xl border border-slate-200 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-slate-200 gap-3">
          <div>
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-[#10B981]" />
              <h4 className="text-sm font-extrabold text-slate-900 uppercase tracking-wide">
                {language === 'id' ? 'SALDO KUOTA TAHUNAN' : 'Annual Quota Balance'}
              </h4>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              {language === 'id'
                ? `Batas kuota tahunan resmi untuk ${selectedBrand?.name} (${activeBalanceYear}). Saldo kuota merupakan jatah penuh satu tahun kalender dan tidak pernah berubah oleh filter tanggal laporan.`
                : `Authoritative annual limits for ${selectedBrand?.name} (${activeBalanceYear}). Quota balances represent full calendar-year allowances and are never altered by reporting date ranges.`}
            </p>
          </div>

          {/* Multi-Year Grouped Tabs (shown when date range spans multiple calendar years) */}
          {affectedYears.length > 1 && (
            <div className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-xl">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 px-2">
                {language === 'id' ? 'Tahun Kuota:' : 'Quota Year:'}
              </span>
              {affectedYears.map((yr) => (
                <button
                  key={yr}
                  type="button"
                  onClick={() => setActiveBalanceYear(yr)}
                  className={`px-3 py-1 text-xs font-bold rounded-lg transition-colors ${
                    activeBalanceYear === yr
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {yr}{' '}
                  {yr === currentWibYear
                    ? (language === 'id' ? '(Aktif)' : '(Active)')
                    : yr < currentWibYear
                    ? (language === 'id' ? '(Historis)' : '(Historical)')
                    : (language === 'id' ? '(Mendatang)' : '(Upcoming)')}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Priority Status Cards for Active Balance Year */}
        {currentSummary ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {(['urgent', 'high', 'medium', 'low'] as RequestPriority[]).map((prio) => {
              const info = currentSummary.priorities[prio];
              const isUnlimited = info?.annualLimit === -1 || prio === 'low';
              const isExhausted = Boolean(info?.isExhausted);
              const isWarning = info?.remaining === 1;

              return (
                <div
                  key={prio}
                  className={`p-4 rounded-xl border bg-white shadow-xs space-y-3 relative overflow-hidden ${
                    isExhausted
                      ? 'border-rose-300 bg-rose-50/20'
                      : isWarning
                      ? 'border-amber-300 bg-amber-50/20'
                      : 'border-slate-200'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span
                        className={`w-2.5 h-2.5 rounded-full ${
                          prio === 'urgent'
                            ? 'bg-rose-500'
                            : prio === 'high'
                            ? 'bg-amber-500'
                            : prio === 'medium'
                            ? 'bg-blue-500'
                            : 'bg-slate-400'
                        }`}
                      />
                      <h5 className="font-extrabold text-sm text-slate-900">
                        {language === 'id' ? `Prioritas ${prioLabel(prio)}` : `${prioLabel(prio)} Priority`}
                      </h5>
                    </div>
                    <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-md bg-slate-100 text-slate-700">
                      SLA: {info?.slaDays} {language === 'id' ? 'Hari' : 'Days'}
                    </span>
                  </div>

                  <div>
                    <div className="text-2xl font-extrabold font-mono text-slate-900 tabular-nums">
                      {isUnlimited ? (
                        language === 'id' ? 'Tanpa Batas' : 'Unlimited'
                      ) : (
                        <span>
                          {info.remaining}{' '}
                          <span className="text-xs font-normal text-slate-400">
                            / {info.annualLimit} {language === 'id' ? 'tersisa' : 'remaining'}
                          </span>
                        </span>
                      )}
                    </div>
                    <div className="text-[11px] text-slate-500 mt-1 flex items-center justify-between">
                      <span>
                        {language === 'id' ? 'Terpakai Tahunan:' : 'Annual Used:'}{' '}
                        {isUnlimited ? '—' : `${info.used} ${language === 'id' ? 'permintaan' : 'requests'}`}
                      </span>
                      {!isUnlimited && (
                        <span className="font-mono font-bold text-slate-700">
                          {info.utilizationPercent}% {language === 'id' ? 'Terpakai' : 'Used'}
                        </span>
                      )}
                    </div>
                  </div>

                  {!isUnlimited && (
                    <div className="w-full h-1.5 rounded-full bg-slate-100 overflow-hidden">
                      <div
                        className={`h-full transition-all duration-500 rounded-full ${
                          isExhausted
                            ? 'bg-rose-600'
                            : isWarning
                            ? 'bg-amber-500'
                            : 'bg-[#10B981]'
                        }`}
                        style={{ width: `${info.utilizationPercent}%` }}
                      />
                    </div>
                  )}

                  <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs">
                    <span className="text-[11px] text-slate-500">
                      {language === 'id' ? 'Status Pengajuan:' : 'Submission Status:'}
                    </span>
                    {isExhausted ? (
                      <span className="text-[10px] font-bold text-rose-700 bg-rose-50 border border-rose-200 px-2 py-0.5 rounded-md">
                        {language === 'id' ? 'Kuota Habis' : 'Quota Exhausted'}
                      </span>
                    ) : isWarning ? (
                      <span className="text-[10px] font-bold text-amber-700 bg-amber-50 border border-amber-200 px-2 py-0.5 rounded-md flex items-center gap-1">
                        <AlertTriangle className="w-3 h-3 text-amber-600" />
                        <span>{language === 'id' ? 'Sisa 1 Unit' : '1 Unit Left'}</span>
                      </span>
                    ) : isUnlimited ? (
                      <span className="text-[10px] font-medium text-slate-600 bg-slate-100 px-2 py-0.5 rounded-md">
                        {language === 'id' ? 'Kapasitas Standar' : 'Baseline Capacity'}
                      </span>
                    ) : (
                      <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-md">
                        {language === 'id' ? 'Tersedia' : 'Available'}
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="py-6 text-center text-xs text-slate-400 italic">
            {language === 'id'
              ? `Memuat data kuota tahunan untuk ${activeBalanceYear}...`
              : `Loading annual quota data for ${activeBalanceYear}...`}
          </div>
        )}
      </div>

      {/* SECTION 3: PERIOD USAGE & AUDIT METRICS */}
      <div className="p-5 bg-white rounded-2xl border border-slate-200 shadow-xs space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-slate-200 gap-2">
          <div className="flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-[#065F46]" />
            <div>
              <h4 className="text-sm font-bold text-slate-900">
                {language === 'id' ? 'Penggunaan Periode & Metrik Pelaporan' : 'Period Usage & Reporting Metrics'}
              </h4>
              <p className="text-xs text-slate-500">
                {periodMode === 'custom_range'
                  ? (language === 'id'
                    ? `Aktivitas dalam rentang: ${startDate} s/d ${endDate} (WIB)`
                    : `Activity within interval: ${startDate} to ${endDate} (WIB)`)
                  : (language === 'id'
                    ? `Aktivitas untuk satu tahun kalender penuh: ${selectedYear} (WIB)`
                    : `Activity for full calendar year: ${selectedYear} (WIB)`)}
              </p>
            </div>
          </div>
          <span className="text-xs font-mono font-bold text-slate-600 bg-slate-50 px-2.5 py-1 rounded-lg border border-slate-200">
            {periodMetrics?.totalRequestCount ?? 0} {language === 'id' ? 'Permintaan Tercatat' : 'Requests Recorded'}
          </span>
        </div>

        {/* 5 KPI Metric Tiles */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
          <div className="p-3.5 rounded-xl border border-slate-200 bg-slate-50/50">
            <div className="text-[10px] font-bold uppercase tracking-wider text-slate-500">
              {language === 'id' ? 'Jumlah Permintaan Periode' : 'Period Request Count'}
            </div>
            <div className="text-xl font-extrabold font-mono text-slate-900 mt-1 tabular-nums">
              {periodMetrics?.totalRequestCount ?? 0}
            </div>
            <div className="text-[10px] text-slate-400 mt-0.5">
              {language === 'id' ? 'Permintaan utama diajukan' : 'Parent requests submitted'}
            </div>
          </div>

          <div className="p-3.5 rounded-xl border border-slate-200 bg-slate-50/50">
            <div className="text-[10px] font-bold uppercase tracking-wider text-rose-600">
              {language === 'id' ? 'Pemakaian Kuota Periode' : 'Period Quota Consumption'}
            </div>
            <div className="text-xl font-extrabold font-mono text-rose-700 mt-1 tabular-nums">
              {periodMetrics?.totalConsumed ?? 0}
            </div>
            <div className="text-[10px] text-slate-400 mt-0.5">
              {language === 'id' ? 'Pengurangan prioritas dipercepat' : 'Expedited priority deductions'}
            </div>
          </div>

          <div className="p-3.5 rounded-xl border border-slate-200 bg-slate-50/50">
            <div className="text-[10px] font-bold uppercase tracking-wider text-emerald-600">
              {language === 'id' ? 'Pengembalian Kuota Periode' : 'Period Quota Releases'}
            </div>
            <div className="text-xl font-extrabold font-mono text-emerald-700 mt-1 tabular-nums">
              {periodMetrics?.totalReleased ?? 0}
            </div>
            <div className="text-[10px] text-slate-400 mt-0.5">
              {language === 'id' ? 'Realokasi prioritas / pengembalian' : 'Priority reallocations / refunds'}
            </div>
          </div>

          <div className="p-3.5 rounded-xl border border-slate-200 bg-slate-50/50">
            <div className="text-[10px] font-bold uppercase tracking-wider text-blue-600">
              {language === 'id' ? 'Penyesuaian Periode' : 'Period Adjustments'}
            </div>
            <div className="text-xl font-extrabold font-mono text-blue-700 mt-1 tabular-nums">
              {periodMetrics ? (periodMetrics.totalAdjusted > 0 ? `+${periodMetrics.totalAdjusted}` : periodMetrics.totalAdjusted) : 0}
            </div>
            <div className="text-[10px] text-slate-400 mt-0.5">
              {language === 'id' ? 'Koreksi administratif' : 'Administrative corrections'}
            </div>
          </div>

          <div className="p-3.5 rounded-xl border border-slate-200 bg-slate-50/50 col-span-2 sm:col-span-1">
            <div className="text-[10px] font-bold uppercase tracking-wider text-slate-800">
              {language === 'id' ? 'Pemakaian Kuota Bersih' : 'Period Net Quota Usage'}
            </div>
            <div className="text-xl font-extrabold font-mono text-slate-900 mt-1 tabular-nums">
              {periodMetrics?.totalNetUsage ?? 0}
            </div>
            <div className="text-[10px] text-slate-400 mt-0.5">
              {language === 'id' ? 'Unit bersih terpakai pada periode' : 'Net units used during period'}
            </div>
          </div>
        </div>

        {/* Priority Usage Breakdown in Period */}
        {periodMetrics && (
          <div className="overflow-x-auto rounded-xl border border-slate-200 text-xs">
            <table className="w-full text-left">
              <thead className="bg-slate-50 text-slate-600 font-bold uppercase text-[10px] tracking-wider border-b border-slate-200">
                <tr>
                  <th className="py-2.5 px-3">{language === 'id' ? 'Tingkat Prioritas' : 'Priority Tier'}</th>
                  <th className="py-2.5 px-3 text-center">{language === 'id' ? 'Permintaan pada Periode' : 'Requests in Period'}</th>
                  <th className="py-2.5 px-3 text-center">{language === 'id' ? 'Terpakai' : 'Consumed'}</th>
                  <th className="py-2.5 px-3 text-center">{language === 'id' ? 'Dikembalikan' : 'Released'}</th>
                  <th className="py-2.5 px-3 text-center">{language === 'id' ? 'Disesuaikan' : 'Adjusted'}</th>
                  <th className="py-2.5 px-3 text-right">{language === 'id' ? 'Perubahan Bersih Periode' : 'Net Period Change'}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-mono">
                {(['urgent', 'high', 'medium', 'low'] as RequestPriority[]).map((prio) => {
                  const m = periodMetrics.priorities[prio];
                  return (
                    <tr key={prio} className="hover:bg-slate-50/60 font-sans">
                      <td className="py-2.5 px-3 font-semibold text-slate-900 flex items-center gap-2">
                        <span
                          className={`w-2 h-2 rounded-full ${
                            prio === 'urgent'
                              ? 'bg-rose-500'
                              : prio === 'high'
                              ? 'bg-amber-500'
                              : prio === 'medium'
                              ? 'bg-blue-500'
                              : 'bg-slate-400'
                          }`}
                        />
                        <span>{prioLabel(prio)}</span>
                      </td>
                      <td className="py-2.5 px-3 text-center font-mono">{m?.requestCount ?? 0}</td>
                      <td className="py-2.5 px-3 text-center font-mono text-rose-600">
                        {m?.consumed ? `-${m.consumed}` : '0'}
                      </td>
                      <td className="py-2.5 px-3 text-center font-mono text-emerald-600">
                        {m?.released ? `+${m.released}` : '0'}
                      </td>
                      <td className="py-2.5 px-3 text-center font-mono text-blue-600">
                        {m?.adjusted ? (m.adjusted > 0 ? `+${m.adjusted}` : String(m.adjusted)) : '0'}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono font-bold text-slate-900">
                        {m?.netUsage ?? 0}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* SECTION 4: HISTORICAL RECONCILIATION GATE (SUPER ADMIN) */}
      {isSuperAdmin && reconciliationPreview && (
        <div className="p-5 bg-white rounded-2xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-200 flex-wrap gap-2">
            <div className="flex items-center gap-2">
              <FileCheck2 className="w-5 h-5 text-blue-600" />
              <div>
                <h4 className="text-sm font-bold text-slate-900">
                  {language === 'id'
                    ? `Rekonsiliasi Permintaan Historis ${activeBalanceYear} (Gerbang Persetujuan)`
                    : `Historical ${activeBalanceYear} Request Reconciliation (Approval Gate)`}
                </h4>
                <p className="text-xs text-slate-500">
                  {language === 'id'
                    ? `Periksa Permintaan Utama aktif yang diajukan pada ${activeBalanceYear} untuk merekonsiliasi saldo buku besar kuota resmi.`
                    : `Inspect non-deleted Parent Requests submitted in ${activeBalanceYear} to reconcile authoritative quota ledger balances.`}
                </p>
              </div>
            </div>

            <div>
              {reconciliationPreview.isApplied ? (
                <div className="flex items-center gap-2 text-xs font-bold text-emerald-800 bg-emerald-50 border border-emerald-200 px-3 py-1.5 rounded-xl">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>
                    {language === 'id'
                      ? `Rekonsiliasi Diterapkan (${reconciliationPreview.appliedBy})`
                      : `Reconciliation Applied (${reconciliationPreview.appliedBy})`}
                  </span>
                </div>
              ) : (
                <button
                  type="button"
                  onClick={handleApplyReconciliation}
                  disabled={isSubmitting}
                  className="px-4 py-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-xs transition-colors flex items-center gap-1.5 disabled:opacity-50"
                >
                  <FileCheck2 className="w-4 h-4" />
                  <span>
                    {language === 'id'
                      ? 'Terapkan Rekonsiliasi (Persetujuan Super Admin)'
                      : 'Apply Reconciliation (Super Admin Approval)'}
                  </span>
                </button>
              )}
            </div>
          </div>

          <div className="overflow-x-auto rounded-xl border border-slate-200 text-xs">
            <table className="w-full text-left">
              <thead className="bg-slate-50 text-slate-600 font-bold uppercase text-[10px] tracking-wider border-b border-slate-200">
                <tr>
                  <th className="py-2.5 px-3">{language === 'id' ? 'Entitas Brand' : 'Brand Entity'}</th>
                  <th className="py-2.5 px-3 text-center">
                    {language === 'id' ? 'Mendesak (Terpakai/Batas)' : 'Urgent (Used/Limit)'}
                  </th>
                  <th className="py-2.5 px-3 text-center">
                    {language === 'id' ? 'Tinggi (Terpakai/Batas)' : 'High (Used/Limit)'}
                  </th>
                  <th className="py-2.5 px-3 text-center">
                    {language === 'id' ? 'Sedang (Terpakai/Batas)' : 'Medium (Used/Limit)'}
                  </th>
                  <th className="py-2.5 px-3 text-right">
                    {language === 'id' ? 'Permintaan Memenuhi Syarat' : 'Eligible Requests'}
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {reconciliationPreview.brands.map((b) => {
                  const urgent = b.priorities.find((p) => p.priority === 'urgent');
                  const high = b.priorities.find((p) => p.priority === 'high');
                  const med = b.priorities.find((p) => p.priority === 'medium');
                  const total = (urgent?.requestCount || 0) + (high?.requestCount || 0) + (med?.requestCount || 0);

                  return (
                    <tr key={b.brandId} className="hover:bg-slate-50/60">
                      <td className="py-2.5 px-3 font-semibold text-slate-900">{b.brandName}</td>
                      <td className="py-2.5 px-3 text-center font-mono">
                        {urgent?.projectedUsage} / {urgent?.limit}
                      </td>
                      <td className="py-2.5 px-3 text-center font-mono">
                        {high?.projectedUsage} / {high?.limit}
                      </td>
                      <td className="py-2.5 px-3 text-center font-mono">
                        {med?.projectedUsage} / {med?.limit}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono font-bold text-blue-700">
                        {total} {language === 'id' ? 'permintaan' : 'requests'}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* SECTION 5: PERIOD-FILTERED AUDIT LEDGER TABLE */}
      <div className="p-5 bg-white rounded-2xl border border-slate-200 shadow-xs space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-200">
          <div className="flex items-center gap-2">
            <History className="w-5 h-5 text-slate-700" />
            <h4 className="text-sm font-bold text-slate-900">
              {language === 'id' ? 'Transaksi Buku Besar Audit Periode' : 'Period Audit Ledger Transactions'}
            </h4>
          </div>
          <span className="text-xs text-slate-500 font-mono">
            {periodMetrics?.ledgerEntries.length ?? 0}{' '}
            {language === 'id' ? 'transaksi pada periode terpilih' : 'transactions in selected period'}
          </span>
        </div>

        {(!periodMetrics || periodMetrics.ledgerEntries.length === 0) ? (
          <div className="py-8 text-center text-xs text-slate-400 italic">
            {language === 'id'
              ? `Tidak ada transaksi kuota yang tercatat untuk ${selectedBrand?.name} pada periode pelaporan yang dipilih.`
              : `No quota transactions logged for ${selectedBrand?.name} within the selected reporting period.`}
          </div>
        ) : (
          <div className="overflow-x-auto rounded-xl border border-slate-200 text-xs">
            <table className="w-full text-left">
              <thead className="bg-slate-50 text-slate-600 font-bold uppercase text-[10px] tracking-wider border-b border-slate-200">
                <tr>
                  <th className="py-2.5 px-3">{language === 'id' ? 'Tanggal (WIB)' : 'Date (WIB)'}</th>
                  <th className="py-2.5 px-3">{language === 'id' ? 'Transaksi' : 'Transaction'}</th>
                  <th className="py-2.5 px-3">{language === 'id' ? 'Prioritas' : 'Priority'}</th>
                  <th className="py-2.5 px-3 text-center">{language === 'id' ? 'Jml' : 'Qty'}</th>
                  <th className="py-2.5 px-3">{language === 'id' ? 'Tiket / Ref' : 'Ticket / Ref'}</th>
                  <th className="py-2.5 px-3">{language === 'id' ? 'Aktor' : 'Actor'}</th>
                  <th className="py-2.5 px-3">{language === 'id' ? 'Justifikasi / Alasan' : 'Justification / Reason'}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {periodMetrics.ledgerEntries.map((e) => (
                  <tr key={e.id} className="hover:bg-slate-50/60">
                    <td className="py-2.5 px-3 font-mono text-[11px] text-slate-600 whitespace-nowrap">
                      {new Date(e.createdAt).toLocaleString(language === 'id' ? 'id-ID' : 'en-GB', {
                        timeZone: 'Asia/Jakarta',
                        day: '2-digit',
                        month: 'short',
                        year: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </td>
                    <td className="py-2.5 px-3">
                      <span
                        className={`inline-block px-2 py-0.5 text-[10px] font-bold rounded-md uppercase tracking-wider ${
                          e.transactionType === 'deduction'
                            ? 'bg-rose-50 text-rose-700 border border-rose-200'
                            : e.transactionType === 'release'
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : e.transactionType === 'reconciliation'
                            ? 'bg-blue-50 text-blue-700 border border-blue-200'
                            : 'bg-purple-50 text-purple-700 border border-purple-200'
                        }`}
                      >
                        {txTypeLabel(e.transactionType)}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 font-semibold text-slate-900">
                      {prioLabel(e.priority)}
                    </td>
                    <td className="py-2.5 px-3 text-center font-mono font-bold">
                      <span
                        className={
                          e.quantity < 0
                            ? 'text-rose-600'
                            : e.quantity > 0
                            ? 'text-emerald-600'
                            : 'text-slate-600'
                        }
                      >
                        {e.quantity > 0 ? `+${e.quantity}` : e.quantity}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 font-mono text-slate-700">
                      {e.ticketNumber || '—'}
                    </td>
                    <td className="py-2.5 px-3 text-slate-700">
                      <span className="font-medium">{e.actorName}</span>
                      <span className="text-[10px] text-slate-400 block capitalize">
                        {e.actorRole.replace('_', ' ')}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-slate-600 max-w-xs truncate" title={e.reason}>
                      {e.reason}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* MODAL 1: EDIT LIMITS */}
      {isEditModalOpen && selectedBrand && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl max-w-md w-full shadow-2xl border border-slate-200 overflow-hidden">
            <div className="p-5 border-b border-slate-200 flex items-center justify-between">
              <div>
                <h4 className="text-base font-bold text-slate-900">
                  {language === 'id' ? 'Ubah Batas Kuota Tahunan' : 'Edit Annual Quota Limits'}
                </h4>
                <p className="text-xs text-slate-500">
                  {selectedBrand.name} · {language === 'id' ? 'Tahun' : 'Year'} {activeBalanceYear}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setIsEditModalOpen(false)}
                className="text-slate-400 hover:text-slate-700 p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveLimits} className="p-5 space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {language === 'id' ? 'Batas Prioritas Mendesak (SLA 1 Hari)' : 'Urgent Priority Limit (1 Day SLA)'}
                </label>
                <input
                  type="number"
                  min="0"
                  max="9999"
                  value={editLimits.urgent}
                  onChange={(e) => setEditLimits({ ...editLimits, urgent: parseInt(e.target.value, 10) || 0 })}
                  className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-300 rounded-xl font-mono text-slate-900"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {language === 'id' ? 'Batas Prioritas Tinggi (SLA 3 Hari)' : 'High Priority Limit (3 Days SLA)'}
                </label>
                <input
                  type="number"
                  min="0"
                  max="9999"
                  value={editLimits.high}
                  onChange={(e) => setEditLimits({ ...editLimits, high: parseInt(e.target.value, 10) || 0 })}
                  className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-300 rounded-xl font-mono text-slate-900"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {language === 'id' ? 'Batas Prioritas Sedang (SLA 7 Hari)' : 'Medium Priority Limit (7 Days SLA)'}
                </label>
                <input
                  type="number"
                  min="0"
                  max="9999"
                  value={editLimits.medium}
                  onChange={(e) => setEditLimits({ ...editLimits, medium: parseInt(e.target.value, 10) || 0 })}
                  className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-300 rounded-xl font-mono text-slate-900"
                  required
                />
              </div>

              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-500">
                {language === 'id'
                  ? 'Prioritas Rendah (SLA 14 Hari) merupakan standar dasar dan tetap tanpa batas.'
                  : 'Low Priority (14 Days SLA) is the standard baseline and remains unlimited.'}
              </div>

              <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsEditModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
                >
                  {language === 'id' ? 'Batal' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-4 py-2 text-xs font-bold text-white bg-[#065F46] hover:bg-[#044e39] rounded-xl shadow-xs disabled:opacity-50"
                >
                  {language === 'id' ? 'Simpan Batas Kuota' : 'Save Quota Limits'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 2: MANUAL ADJUSTMENT */}
      {isAdjustModalOpen && selectedBrand && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl max-w-md w-full shadow-2xl border border-slate-200 overflow-hidden">
            <div className="p-5 border-b border-slate-200 flex items-center justify-between">
              <div>
                <h4 className="text-base font-bold text-slate-900">
                  {language === 'id' ? 'Penyesuaian Kuota Manual' : 'Manual Quota Adjustment'}
                </h4>
                <p className="text-xs text-slate-500">
                  {selectedBrand.name} · {language === 'id' ? 'Tahun' : 'Year'} {activeBalanceYear}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setIsAdjustModalOpen(false)}
                className="text-slate-400 hover:text-slate-700 p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAdjustQuota} className="p-5 space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {language === 'id' ? 'Target Tingkat Prioritas' : 'Target Priority Tier'}
                </label>
                <select
                  value={adjustData.priority}
                  onChange={(e) => setAdjustData({ ...adjustData, priority: e.target.value as RequestPriority })}
                  className="w-full px-3 py-2 text-xs font-bold bg-slate-50 border border-slate-300 rounded-xl text-slate-900"
                >
                  <option value="urgent">
                    {language === 'id' ? 'Prioritas Mendesak (SLA 1 Hari)' : 'Urgent Priority (1 Day SLA)'}
                  </option>
                  <option value="high">
                    {language === 'id' ? 'Prioritas Tinggi (SLA 3 Hari)' : 'High Priority (3 Days SLA)'}
                  </option>
                  <option value="medium">
                    {language === 'id' ? 'Prioritas Sedang (SLA 7 Hari)' : 'Medium Priority (7 Days SLA)'}
                  </option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {language === 'id' ? 'Jenis Penyesuaian & Jumlah' : 'Adjustment Type & Quantity'}
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setAdjustData({ ...adjustData, quantity: 1 })}
                    className={`p-2.5 text-xs font-bold rounded-xl border flex items-center justify-center gap-1.5 transition-colors ${
                      adjustData.quantity > 0
                        ? 'border-emerald-500 bg-emerald-50 text-emerald-800'
                        : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    <Plus className="w-4 h-4 text-emerald-600" />
                    <span>{language === 'id' ? '+1 Kembalikan / Tambah' : '+1 Refund / Add'}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setAdjustData({ ...adjustData, quantity: -1 })}
                    className={`p-2.5 text-xs font-bold rounded-xl border flex items-center justify-center gap-1.5 transition-colors ${
                      adjustData.quantity < 0
                        ? 'border-rose-500 bg-rose-50 text-rose-800'
                        : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    <Minus className="w-4 h-4 text-rose-600" />
                    <span>{language === 'id' ? '-1 Kurangi' : '-1 Deduct'}</span>
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {language === 'id' ? 'Justifikasi / Alasan Wajib' : 'Mandatory Justification / Reason'}{' '}
                  <span className="text-rose-500">*</span>
                </label>
                <textarea
                  value={adjustData.reason}
                  onChange={(e) => setAdjustData({ ...adjustData, reason: e.target.value })}
                  placeholder={
                    language === 'id'
                      ? 'Contoh: Refund kuota Mendesak karena pembatalan event resmi direksi (min. 5 karakter)...'
                      : 'e.g., Refund Urgent quota due to official board event cancellation (min. 5 characters)...'
                  }
                  className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-xl text-slate-900 h-20"
                  required
                  minLength={5}
                />
              </div>

              <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAdjustModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
                >
                  {language === 'id' ? 'Batal' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting || adjustData.reason.trim().length < 5}
                  className="px-4 py-2 text-xs font-bold text-white bg-[#065F46] hover:bg-[#044e39] rounded-xl shadow-xs disabled:opacity-50"
                >
                  {language === 'id' ? 'Simpan Penyesuaian' : 'Save Adjustment'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
