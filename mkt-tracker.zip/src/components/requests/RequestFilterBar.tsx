import {
  Search,
  Filter,
  X,
  Table,
  Kanban,
  AlertTriangle,
  RotateCcw,
  Calendar,
  Download,
  User,
} from 'lucide-react';
import { useRequests } from '../../context/RequestContext';
import { useAuth } from '../../context/AuthContext';
import { useLanguage } from '../../context/LanguageContext';
import { RequestStatus, RequestPriority, FilterState } from '../../types';

interface RequestFilterBarProps {
  viewMode: 'table' | 'kanban';
  onChangeViewMode: (mode: 'table' | 'kanban') => void;
  onExportCsv: () => void;
  totalFilteredCount: number;
  hideCompletedStatusFilter?: boolean;
  hideStatusFilter?: boolean;
  hideViewModeToggle?: boolean;
}

export const RequestFilterBar: React.FC<RequestFilterBarProps> = ({
  viewMode,
  onChangeViewMode,
  onExportCsv,
  totalFilteredCount,
  hideCompletedStatusFilter = false,
  hideStatusFilter = false,
  hideViewModeToggle = false,
}) => {
  const { filters, setFilters, resetFilters, regions, brands, categories, teams } = useRequests();
  const { allUsers } = useAuth();
  const { t, isIndonesian } = useLanguage();

  const allStatusOptions: { value: RequestStatus | 'all'; label: string }[] = [
    { value: 'all', label: t('status.all') },
    { value: 'todo', label: t('status.todo') },
    { value: 'in_progress', label: t('status.in_progress') },
    { value: 'pending_review', label: t('status.pending_review') },
    { value: 'revision', label: t('status.revision') },
    { value: 'on_hold', label: t('status.on_hold') },
    { value: 'completed', label: t('status.completed') },
    { value: 'cancelled', label: t('status.cancelled') },
  ];

  const statusOptions = hideCompletedStatusFilter
    ? allStatusOptions.filter((opt) => opt.value !== 'completed')
    : allStatusOptions;

  const priorityOptions: { value: RequestPriority | 'all'; label: string }[] = [
    { value: 'all', label: t('priority.all') },
    { value: 'urgent', label: t('priority.urgent') },
    { value: 'high', label: t('priority.high') },
    { value: 'medium', label: t('priority.medium') },
    { value: 'low', label: t('priority.low') },
  ];

  const isFiltered =
    filters.search !== '' ||
    filters.status !== 'all' ||
    filters.priority !== 'all' ||
    filters.regionId !== 'all' ||
    filters.brandId !== 'all' ||
    filters.categoryId !== 'all' ||
    filters.assignedTeamId !== 'all' ||
    filters.assigneeId !== 'all' ||
    (!!filters.requesterId && filters.requesterId !== 'all') ||
    filters.overdueOnly ||
    filters.dateRange !== 'all';

  // Filter brands according to selected region
  const availableBrands =
    filters.regionId === 'all'
      ? brands
      : brands.filter((b) => b.regionId === filters.regionId);

  return (
    <div className="bg-white rounded-2xl border border-slate-200 p-3.5 sm:p-4 shadow-xs space-y-3">
      {/* Top Row: Search, Segmented View Mode, and CSV Export */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5">
        {/* Search Input */}
        <div className="relative flex-1 min-w-0">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none shrink-0" />
          <input
            type="text"
            value={filters.search}
            onChange={(e) => setFilters((prev) => ({ ...prev, search: e.target.value }))}
            placeholder={t('filter.searchPlaceholder')}
            className="w-full pl-9 pr-8 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-[#065F46]/20 focus:border-[#065F46] transition-colors"
          />
          {filters.search && (
            <button
              onClick={() => setFilters((prev) => ({ ...prev, search: '' }))}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-1"
              aria-label={isIndonesian ? 'Hapus pencarian' : 'Clear search'}
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* View Switcher & CSV Export Buttons */}
        <div className="flex items-center justify-between sm:justify-end gap-2 shrink-0">
          <button
            onClick={onExportCsv}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-xl transition-colors shrink-0"
            title={isIndonesian ? 'Ekspor data terfilter ke CSV' : 'Export filtered data to CSV'}
          >
            <Download className="w-3.5 h-3.5 text-slate-500 shrink-0" />
            <span className="hidden md:inline">{t('filter.exportCsv')}</span>
            <span className="md:hidden">CSV</span>
          </button>

          {/* Segmented View Mode */}
          {!hideViewModeToggle && (
            <div className="flex items-center p-0.5 sm:p-1 bg-slate-100 rounded-xl border border-slate-200/80 shrink-0">
              <button
                onClick={() => onChangeViewMode('table')}
                className={`flex items-center gap-1.5 px-2.5 sm:px-3 py-1 text-xs font-semibold rounded-lg transition-colors ${
                  viewMode === 'table'
                    ? 'bg-white text-[#065F46] font-bold shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Table className="w-3.5 h-3.5 shrink-0" />
                <span>{isIndonesian ? 'Tabel' : 'Table'}</span>
              </button>
              <button
                onClick={() => onChangeViewMode('kanban')}
                className={`flex items-center gap-1.5 px-2.5 sm:px-3 py-1 text-xs font-semibold rounded-lg transition-colors ${
                  viewMode === 'kanban'
                    ? 'bg-white text-[#065F46] font-bold shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Kanban className="w-3.5 h-3.5 shrink-0" />
                <span>Kanban</span>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Second Row: Structured Responsive Filter Grid */}
      <div className="pt-2.5 border-t border-slate-100">
        <div
          className={`grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2 text-xs ${
            hideStatusFilter ? 'lg:grid-cols-4 xl:grid-cols-8' : 'lg:grid-cols-5 xl:grid-cols-9'
          }`}
        >
          {/* Status Dropdown */}
          {!hideStatusFilter && (
            <select
              value={filters.status}
              onChange={(e) =>
                setFilters((prev) => ({ ...prev, status: e.target.value as RequestStatus | 'all' }))
              }
              className="w-full h-8.5 px-2 bg-slate-50 hover:bg-white border border-slate-200 rounded-lg text-slate-700 font-medium focus:outline-hidden focus:border-blue-600 cursor-pointer transition-colors truncate"
            >
              {statusOptions.map((opt) => (
                <option key={opt.value} value={opt.value}>
                  {opt.label}
                </option>
              ))}
            </select>
          )}

          {/* Region Dropdown */}
          <select
            value={filters.regionId}
            onChange={(e) =>
              setFilters((prev) => ({
                ...prev,
                regionId: e.target.value,
                brandId: 'all',
              }))
            }
            className="w-full h-8.5 px-2 bg-slate-50 hover:bg-white border border-slate-200 rounded-lg text-slate-700 font-medium focus:outline-hidden focus:border-blue-600 cursor-pointer transition-colors truncate"
          >
            <option value="all">{t('filter.allRegions')}</option>
            {regions.map((reg) => (
              <option key={reg.id} value={reg.id}>
                {reg.name}
              </option>
            ))}
          </select>

          {/* Brand Dropdown */}
          <select
            value={filters.brandId}
            onChange={(e) => setFilters((prev) => ({ ...prev, brandId: e.target.value }))}
            className="w-full h-8.5 px-2 bg-slate-50 hover:bg-white border border-slate-200 rounded-lg text-slate-700 font-medium focus:outline-hidden focus:border-blue-600 cursor-pointer transition-colors truncate"
          >
            <option value="all">{t('filter.allBrands')}</option>
            {availableBrands.map((b) => (
              <option key={b.id} value={b.id}>
                {b.name}
              </option>
            ))}
          </select>

          {/* Category Dropdown */}
          <select
            value={filters.categoryId}
            onChange={(e) => setFilters((prev) => ({ ...prev, categoryId: e.target.value }))}
            className="w-full h-8.5 px-2 bg-slate-50 hover:bg-white border border-slate-200 rounded-lg text-slate-700 font-medium focus:outline-hidden focus:border-blue-600 cursor-pointer transition-colors truncate"
          >
            <option value="all">{t('filter.allCategories')}</option>
            {categories.map((cat) => (
              <option key={cat.id} value={cat.id}>
                {cat.name}
              </option>
            ))}
          </select>

          {/* Team Dropdown */}
          <select
            value={filters.assignedTeamId}
            onChange={(e) => setFilters((prev) => ({ ...prev, assignedTeamId: e.target.value }))}
            className="w-full h-8.5 px-2 bg-slate-50 hover:bg-white border border-slate-200 rounded-lg text-slate-700 font-medium focus:outline-hidden focus:border-blue-600 cursor-pointer transition-colors truncate"
          >
            <option value="all">{t('filter.allTeams')}</option>
            {teams.map((team) => (
              <option key={team.id} value={team.id}>
                {team.name}
              </option>
            ))}
          </select>

          {/* Primary Assignee Dropdown */}
          <select
            value={filters.assigneeId}
            onChange={(e) => setFilters((prev) => ({ ...prev, assigneeId: e.target.value }))}
            className="w-full h-8.5 px-2 bg-slate-50 hover:bg-white border border-slate-200 rounded-lg text-slate-700 font-medium focus:outline-hidden focus:border-[#065F46] cursor-pointer transition-colors truncate"
          >
            <option value="all">{t('filter.allAssignees')}</option>
            {allUsers
              .filter((u) => u.role === 'admin' || u.role === 'super_admin' || u.role === 'team_member')
              .map((u) => (
                <option key={u.id} value={u.id}>
                  {u.fullName}
                </option>
              ))}
          </select>

          {/* Requestor's Name Dropdown */}
          <select
            value={filters.requesterId || 'all'}
            onChange={(e) => setFilters((prev) => ({ ...prev, requesterId: e.target.value }))}
            className="w-full h-8.5 px-2 bg-slate-50 hover:bg-white border border-slate-200 rounded-lg text-slate-700 font-medium focus:outline-hidden focus:border-[#065F46] cursor-pointer transition-colors truncate"
            title={isIndonesian ? 'Filter berdasarkan Nama Pemohon' : "Filter by Requestor's Name"}
          >
            <option value="all">{isIndonesian ? 'Semua Pemohon' : 'All Requestors'}</option>
            {allUsers.map((u) => (
              <option key={u.id} value={u.id}>
                {u.fullName} ({u.department || (isIndonesian ? 'Pengguna' : 'User')})
              </option>
            ))}
          </select>

          {/* Priority Dropdown */}
          <select
            value={filters.priority}
            onChange={(e) =>
              setFilters((prev) => ({ ...prev, priority: e.target.value as RequestPriority | 'all' }))
            }
            className="w-full h-8.5 px-2 bg-slate-50 hover:bg-white border border-slate-200 rounded-lg text-slate-700 font-medium focus:outline-hidden focus:border-blue-600 cursor-pointer transition-colors truncate"
          >
            {priorityOptions.map((opt) => (
              <option key={opt.value} value={opt.value}>
                {opt.label}
              </option>
            ))}
          </select>

          {/* Date Range Dropdown */}
          <select
            value={filters.dateRange}
            onChange={(e) => {
              const val = e.target.value as FilterState['dateRange'];
              if (val === 'custom') {
                const today = new Date().toISOString().split('T')[0];
                const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000)
                  .toISOString()
                  .split('T')[0];
                setFilters((prev) => ({
                  ...prev,
                  dateRange: 'custom',
                  startDate: prev.startDate || thirtyDaysAgo,
                  endDate: prev.endDate || today,
                }));
              } else {
                setFilters((prev) => ({
                  ...prev,
                  dateRange: val,
                  startDate: undefined,
                  endDate: undefined,
                }));
              }
            }}
            className="w-full h-8.5 px-2 bg-slate-50 hover:bg-white border border-slate-200 rounded-lg text-slate-700 font-medium focus:outline-hidden focus:border-blue-600 cursor-pointer transition-colors truncate"
          >
            <option value="all">{t('filter.allPeriods')}</option>
            <option value="today">{t('filter.today')}</option>
            <option value="this_week">{t('filter.thisWeek')}</option>
            <option value="this_month">{t('filter.thisMonth')}</option>
            <option value="custom">{t('filter.custom')}</option>
          </select>
        </div>

        {/* Action Toggles: Overdue, Custom Date Inputs & Reset */}
        <div className="flex items-center justify-between gap-2 pt-2.5 mt-2 border-t border-slate-100/80 flex-wrap">
          <div className="flex items-center gap-2 flex-wrap">
            <button
              type="button"
              onClick={() => setFilters((prev) => ({ ...prev, overdueOnly: !prev.overdueOnly }))}
              className={`h-7.5 inline-flex items-center gap-1.5 px-2.5 rounded-lg border text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer ${
                filters.overdueOnly
                  ? 'bg-rose-50 text-rose-700 border-rose-300'
                  : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
              }`}
            >
              <AlertTriangle className="w-3.5 h-3.5 text-rose-500 shrink-0" />
              <span>{t('filter.overdueOnly')}</span>
            </button>

            {filters.dateRange === 'custom' && (
              <div className="flex items-center gap-1.5 bg-slate-50 px-2 py-1 rounded-lg border border-slate-200 text-xs">
                <span className="text-[10px] text-slate-500 font-semibold">{isIndonesian ? 'Rentang:' : 'Range:'}</span>
                <input
                  type="date"
                  value={filters.startDate || ''}
                  onChange={(e) =>
                    setFilters((prev) => ({ ...prev, startDate: e.target.value }))
                  }
                  className="h-6 px-1 text-xs bg-white border border-slate-200 rounded text-slate-800 font-mono focus:outline-none focus:ring-1 focus:ring-blue-500"
                />
                <span className="text-slate-400">-</span>
                <input
                  type="date"
                  value={filters.endDate || ''}
                  onChange={(e) =>
                    setFilters((prev) => ({ ...prev, endDate: e.target.value }))
                  }
                  className="h-6 px-1 text-xs bg-white border border-slate-200 rounded text-slate-800 font-mono focus:outline-none focus:ring-1 focus:ring-blue-500"
                />
              </div>
            )}

            {isFiltered && (
              <button
                type="button"
                onClick={resetFilters}
                className="h-7.5 inline-flex items-center gap-1 px-2.5 text-xs font-semibold text-rose-700 bg-rose-50 hover:bg-rose-100 border border-rose-200 rounded-lg transition-colors whitespace-nowrap cursor-pointer"
              >
                <RotateCcw className="w-3 h-3 shrink-0" />
                <span>{t('filter.clearFilters')}</span>
              </button>
            )}
          </div>

          <div className="text-[11px] text-slate-500 shrink-0">
            {t('filter.resultsCount', { count: totalFilteredCount })}
          </div>
        </div>
      </div>
    </div>
  );
};
