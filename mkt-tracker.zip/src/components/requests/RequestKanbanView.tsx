import React, { useState } from 'react';
import {
  Clock,
  User,
  Paperclip,
  CheckCircle2,
  AlertTriangle,
  MoveRight,
  ExternalLink,
  Layers,
} from 'lucide-react';
import { RequestItem, RequestStatus } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { useRequests } from '../../context/RequestContext';
import { useLanguage } from '../../context/LanguageContext';
import { PriorityBadge, OverdueBadge, STATUS_STYLES } from '../common/StatusBadge';

interface RequestKanbanViewProps {
  requests: RequestItem[];
  onSelectRequest: (requestId: string) => void;
  includeCompleted?: boolean;
}

export const RequestKanbanView: React.FC<RequestKanbanViewProps> = ({
  requests,
  onSelectRequest,
  includeCompleted = false,
}) => {
  const { canTransitionStatus } = useAuth();
  const { changeStatus, showToast } = useRequests();
  const { isIndonesian } = useLanguage();

  const allColumns: { id: RequestStatus; title: string; hint: string }[] = [
    {
      id: 'todo',
      title: isIndonesian ? 'Antrean (To Do)' : 'To Do',
      hint: isIndonesian ? 'Brief masuk baru' : 'New inbound brief',
    },
    {
      id: 'in_progress',
      title: isIndonesian ? 'Sedang Dikerjakan' : 'In Progress',
      hint: isIndonesian ? 'Sedang dalam produksi' : 'Currently in production',
    },
    {
      id: 'pending_review',
      title: isIndonesian ? 'Menunggu Review' : 'Pending Review',
      hint: isIndonesian ? 'Menunggu evaluasi reviewer' : 'Awaiting reviewer evaluation',
    },
    {
      id: 'revision',
      title: isIndonesian ? 'Perlu Revisi' : 'Revision',
      hint: isIndonesian ? 'Modifikasi sedang berjalan' : 'Modification in progress',
    },
    {
      id: 'on_hold',
      title: isIndonesian ? 'Ditunda (On Hold)' : 'On Hold',
      hint: isIndonesian ? 'Dijeda sementara' : 'Temporarily paused',
    },
    {
      id: 'completed',
      title: isIndonesian ? 'Selesai Disetujui' : 'Completed',
      hint: isIndonesian ? 'Disetujui & final' : 'Approved & finalized',
    },
    {
      id: 'cancelled',
      title: isIndonesian ? 'Dibatalkan' : 'Cancelled',
      hint: isIndonesian ? 'Dibatalkan & diarsipkan' : 'Cancelled & archived',
    },
  ];

  const columns = allColumns.filter((c) => {
    if (c.id === 'completed') return includeCompleted || requests.some((r) => r.status === 'completed');
    if (c.id === 'cancelled') return requests.some((r) => r.status === 'cancelled');
    return true;
  });

  const [draggedRequestId, setDraggedRequestId] = useState<string | null>(null);
  const [dragOverColumn, setDragOverColumn] = useState<RequestStatus | null>(null);

  const handleDragStart = (e: React.DragEvent, reqId: string) => {
    e.dataTransfer.setData('text/plain', reqId);
    setDraggedRequestId(reqId);
  };

  const handleDragOver = (e: React.DragEvent, colId: RequestStatus) => {
    e.preventDefault();
    if (dragOverColumn !== colId) {
      setDragOverColumn(colId);
    }
  };

  const handleDragLeave = () => {
    setDragOverColumn(null);
  };

  const handleDrop = async (e: React.DragEvent, targetStatus: RequestStatus) => {
    e.preventDefault();
    setDragOverColumn(null);
    const reqId = e.dataTransfer.getData('text/plain') || draggedRequestId;
    setDraggedRequestId(null);

    if (!reqId) return;
    const req = requests.find((r) => r.id === reqId);
    if (!req) return;

    if (req.status === targetStatus) return;

    // Check transition validity
    const check = canTransitionStatus(req, targetStatus);
    if (!check.allowed) {
      showToast(
        check.reason ||
          (isIndonesian ? 'Perubahan status tidak diizinkan.' : 'Status transition not allowed.'),
        'error'
      );
      return;
    }

    // If target is revision, needs revision note dialog -> instruct user
    if (targetStatus === 'revision') {
      showToast(
        isIndonesian
          ? 'Permintaan revisi memerlukan catatan masukan pada panel rincian tugas.'
          : 'Revision requests require feedback notes in the task detail drawer.',
        'info'
      );
      onSelectRequest(req.id);
      return;
    }

    // If target is on_hold, needs hold reason -> open detail drawer
    if (targetStatus === 'on_hold') {
      showToast(
        isIndonesian
          ? 'Menunda permintaan memerlukan alasan penundaan pada panel rincian tugas.'
          : 'Placing a request on hold requires a hold reason in the task detail drawer.',
        'info'
      );
      onSelectRequest(req.id);
      return;
    }

    // If target is cancelled, needs cancellation reason -> open detail drawer
    if (targetStatus === 'cancelled') {
      showToast(
        isIndonesian
          ? 'Membatalkan permintaan memerlukan alasan pembatalan pada panel rincian tugas.'
          : 'Cancelling a request requires a cancellation reason in the task detail drawer.',
        'info'
      );
      onSelectRequest(req.id);
      return;
    }

    // Execute transition
    await changeStatus(req.id, targetStatus);
  };

  const [activeMobileColumn, setActiveMobileColumn] = useState<RequestStatus | 'all'>('all');

  return (
    <div className="space-y-3">
      {/* Mobile Column Quick-Tab Filter (visible only on small mobile < sm) */}
      <div className="flex sm:hidden items-center gap-1.5 overflow-x-auto no-scrollbar pb-1">
        <button
          onClick={() => setActiveMobileColumn('all')}
          className={`px-3 py-1 text-xs font-semibold rounded-lg shrink-0 transition-colors ${
            activeMobileColumn === 'all'
              ? 'bg-[#065F46] text-white shadow-2xs'
              : 'bg-white text-slate-600 border border-slate-200'
          }`}
        >
          {isIndonesian ? 'Semua' : 'All'} ({requests.length})
        </button>
        {columns.map((col) => {
          const count = requests.filter((r) => r.status === col.id).length;
          const isSelected = activeMobileColumn === col.id;
          return (
            <button
              key={col.id}
              onClick={() => setActiveMobileColumn(col.id)}
              className={`px-2.5 py-1 text-xs font-semibold rounded-lg shrink-0 transition-colors flex items-center gap-1.5 ${
                isSelected
                  ? 'bg-[#065F46] text-white shadow-2xs'
                  : 'bg-white text-slate-600 border border-slate-200'
              }`}
            >
              <span>{col.title}</span>
              <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono tabular-nums ${
                isSelected ? 'bg-[#044e39] text-white' : 'bg-slate-100 text-slate-600'
              }`}>
                {count}
              </span>
            </button>
          );
        })}
      </div>

      {/* Kanban Board Container: Horizontal Snap-Scroll on Mobile & Tablet, Grid on Desktop XL */}
      <div
        className={`flex flex-nowrap xl:grid gap-3.5 overflow-x-auto snap-x snap-mandatory pb-4 items-start ${
          columns.length <= 4
            ? 'xl:grid-cols-4'
            : columns.length === 5
            ? 'xl:grid-cols-5'
            : columns.length === 6
            ? 'xl:grid-cols-6'
            : 'xl:grid-cols-7'
        }`}
      >
        {columns.filter((col) => activeMobileColumn === 'all' || activeMobileColumn === col.id).map((col) => {
          const colRequests = requests.filter((r) => r.status === col.id);
          const isTargetOver = dragOverColumn === col.id;
          const style = STATUS_STYLES[col.id];

          const columnBg =
            col.id === 'todo'
              ? 'bg-slate-100/70 border-slate-200/90'
              : col.id === 'in_progress'
              ? 'bg-blue-50/50 border-blue-200/80'
              : col.id === 'pending_review'
              ? 'bg-purple-50/50 border-purple-200/80'
              : col.id === 'revision'
              ? 'bg-amber-50/50 border-amber-200/80'
              : col.id === 'on_hold'
              ? 'bg-yellow-50/70 border-yellow-200/80'
              : col.id === 'cancelled'
              ? 'bg-rose-50/50 border-rose-200/80'
              : 'bg-emerald-50/50 border-emerald-200/80';

          return (
            <div
              key={col.id}
              onDragOver={(e) => handleDragOver(e, col.id)}
              onDragLeave={handleDragLeave}
              onDrop={(e) => handleDrop(e, col.id)}
              className={`flex flex-col rounded-2xl border transition-all w-[285px] sm:w-[310px] xl:w-auto shrink-0 snap-start p-3 sm:p-3.5 min-h-[460px] ${columnBg} ${
                isTargetOver ? 'border-[#065F46] bg-emerald-50/40 ring-2 ring-[#065F46]/20' : ''
              }`}
            >
              {/* Column Header */}
              <div className="flex items-center justify-between pb-2.5 mb-2.5 border-b border-black/5">
                <div className="flex items-center gap-2 min-w-0">
                  <span className={`w-2.5 h-2.5 rounded-full shrink-0 ${style.dot}`} />
                  <h3 className="text-xs font-bold text-slate-900 leading-snug truncate">{col.title}</h3>
                </div>
                <span className="text-xs font-mono font-bold px-2 py-0.5 rounded-full bg-white text-slate-700 border border-slate-200 shadow-2xs tabular-nums shrink-0">
                  {colRequests.length}
                </span>
              </div>

              {/* Column Cards */}
              <div className="flex-1 space-y-2.5 overflow-y-auto max-h-[70vh] pr-0.5">
                {colRequests.length === 0 ? (
                  <div className="h-28 border border-dashed border-slate-300 rounded-xl flex items-center justify-center text-xs text-slate-400 text-center p-3 select-none bg-white/50">
                    {isIndonesian ? 'Tarik permintaan ke kolom ini' : 'Drag requests to this column'}
                  </div>
                ) : (
                  colRequests.map((req) => {
                    const hasDeliverables =
                      (req.deliverableAttachments && req.deliverableAttachments.length > 0) ||
                      (req.deliverableLinks && req.deliverableLinks.length > 0);

                    return (
                      <div
                        key={req.id}
                        draggable
                        onDragStart={(e) => handleDragStart(e, req.id)}
                        onClick={() => onSelectRequest(req.id)}
                        className="p-3 bg-white rounded-xl border border-[#E5E7EB] hover:border-[#065F46] shadow-2xs hover:shadow-md transition-all cursor-grab active:cursor-grabbing group relative space-y-2"
                      >
                        {/* Ticket Number & Priority */}
                        <div className="flex items-center justify-between gap-1.5 flex-wrap">
                          <span className="font-mono text-[11px] font-bold text-slate-900 tracking-tight bg-slate-100 px-1.5 py-0.2 rounded">
                            {req.ticketNumber}
                          </span>
                          <PriorityBadge priority={req.priority} compact={true} />
                        </div>

                        {/* Title */}
                        <h4 className="text-xs font-bold text-slate-900 group-hover:text-[#065F46] transition-colors line-clamp-2 leading-snug">
                          {req.title}
                        </h4>

                        {/* Brand & Category info */}
                        <div className="text-[11px] text-slate-500 truncate">
                          <span className="font-semibold text-slate-700">{req.brandName}</span>
                          <span className="mx-1 text-slate-300">·</span>
                          <span>{req.categoryName}</span>
                        </div>

                        {/* Requestor's Name & SubItems Count */}
                        <div className="flex items-center justify-between gap-1 flex-wrap">
                          <div className="flex items-center gap-1.5 text-[10px] text-slate-600 bg-slate-50/90 px-2 py-0.5 rounded-md border border-slate-200/70">
                            <User className="w-3 h-3 text-[#065F46] shrink-0" />
                            <span className="text-slate-400">{isIndonesian ? 'Pemohon:' : 'Requestor:'}</span>
                            <span className="font-semibold text-slate-800 truncate max-w-[120px]">
                              {req.requestorName || req.requesterName}
                            </span>
                          </div>
                          {(() => {
                            const count = req.subItems?.filter((s) => !s.deletedAt).length || 0;
                            if (count === 0) return null;
                            return (
                              <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-[#065F46] bg-emerald-50 border border-emerald-200 px-1.5 py-0.5 rounded">
                                <Layers className="w-2.5 h-2.5" />
                                <span>{count} {isIndonesian ? 'Sub Item' : 'Sub Items'}</span>
                              </span>
                            );
                          })()}
                        </div>

                        {/* Assignee & Deliverable Badge */}
                        <div className="flex items-center justify-between pt-2 border-t border-slate-100 text-[11px] gap-2">
                          <div className="flex items-center gap-1.5 text-slate-700 font-medium truncate min-w-0">
                            <span className="w-5 h-5 rounded-full bg-slate-100 text-slate-700 font-bold text-[10px] flex items-center justify-center shrink-0 border border-slate-200">
                              {req.primaryAssigneeName ? req.primaryAssigneeName.charAt(0) : '?'}
                            </span>
                            <span className="truncate text-xs">
                              {req.primaryAssigneeName || (isIndonesian ? 'Belum Ditugaskan' : 'Unassigned')}
                            </span>
                          </div>

                          {hasDeliverables && (
                            <span
                              className="text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded text-[10px] font-semibold flex items-center gap-0.5 border border-emerald-200 shrink-0 whitespace-nowrap"
                              title={isIndonesian ? 'Deliverable telah siap' : 'Deliverables available'}
                            >
                              <Paperclip className="w-2.5 h-2.5" />
                              <span>{isIndonesian ? 'Siap' : 'Ready'}</span>
                            </span>
                          )}
                        </div>

                        {/* Deadline & Overdue State */}
                        <div className="flex items-center justify-between pt-1 text-[10px] gap-1.5">
                          <span className="font-mono text-slate-500 truncate text-[11px]">
                            {req.committedDeadline
                              ? `${isIndonesian ? 'Tenggat:' : 'Due:'} ${req.committedDeadline}`
                              : (isIndonesian ? 'Tanpa tenggat' : 'No deadline')}
                          </span>
                          <OverdueBadge
                            isOverdue={req.isOverdue}
                            status={req.status}
                            committedDeadline={req.committedDeadline}
                            slaFulfilled={req.slaFulfilled}
                          />
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
