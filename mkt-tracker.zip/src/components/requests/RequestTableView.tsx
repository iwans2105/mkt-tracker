import React, { useState } from 'react';
import {
  ArrowUpDown,
  FileText,
  ChevronRight,
  ChevronDown,
  Paperclip,
  CheckCircle2,
  Clock,
  ExternalLink,
  Layers,
  Inbox,
  PlayCircle,
  HelpCircle,
  RotateCcw,
  User,
  PauseCircle,
  Ban,
  Building2,
} from 'lucide-react';
import { RequestItem, RequestStatus } from '../../types';
import { StatusBadge, PriorityBadge, OverdueBadge, STATUS_STYLES, STATUS_LABELS } from '../common/StatusBadge';
import { SubItemTableView } from '../subitems/SubItemTableView';
import { useLanguage } from '../../context/LanguageContext';

interface RequestTableViewProps {
  requests: RequestItem[];
  onSelectRequest: (requestId: string) => void;
  groupByStatus?: boolean;
  groupByRequestor?: boolean;
  groupByBrand?: boolean;
  hideStatusColumn?: boolean;
}

interface GroupConfig {
  id: RequestStatus;
  title: string;
  icon: React.ReactNode;
  hint: string;
  badgeClass: string;
}

export const RequestTableView: React.FC<RequestTableViewProps> = ({
  requests,
  onSelectRequest,
  groupByStatus = false,
  groupByRequestor = false,
  groupByBrand = false,
  hideStatusColumn = false,
}) => {
  const { t, isIndonesian } = useLanguage();
  const [sortField, setSortField] = useState<keyof RequestItem>('createdAt');
  const [sortAsc, setSortAsc] = useState<boolean>(false);
  const [collapsedGroups, setCollapsedGroups] = useState<Record<string, boolean>>({});
  const [expandedSubItems, setExpandedSubItems] = useState<Record<string, boolean>>({
    'req-004': true, // Auto-expand reference campaign
  });

  const activeGroups: GroupConfig[] = [
    {
      id: 'todo',
      title: isIndonesian ? 'Antrean (To Do)' : 'To Do / Backlog',
      icon: <Inbox className="w-4 h-4 text-slate-500" />,
      hint: isIndonesian ? 'Brief masuk baru menunggu antrean pengerjaan' : 'New inbound briefs awaiting scheduling & execution queue',
      badgeClass: 'bg-slate-100 text-slate-700 border-slate-200',
    },
    {
      id: 'in_progress',
      title: isIndonesian ? 'Sedang Dikerjakan' : 'In Progress',
      icon: <PlayCircle className="w-4 h-4 text-sky-600" />,
      hint: isIndonesian ? 'Pekerjaan sedang diproduksi aktif oleh tim Marcomm' : 'Work actively in production by the Marcomm team',
      badgeClass: 'bg-sky-100 text-sky-800 border-sky-200',
    },
    {
      id: 'pending_review',
      title: isIndonesian ? 'Menunggu Review / Persetujuan' : 'Pending Review / Approval',
      icon: <Clock className="w-4 h-4 text-purple-600" />,
      hint: isIndonesian ? 'Deliverable telah diserahkan menunggu evaluasi dan persetujuan' : 'Deliverables submitted awaiting evaluation and sign-off',
      badgeClass: 'bg-purple-100 text-purple-800 border-purple-200',
    },
    {
      id: 'revision',
      title: isIndonesian ? 'Perlu Revisi' : 'Revision',
      icon: <RotateCcw className="w-4 h-4 text-orange-600" />,
      hint: isIndonesian ? 'Tugas dalam modifikasi berdasarkan masukan reviewer' : 'Tasks under modification based on reviewer feedback',
      badgeClass: 'bg-orange-100 text-orange-800 border-orange-200',
    },
    {
      id: 'on_hold',
      title: isIndonesian ? 'Ditunda (On Hold)' : 'On Hold',
      icon: <PauseCircle className="w-4 h-4 text-amber-600" />,
      hint: isIndonesian ? 'Tugas dijeda sementara menunggu input atau izin eksternal' : 'Tasks temporarily paused awaiting external input or clearance',
      badgeClass: 'bg-amber-100 text-amber-800 border-amber-200',
    },
    {
      id: 'cancelled',
      title: isIndonesian ? 'Dibatalkan' : 'Cancelled',
      icon: <Ban className="w-4 h-4 text-rose-600" />,
      hint: isIndonesian ? 'Tugas dibatalkan dan dihapus dari alur kerja' : 'Tasks cancelled and removed from active pipeline',
      badgeClass: 'bg-rose-100 text-rose-800 border-rose-200',
    },
  ];

  const handleSort = (field: keyof RequestItem) => {
    if (sortField === field) {
      setSortAsc(!sortAsc);
    } else {
      setSortField(field);
      setSortAsc(false);
    }
  };

  const toggleGroup = (groupId: string) => {
    setCollapsedGroups((prev) => ({
      ...prev,
      [groupId]: !prev[groupId],
    }));
  };

  const toggleSubItems = (requestId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setExpandedSubItems((prev) => ({
      ...prev,
      [requestId]: !prev[requestId],
    }));
  };

  const sortItems = (items: RequestItem[]) => {
    return [...items].sort((a, b) => {
      let valA = a[sortField];
      let valB = b[sortField];

      if (valA === undefined) valA = '';
      if (valB === undefined) valB = '';

      if (valA < valB) return sortAsc ? -1 : 1;
      if (valA > valB) return sortAsc ? 1 : -1;
      return 0;
    });
  };

  if (requests.length === 0) {
    return (
      <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center shadow-xs">
        <div className="w-12 h-12 rounded-2xl bg-slate-100 text-slate-400 flex items-center justify-center mx-auto mb-3">
          <FileText className="w-6 h-6" />
        </div>
        <h3 className="text-sm font-bold text-slate-900">
          {isIndonesian ? 'Tidak ada permintaan yang cocok' : 'No matching requests found'}
        </h3>
        <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1 leading-relaxed">
          {isIndonesian
            ? 'Coba sesuaikan kriteria pencarian, filter, atau rentang tanggal untuk melihat item pekerjaan lain.'
            : 'Try adjusting your search criteria, filters, or date range to view other work items.'}
        </p>
      </div>
    );
  }

  // Render a single table for a given set of requests
  const renderTableSection = (sectionRequests: RequestItem[], groupKey?: string) => {
    const sorted = sortItems(sectionRequests);

    return (
      <div key={groupKey || 'all'} className="space-y-3">
        {/* 1. Mobile & Small Tablet Card View (Screens < md) */}
        <div className="block md:hidden space-y-2.5">
          {sorted.length === 0 ? (
            <div className="p-4 bg-slate-50/70 rounded-xl border border-dashed border-slate-200 text-center text-xs text-slate-400 italic">
              {isIndonesian ? 'Tidak ada permintaan pada status ini.' : 'No requests in this status.'}
            </div>
          ) : (
            sorted.map((req) => {
              const hasDeliverables =
                (req.deliverableAttachments && req.deliverableAttachments.length > 0) ||
                (req.deliverableLinks && req.deliverableLinks.length > 0);
              const isExpanded = !!expandedSubItems[req.id];
              const activeSubItems = req.subItems?.filter((s) => !s.deletedAt) || [];
              const subItemCount = activeSubItems.length;

              return (
                <div
                  key={req.id}
                  onClick={() => onSelectRequest(req.id)}
                  className={`p-3.5 bg-white rounded-2xl border transition-all shadow-2xs cursor-pointer space-y-2.5 ${
                    isExpanded ? 'border-emerald-500 ring-2 ring-emerald-500/10' : 'border-slate-200 hover:border-emerald-400'
                  }`}
                >
                  {/* Top Row: Ticket ID + Status + Priority + SubItems Toggle */}
                  <div className="flex items-center justify-between gap-1.5 flex-wrap">
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={(e) => toggleSubItems(req.id, e)}
                        className="inline-flex items-center gap-1 font-mono tabular-nums font-bold text-slate-900 text-xs tracking-tight bg-slate-100 hover:bg-[#D1FAE5] hover:text-[#065F46] px-2 py-0.5 rounded transition-colors"
                        title={
                          isExpanded
                            ? isIndonesian
                              ? 'Tutup Sub Item'
                              : 'Collapse Sub Items'
                            : isIndonesian
                            ? 'Buka Sub Item'
                            : 'Expand Sub Items'
                        }
                      >
                        <ChevronDown className={`w-3.5 h-3.5 text-slate-500 transition-transform ${isExpanded ? 'rotate-180 text-[#065F46]' : ''}`} />
                        <span>{req.ticketNumber}</span>
                        {subItemCount > 0 && (
                          <span className="text-[10px] font-bold px-1.5 py-0.2 rounded-full bg-emerald-100 text-[#065F46] border border-emerald-200">
                            {subItemCount}
                          </span>
                        )}
                      </button>
                      {!hideStatusColumn && (
                        <StatusBadge status={req.status} size="sm" compact={true} />
                      )}
                    </div>
                    <PriorityBadge priority={req.priority} compact={true} />
                  </div>

                  {/* Title */}
                  <div>
                    <h4 className="font-bold text-slate-900 text-sm leading-snug line-clamp-2">
                      {req.title}
                    </h4>
                    <div className="flex items-center gap-1.5 text-xs text-slate-500 mt-1 flex-wrap">
                      <span className="font-semibold text-slate-700">{req.brandName}</span>
                      <span aria-hidden="true" className="text-slate-300">·</span>
                      <span className="text-slate-600">{req.categoryName}</span>
                      {subItemCount > 0 && (
                        <>
                          <span aria-hidden="true" className="text-slate-300">·</span>
                          <span className="text-[#065F46] font-semibold text-[11px] bg-[#D1FAE5]/70 px-1.5 py-0.5 rounded">
                            {subItemCount} {isIndonesian ? 'Sub Item' : 'Sub Items'}
                          </span>
                        </>
                      )}
                      {hasDeliverables && (
                        <>
                          <span aria-hidden="true" className="text-slate-300">·</span>
                          <span className="text-emerald-700 font-medium inline-flex items-center gap-1">
                            <Paperclip className="w-3 h-3 shrink-0" />
                            <span>{isIndonesian ? 'Deliverable Siap' : 'Deliverables Ready'}</span>
                          </span>
                        </>
                      )}
                    </div>
                    {/* Requestor's Name Pill */}
                    <div className="mt-1.5 flex items-center gap-1 text-[11px] text-slate-600 bg-slate-50 border border-slate-200/80 rounded-md px-2 py-0.5 w-fit">
                      <User className="w-3 h-3 text-[#065F46] shrink-0" />
                      <span className="text-slate-500">{isIndonesian ? 'Pemohon:' : 'Requestor:'}</span>
                      <span className="font-semibold text-slate-800">{req.requestorName || req.requesterName}</span>
                    </div>
                  </div>

                  {/* Bottom Row: Assignee + Committed Deadline + Arrow */}
                  <div className="pt-2 border-t border-slate-100 flex items-center justify-between gap-2 text-xs">
                    <div className="flex items-center gap-2 min-w-0">
                      <span className="w-6 h-6 rounded-full bg-blue-100 text-blue-700 font-bold text-[11px] flex items-center justify-center shrink-0 border border-blue-200">
                        {req.primaryAssigneeName ? req.primaryAssigneeName.charAt(0) : '?'}
                      </span>
                      <div className="min-w-0 truncate">
                        <span className="font-semibold text-slate-800 truncate block">
                          {req.primaryAssigneeName || (isIndonesian ? 'Belum Ditugaskan' : 'Unassigned')}
                        </span>
                        <span className="text-[10px] text-slate-400 truncate block">
                          {req.assignedTeamName || 'Marcomm'}
                        </span>
                      </div>
                    </div>

                    <div className="text-right shrink-0">
                      <div className="font-mono font-bold text-slate-900 text-[11px]">
                        {req.committedDeadline || req.requestedDeadline}
                      </div>
                      <div className="mt-0.5">
                        <OverdueBadge
                          isOverdue={req.isOverdue}
                          status={req.status}
                          committedDeadline={req.committedDeadline}
                          slaFulfilled={req.slaFulfilled}
                        />
                      </div>
                    </div>
                  </div>

                  {/* Expandable Sub Items Table in Mobile Card */}
                  {isExpanded && (
                    <div
                      className="pt-3 border-t border-slate-200 mt-2"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <SubItemTableView parentRequest={req} />
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>

        {/* 2. Tablet Landscape & Desktop Data Table (Screens >= md) */}
        <div className="hidden md:block bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs min-w-[1000px]">
              {/* Table Header */}
              <thead className="bg-slate-50/90 border-b border-slate-200 text-slate-600 font-semibold select-none">
                <tr>
                  <th
                    onClick={() => handleSort('ticketNumber')}
                    className="py-3 px-4 cursor-pointer hover:text-slate-900 whitespace-nowrap w-40"
                  >
                    <div className="flex items-center gap-1.5">
                      <span>{t('table.ticketId')}</span>
                      <ArrowUpDown className="w-3 h-3 text-slate-400" />
                    </div>
                  </th>

                  <th
                    onClick={() => handleSort('title')}
                    className="py-3 px-4 cursor-pointer hover:text-slate-900 min-w-[260px]"
                  >
                    <div className="flex items-center gap-1.5">
                      <span>{t('table.title')}</span>
                      <ArrowUpDown className="w-3 h-3 text-slate-400" />
                    </div>
                  </th>

                  <th className="py-3 px-4 whitespace-nowrap w-40">{t('table.brandUnit')}</th>

                  {!hideStatusColumn && (
                    <th
                      onClick={() => handleSort('status')}
                      className="py-3 px-4 cursor-pointer hover:text-slate-900 whitespace-nowrap w-40"
                    >
                      <div className="flex items-center gap-1.5">
                        <span>{t('table.status')}</span>
                        <ArrowUpDown className="w-3 h-3 text-slate-400" />
                      </div>
                    </th>
                  )}

                  <th className="py-3 px-4 whitespace-nowrap w-36">{t('table.priority')}</th>

                  <th className="py-3 px-4 whitespace-nowrap w-48">{t('table.assignee')}</th>

                  <th
                    onClick={() => handleSort('committedDeadline')}
                    className="py-3 px-4 cursor-pointer hover:text-slate-900 whitespace-nowrap w-36"
                  >
                    <div className="flex items-center gap-1.5">
                      <span>{t('table.deadline')}</span>
                      <ArrowUpDown className="w-3 h-3 text-slate-400" />
                    </div>
                  </th>

                  <th className="py-3 px-4 whitespace-nowrap text-right w-12">{t('table.action')}</th>
                </tr>
              </thead>

              {/* Table Body */}
              <tbody className="divide-y divide-slate-100">
                {sorted.length === 0 ? (
                  <tr>
                    <td
                      colSpan={hideStatusColumn ? 7 : 8}
                      className="py-8 text-center text-xs text-slate-400 italic bg-slate-50/40"
                    >
                      {isIndonesian ? 'Tidak ada permintaan di bagian ini.' : 'No requests found in this section.'}
                    </td>
                  </tr>
                ) : (
                  sorted.map((req) => {
                    const hasDeliverables =
                      (req.deliverableAttachments && req.deliverableAttachments.length > 0) ||
                      (req.deliverableLinks && req.deliverableLinks.length > 0);
                    const isExpanded = !!expandedSubItems[req.id];
                    const activeSubItems = req.subItems?.filter((s) => !s.deletedAt) || [];
                    const subItemCount = activeSubItems.length;

                    return (
                      <React.Fragment key={req.id}>
                        <tr
                          onClick={() => onSelectRequest(req.id)}
                          className={`hover:bg-[#F0FDF4]/70 transition-colors cursor-pointer group ${
                            isExpanded ? 'bg-emerald-50/30' : ''
                          }`}
                        >
                          {/* Ticket Number & Overdue indicator + SubItem toggle */}
                          <td className="py-3 px-4 whitespace-nowrap align-top">
                            <div className="flex items-center gap-1.5">
                              <button
                                type="button"
                                onClick={(e) => toggleSubItems(req.id, e)}
                                className="p-1 hover:bg-[#D1FAE5]/80 text-slate-400 hover:text-[#065F46] rounded transition-colors"
                                title={
                                  isExpanded
                                    ? isIndonesian
                                      ? 'Tutup Sub Item'
                                      : 'Collapse Sub Items'
                                    : isIndonesian
                                    ? 'Buka Sub Item'
                                    : 'Expand Sub Items'
                                }
                              >
                                <ChevronDown
                                  className={`w-4 h-4 transition-transform duration-200 ${
                                    isExpanded ? 'rotate-180 text-[#065F46]' : ''
                                  }`}
                                />
                              </button>
                              <div className="font-mono tabular-nums font-bold text-slate-900 text-xs tracking-tight">
                                {req.ticketNumber}
                              </div>
                              {subItemCount > 0 && (
                                <span className="ml-0.5 text-[10px] font-bold px-1.5 py-0.2 rounded-full bg-emerald-100 text-[#065F46] border border-emerald-200">
                                  {subItemCount}
                                </span>
                              )}
                            </div>
                            <div className="mt-1 pl-6">
                              <OverdueBadge
                                isOverdue={req.isOverdue}
                                status={req.status}
                                committedDeadline={req.committedDeadline}
                                slaFulfilled={req.slaFulfilled}
                              />
                            </div>
                          </td>

                          {/* Title & Metadata */}
                          <td className="py-3 px-4 align-top">
                            <div className="flex items-center gap-2">
                              <span className="font-semibold text-slate-900 group-hover:text-[#065F46] transition-colors line-clamp-1 text-xs leading-snug">
                                {req.title}
                              </span>
                              {subItemCount > 0 && (
                                <span className="shrink-0 text-[10px] font-semibold text-[#065F46] bg-emerald-50 border border-emerald-200 px-1.5 py-0.2 rounded">
                                  ({subItemCount})
                                </span>
                              )}
                            </div>
                            <div className="flex items-center gap-2 text-[11px] text-slate-500 mt-1 flex-wrap">
                              <span className="font-medium text-slate-600">{req.categoryName}</span>
                              <span aria-hidden="true" className="text-slate-300">·</span>
                              <span className="inline-flex items-center gap-1 font-semibold text-slate-700 bg-slate-100 px-1.5 py-0.5 rounded text-[10px]">
                                <User className="w-3 h-3 text-[#065F46]" />
                                {isIndonesian ? 'Pemohon:' : 'Requestor:'} {req.requestorName || req.requesterName}
                              </span>
                              {hasDeliverables && (
                                <>
                                  <span aria-hidden="true" className="text-slate-300">·</span>
                                  <span className="text-emerald-700 font-medium inline-flex items-center gap-1">
                                    <Paperclip className="w-3 h-3 shrink-0" />
                                    <span>{isIndonesian ? 'Deliverable Siap' : 'Deliverables Ready'}</span>
                                  </span>
                                </>
                              )}
                            </div>
                          </td>

                          {/* Brand & Internal Unit */}
                          <td className="py-3 px-4 whitespace-nowrap align-top">
                            <div className="font-semibold text-slate-800 text-xs">{req.brandName}</div>
                            <div className="text-[11px] text-slate-500 mt-0.5">
                              {req.unitName ? req.unitName : req.regionName}
                            </div>
                          </td>

                          {/* Status Badge */}
                          {!hideStatusColumn && (
                            <td className="py-3 px-4 whitespace-nowrap align-top">
                              <StatusBadge status={req.status} size="sm" />
                            </td>
                          )}

                          {/* Priority Badge */}
                          <td className="py-3 px-4 whitespace-nowrap align-top">
                            <PriorityBadge priority={req.priority} />
                          </td>

                          {/* Primary Assignee & Team */}
                          <td className="py-3 px-4 whitespace-nowrap align-top">
                            {req.primaryAssigneeName ? (
                              <div className="flex items-center gap-2">
                                <span className="w-6 h-6 rounded-full bg-blue-100 text-blue-700 font-bold text-xs flex items-center justify-center shrink-0 border border-blue-200">
                                  {req.primaryAssigneeName.charAt(0)}
                                </span>
                                <div className="min-w-0">
                                  <div className="font-semibold text-slate-900 text-xs truncate max-w-[120px]">
                                    {req.primaryAssigneeName}
                                  </div>
                                  <div className="text-[11px] text-slate-500 truncate max-w-[120px]">
                                    {req.assignedTeamName}
                                    {req.collaboratorIds && req.collaboratorIds.length > 0 && (
                                      <span className="ml-1 text-slate-400 font-medium">
                                        (+{req.collaboratorIds.length})
                                      </span>
                                    )}
                                  </div>
                                </div>
                              </div>
                            ) : (
                              <span className="text-slate-400 italic text-[11px] inline-block pt-1">
                                {isIndonesian ? 'Belum Ditugaskan' : 'Unassigned'}
                              </span>
                            )}
                          </td>

                          {/* Deadlines */}
                          <td className="py-3 px-4 whitespace-nowrap font-mono tabular-nums align-top">
                            {req.committedDeadline ? (
                              <div>
                                <div className="font-bold text-slate-900 text-xs">
                                  {req.committedDeadline}
                                </div>
                                <div className="text-[10px] text-slate-400 mt-0.5">
                                  {isIndonesian ? 'Diminta:' : 'Req:'} {req.requestedDeadline}
                                </div>
                              </div>
                            ) : (
                              <div>
                                <div className="text-slate-500 text-[11px]">
                                  {isIndonesian ? 'Diminta:' : 'Req:'} {req.requestedDeadline}
                                </div>
                                <div className="text-[10px] text-amber-600 font-medium mt-0.5">
                                  {isIndonesian ? 'Menunggu SLA' : 'Awaiting SLA'}
                                </div>
                              </div>
                            )}
                          </td>

                          {/* Action arrow */}
                          <td className="py-3 px-4 whitespace-nowrap text-right align-middle">
                            <button
                              type="button"
                              className="p-1.5 text-slate-400 group-hover:text-[#065F46] group-hover:bg-[#D1FAE5]/60 rounded-lg transition-colors cursor-pointer"
                              title={isIndonesian ? 'Lihat Rincian & Aksi' : 'View Details & Actions'}
                            >
                              <ChevronRight className="w-4 h-4" />
                            </button>
                          </td>
                        </tr>

                        {/* Expanded Sub Items Row */}
                        {isExpanded && (
                          <tr className="bg-slate-50/80 border-b border-slate-200">
                            <td colSpan={hideStatusColumn ? 7 : 8} className="p-3 sm:p-4 bg-slate-50/60">
                              <div
                                className="pl-3 sm:pl-7 pr-2 py-1"
                                onClick={(e) => e.stopPropagation()}
                              >
                                <SubItemTableView parentRequest={req} />
                              </div>
                            </td>
                          </tr>
                        )}
                      </React.Fragment>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    );
  };

  // GROUPED RENDERING by Brand
  if (groupByBrand) {
    const brandMap = new Map<string, RequestItem[]>();
    requests.forEach((req) => {
      const brand = (req.brandName || (isIndonesian ? 'Tanpa Brand' : 'Unassigned Brand')).trim();
      if (!brandMap.has(brand)) {
        brandMap.set(brand, []);
      }
      brandMap.get(brand)!.push(req);
    });

    const sortedBrands = Array.from(brandMap.keys()).sort((a, b) => a.localeCompare(b));

    return (
      <div className="space-y-6">
        {sortedBrands.map((brandName) => {
          const groupItems = brandMap.get(brandName) || [];
          const isCollapsed = !!collapsedGroups[`brand-${brandName}`];
          const onTimeCount = groupItems.filter((r) => r.slaFulfilled).length;

          return (
            <div key={brandName} className="space-y-3">
              {/* Brand Group Header Card */}
              <div
                onClick={() => toggleGroup(`brand-${brandName}`)}
                className="flex items-center justify-between p-3.5 sm:p-4 bg-white rounded-2xl border border-slate-200 shadow-2xs hover:border-slate-300 transition-colors cursor-pointer select-none"
              >
                <div className="flex items-center gap-2.5 sm:gap-3 min-w-0">
                  <button
                    type="button"
                    className="p-1 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 transition-colors shrink-0"
                    aria-label={
                      isCollapsed
                        ? isIndonesian
                          ? 'Buka tabel brand'
                          : 'Expand brand table'
                        : isIndonesian
                        ? 'Tutup tabel brand'
                        : 'Collapse brand table'
                    }
                  >
                    <ChevronDown
                      className={`w-4 h-4 transition-transform duration-200 ${
                        isCollapsed ? '-rotate-90' : 'rotate-0'
                      }`}
                    />
                  </button>
                  <div className="w-8 h-8 rounded-xl bg-emerald-50 text-[#065F46] font-bold text-xs flex items-center justify-center shrink-0 border border-emerald-200">
                    <Building2 className="w-4 h-4" />
                  </div>
                  <div className="flex items-center gap-2 min-w-0 flex-wrap sm:flex-nowrap">
                    <span className="text-xs text-slate-400 hidden sm:inline">Brand:</span>
                    <h3 className="text-sm font-bold text-slate-900 truncate">{brandName}</h3>
                  </div>
                  <span className="px-2 py-0.5 text-xs font-mono font-bold rounded-full border bg-emerald-50 text-emerald-800 border-emerald-200 shrink-0">
                    {groupItems.length} {isIndonesian ? 'Permintaan' : groupItems.length === 1 ? 'Request' : 'Requests'}
                  </span>
                  {onTimeCount > 0 && (
                    <span className="hidden md:inline-flex items-center gap-1 text-[11px] font-medium text-emerald-700 bg-emerald-50/70 border border-emerald-200 px-2 py-0.5 rounded-full">
                      <CheckCircle2 className="w-3 h-3" />
                      <span>{onTimeCount} {isIndonesian ? 'SLA Tepat Waktu' : 'On-Time SLA'}</span>
                    </span>
                  )}
                </div>

                <div className="text-xs text-slate-500 font-medium shrink-0 flex items-center gap-2">
                  {isCollapsed ? (
                    <span className="text-[#065F46] font-semibold">{isIndonesian ? 'Klik untuk membuka' : 'Click to expand'}</span>
                  ) : (
                    <span>{groupItems.length} {isIndonesian ? 'Selesai' : 'Completed'}</span>
                  )}
                </div>
              </div>

              {!isCollapsed && renderTableSection(groupItems, `brand-${brandName}`)}
            </div>
          );
        })}
      </div>
    );
  }

  // GROUPED RENDERING by Requestor's Name
  if (groupByRequestor) {
    const requestorMap = new Map<string, RequestItem[]>();
    requests.forEach((req) => {
      const name = req.requestorName || req.requesterName || (isIndonesian ? 'Pemohon Tidak Diketahui' : 'Unknown Requestor');
      if (!requestorMap.has(name)) {
        requestorMap.set(name, []);
      }
      requestorMap.get(name)!.push(req);
    });

    const sortedRequestors = Array.from(requestorMap.keys()).sort((a, b) => a.localeCompare(b));

    return (
      <div className="space-y-6">
        {sortedRequestors.map((name) => {
          const groupItems = requestorMap.get(name) || [];
          const isCollapsed = !!collapsedGroups[`req-${name}`];

          return (
            <div key={name} className="space-y-3">
              <div
                onClick={() => toggleGroup(`req-${name}`)}
                className="flex items-center justify-between p-3.5 sm:p-4 bg-white rounded-2xl border border-slate-200 shadow-2xs hover:border-slate-300 transition-colors cursor-pointer select-none"
              >
                <div className="flex items-center gap-2.5 sm:gap-3 min-w-0">
                  <button
                    type="button"
                    className="p-1 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 transition-colors shrink-0"
                    aria-label={
                      isCollapsed
                        ? isIndonesian
                          ? 'Buka tabel pemohon'
                          : 'Expand requestor table'
                        : isIndonesian
                        ? 'Tutup tabel pemohon'
                        : 'Collapse requestor table'
                    }
                  >
                    <ChevronDown
                      className={`w-4 h-4 transition-transform duration-200 ${
                        isCollapsed ? '-rotate-90' : 'rotate-0'
                      }`}
                    />
                  </button>
                  <div className="w-7 h-7 rounded-full bg-[#D1FAE5] text-[#065F46] font-bold text-xs flex items-center justify-center shrink-0 border border-[#A7F3D0]">
                    {name.charAt(0)}
                  </div>
                  <div className="flex items-center gap-2 min-w-0">
                    <span className="text-xs text-slate-400">{isIndonesian ? 'Pemohon:' : 'Requestor:'}</span>
                    <h3 className="text-sm font-bold text-slate-900 truncate">{name}</h3>
                  </div>
                  <span className="px-2 py-0.5 text-xs font-mono font-bold rounded-full border bg-emerald-50 text-emerald-800 border-emerald-200 shrink-0">
                    {groupItems.length} {isIndonesian ? 'tugas' : groupItems.length === 1 ? 'task' : 'tasks'}
                  </span>
                </div>

                <div className="text-xs text-slate-500 font-medium shrink-0">
                  {isCollapsed ? (
                    <span className="text-[#065F46]">{isIndonesian ? 'Klik untuk membuka' : 'Click to expand'}</span>
                  ) : (
                    <span>{groupItems.length} {isIndonesian ? 'Permintaan' : 'Requests'}</span>
                  )}
                </div>
              </div>

              {!isCollapsed && renderTableSection(groupItems, `req-${name}`)}
            </div>
          );
        })}
      </div>
    );
  }

  // If not grouped, render standard flat table
  if (!groupByStatus) {
    return renderTableSection(requests);
  }

  // GROUPED RENDERING by Status Pipeline (To Do, In Progress, Pending Review, Revision, On Hold, Cancelled)
  return (
    <div className="space-y-6">
      {activeGroups.filter((grp) => {
        const count = requests.filter((r) => r.status === grp.id).length;
        if (grp.id === 'cancelled') return count > 0;
        return true;
      }).map((grp) => {
        const groupItems = requests.filter((r) => r.status === grp.id);
        const isCollapsed = !!collapsedGroups[grp.id];

        return (
          <div key={grp.id} className="space-y-3">
            {/* Group Header Card */}
            <div
              onClick={() => toggleGroup(grp.id)}
              className="flex items-center justify-between p-3.5 sm:p-4 bg-white rounded-2xl border border-slate-200 shadow-2xs hover:border-slate-300 transition-colors cursor-pointer select-none"
            >
              <div className="flex items-center gap-2.5 sm:gap-3 min-w-0">
                <button
                  type="button"
                  className="p-1 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 transition-colors shrink-0"
                  aria-label={
                    isCollapsed
                      ? isIndonesian
                        ? 'Buka tabel status'
                        : 'Expand status table'
                      : isIndonesian
                      ? 'Tutup tabel status'
                      : 'Collapse status table'
                  }
                >
                  <ChevronDown
                    className={`w-4 h-4 transition-transform duration-200 ${
                      isCollapsed ? '-rotate-90' : 'rotate-0'
                    }`}
                  />
                </button>
                <div className="flex items-center gap-2 shrink-0">
                  {grp.icon}
                  <h3 className="text-sm font-bold text-slate-900">{grp.title}</h3>
                </div>
                <span
                  className={`px-2 py-0.5 text-xs font-mono font-bold rounded-full border ${grp.badgeClass}`}
                >
                  {groupItems.length}
                </span>
                <span className="text-xs text-slate-400 hidden lg:inline truncate">
                  · {grp.hint}
                </span>
              </div>

              <div className="text-xs text-slate-500 font-medium shrink-0">
                {isCollapsed ? (
                  <span className="text-blue-600">{isIndonesian ? 'Klik untuk membuka' : 'Click to expand'}</span>
                ) : (
                  <span>{groupItems.length} {isIndonesian ? 'Permintaan' : 'Requests'}</span>
                )}
              </div>
            </div>

            {/* Group Content */}
            {!isCollapsed && renderTableSection(groupItems, grp.id)}
          </div>
        );
      })}
    </div>
  );
};
