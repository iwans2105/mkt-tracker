import React, { useState, useRef, useEffect } from 'react';
import {
  User,
  Mail,
  Building,
  Briefcase,
  ShieldCheck,
  CheckCircle2,
  Lock,
  Edit2,
  Camera,
  MapPin,
  Tag,
  Upload,
  Trash2,
  AlertCircle,
  KeyRound,
  Send,
  RefreshCw,
  Check,
  X,
  FileImage,
  LogOut,
  Sparkles,
  ShieldAlert,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useRequests } from '../../context/RequestContext';
import { useLanguage } from '../../context/LanguageContext';
import { StorageService } from '../../services/storageService';
import { PasswordInput, generateStrongPassword } from '../common/PasswordInput';

export const UserProfileView: React.FC = () => {
  const {
    currentUser,
    csrfToken,
    updateUserAccount,
    logout,
    isLoggingOut,
    registerBeforeLogoutFlush,
    changePassword,
  } = useAuth();
  const { teams, showToast } = useRequests();
  const { isIndonesian } = useLanguage();

  const defaultAvatar =
    'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80';

  // Tab State: 'details' or 'security'
  const [activeTab, setActiveTab] = useState<'details' | 'security'>('details');

  const [fullName, setFullName] = useState(currentUser.fullName);
  const [jobTitle, setJobTitle] = useState(currentUser.jobTitle);
  const [department, setDepartment] = useState(currentUser.department);
  const [avatarUrl, setAvatarUrl] = useState(currentUser.avatarUrl || defaultAvatar);
  const [isSaved, setIsSaved] = useState(false);
  const [isSavingProfile, setIsSavingProfile] = useState(false);

  const syncedUserSnapshotRef = useRef({
    id: currentUser.id,
    fullName: currentUser.fullName,
    jobTitle: currentUser.jobTitle,
    department: currentUser.department,
    avatarUrl: currentUser.avatarUrl || defaultAvatar,
  });
  const draftValuesRef = useRef({ fullName, jobTitle, department, avatarUrl });
  draftValuesRef.current = { fullName, jobTitle, department, avatarUrl };

  useEffect(() => {
    const nextAvatar = currentUser.avatarUrl || defaultAvatar;
    const prevBase = syncedUserSnapshotRef.current;
    const prevDraft = draftValuesRef.current;
    const isDirty =
      prevDraft.fullName !== prevBase.fullName ||
      prevDraft.jobTitle !== prevBase.jobTitle ||
      prevDraft.department !== prevBase.department ||
      prevDraft.avatarUrl !== prevBase.avatarUrl;

    if (currentUser.id !== prevBase.id || !isDirty) {
      setFullName(currentUser.fullName);
      setJobTitle(currentUser.jobTitle);
      setDepartment(currentUser.department);
      setAvatarUrl(nextAvatar);
      syncedUserSnapshotRef.current = {
        id: currentUser.id,
        fullName: currentUser.fullName,
        jobTitle: currentUser.jobTitle,
        department: currentUser.department,
        avatarUrl: nextAvatar,
      };
    }
  }, [currentUser.id, currentUser.fullName, currentUser.jobTitle, currentUser.department, currentUser.avatarUrl]);

  useEffect(() => {
    return registerBeforeLogoutFlush(async () => {
      const draft = draftValuesRef.current;
      const base = syncedUserSnapshotRef.current;
      if (!currentUser.id || currentUser.id !== base.id) return;
      const hasPendingChanges =
        draft.fullName.trim() !== (base.fullName || '').trim() ||
        draft.jobTitle.trim() !== (base.jobTitle || '').trim() ||
        draft.department.trim() !== (base.department || '').trim() ||
        draft.avatarUrl !== base.avatarUrl;
      if (!hasPendingChanges || !draft.fullName.trim()) return;

      const res = await updateUserAccount({
        ...currentUser,
        fullName: draft.fullName.trim(),
        jobTitle: draft.jobTitle.trim(),
        department: draft.department.trim(),
        avatarUrl: draft.avatarUrl,
      });
      if (res.success && res.user) {
        const nextAv = res.user.avatarUrl || defaultAvatar;
        syncedUserSnapshotRef.current = {
          id: res.user.id,
          fullName: res.user.fullName,
          jobTitle: res.user.jobTitle,
          department: res.user.department,
          avatarUrl: nextAv,
        };
      }
    });
  }, [registerBeforeLogoutFlush, currentUser, updateUserAccount]);

  // Email change & verification state
  const [isChangingEmail, setIsChangingEmail] = useState(false);
  const [newEmail, setNewEmail] = useState('');
  const [verificationSent, setVerificationSent] = useState(false);
  const [verificationCode, setVerificationCode] = useState('');
  const [generatedCode, setGeneratedCode] = useState('');
  const [emailError, setEmailError] = useState('');
  const [isVerifying, setIsVerifying] = useState(false);
  const [resendCountdown, setResendCountdown] = useState(0);

  // Avatar upload state
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [uploadError, setUploadError] = useState('');
  const [isDragging, setIsDragging] = useState(false);

  // Change Password state
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmNewPassword, setConfirmNewPassword] = useState('');
  const [isSubmittingPassword, setIsSubmittingPassword] = useState(false);
  const [passwordError, setPasswordError] = useState('');
  const [passwordSuccess, setPasswordSuccess] = useState('');

  // Allowed avatar image extensions
  const ALLOWED_IMAGE_TYPES = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'heic', 'heif'];
  const MAX_AVATAR_SIZE = 10 * 1024 * 1024; // 10MB

  const handleFileProcess = async (file: File) => {
    setUploadError('');
    const ext = file.name.split('.').pop()?.toLowerCase() || '';

    if (!ALLOWED_IMAGE_TYPES.includes(ext) && !file.type.startsWith('image/')) {
      setUploadError(
        isIndonesian
          ? `Format file "${file.name}" tidak didukung. Silakan unggah gambar JPG, JPEG, PNG, GIF, WEBP, HEIC, atau HEIF.`
          : `File format "${file.name}" is not supported. Please upload a JPG, JPEG, PNG, GIF, WEBP, HEIC, or HEIF image.`
      );
      return;
    }

    if (file.size > MAX_AVATAR_SIZE) {
      setUploadError(
        isIndonesian
          ? `Ukuran file "${file.name}" melebihi batas maksimal 10MB.`
          : `File size "${file.name}" exceeds the 10MB limit.`
      );
      return;
    }

    try {
      const uploaded = await StorageService.uploadFileToR2(
        file,
        { scopeType: 'avatar' },
        csrfToken
      );
      setAvatarUrl(uploaded.url);
      showToast(
        isIndonesian
          ? 'Foto profil baru berhasil diunggah ke R2. Klik "Simpan Profil" untuk menyimpan perubahan.'
          : 'New profile photo uploaded to R2. Click "Save Profile" to save changes.',
        'info'
      );
    } catch (err: any) {
      setUploadError(
        err?.message ||
          (isIndonesian
            ? 'Gagal mengunggah gambar profil ke R2. Silakan coba file lain.'
            : 'Failed to upload profile image to R2. Please try another file.')
      );
    }
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      handleFileProcess(file);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      handleFileProcess(file);
    }
  };

  const handleRemoveAvatar = () => {
    setAvatarUrl(
      'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80'
    );
    showToast(
      isIndonesian ? 'Foto profil dikembalikan ke avatar default.' : 'Profile photo reset to default avatar.',
      'info'
    );
  };

  // Email verification handlers
  const handleStartEmailChange = () => {
    setIsChangingEmail(true);
    setNewEmail('');
    setVerificationSent(false);
    setVerificationCode('');
    setEmailError('');
  };

  const handleSendVerification = (e: React.FormEvent) => {
    e.preventDefault();
    setEmailError('');

    const emailTrimmed = newEmail.trim().toLowerCase();
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(emailTrimmed)) {
      setEmailError(isIndonesian ? 'Format alamat email tidak valid.' : 'Invalid email address format.');
      return;
    }

    if (emailTrimmed === currentUser.email.toLowerCase()) {
      setEmailError(
        isIndonesian
          ? 'Alamat email baru tidak boleh sama dengan email saat ini.'
          : 'New email address cannot be the same as your current email.'
      );
      return;
    }

    const code = Math.floor(100000 + Math.random() * 900000).toString();
    setGeneratedCode(code);
    setVerificationSent(true);

    showToast(
      isIndonesian
        ? `[Kode Verifikasi: ${code}] Kode verifikasi telah dikirim ke ${emailTrimmed}.`
        : `[Verification Code: ${code}] A verification code has been sent to ${emailTrimmed}.`,
      'info'
    );

    setResendCountdown(60);
    const timer = setInterval(() => {
      setResendCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  const handleVerifyAndSaveEmail = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsVerifying(true);
    setEmailError('');

    if (verificationCode.trim() !== generatedCode) {
      setEmailError(
        isIndonesian
          ? 'Kode verifikasi tidak valid. Silakan periksa dan coba lagi.'
          : 'Invalid verification code. Please check and try again.'
      );
      setIsVerifying(false);
      return;
    }

    const updatedUser = {
      ...currentUser,
      email: newEmail.trim().toLowerCase(),
    };
    const res = await updateUserAccount(updatedUser);
    setIsVerifying(false);
    if (!res.success) {
      setEmailError(res.error || (isIndonesian ? 'Gagal memperbarui email.' : 'Failed to update email.'));
      return;
    }

    setIsChangingEmail(false);
    setVerificationSent(false);
    showToast(
      isIndonesian
        ? `Email berhasil diperbarui menjadi ${updatedUser.email}!`
        : `Email successfully updated to ${updatedUser.email}!`,
      'success'
    );
  };

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isSavingProfile) return;
    setIsSavingProfile(true);
    try {
      const updatedUser = {
        ...currentUser,
        fullName: fullName.trim(),
        jobTitle: jobTitle.trim(),
        department: department.trim(),
        avatarUrl,
      };
      const res = await updateUserAccount(updatedUser);
      if (!res.success) {
        showToast(
          res.error || (isIndonesian ? 'Gagal memperbarui detail profil.' : 'Failed to update profile details.'),
          'error'
        );
        return;
      }
      const nextAv = (res.user?.avatarUrl || avatarUrl) || defaultAvatar;
      syncedUserSnapshotRef.current = {
        id: currentUser.id,
        fullName: updatedUser.fullName,
        jobTitle: updatedUser.jobTitle,
        department: updatedUser.department,
        avatarUrl: nextAv,
      };
      setIsSaved(true);
      showToast(
        isIndonesian ? 'Detail profil berhasil diperbarui!' : 'Profile details updated successfully!',
        'success'
      );
      setTimeout(() => setIsSaved(false), 3000);
    } finally {
      setIsSavingProfile(false);
    }
  };

  // Password Change Handler
  const handleChangePasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordError('');
    setPasswordSuccess('');

    if (!currentPassword || !newPassword || !confirmNewPassword) {
      setPasswordError(
        isIndonesian ? 'Semua kolom password wajib diisi.' : 'All password fields are required.'
      );
      return;
    }

    if (newPassword.length < 12) {
      setPasswordError(
        isIndonesian
          ? 'Password baru minimal 12 karakter untuk standar enterprise PT Lyman Devindo.'
          : 'New password must be at least 12 characters for PT Lyman Devindo enterprise standard.'
      );
      return;
    }

    if (newPassword !== confirmNewPassword) {
      setPasswordError(
        isIndonesian ? 'Konfirmasi password baru tidak cocok.' : 'New password confirmation does not match.'
      );
      return;
    }

    if (currentPassword === newPassword) {
      setPasswordError(
        isIndonesian
          ? 'Password baru tidak boleh sama dengan password saat ini.'
          : 'New password cannot be the same as your current password.'
      );
      return;
    }

    setIsSubmittingPassword(true);
    try {
      const res = await changePassword(currentPassword, newPassword, confirmNewPassword);
      if (res.success) {
        setPasswordSuccess(
          res.message || (isIndonesian ? 'Password berhasil diperbarui.' : 'Password updated successfully.')
        );
        showToast(
          isIndonesian ? 'Password Anda berhasil diperbarui!' : 'Your password has been updated!',
          'success'
        );
        setCurrentPassword('');
        setNewPassword('');
        setConfirmNewPassword('');
      } else {
        setPasswordError(
          res.error ||
            (isIndonesian
              ? 'Gagal mengubah password. Silakan periksa password saat ini.'
              : 'Failed to change password. Please check your current password.')
        );
      }
    } catch {
      setPasswordError(
        isIndonesian
          ? 'Koneksi bermasalah. Silakan coba kembali.'
          : 'Connection error. Please try again.'
      );
    } finally {
      setIsSubmittingPassword(false);
    }
  };

  const handleGeneratePasswordForProfile = () => {
    const generated = generateStrongPassword();
    setNewPassword(generated);
    setConfirmNewPassword(generated);
    setPasswordError('');
  };

  const userTeams = teams.filter((t) => currentUser.teams?.includes(t.id));

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="p-6 bg-white rounded-2xl border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-slate-900">
            {isIndonesian ? 'Profil Pengguna & Pengaturan Akun' : 'User Profile & Account Settings'}
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            {isIndonesian
              ? 'Kelola profil pribadi, kredensial, dan keamanan kata sandi untuk portal PT Lyman Devindo.'
              : 'Manage your personal profile, credentials, and password security for PT Lyman Devindo portal.'}
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setActiveTab('details')}
            className={`px-4 py-2 text-xs font-bold rounded-xl transition-all ${
              activeTab === 'details'
                ? 'bg-[#065F46] text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            {isIndonesian ? 'Detail Profil' : 'Profile Details'}
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('security')}
            className={`px-4 py-2 text-xs font-bold rounded-xl transition-all flex items-center gap-1.5 ${
              activeTab === 'security'
                ? 'bg-[#065F46] text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            <KeyRound className="w-3.5 h-3.5" />
            <span>{isIndonesian ? 'Keamanan & Kata Sandi' : 'Security & Password'}</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Left Column: Profile Card */}
        <div className="p-6 bg-white rounded-2xl border border-slate-200 shadow-xs text-center space-y-4 h-fit">
          <div className="relative inline-block mx-auto group">
            <img
              src={avatarUrl}
              alt={currentUser.fullName}
              className="w-24 h-24 rounded-full object-cover border-4 border-slate-100 shadow-sm mx-auto"
            />
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="absolute bottom-0 right-0 p-2 bg-[#065F46] text-white rounded-full shadow-md hover:bg-[#044e39] transition-all"
              title={isIndonesian ? 'Unggah foto profil baru' : 'Upload new profile photo'}
            >
              <Camera className="w-3.5 h-3.5" />
            </button>
          </div>

          <div>
            <h3 className="font-bold text-slate-900 text-sm">{currentUser.fullName}</h3>
            <p className="text-xs text-slate-500 mt-0.5">{currentUser.jobTitle}</p>
            <span className="text-[11px] font-mono text-slate-400 block mt-0.5">{currentUser.email}</span>
          </div>

          <div className="pt-3 border-t border-slate-100 text-left text-xs space-y-2">
            <div className="flex items-center justify-between p-2 rounded-lg bg-slate-50">
              <span className="text-slate-500">{isIndonesian ? 'Departemen:' : 'Department:'}</span>
              <span className="font-bold text-slate-900">{currentUser.department}</span>
            </div>

            <div className="flex items-center justify-between p-2 rounded-lg bg-slate-50 gap-2">
              <span className="text-slate-500 shrink-0">{isIndonesian ? 'Peran Sistem:' : 'System Role:'}</span>
              <span className="font-bold text-slate-900 capitalize truncate">
                {currentUser.role.replace('_', ' ')}
              </span>
            </div>

            <div className="flex items-center justify-between p-2 rounded-lg bg-slate-50 gap-2">
              <span className="text-slate-500 shrink-0">
                {isIndonesian ? 'Izin Reviewer:' : 'Reviewer Permission:'}
              </span>
              <span className="font-bold text-slate-900 truncate">
                {currentUser.isReviewer
                  ? (isIndonesian ? 'Aktif (Berwenang)' : 'Active (Authorized)')
                  : (isIndonesian ? 'Nonaktif' : 'Disabled')}
              </span>
            </div>

            <div className="flex items-center justify-between p-2 rounded-lg bg-slate-50">
              <span className="text-slate-500">{isIndonesian ? 'Status Akun:' : 'Account Status:'}</span>
              <span className="font-bold text-emerald-700 flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                {isIndonesian ? 'Aktif & Terverifikasi' : 'Active & Verified'}
              </span>
            </div>
          </div>

          {userTeams.length > 0 && (
            <div className="pt-3 border-t border-slate-100 text-left text-xs">
              <span className="text-slate-400 block mb-1.5 font-semibold">
                {isIndonesian ? 'Keanggotaan Tim:' : 'Team Memberships:'}
              </span>
              <div className="space-y-1">
                {userTeams.map((t) => (
                  <div key={t.id} className="flex items-center gap-2 font-medium text-slate-700">
                    <span className="w-2 h-2 rounded-full" style={{ backgroundColor: t.color }} />
                    <span>{t.name}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {currentUser.competencies && currentUser.competencies.length > 0 && (
            <div className="pt-2 text-left text-xs">
              <span className="text-slate-400 block mb-1.5 font-semibold">
                {isIndonesian ? 'Keahlian & Kompetensi:' : 'Skills & Competencies:'}
              </span>
              <div className="flex items-center gap-1.5 flex-wrap">
                {currentUser.competencies.map((comp) => (
                  <span
                    key={comp}
                    className="text-[11px] px-2 py-0.5 rounded bg-blue-50 text-blue-700 font-medium"
                  >
                    {comp}
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Right Column: Tab 1 (Details) or Tab 2 (Security & Password) */}
        <div className="md:col-span-2 p-6 bg-white rounded-2xl border border-slate-200 shadow-xs space-y-6">
          {activeTab === 'details' ? (
            <>
              <div>
                <h3 className="text-sm font-bold text-slate-900">
                  {isIndonesian ? 'Perbarui Detail Profil' : 'Update Profile Details'}
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  {isIndonesian
                    ? 'Detail ini akan ditampilkan pada brief yang Anda ajukan, penugasan tugas, komentar masukan, dan hasil pekerjaan.'
                    : 'These details will be displayed across your submitted briefs, task assignments, feedback comments, and deliverables.'}
                </p>
              </div>

              <form onSubmit={handleSaveProfile} className="space-y-5 text-xs">
                {/* Full Name */}
                <div>
                  <label className="block font-bold text-slate-800 mb-1">
                    {isIndonesian ? 'Nama Lengkap *' : 'Full Name *'}
                  </label>
                  <input
                    type="text"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    required
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:outline-hidden focus:border-[#065F46]"
                  />
                </div>

                {/* Email Address with Verification */}
                <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <label className="font-bold text-slate-900 block">
                        {isIndonesian ? 'Alamat Email Terdaftar' : 'Registered Email Address'}
                      </label>
                      <span className="text-[11px] text-slate-500">
                        {isIndonesian
                          ? 'Email korporat yang digunakan untuk autentikasi akun dan notifikasi.'
                          : 'Corporate email used for account authentication and notifications.'}
                      </span>
                    </div>
                    {!isChangingEmail && (
                      <button
                        type="button"
                        onClick={handleStartEmailChange}
                        className="text-xs text-emerald-800 hover:text-emerald-950 font-semibold flex items-center gap-1 hover:underline"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                        <span>{isIndonesian ? 'Ubah Email' : 'Change Email'}</span>
                      </button>
                    )}
                  </div>

                  {!isChangingEmail ? (
                    <div className="flex items-center justify-between p-2.5 bg-white border border-slate-200 rounded-xl text-xs font-mono">
                      <div className="flex items-center gap-2">
                        <Mail className="w-4 h-4 text-slate-400" />
                        <span className="text-slate-800 font-bold">{currentUser.email}</span>
                      </div>
                      <span className="text-[10px] px-2 py-0.5 bg-emerald-50 text-emerald-700 font-bold rounded border border-emerald-200 flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" />
                        {isIndonesian ? 'Terverifikasi' : 'Verified'}
                      </span>
                    </div>
                  ) : (
                    <div className="p-3 bg-white border border-emerald-200 rounded-xl space-y-3">
                      {!verificationSent ? (
                        <div className="space-y-2">
                          <label className="block text-slate-700 font-semibold text-[11px]">
                            {isIndonesian ? 'Masukkan Alamat Email Baru' : 'Enter New Email Address'}
                          </label>
                          <div className="flex gap-2">
                            <input
                              type="email"
                              value={newEmail}
                              onChange={(e) => setNewEmail(e.target.value)}
                              placeholder="name@lyman.co.id"
                              required
                              className="flex-1 p-2 border border-slate-300 rounded-lg text-xs font-mono focus:border-[#065F46]"
                            />
                            <button
                              type="button"
                              onClick={handleSendVerification}
                              className="px-3 py-1.5 bg-[#065F46] text-white font-semibold rounded-lg text-xs hover:bg-[#044e39] flex items-center gap-1.5"
                            >
                              <Send className="w-3.5 h-3.5" />
                              <span>{isIndonesian ? 'Kirim Kode' : 'Send Code'}</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => setIsChangingEmail(false)}
                              className="px-2.5 py-1.5 text-slate-600 hover:text-slate-800 text-xs font-medium"
                            >
                              {isIndonesian ? 'Batal' : 'Cancel'}
                            </button>
                          </div>
                        </div>
                      ) : (
                        <div className="space-y-2">
                          <div className="flex items-center justify-between">
                            <label className="block text-slate-700 font-semibold text-[11px]">
                              {isIndonesian ? 'Masukkan 6-Digit Kode yang dikirim ke:' : 'Enter 6-Digit Code sent to:'}{' '}
                              <span className="font-mono text-emerald-700">{newEmail}</span>
                            </label>
                            <span className="text-[10px] text-slate-400">
                              {resendCountdown > 0
                                ? (isIndonesian ? `Kirim ulang dalam ${resendCountdown} dtk` : `Resend in ${resendCountdown}s`)
                                : ''}
                            </span>
                          </div>
                          <div className="flex gap-2">
                            <input
                              type="text"
                              maxLength={6}
                              value={verificationCode}
                              onChange={(e) => setVerificationCode(e.target.value)}
                              placeholder="123456"
                              className="w-32 p-2 border border-slate-300 rounded-lg text-xs font-mono text-center tracking-widest focus:border-[#065F46]"
                            />
                            <button
                              type="button"
                              onClick={handleVerifyAndSaveEmail}
                              disabled={isVerifying || verificationCode.length < 6}
                              className="px-4 py-1.5 bg-emerald-700 text-white font-semibold rounded-lg text-xs hover:bg-emerald-800 disabled:bg-slate-300 flex items-center gap-1.5"
                            >
                              <Check className="w-3.5 h-3.5" />
                              <span>{isIndonesian ? 'Verifikasi & Simpan' : 'Verify & Update'}</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => setVerificationSent(false)}
                              className="px-2.5 py-1.5 text-slate-500 hover:text-slate-800 text-xs"
                            >
                              {isIndonesian ? 'Kembali' : 'Back'}
                            </button>
                          </div>
                        </div>
                      )}

                      {emailError && (
                        <p className="text-[11px] text-rose-600 flex items-center gap-1 font-medium">
                          <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                          <span>{emailError}</span>
                        </p>
                      )}
                    </div>
                  )}
                </div>

                {/* Upload Avatar Drag & Drop */}
                <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <label className="font-bold text-slate-900 block">
                        {isIndonesian ? 'Unggah Foto Profil (Avatar)' : 'Upload Profile Picture (Avatar)'}
                      </label>
                      <span className="text-[11px] text-slate-500">
                        {isIndonesian
                          ? 'Mendukung JPG, JPEG, PNG, GIF, WEBP, HEIC, HEIF (Maks 10MB)'
                          : 'Supports JPG, JPEG, PNG, GIF, WEBP, HEIC, HEIF (Max 10MB)'}
                      </span>
                    </div>
                    {avatarUrl && (
                      <button
                        type="button"
                        onClick={handleRemoveAvatar}
                        className="text-xs text-rose-600 hover:text-rose-800 font-semibold flex items-center gap-1 hover:underline"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>{isIndonesian ? 'Reset Foto' : 'Reset Photo'}</span>
                      </button>
                    )}
                  </div>

                  <div
                    onDragOver={(e) => {
                      e.preventDefault();
                      setIsDragging(true);
                    }}
                    onDragLeave={() => setIsDragging(false)}
                    onDrop={handleDrop}
                    onClick={() => fileInputRef.current?.click()}
                    className={`p-5 border-2 border-dashed rounded-xl flex flex-col items-center justify-center text-center cursor-pointer transition-colors bg-white ${
                      isDragging
                        ? 'border-emerald-500 bg-emerald-50/40'
                        : 'border-slate-300 hover:border-emerald-400 hover:bg-slate-50/50'
                    }`}
                  >
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept=".jpg,.jpeg,.png,.gif,.webp,.heic,.heif,image/jpeg,image/png,image/gif,image/webp,image/heic,image/heif"
                      onChange={handleFileInputChange}
                      className="hidden"
                    />

                    <div className="w-10 h-10 rounded-full bg-emerald-50 text-emerald-700 flex items-center justify-center mb-2">
                      <Upload className="w-5 h-5" />
                    </div>
                    <div className="text-xs font-bold text-slate-800">
                      {isIndonesian
                        ? 'Klik untuk memilih file atau seret gambar ke sini'
                        : 'Click to choose file or drag image here'}
                    </div>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      {isIndonesian ? 'JPG / PNG / WEBP hingga 10MB' : 'JPG / PNG / WEBP up to 10MB'}
                    </p>
                  </div>

                  {uploadError && (
                    <p className="text-[11px] text-rose-600 flex items-center gap-1 font-medium">
                      <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                      <span>{uploadError}</span>
                    </p>
                  )}
                </div>

                {/* Job Title & Department */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div>
                    <label className="block font-bold text-slate-800 mb-1">
                      {isIndonesian ? 'Jabatan / Peran' : 'Job Title / Role'}
                    </label>
                    <input
                      type="text"
                      value={jobTitle}
                      onChange={(e) => setJobTitle(e.target.value)}
                      className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:outline-hidden focus:border-[#065F46]"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-slate-800 mb-1">
                      {isIndonesian ? 'Departemen' : 'Department'}
                    </label>
                    <input
                      type="text"
                      value={department}
                      onChange={(e) => setDepartment(e.target.value)}
                      className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:outline-hidden focus:border-[#065F46]"
                    />
                  </div>
                </div>

                {/* Bottom Actions */}
                <div className="pt-3 border-t border-slate-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                  <span className="text-[11px] text-slate-400 flex items-center gap-1">
                    <Lock className="w-3.5 h-3.5" />
                    <span>
                      {isIndonesian
                        ? 'Izin peran dan penugasan tim dikelola oleh Super Admin.'
                        : 'Role permissions and team assignments are managed by Super Admin.'}
                    </span>
                  </span>
                  <div className="flex items-center gap-2 self-end sm:self-auto">
                    <button
                      type="button"
                      disabled={isLoggingOut}
                      onClick={() => logout()}
                      className="px-4 py-2 text-xs font-semibold text-rose-600 bg-rose-50 hover:bg-rose-100 disabled:opacity-50 rounded-xl transition-colors flex items-center gap-1.5"
                    >
                      <LogOut className="w-3.5 h-3.5" />
                      <span>
                        {isLoggingOut
                          ? isIndonesian
                            ? 'Menyimpan...'
                            : 'Saving...'
                          : isIndonesian
                          ? 'Keluar'
                          : 'Sign Out'}
                      </span>
                    </button>
                    <button
                      type="submit"
                      disabled={isSavingProfile || isLoggingOut}
                      className="px-5 py-2 text-xs font-bold text-white bg-[#065F46] hover:bg-[#044e39] disabled:opacity-60 rounded-xl transition-colors shadow-xs active:scale-[0.98]"
                    >
                      {isSavingProfile
                        ? isIndonesian
                          ? 'Menyimpan...'
                          : 'Saving...'
                        : isSaved
                        ? isIndonesian
                          ? 'Tersimpan!'
                          : 'Saved!'
                        : isIndonesian
                        ? 'Simpan Profil'
                        : 'Save Profile'}
                    </button>
                  </div>
                </div>
              </form>
            </>
          ) : (
            <>
              {/* TAB 2: SECURITY & PASSWORD */}
              <div className="space-y-6">
                <div>
                  <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                    <KeyRound className="w-4 h-4 text-[#065F46]" />
                    <span>{isIndonesian ? 'Ubah Kata Sandi Saya' : 'Change My Password'}</span>
                  </h3>
                  <p className="text-xs text-slate-500 mt-0.5">
                    {isIndonesian
                      ? 'Pastikan password Anda memiliki panjang minimal 12 karakter untuk mematuhi kebijakan keamanan enterprise PT Lyman Devindo.'
                      : 'Ensure your password is at least 12 characters long to comply with PT Lyman Devindo enterprise security policy.'}
                  </p>
                </div>

                {passwordError && (
                  <div className="p-3.5 bg-rose-50 text-rose-700 text-xs font-semibold rounded-xl border border-rose-200 flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                    <span>{passwordError}</span>
                  </div>
                )}

                {passwordSuccess && (
                  <div className="p-3.5 bg-emerald-50 text-emerald-800 text-xs font-semibold rounded-xl border border-emerald-200 flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>{passwordSuccess}</span>
                  </div>
                )}

                <form onSubmit={handleChangePasswordSubmit} className="space-y-4 max-w-lg">
                  <PasswordInput
                    id="profile-current-password"
                    label={isIndonesian ? 'Kata Sandi Saat Ini' : 'Current Password'}
                    value={currentPassword}
                    onChange={setCurrentPassword}
                    placeholder={isIndonesian ? 'Masukkan kata sandi saat ini' : 'Enter current password'}
                    required
                    disabled={isSubmittingPassword}
                  />

                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] text-slate-500">
                        {isIndonesian ? 'Kata sandi baru:' : 'New password:'}
                      </span>
                      <button
                        type="button"
                        onClick={handleGeneratePasswordForProfile}
                        className="text-[11px] font-bold text-emerald-700 hover:text-emerald-900 flex items-center gap-1 hover:underline"
                      >
                        <Sparkles className="w-3 h-3 text-emerald-600" />
                        <span>{isIndonesian ? 'Buat Password Kuat Otomatis' : 'Generate Strong Password'}</span>
                      </button>
                    </div>

                    <PasswordInput
                      id="profile-new-password"
                      label={isIndonesian ? 'Kata Sandi Baru' : 'New Password'}
                      value={newPassword}
                      onChange={setNewPassword}
                      placeholder={isIndonesian ? 'Minimal 12 karakter' : 'Minimum 12 characters'}
                      required
                      showStrength
                      disabled={isSubmittingPassword}
                      helpText={
                        isIndonesian
                          ? 'Dapat berupa passphrase unik atau kombinasi huruf, angka, dan simbol.'
                          : 'Can be a unique passphrase or combination of letters, numbers, and symbols.'
                      }
                    />
                  </div>

                  <PasswordInput
                    id="profile-confirm-password"
                    label={isIndonesian ? 'Konfirmasi Kata Sandi Baru' : 'Confirm New Password'}
                    value={confirmNewPassword}
                    onChange={setConfirmNewPassword}
                    placeholder={isIndonesian ? 'Ulangi kata sandi baru' : 'Repeat new password'}
                    required
                    disabled={isSubmittingPassword}
                    error={
                      confirmNewPassword && newPassword !== confirmNewPassword
                        ? (isIndonesian ? 'Konfirmasi kata sandi tidak cocok' : 'Password confirmation does not match')
                        : undefined
                    }
                  />

                  <div className="pt-2">
                    <button
                      type="submit"
                      disabled={isSubmittingPassword || (confirmNewPassword.length > 0 && newPassword !== confirmNewPassword)}
                      className="px-6 py-2.5 text-xs font-bold text-white bg-[#065F46] hover:bg-[#044e39] disabled:bg-slate-300 rounded-xl transition-all shadow-xs active:scale-[0.98] flex items-center gap-2"
                    >
                      <Lock className="w-3.5 h-3.5" />
                      <span>
                        {isSubmittingPassword
                          ? (isIndonesian ? 'Memperbarui...' : 'Updating...')
                          : (isIndonesian ? 'Perbarui Kata Sandi' : 'Update Password')}
                      </span>
                    </button>
                  </div>
                </form>

                {/* Session notice */}
                <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 text-xs text-slate-600 space-y-1.5">
                  <div className="flex items-center gap-2 font-bold text-slate-800">
                    <ShieldCheck className="w-4 h-4 text-[#065F46]" />
                    <span>{isIndonesian ? 'Manajemen Sesi Otomatis' : 'Automatic Session Management'}</span>
                  </div>
                  <p className="text-[11px] leading-relaxed">
                    {isIndonesian
                      ? 'Setelah kata sandi berhasil diperbarui, seluruh sesi login aktif lainnya pada perangkat lain akan secara otomatis dicabut demi perlindungan keamanan akun. Sesi browser ini akan tetap aktif secara aman.'
                      : 'Once your password is updated, all other active login sessions on other devices will be automatically revoked to protect account security. Your current browser session will remain safely active.'}
                  </p>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
