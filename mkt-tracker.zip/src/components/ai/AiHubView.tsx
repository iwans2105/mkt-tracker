import React, { useState } from 'react';
import {
  Sparkles,
  FileCheck,
  UserCheck,
  Briefcase,
  AlertTriangle,
  Lightbulb,
  TrendingUp,
  FileText,
  BookOpen,
  ArrowRight,
  Send,
  RefreshCw,
  Copy,
  Check,
  ShieldAlert,
  ChevronRight,
  Sliders,
  Percent,
  CheckCircle2,
  Calendar,
  Layers,
  HelpCircle,
} from 'lucide-react';
import { useRequests } from '../../context/RequestContext';
import { useAuth } from '../../context/AuthContext';
import { useLanguage } from '../../context/LanguageContext';
import {
  STATUS_LABELS,
  STATUS_LABELS_ID,
  PRIORITY_LABELS,
  PRIORITY_LABELS_ID,
} from '../common/StatusBadge';
import {
  AiService,
  RequestAssistantResult,
  BriefAnalysisResult,
  AssignmentRecommendationResult,
  WorkloadOptimizerResult,
  DeadlineRiskResult,
  CreativeAssistantResult,
  ExecutiveInsightsResult,
} from '../../services/aiService';

type AiHubTab =
  | 'request_assistant'
  | 'brief_analyzer'
  | 'task_assignment'
  | 'workload_optimizer'
  | 'deadline_risk'
  | 'creative_assistant'
  | 'executive_insights'
  | 'report_generator'
  | 'knowledge_assistant';

interface AiHubViewProps {
  onOpenCreateWithPrefill?: (prefill: {
    title: string;
    description: string;
    deliverables: string;
    priority: 'urgent' | 'high' | 'medium' | 'low';
    categoryId?: string;
  }) => void;
  onSelectRequestDetail?: (requestId: string) => void;
}

export const AiHubView: React.FC<AiHubViewProps> = ({
  onOpenCreateWithPrefill,
  onSelectRequestDetail,
}) => {
  const { requests, brands, categories, analytics, showToast } = useRequests();
  const { currentUser, isAdmin } = useAuth();
  const { isIndonesian } = useLanguage();

  const [activeTab, setActiveTab] = useState<AiHubTab>('request_assistant');
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  // 1. Request Assistant State
  const [reqPrompt, setReqPrompt] = useState('');
  const [reqBrand, setReqBrand] = useState('Mason Pine Hotel');
  const [reqCategory, setReqCategory] = useState('Graphic Design');
  const [reqResult, setReqResult] = useState<RequestAssistantResult | null>(null);

  // 2. Brief Analyzer State
  const [analyzerSelectedId, setAnalyzerSelectedId] = useState<string>(requests[0]?.id || '');
  const [analyzerResult, setAnalyzerResult] = useState<BriefAnalysisResult | null>(null);

  // 3. Task Assignment State
  const [assignSelectedId, setAssignSelectedId] = useState<string>(requests[0]?.id || '');
  const [assignResult, setAssignResult] = useState<AssignmentRecommendationResult | null>(null);

  // 4. Workload Optimizer State
  const [workloadResult, setWorkloadResult] = useState<WorkloadOptimizerResult | null>(null);

  // 5. Deadline Risk State
  const [riskSelectedId, setRiskSelectedId] = useState<string>(requests[0]?.id || '');
  const [riskResult, setRiskResult] = useState<DeadlineRiskResult | null>(null);

  // 6. Creative Assistant State
  const [creativeBrand, setCreativeBrand] = useState('Wahoo Waterworld');
  const [creativeTheme, setCreativeTheme] = useState(
    isIndonesian ? 'Kampanye Promo Seru Liburan Sekolah' : 'Exciting School Holiday Promo Campaign'
  );
  const [creativeMedium, setCreativeMedium] = useState('Instagram Feed & Story');
  const [creativeTone, setCreativeTone] = useState(
    isIndonesian ? 'Ceria, Menarik, Ramah Keluarga' : 'Vibrant, Engaging, Family-Friendly'
  );
  const [creativeResult, setCreativeResult] = useState<CreativeAssistantResult | null>(null);

  // 7. Executive Insights State
  const [insightsResult, setInsightsResult] = useState<ExecutiveInsightsResult | null>(null);

  // 8. Report Generator State
  const [reportTitle, setReportTitle] = useState(
    isIndonesian
      ? 'Laporan Kinerja Bulanan — Marketing Communications'
      : 'Monthly Performance Report — Marketing Communications'
  );
  const [reportPeriod, setReportPeriod] = useState('Q1 2026');
  const [reportMarkdown, setReportMarkdown] = useState<string>('');

  // 9. Knowledge Assistant State
  const [chatQuestion, setChatQuestion] = useState('');
  const [chatMessages, setChatMessages] = useState<Array<{ sender: 'user' | 'ai'; text: string }>>([
    {
      sender: 'ai',
      text: isIndonesian
        ? 'Halo! Saya Asisten Pengetahuan Marcomm Anda. Tanyakan apa saja mengenai SOP Divisi, Kebijakan SLA (Mendesak 1h, Tinggi 3h, Sedang 7h, Rendah 14h), Direktori Properti Jakarta & Bandung, atau Alur Persetujuan Revisi Kreatif.'
        : 'Hello! I am your Marcomm Knowledge Assistant. Ask me anything regarding Division SOPs, SLA Policies (Urgent 1d, High 3d, Medium 7d, Low 14d), Jakarta & Bandung Property Directories, or Creative Revision Approval Workflows.',
    },
  ]);

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Run Request Assistant
  const handleRunRequestAssistant = async () => {
    if (!reqPrompt.trim()) return;
    setLoading(true);
    try {
      const res = await AiService.getRequestAssistant({
        prompt: reqPrompt,
        brand: reqBrand,
        category: reqCategory,
      });
      setReqResult(res);
      showToast(
        isIndonesian
          ? 'Asisten Permintaan AI berhasil menyusun brief terstruktur'
          : 'AI Request Assistant successfully formulated a structured brief',
        'success'
      );
    } catch (err: any) {
      showToast(
        err.message || (isIndonesian ? 'Gagal memproses Asisten Permintaan AI' : 'Failed to process AI Request Assistant'),
        'error'
      );
    } finally {
      setLoading(false);
    }
  };

  // Run Brief Analyzer
  const handleRunBriefAnalyzer = async () => {
    const target = requests.find((r) => r.id === analyzerSelectedId) || requests[0];
    if (!target) return;
    setLoading(true);
    try {
      let lastComments = '';
      try {
        const cmRes = await fetch(`/api/requests/${encodeURIComponent(target.id)}/comments`, {
          credentials: 'include',
          cache: 'no-store',
        });
        const cmData = await cmRes.json().catch(() => ({}));
        if (cmRes.ok && Array.isArray(cmData.comments)) {
          lastComments = cmData.comments
            .map((c: { authorName: string; content: string }) => `${c.authorName}: ${c.content}`)
            .join('\n');
        }
      } catch {
        // Proceed with brief analysis even if comments endpoint is empty
      }
      const res = await AiService.analyzeBrief({
        title: target.title,
        description: target.description,
        deliverables: target.deliverablesExpected,
        category: target.categoryId,
        comments: lastComments,
      });
      setAnalyzerResult(res);
    } catch (err: any) {
      showToast(isIndonesian ? 'Gagal menganalisis brief' : 'Failed to analyze brief', 'error');
    } finally {
      setLoading(false);
    }
  };

  // Run Task Assignment
  const handleRunTaskAssignment = async () => {
    const target = requests.find((r) => r.id === assignSelectedId) || requests[0];
    if (!target) return;
    setLoading(true);
    try {
      const res = await AiService.recommendAssignment({
        category: target.categoryId,
        brand: target.brandName,
        priority: target.priority,
      });
      setAssignResult(res);
    } catch (err: any) {
      showToast(
        isIndonesian ? 'Gagal mengambil rekomendasi penugasan' : 'Failed to retrieve assignment recommendations',
        'error'
      );
    } finally {
      setLoading(false);
    }
  };

  // Run Workload Optimizer
  const handleRunWorkloadOptimizer = async () => {
    setLoading(true);
    try {
      const res = await AiService.optimizeWorkload({
        teamStats: {
          totalRequests: requests.length,
          activeRequests: requests.filter((r) => r.status !== 'completed').length,
          overdue: requests.filter((r) => r.isOverdue).length,
        },
      });
      setWorkloadResult(res);
    } catch (err: any) {
      showToast(isIndonesian ? 'Gagal mengoptimalkan beban kerja' : 'Failed to optimize workload', 'error');
    } finally {
      setLoading(false);
    }
  };

  // Run Deadline Risk
  const handleRunDeadlineRisk = async () => {
    const target = requests.find((r) => r.id === riskSelectedId) || requests[0];
    if (!target) return;
    setLoading(true);
    try {
      const deadlineDate = target.committedDeadline
        ? new Date(target.committedDeadline)
        : new Date(target.requestedDeadline);
      const diffDays = Math.ceil((deadlineDate.getTime() - Date.now()) / (1000 * 60 * 60 * 24));
      const res = await AiService.predictDeadlineRisk({
        requestTitle: target.title,
        priority: target.priority,
        status: target.status,
        daysLeft: diffDays,
        isOverdue: Boolean(target.isOverdue),
        revisionsCount: target.reopenCount || 0,
      });
      setRiskResult(res);
    } catch (err: any) {
      showToast(isIndonesian ? 'Gagal memprediksi risiko tenggat waktu' : 'Failed to predict deadline risk', 'error');
    } finally {
      setLoading(false);
    }
  };

  // Run Creative Assistant
  const handleRunCreativeAssistant = async () => {
    setLoading(true);
    try {
      const res = await AiService.generateCreativeIdeas({
        brand: creativeBrand,
        campaignTheme: creativeTheme,
        medium: creativeMedium,
        tone: creativeTone,
      });
      setCreativeResult(res);
      showToast(
        isIndonesian ? 'Konsep kreatif & copywriting berhasil dibuat' : 'Creative concepts & copywriting generated successfully',
        'success'
      );
    } catch (err: any) {
      showToast(isIndonesian ? 'Gagal membuat konsep kreatif' : 'Failed to generate creative concepts', 'error');
    } finally {
      setLoading(false);
    }
  };

  // Run Executive Insights
  const handleRunExecutiveInsights = async () => {
    setLoading(true);
    try {
      const res = await AiService.getExecutiveInsights({
        summaryData: {
          total: analytics.totalRequests,
          completed: analytics.completedRequests,
          inProgress: analytics.activeRequests,
          overdue: analytics.overdueRequests,
          complianceRate: analytics.slaFulfillmentRate || 0,
          avgCompletionDays: analytics.avgCompletionDays || 0,
        },
      });
      setInsightsResult(res);
    } catch (err: any) {
      showToast(isIndonesian ? 'Gagal menyusun wawasan eksekutif' : 'Failed to formulate executive insights', 'error');
    } finally {
      setLoading(false);
    }
  };

  // Run Report Generator
  const handleRunReportGenerator = async () => {
    setLoading(true);
    try {
      const report = await AiService.generateExecutiveReport({
        title: reportTitle,
        period: reportPeriod,
        stats: {
          total: analytics.totalRequests,
          completed: analytics.completedRequests,
          active: analytics.totalRequests - analytics.completedRequests,
          slaCompliance: `${analytics.slaFulfillmentRate || 0}%`,
        },
      });
      setReportMarkdown(report);
      showToast(isIndonesian ? 'Laporan eksekutif berhasil dibuat' : 'Executive report generated successfully', 'success');
    } catch (err: any) {
      showToast(isIndonesian ? 'Gagal membuat laporan' : 'Failed to generate report', 'error');
    } finally {
      setLoading(false);
    }
  };

  // Run Knowledge Chat
  const handleSendChatMessage = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!chatQuestion.trim()) return;

    const userText = chatQuestion;
    setChatMessages((prev) => [...prev, { sender: 'user', text: userText }]);
    setChatQuestion('');
    setLoading(true);

    try {
      const res = await AiService.askKnowledgeAssistant({ question: userText });
      setChatMessages((prev) => [...prev, { sender: 'ai', text: res.answer }]);
    } catch (err: any) {
      setChatMessages((prev) => [
        ...prev,
        {
          sender: 'ai',
          text: isIndonesian
            ? 'Terjadi kendala saat menghubungi Asisten Pengetahuan. Silakan coba susun ulang pertanyaan Anda.'
            : 'We encountered an issue reaching the Knowledge Assistant. Please try rephrasing your question.',
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  const navTabs: Array<{ id: AiHubTab; label: string; icon: React.ReactNode; desc: string }> = [
    {
      id: 'request_assistant',
      label: isIndonesian ? 'Asisten Permintaan AI' : 'AI Request Assistant',
      icon: <Sparkles className="w-4 h-4 text-indigo-600" />,
      desc: isIndonesian ? 'Susun brief & rekomendasi SLA' : 'Formulate briefs & SLA recommendations',
    },
    {
      id: 'brief_analyzer',
      label: isIndonesian ? 'Analisis Brief & Umpan Balik AI' : 'AI Brief & Feedback Analyzer',
      icon: <FileCheck className="w-4 h-4 text-emerald-600" />,
      desc: isIndonesian ? 'Skor kejelasan & rincian revisi' : 'Clarity score & revision breakdown',
    },
    {
      id: 'task_assignment',
      label: isIndonesian ? 'Optimizer Penugasan Tugas AI' : 'AI Task Assignment Optimizer',
      icon: <UserCheck className="w-4 h-4 text-blue-600" />,
      desc: isIndonesian ? 'Rekomendasi pelaksana & tim terbaik' : 'Optimal assignee & team recommendations',
    },
    {
      id: 'workload_optimizer',
      label: isIndonesian ? 'Optimizer Beban Kerja AI' : 'AI Workload Optimizer',
      icon: <Briefcase className="w-4 h-4 text-amber-600" />,
      desc: isIndonesian ? 'Deteksi bottleneck & seimbangkan beban' : 'Detect bottlenecks & balance workload',
    },
    {
      id: 'deadline_risk',
      label: isIndonesian ? 'Prediksi Risiko Tenggat AI' : 'AI Deadline Risk Prediction',
      icon: <AlertTriangle className="w-4 h-4 text-rose-600" />,
      desc: isIndonesian ? 'Prediksi peluang keterlambatan & mitigasi' : 'Predict delay probability & mitigation',
    },
    {
      id: 'creative_assistant',
      label: isIndonesian ? 'Asisten Kreatif & Pemasaran AI' : 'AI Creative & Marketing',
      icon: <Lightbulb className="w-4 h-4 text-purple-600" />,
      desc: isIndonesian ? 'Ide kampanye, copywriting & caption' : 'Campaign ideas, copy & social captions',
    },
    {
      id: 'executive_insights',
      label: isIndonesian ? 'Analitik & Wawasan Eksekutif AI' : 'AI Analytics & Insights',
      icon: <TrendingUp className="w-4 h-4 text-teal-600" />,
      desc: isIndonesian ? 'Diagnosis kinerja & saran strategis' : 'Performance diagnosis & strategic advice',
    },
    {
      id: 'report_generator',
      label: isIndonesian ? 'Pembuat Laporan Eksekutif AI' : 'AI Report Generator',
      icon: <FileText className="w-4 h-4 text-cyan-600" />,
      desc: isIndonesian ? 'Buat laporan eksekutif resmi' : 'Generate formal executive reports',
    },
    {
      id: 'knowledge_assistant',
      label: isIndonesian ? 'Asisten Pengetahuan AI' : 'AI Knowledge Assistant',
      icon: <BookOpen className="w-4 h-4 text-orange-600" />,
      desc: isIndonesian ? 'Tanya jawab SOP, Brand & Kebijakan SLA' : 'SOP, Brand & SLA Policy Q&A',
    },
  ];

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="relative overflow-hidden bg-gradient-to-r from-[#065F46] via-[#047857] to-[#0f172a] rounded-2xl p-4 sm:p-6 md:p-8 text-white shadow-md border border-emerald-700/40">
        <div className="relative z-10 max-w-3xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/15 text-[#A7F3D0] text-xs font-semibold mb-2.5 border border-white/20">
            <Sparkles className="w-3.5 h-3.5 text-[#A7F3D0] animate-pulse" />
            {isIndonesian ? 'Rangkaian Kecerdasan AI Marcomm' : 'AI Marcomm Intelligence Suite'}
          </div>
          <h1 className="text-xl sm:text-2xl md:text-3xl font-extrabold tracking-tight text-white mb-2 leading-snug">
            {isIndonesian ? 'Pusat AI Marcomm & Dukungan Keputusan' : 'Marcomm AI Hub & Decision Support'}
          </h1>
          <p className="text-emerald-50 text-xs sm:text-sm md:text-base leading-relaxed">
            {isIndonesian
              ? 'Sistem kecerdasan terintegrasi untuk Marketing Communications Lyman Group. Akses 9 modul AI korporat untuk perumusan brief terstruktur, optimasi penugasan tugas, mitigasi risiko tenggat waktu, penulisan kreatif, dan pelaporan SLA eksekutif.'
              : 'Integrated intelligence system for Lyman Group Marketing Communications. Access 9 enterprise AI modules for structured brief formulation, task assignment optimization, deadline risk mitigation, creative copywriting, and executive SLA reporting.'}
          </p>
        </div>
      </div>

      {/* Grid Navigation: 9 Modules */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5 sm:gap-3">
        {navTabs.map((tab) => {
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-start gap-3 p-3 sm:p-4 rounded-xl text-left transition-all border cursor-pointer ${
                isActive
                  ? 'bg-[#D1FAE5]/60 border-[#A7F3D0] ring-2 ring-[#065F46]/20 shadow-xs'
                  : 'bg-white border-[#E5E7EB] hover:border-slate-300 hover:bg-[#F0FDF4]/40 shadow-2xs'
              }`}
            >
              <div
                className={`p-2 rounded-lg shrink-0 ${
                  isActive ? 'bg-[#065F46] text-white shadow-xs' : 'bg-slate-100 text-slate-600'
                }`}
              >
                {tab.icon}
              </div>
              <div className="min-w-0 flex-1">
                <div
                  className={`text-xs sm:text-sm font-semibold truncate ${
                    isActive ? 'text-[#065F46] font-bold' : 'text-slate-800'
                  }`}
                >
                  {tab.label}
                </div>
                <div className="text-[11px] sm:text-xs text-[#64748B] mt-0.5 line-clamp-1">{tab.desc}</div>
              </div>
            </button>
          );
        })}
      </div>

      {/* Main Feature Container */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        {/* 1. AI REQUEST ASSISTANT */}
        {activeTab === 'request_assistant' && (
          <div className="p-4 sm:p-6 md:p-8 space-y-5 sm:space-y-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-100">
              <div>
                <div className="flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-indigo-600" />
                  <h2 className="text-lg font-bold text-slate-900">
                    {isIndonesian ? 'Asisten Permintaan AI' : 'AI Request Assistant'}
                  </h2>
                </div>
                <p className="text-xs text-slate-500 mt-1">
                  {isIndonesian
                    ? 'Ketikkan ide mentah atau kebutuhan proyek Anda. AI akan menyusun judul profesional, deskripsi terstruktur, daftar hasil pekerjaan, serta rekomendasi kategori & SLA yang tepat.'
                    : 'Type your raw ideas or project requirements. AI will formulate a professional title, structured description, deliverables list, and appropriate category & SLA recommendations.'}
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Input Form */}
              <div className="lg:col-span-5 space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                    {isIndonesian ? 'Brand / Entitas' : 'Brand / Entity'}
                  </label>
                  <select
                    value={reqBrand}
                    onChange={(e) => setReqBrand(e.target.value)}
                    className="w-full text-sm rounded-lg border border-slate-300 bg-white px-3 py-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  >
                    {brands.map((b) => (
                      <option key={b.id} value={b.name}>
                        {b.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                    {isIndonesian ? 'Kategori Awal (Opsional)' : 'Initial Category (Optional)'}
                  </label>
                  <select
                    value={reqCategory}
                    onChange={(e) => setReqCategory(e.target.value)}
                    className="w-full text-sm rounded-lg border border-slate-300 bg-white px-3 py-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  >
                    {categories.map((c) => (
                      <option key={c.id} value={c.name}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                    {isIndonesian ? 'Ide Brief Kreatif / Permintaan Awal' : 'Initial Request / Creative Brief Idea'}
                  </label>
                  <textarea
                    rows={5}
                    value={reqPrompt}
                    onChange={(e) => setReqPrompt(e.target.value)}
                    placeholder={
                      isIndonesian
                        ? 'Contoh: Butuh materi promosi diskon tiket weekday 25% di Wahoo Waterworld untuk Instagram feed dan reels, dibutuhkan sebelum Jumat...'
                        : 'Example: Need promotional creatives for 25% weekday ticket discount at Wahoo Waterworld for Instagram feed and reels, required before Friday...'
                    }
                    className="w-full text-sm rounded-lg border border-slate-300 bg-white p-3 text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>

                <button
                  type="button"
                  onClick={handleRunRequestAssistant}
                  disabled={loading || !reqPrompt.trim()}
                  className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-indigo-600 text-white font-medium text-sm hover:bg-indigo-700 disabled:opacity-50 transition-colors shadow-xs cursor-pointer"
                >
                  {loading ? (
                    <RefreshCw className="w-4 h-4 animate-spin" />
                  ) : (
                    <Sparkles className="w-4 h-4" />
                  )}
                  {loading
                    ? isIndonesian ? 'Menyusun Brief...' : 'Formulating Brief...'
                    : isIndonesian ? 'Susun Brief dengan AI' : 'Formulate Brief with AI'}
                </button>
              </div>

              {/* Output Result */}
              <div className="lg:col-span-7 bg-slate-50/70 rounded-xl p-5 border border-slate-200">
                {reqResult ? (
                  <div className="space-y-4">
                    <div className="flex items-start justify-between gap-4">
                      <div>
                        <div className="text-xs font-semibold text-indigo-700 uppercase tracking-wider">
                          {isIndonesian ? 'Rekomendasi Judul & SLA' : 'Recommended Title & SLA'}
                        </div>
                        <h3 className="text-base font-bold text-slate-900 mt-0.5">
                          {reqResult.title}
                        </h3>
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-indigo-100 text-indigo-800">
                          {isIndonesian ? PRIORITY_LABELS_ID[reqResult.recommendedPriority] : PRIORITY_LABELS[reqResult.recommendedPriority]} SLA
                        </span>
                      </div>
                    </div>

                    <div className="p-3 bg-amber-50 rounded-lg border border-amber-200 text-xs text-amber-900 leading-relaxed">
                      <strong>{isIndonesian ? 'Dasar Pertimbangan SLA:' : 'SLA Rationale:'}</strong> {reqResult.slaRationale}
                    </div>

                    <div>
                      <div className="text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1">
                        {isIndonesian ? 'Deskripsi Permintaan' : 'Request Description'}
                      </div>
                      <div className="text-xs text-slate-800 whitespace-pre-line bg-white p-3 rounded-lg border border-slate-200">
                        {reqResult.description}
                      </div>
                    </div>

                    <div>
                      <div className="text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1">
                        {isIndonesian ? 'Daftar Hasil Pekerjaan (Deliverables)' : 'Deliverables List'}
                      </div>
                      <ul className="space-y-1 bg-white p-3 rounded-lg border border-slate-200 text-xs text-slate-800">
                        {reqResult.deliverables.map((item, idx) => (
                          <li key={idx} className="flex items-center gap-2">
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                            <span>{item}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    {reqResult.technicalSpecs && (
                      <div className="text-xs text-slate-600">
                        <strong>{isIndonesian ? 'Spesifikasi Teknis:' : 'Technical Specifications:'}</strong> {reqResult.technicalSpecs}
                      </div>
                    )}

                    {onOpenCreateWithPrefill && (
                      <button
                        type="button"
                        onClick={() =>
                          onOpenCreateWithPrefill({
                            title: reqResult.title,
                            description: reqResult.description,
                            deliverables: reqResult.deliverables.join('\n'),
                            priority: reqResult.recommendedPriority,
                          })
                        }
                        className="w-full inline-flex items-center justify-center gap-2 px-4 py-2 rounded-lg bg-emerald-600 text-white font-medium text-xs hover:bg-emerald-700 transition-colors shadow-xs cursor-pointer"
                      >
                        {isIndonesian ? 'Gunakan Brief Ini di Formulir Permintaan' : 'Use This Brief in Request Form'}
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                ) : (
                  <div className="h-full flex flex-col items-center justify-center text-center p-8 text-slate-400">
                    <Sparkles className="w-10 h-10 text-slate-300 mb-3" />
                    <p className="text-sm font-medium text-slate-600">
                      {isIndonesian ? 'Belum Ada Brief yang Dibuat' : 'No Brief Generated Yet'}
                    </p>
                    <p className="text-xs text-slate-400 max-w-sm mt-1">
                      {isIndonesian
                        ? "Masukkan ringkasan permintaan Anda di sebelah kiri lalu klik 'Susun Brief dengan AI'."
                        : "Enter an overview of your request on the left and click 'Formulate Brief with AI'."}
                    </p>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* 2. AI BRIEF & FEEDBACK ANALYZER */}
        {activeTab === 'brief_analyzer' && (
          <div className="p-6 md:p-8 space-y-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-100">
              <div>
                <div className="flex items-center gap-2">
                  <FileCheck className="w-5 h-5 text-emerald-600" />
                  <h2 className="text-lg font-bold text-slate-900">
                    {isIndonesian ? 'Analisis Brief & Umpan Balik AI' : 'AI Brief & Feedback Analyzer'}
                  </h2>
                </div>
                <p className="text-xs text-slate-500 mt-1">
                  {isIndonesian
                    ? 'Menganalisis kelengkapan teknis permintaan, mendeteksi spesifikasi desain yang kurang, serta mengurai sentimen umpan balik revisi dan tindak lanjutnya.'
                    : 'Analyzes technical completeness of a request, detects missing design specifications, and deciphers revision feedback sentiments and actionable tasks.'}
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              <div className="lg:col-span-5 space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                    {isIndonesian ? 'Pilih Permintaan untuk Dianalisis' : 'Select Request to Analyze'}
                  </label>
                  <select
                    value={analyzerSelectedId}
                    onChange={(e) => setAnalyzerSelectedId(e.target.value)}
                    className="w-full text-sm rounded-lg border border-slate-300 bg-white px-3 py-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  >
                    {requests.map((r) => (
                      <option key={r.id} value={r.id}>
                        {r.ticketNumber} - {r.title}
                      </option>
                    ))}
                  </select>
                </div>

                <button
                  type="button"
                  onClick={handleRunBriefAnalyzer}
                  disabled={loading}
                  className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-emerald-600 text-white font-medium text-sm hover:bg-emerald-700 disabled:opacity-50 transition-colors shadow-xs cursor-pointer"
                >
                  {loading ? (
                    <RefreshCw className="w-4 h-4 animate-spin" />
                  ) : (
                    <FileCheck className="w-4 h-4" />
                  )}
                  {loading
                    ? isIndonesian ? 'Menganalisis Brief...' : 'Analyzing Brief...'
                    : isIndonesian ? 'Audit Kelengkapan Brief' : 'Audit Brief Completeness'}
                </button>
              </div>

              <div className="lg:col-span-7 bg-slate-50/70 rounded-xl p-5 border border-slate-200">
                {analyzerResult ? (
                  <div className="space-y-4">
                    <div className="flex items-center justify-between bg-white p-4 rounded-xl border border-slate-200">
                      <div>
                        <div className="text-xs text-slate-500">
                          {isIndonesian ? 'Skor Kelengkapan Brief' : 'Brief Completeness Score'}
                        </div>
                        <div className="text-2xl font-black text-slate-900 mt-0.5">
                          {analyzerResult.completenessScore}/100
                        </div>
                      </div>
                      <span
                        className={`px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider ${
                          analyzerResult.completenessScore >= 80
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-amber-100 text-amber-800'
                        }`}
                      >
                        {analyzerResult.clarityGrade}
                      </span>
                    </div>

                    {analyzerResult.missingSpecs.length > 0 && (
                      <div className="bg-rose-50/80 p-3.5 rounded-lg border border-rose-200">
                        <div className="text-xs font-bold text-rose-900 flex items-center gap-1.5 mb-1.5">
                          <AlertTriangle className="w-4 h-4 text-rose-600" />
                          {isIndonesian ? 'Spesifikasi Teknis yang Belum Lengkap:' : 'Missing Technical Specifications:'}
                        </div>
                        <ul className="list-disc list-inside text-xs text-rose-800 space-y-1">
                          {analyzerResult.missingSpecs.map((spec, i) => (
                            <li key={i}>{spec}</li>
                          ))}
                        </ul>
                      </div>
                    )}

                    <div className="bg-white p-3.5 rounded-lg border border-slate-200 text-xs space-y-2">
                      <div className="font-semibold text-slate-700">
                        {isIndonesian ? 'Rekomendasi Perbaikan:' : 'Improvement Recommendations:'}
                      </div>
                      <ul className="list-disc list-inside text-slate-600 space-y-1">
                        {analyzerResult.recommendations.map((rec, i) => (
                          <li key={i}>{rec}</li>
                        ))}
                      </ul>
                    </div>

                    {analyzerResult.revisionAnalysis?.hasRevisionNotes && (
                      <div className="bg-indigo-50/70 p-3.5 rounded-lg border border-indigo-200 text-xs space-y-1.5">
                        <div className="font-bold text-indigo-950 flex items-center gap-2">
                          <span>{isIndonesian ? 'Analisis Umpan Balik Revisi' : 'Revision Feedback Analysis'}</span>
                          <span className="px-2 py-0.5 bg-white rounded text-[10px] font-semibold text-indigo-700 border border-indigo-200">
                            {isIndonesian ? 'Sentimen:' : 'Sentiment:'} {analyzerResult.revisionAnalysis.sentiment}
                          </span>
                        </div>
                        <div className="text-indigo-900 font-medium">
                          {isIndonesian ? 'Poin Tindak Lanjut:' : 'Actionable Items:'}
                        </div>
                        <ul className="list-disc list-inside text-indigo-800 space-y-0.5">
                          {analyzerResult.revisionAnalysis.actionableItems.map((act, i) => (
                            <li key={i}>{act}</li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="h-full flex flex-col items-center justify-center text-center p-8 text-slate-400">
                    <FileCheck className="w-10 h-10 text-slate-300 mb-3" />
                    <p className="text-sm font-medium text-slate-600">
                      {isIndonesian ? 'Pilih Permintaan untuk Diaudit' : 'Select a Request to Audit'}
                    </p>
                    <p className="text-xs text-slate-400 max-w-sm mt-1">
                      {isIndonesian
                        ? 'AI akan mengevaluasi kejelasan tujuan, kelengkapan spesifikasi teknis, dan catatan revisi.'
                        : 'AI will evaluate goal clarity, technical specification completeness, and revision notes.'}
                    </p>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* 3. AI TASK ASSIGNMENT OPTIMIZER */}
        {activeTab === 'task_assignment' && (
          <div className="p-6 md:p-8 space-y-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-100">
              <div>
                <div className="flex items-center gap-2">
                  <UserCheck className="w-5 h-5 text-blue-600" />
                  <h2 className="text-lg font-bold text-slate-900">
                    {isIndonesian ? 'Optimizer Penugasan Tugas AI' : 'AI Task Assignment Optimizer'}
                  </h2>
                </div>
                <p className="text-xs text-slate-500 mt-1">
                  {isIndonesian
                    ? 'Mencocokkan spesifikasi permintaan dengan keahlian anggota tim Marcomm (Desain Grafis, Media Sosial & Dokumentasi, Pemasaran Digital, Dukungan TI) serta kapasitas beban kerja real-time.'
                    : 'Matches request specifications with skill sets across Marcomm team members (Graphic Design, Social Media & Documentation, Digital Marketing, IT Support) and real-time workload capacity.'}
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              <div className="lg:col-span-5 space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                    {isIndonesian ? 'Pilih Permintaan untuk Ditugaskan' : 'Select Request to Assign'}
                  </label>
                  <select
                    value={assignSelectedId}
                    onChange={(e) => setAssignSelectedId(e.target.value)}
                    className="w-full text-sm rounded-lg border border-slate-300 bg-white px-3 py-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    {requests.map((r) => (
                      <option key={r.id} value={r.id}>
                        {r.ticketNumber} - {r.title} ({r.categoryName || r.categoryId})
                      </option>
                    ))}
                  </select>
                </div>

                <button
                  type="button"
                  onClick={handleRunTaskAssignment}
                  disabled={loading}
                  className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-blue-600 text-white font-medium text-sm hover:bg-blue-700 disabled:opacity-50 transition-colors shadow-xs cursor-pointer"
                >
                  {loading ? (
                    <RefreshCw className="w-4 h-4 animate-spin" />
                  ) : (
                    <UserCheck className="w-4 h-4" />
                  )}
                  {loading
                    ? isIndonesian ? 'Menghitung...' : 'Calculating...'
                    : isIndonesian ? 'Rekomendasikan Pelaksana' : 'Recommend Assignee'}
                </button>
              </div>

              <div className="lg:col-span-7 bg-slate-50/70 rounded-xl p-5 border border-slate-200">
                {assignResult ? (
                  <div className="space-y-4">
                    {/* Primary Assignee Card */}
                    <div className="bg-white p-4 rounded-xl border border-blue-200 shadow-xs">
                      <div className="flex items-center justify-between">
                        <div>
                          <span className="text-[10px] font-bold uppercase tracking-wider text-blue-600">
                            {isIndonesian ? 'Rekomendasi Pelaksana Utama' : 'Recommended Primary Assignee'}
                          </span>
                          <h4 className="text-base font-bold text-slate-900 mt-0.5">
                            {assignResult.primaryAssignee.name}
                          </h4>
                        </div>
                        <div className="text-right">
                          <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-bold bg-blue-100 text-blue-800">
                            {isIndonesian ? 'Kesesuaian' : 'Match'} {assignResult.primaryAssignee.matchScore}%
                          </span>
                        </div>
                      </div>
                      <p className="text-xs text-slate-600 mt-2 bg-slate-50 p-2.5 rounded-lg border border-slate-100 leading-relaxed">
                        {assignResult.primaryAssignee.rationale}
                      </p>
                    </div>

                    {/* Collaborator */}
                    <div className="bg-white p-3.5 rounded-xl border border-slate-200 flex items-center justify-between text-xs">
                      <div>
                        <span className="text-slate-500">
                          {isIndonesian ? 'Kolaborator Pendukung:' : 'Supporting Collaborator:'}
                        </span>
                        <div className="font-bold text-slate-900 mt-0.5">
                          {assignResult.collaborator.name}
                        </div>
                      </div>
                      <span className="text-slate-500 font-medium">
                        {assignResult.collaborator.role}
                      </span>
                    </div>

                    <div className="p-3 bg-amber-50 rounded-lg border border-amber-200 text-xs text-amber-900">
                      <strong>{isIndonesian ? 'Catatan Kapasitas:' : 'Capacity Notice:'}</strong> {assignResult.workloadNotice}
                    </div>

                    <div className="text-xs text-slate-600 bg-white p-3 rounded-lg border border-slate-200">
                      <strong>{isIndonesian ? 'Rekomendasi Reviewer:' : 'Recommended Reviewer:'}</strong> {assignResult.reviewSuggestion}
                    </div>
                  </div>
                ) : (
                  <div className="h-full flex flex-col items-center justify-center text-center p-8 text-slate-400">
                    <UserCheck className="w-10 h-10 text-slate-300 mb-3" />
                    <p className="text-sm font-medium text-slate-600">
                      {isIndonesian ? 'Pilih Permintaan untuk Ditugaskan' : 'Select a Request to Assign'}
                    </p>
                    <p className="text-xs text-slate-400 max-w-sm mt-1">
                      {isIndonesian
                        ? 'AI mengevaluasi riwayat penyelesaian tugas, keahlian khusus, dan beban kerja aktif tim.'
                        : 'AI evaluates task completion history, specialized skill sets, and active team workload.'}
                    </p>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* 4. AI WORKLOAD OPTIMIZER */}
        {activeTab === 'workload_optimizer' && (
          <div className="p-6 md:p-8 space-y-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-100">
              <div>
                <div className="flex items-center gap-2">
                  <Briefcase className="w-5 h-5 text-amber-600" />
                  <h2 className="text-lg font-bold text-slate-900">
                    {isIndonesian ? 'Optimizer Beban Kerja AI' : 'AI Workload Optimizer'}
                  </h2>
                </div>
                <p className="text-xs text-slate-500 mt-1">
                  {isIndonesian
                    ? 'Mendeteksi ketimpangan beban kerja, penumpukan tugas pada anggota tim tertentu, dan menyusun strategi pemerataan tugas untuk menjaga kepatuhan SLA.'
                    : 'Detects workload imbalances, task bottlenecks on individual team members, and generates task redistribution strategies to maintain SLA compliance.'}
                </p>
              </div>
              <button
                type="button"
                onClick={handleRunWorkloadOptimizer}
                disabled={loading}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-amber-600 text-white font-medium text-xs hover:bg-amber-700 disabled:opacity-50 transition-colors shadow-xs cursor-pointer"
              >
                {loading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <RefreshCw className="w-4 h-4" />}
                {loading
                  ? isIndonesian ? 'Menganalisis...' : 'Analyzing...'
                  : isIndonesian ? 'Jalankan Optimasi Beban Kerja' : 'Run Workload Optimization'}
              </button>
            </div>

            {workloadResult ? (
              <div className="space-y-4">
                <div className="bg-amber-50 p-4 rounded-xl border border-amber-200 flex items-center justify-between">
                  <div>
                    <div className="text-xs font-semibold text-amber-800 uppercase tracking-wider">
                      {isIndonesian ? 'Kesehatan Kapasitas Tim' : 'Team Capacity Health'}
                    </div>
                    <div className="text-xl font-bold text-amber-950 mt-0.5">
                      {workloadResult.capacityHealth}
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="bg-white p-4 rounded-xl border border-slate-200">
                    <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-2">
                      {isIndonesian ? 'Deteksi Bottleneck' : 'Bottleneck Detection'}
                    </h4>
                    <ul className="space-y-1.5 text-xs text-slate-700">
                      {workloadResult.bottlenecks.map((item, i) => (
                        <li key={i} className="flex items-start gap-2">
                          <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                          <span>{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="bg-white p-4 rounded-xl border border-slate-200">
                    <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-2">
                      {isIndonesian ? 'Tips Operasional SLA' : 'Operational SLA Tips'}
                    </h4>
                    <ul className="space-y-1.5 text-xs text-slate-700">
                      {workloadResult.operationalTips.map((tip, i) => (
                        <li key={i} className="flex items-start gap-2">
                          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                          <span>{tip}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                <div className="bg-white p-4 rounded-xl border border-slate-200">
                  <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-3">
                    {isIndonesian ? 'Rekomendasi Penyeimbangan Ulang Tugas' : 'Task Rebalancing Recommendations'}
                  </h4>
                  <div className="space-y-2">
                    {workloadResult.rebalancingRecommendations.map((rec, i) => (
                      <div
                        key={i}
                        className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 p-3 rounded-lg bg-slate-50 border border-slate-200 text-xs"
                      >
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-rose-700">{rec.from}</span>
                          <ArrowRight className="w-3.5 h-3.5 text-slate-400" />
                          <span className="font-bold text-emerald-700">{rec.to}</span>
                        </div>
                        <div className="text-slate-600">{rec.suggestion}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-center py-12 text-slate-400">
                <Briefcase className="w-12 h-12 text-slate-300 mx-auto mb-3" />
                <p className="text-sm font-medium text-slate-600">
                  {isIndonesian ? "Klik 'Jalankan Optimasi Beban Kerja'" : "Click 'Run Workload Optimization'"}
                </p>
                <p className="text-xs text-slate-400 mt-1">
                  {isIndonesian
                    ? 'AI akan menghitung rasio beban kerja aktif untuk seluruh anggota tim Marcomm.'
                    : 'AI will calculate active workload ratios for Durman, Bayu, Ivan, Ragilhary, Franklin, and Iwan.'}
                </p>
              </div>
            )}
          </div>
        )}

        {/* 5. AI DEADLINE RISK PREDICTION */}
        {activeTab === 'deadline_risk' && (
          <div className="p-6 md:p-8 space-y-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-100">
              <div>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="w-5 h-5 text-rose-600" />
                  <h2 className="text-lg font-bold text-slate-900">
                    {isIndonesian ? 'Prediksi Risiko Tenggat AI' : 'AI Deadline Risk Prediction'}
                  </h2>
                </div>
                <p className="text-xs text-slate-500 mt-1">
                  {isIndonesian
                    ? 'Perhitungan probabilitas dini terhadap keterlambatan tenggat berdasarkan sisa waktu pengerjaan, siklus revisi, dan antrean persetujuan.'
                    : 'Early probability calculation of deadline delays based on remaining turnaround time, revision cycles, and pending approval queues.'}
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              <div className="lg:col-span-5 space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                    {isIndonesian ? 'Pilih Permintaan Aktif' : 'Select Active Request'}
                  </label>
                  <select
                    value={riskSelectedId}
                    onChange={(e) => setRiskSelectedId(e.target.value)}
                    className="w-full text-sm rounded-lg border border-slate-300 bg-white px-3 py-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-rose-500"
                  >
                    {requests.map((r) => (
                      <option key={r.id} value={r.id}>
                        {r.ticketNumber} - {r.title} ({isIndonesian ? STATUS_LABELS_ID[r.status] : STATUS_LABELS[r.status]})
                      </option>
                    ))}
                  </select>
                </div>

                <button
                  type="button"
                  onClick={handleRunDeadlineRisk}
                  disabled={loading}
                  className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-rose-600 text-white font-medium text-sm hover:bg-rose-700 disabled:opacity-50 transition-colors shadow-xs cursor-pointer"
                >
                  {loading ? (
                    <RefreshCw className="w-4 h-4 animate-spin" />
                  ) : (
                    <AlertTriangle className="w-4 h-4" />
                  )}
                  {loading
                    ? isIndonesian ? 'Menghitung Risiko...' : 'Calculating Risk...'
                    : isIndonesian ? 'Hitung Risiko Tenggat' : 'Calculate Deadline Risk'}
                </button>
              </div>

              <div className="lg:col-span-7 bg-slate-50/70 rounded-xl p-5 border border-slate-200">
                {riskResult ? (
                  <div className="space-y-4">
                    <div className="bg-white p-4 rounded-xl border border-slate-200 flex items-center justify-between">
                      <div>
                        <div className="text-xs text-slate-500">
                          {isIndonesian ? 'Probabilitas Risiko Terlambat' : 'Overdue Risk Probability'}
                        </div>
                        <div className="text-2xl font-black text-slate-900 mt-0.5">
                          {riskResult.riskPercentage}% {isIndonesian ? 'Peluang' : 'Probability'}
                        </div>
                      </div>
                      <span
                        className={`px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider ${
                          riskResult.riskLevel === 'critical'
                            ? 'bg-rose-100 text-rose-800'
                            : riskResult.riskLevel === 'high'
                            ? 'bg-orange-100 text-orange-800'
                            : riskResult.riskLevel === 'medium'
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-emerald-100 text-emerald-800'
                        }`}
                      >
                        {isIndonesian
                          ? `RISIKO ${
                              riskResult.riskLevel === 'critical'
                                ? 'KRITIS'
                                : riskResult.riskLevel === 'high'
                                ? 'TINGGI'
                                : riskResult.riskLevel === 'medium'
                                ? 'SEDANG'
                                : 'RENDAH'
                            }`
                          : `${riskResult.riskLevel.toUpperCase()} RISK`}
                      </span>
                    </div>

                    <p className="text-xs text-slate-700 bg-white p-3 rounded-lg border border-slate-200 leading-relaxed">
                      {riskResult.summary}
                    </p>

                    <div className="bg-white p-3.5 rounded-lg border border-slate-200 text-xs">
                      <div className="font-semibold text-slate-700 mb-1.5">
                        {isIndonesian ? 'Faktor Pemicu Risiko Utama:' : 'Key Risk Drivers:'}
                      </div>
                      <ul className="list-disc list-inside text-slate-600 space-y-1">
                        {riskResult.riskFactors.map((rf, i) => (
                          <li key={i}>{rf}</li>
                        ))}
                      </ul>
                    </div>

                    <div className="bg-emerald-50/80 p-3.5 rounded-lg border border-emerald-200 text-xs">
                      <div className="font-bold text-emerald-950 mb-1.5">
                        {isIndonesian ? 'Rencana Aksi Mitigasi Terjadwal:' : 'Scheduled Mitigation Action Plan:'}
                      </div>
                      <ul className="list-disc list-inside text-emerald-800 space-y-1">
                        {riskResult.mitigationActions.map((ma, i) => (
                          <li key={i}>{ma}</li>
                        ))}
                      </ul>
                    </div>
                  </div>
                ) : (
                  <div className="h-full flex flex-col items-center justify-center text-center p-8 text-slate-400">
                    <AlertTriangle className="w-10 h-10 text-slate-300 mb-3" />
                    <p className="text-sm font-medium text-slate-600">
                      {isIndonesian ? 'Pilih Permintaan Aktif' : 'Select Active Request'}
                    </p>
                    <p className="text-xs text-slate-400 max-w-sm mt-1">
                      {isIndonesian
                        ? 'AI menghitung selisih tenggat komitmen, kecepatan respons, dan siklus revisi.'
                        : 'AI computes committed deadline delta, response speed, and revision cycles.'}
                    </p>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* 6. AI CREATIVE & MARKETING ASSISTANT */}
        {activeTab === 'creative_assistant' && (
          <div className="p-6 md:p-8 space-y-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-100">
              <div>
                <div className="flex items-center gap-2">
                  <Lightbulb className="w-5 h-5 text-purple-600" />
                  <h2 className="text-lg font-bold text-slate-900">
                    {isIndonesian ? 'Asisten Kreatif & Pemasaran AI' : 'AI Creative & Marketing Assistant'}
                  </h2>
                </div>
                <p className="text-xs text-slate-500 mt-1">
                  {isIndonesian
                    ? 'Membantu tim kreatif dan pemohon merumuskan konsep kampanye, headline menarik, copywriting siap pakai, caption media sosial, dan panduan arahan visual.'
                    : 'Assists creative teams and requesters in formulating campaign concepts, catchy headlines, ready-to-use copywriting, social media captions, and art direction guidelines.'}
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              <div className="lg:col-span-4 space-y-3.5">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                    {isIndonesian ? 'Brand / Properti' : 'Brand / Property'}
                  </label>
                  <select
                    value={creativeBrand}
                    onChange={(e) => setCreativeBrand(e.target.value)}
                    className="w-full text-xs rounded-lg border border-slate-300 bg-white px-2.5 py-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-purple-500"
                  >
                    {brands.map((b) => (
                      <option key={b.id} value={b.name}>
                        {b.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                    {isIndonesian ? 'Tema Kampanye / Promo' : 'Campaign / Promo Theme'}
                  </label>
                  <input
                    type="text"
                    value={creativeTheme}
                    onChange={(e) => setCreativeTheme(e.target.value)}
                    className="w-full text-xs rounded-lg border border-slate-300 bg-white px-2.5 py-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-purple-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                    {isIndonesian ? 'Saluran Media' : 'Media Channel'}
                  </label>
                  <input
                    type="text"
                    value={creativeMedium}
                    onChange={(e) => setCreativeMedium(e.target.value)}
                    className="w-full text-xs rounded-lg border border-slate-300 bg-white px-2.5 py-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-purple-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                    {isIndonesian ? 'Gaya Bahasa (Tone of Voice)' : 'Tone of Voice'}
                  </label>
                  <input
                    type="text"
                    value={creativeTone}
                    onChange={(e) => setCreativeTone(e.target.value)}
                    className="w-full text-xs rounded-lg border border-slate-300 bg-white px-2.5 py-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-purple-500"
                  />
                </div>

                <button
                  type="button"
                  onClick={handleRunCreativeAssistant}
                  disabled={loading}
                  className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-purple-600 text-white font-medium text-xs hover:bg-purple-700 disabled:opacity-50 transition-colors shadow-xs cursor-pointer"
                >
                  {loading ? (
                    <RefreshCw className="w-4 h-4 animate-spin" />
                  ) : (
                    <Lightbulb className="w-4 h-4" />
                  )}
                  {loading
                    ? isIndonesian ? 'Membuat Ide...' : 'Generating Ideas...'
                    : isIndonesian ? 'Buat Konsep & Copywriting' : 'Generate Concept & Copy'}
                </button>
              </div>

              <div className="lg:col-span-8 bg-slate-50/70 rounded-xl p-5 border border-slate-200">
                {creativeResult ? (
                  <div className="space-y-4 text-xs">
                    <div className="bg-white p-3.5 rounded-xl border border-purple-200">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-purple-700">
                        {isIndonesian ? 'Konsep Inti & Daya Tarik Visual' : 'Core Concept & Visual Hook'}
                      </span>
                      <p className="text-slate-800 font-medium mt-1 leading-relaxed">
                        {creativeResult.creativeConcept}
                      </p>
                    </div>

                    <div className="bg-white p-3.5 rounded-xl border border-slate-200">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">
                        {isIndonesian ? 'Opsi Headline & Tagline' : 'Headline & Tagline Options'}
                      </span>
                      <div className="mt-1.5 space-y-1.5">
                        {creativeResult.headlines.map((hl, i) => (
                          <div
                            key={i}
                            className="flex items-center justify-between p-2 rounded bg-slate-50 text-slate-900 font-semibold"
                          >
                            <span>"{hl}"</span>
                            <button
                              onClick={() => handleCopy(hl)}
                              className="text-slate-400 hover:text-slate-700 cursor-pointer"
                              title={isIndonesian ? 'Salin' : 'Copy'}
                            >
                              <Copy className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="bg-white p-3.5 rounded-xl border border-slate-200 space-y-2">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">
                        {isIndonesian ? 'Teks Media Sosial (Feed & Story)' : 'Social Copy (Feed & Story)'}
                      </span>
                      <div className="p-2.5 rounded bg-slate-50 text-slate-700 whitespace-pre-line leading-relaxed font-sans">
                        {creativeResult.socialCaptions.detailed}
                      </div>
                      <div className="flex flex-wrap gap-1.5 pt-1">
                        {creativeResult.hashtags.map((ht, i) => (
                          <span
                            key={i}
                            className="px-2 py-0.5 rounded bg-purple-50 text-purple-700 font-medium text-[11px]"
                          >
                            {ht}
                          </span>
                        ))}
                      </div>
                    </div>

                    <div className="bg-white p-3.5 rounded-xl border border-slate-200">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">
                        {isIndonesian ? 'Panduan Arahan Visual' : 'Art Direction Guidelines'}
                      </span>
                      <div className="mt-1 text-slate-600 space-y-1">
                        <p>
                          <strong>{isIndonesian ? 'Palet Warna:' : 'Palette:'}</strong> {creativeResult.artDirection.colorPalette}
                        </p>
                        <p>
                          <strong>{isIndonesian ? 'Elemen Visual:' : 'Visuals:'}</strong> {creativeResult.artDirection.visualElements}
                        </p>
                        <p>
                          <strong>CTA:</strong> "{creativeResult.artDirection.ctaWording}"
                        </p>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="h-full flex flex-col items-center justify-center text-center p-8 text-slate-400">
                    <Lightbulb className="w-10 h-10 text-slate-300 mb-3" />
                    <p className="text-sm font-medium text-slate-600">
                      {isIndonesian ? 'Pilih Brand & Masukkan Tema Kampanye' : 'Select Brand & Enter Campaign Theme'}
                    </p>
                    <p className="text-xs text-slate-400 max-w-sm mt-1">
                      {isIndonesian
                        ? 'AI menghasilkan konsep visual, copywriting siap publikasi, dan tagar yang relevan.'
                        : 'AI generates visual concepts, ready-to-publish copywriting, and targeted hashtags.'}
                    </p>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* 7. AI ANALYTICS & EXECUTIVE INSIGHTS */}
        {activeTab === 'executive_insights' && (
          <div className="p-6 md:p-8 space-y-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-100">
              <div>
                <div className="flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-teal-600" />
                  <h2 className="text-lg font-bold text-slate-900">
                    {isIndonesian ? 'Analitik & Wawasan Eksekutif AI' : 'AI Analytics & Executive Insights'}
                  </h2>
                </div>
                <p className="text-xs text-slate-500 mt-1">
                  {isIndonesian
                    ? 'Diagnosis operasional komprehensif terhadap kinerja divisi Marcomm. Mengidentifikasi pola kecepatan kerja, tingkat kepatuhan SLA 1h/3h/7h/14h, dan rekomendasi strategis bagi pimpinan.'
                    : 'Comprehensive operational diagnosis of Marcomm division performance. Identifies velocity patterns, 1d/3d/7d/14d SLA compliance rates, and strategic recommendations for executive leadership.'}
                </p>
              </div>
              <button
                type="button"
                onClick={handleRunExecutiveInsights}
                disabled={loading}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-teal-600 text-white font-medium text-xs hover:bg-teal-700 disabled:opacity-50 transition-colors shadow-xs cursor-pointer"
              >
                {loading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <TrendingUp className="w-4 h-4" />}
                {loading
                  ? isIndonesian ? 'Mendiagnosis...' : 'Diagnosing...'
                  : isIndonesian ? 'Susun Wawasan Eksekutif' : 'Formulate Executive Insights'}
              </button>
            </div>

            {insightsResult ? (
              <div className="space-y-4">
                <div className="bg-teal-50/80 p-4 rounded-xl border border-teal-200">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-teal-800">
                    {isIndonesian ? 'Ringkasan Utama Eksekutif' : 'Executive Headline'}
                  </span>
                  <h3 className="text-base font-bold text-teal-950 mt-0.5">
                    {insightsResult.executiveHeadline}
                  </h3>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                  <div className="bg-white p-4 rounded-xl border border-slate-200">
                    <span className="font-bold text-slate-900 uppercase tracking-wider">
                      {isIndonesian ? 'Kecepatan Operasional & SLA' : 'Operational Velocity & SLA'}
                    </span>
                    <p className="text-slate-600 mt-2 leading-relaxed">
                      {insightsResult.operationalVelocity}
                    </p>
                    <p className="text-slate-600 mt-2 leading-relaxed">
                      {insightsResult.slaHealthDiagnosis}
                    </p>
                  </div>

                  <div className="bg-white p-4 rounded-xl border border-slate-200">
                    <span className="font-bold text-slate-900 uppercase tracking-wider">
                      {isIndonesian ? 'Tren Permintaan Brand & Properti' : 'Brand & Property Demand Trends'}
                    </span>
                    <p className="text-slate-600 mt-2 leading-relaxed">
                      {insightsResult.brandDemandTrends}
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                  <div className="bg-white p-4 rounded-xl border border-slate-200">
                    <span className="font-bold text-emerald-800 uppercase tracking-wider">
                      {isIndonesian ? 'Pencapaian Utama Tim' : 'Key Team Achievements'}
                    </span>
                    <ul className="mt-2 space-y-1.5 text-slate-700">
                      {insightsResult.topAchievements.map((item, i) => (
                        <li key={i} className="flex items-start gap-2">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                          <span>{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="bg-white p-4 rounded-xl border border-slate-200">
                    <span className="font-bold text-rose-800 uppercase tracking-wider">
                      {isIndonesian ? 'Area Risiko & Hambatan' : 'Risk Areas & Bottlenecks'}
                    </span>
                    <ul className="mt-2 space-y-1.5 text-slate-700">
                      {insightsResult.criticalRisks.map((item, i) => (
                        <li key={i} className="flex items-start gap-2">
                          <AlertTriangle className="w-3.5 h-3.5 text-rose-600 shrink-0 mt-0.5" />
                          <span>{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                <div className="bg-white p-4 rounded-xl border border-slate-200 text-xs">
                  <span className="font-bold text-indigo-900 uppercase tracking-wider">
                    {isIndonesian ? 'Rekomendasi Peta Jalan Strategis' : 'Strategic Roadmap Recommendations'}
                  </span>
                  <ul className="mt-2 space-y-1.5 text-slate-700">
                    {insightsResult.strategicRoadmap.map((item, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <ArrowRight className="w-3.5 h-3.5 text-indigo-600 shrink-0 mt-0.5" />
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            ) : (
              <div className="text-center py-12 text-slate-400">
                <TrendingUp className="w-12 h-12 text-slate-300 mx-auto mb-3" />
                <p className="text-sm font-medium text-slate-600">
                  {isIndonesian ? "Klik 'Susun Wawasan Eksekutif'" : "Click 'Formulate Executive Insights'"}
                </p>
                <p className="text-xs text-slate-400 mt-1">
                  {isIndonesian
                    ? `AI akan merangkum tingkat kepatuhan SLA (${analytics.slaFulfillmentRate || 0}%), volume permintaan, dan latensi penyelesaian.`
                    : `AI will synthesize SLA fulfillment rate (${analytics.slaFulfillmentRate || 0}%), request volume, and turnaround latencies.`}
                </p>
              </div>
            )}
          </div>
        )}

        {/* 8. AI REPORT GENERATOR */}
        {activeTab === 'report_generator' && (
          <div className="p-6 md:p-8 space-y-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-100">
              <div>
                <div className="flex items-center gap-2">
                  <FileText className="w-5 h-5 text-cyan-600" />
                  <h2 className="text-lg font-bold text-slate-900">
                    {isIndonesian ? 'Pembuat Laporan Eksekutif AI' : 'AI Report Generator'}
                  </h2>
                </div>
                <p className="text-xs text-slate-500 mt-1">
                  {isIndonesian
                    ? 'Membuat Laporan Eksekutif Marcomm siap publikasi lengkap dengan KPI terstruktur, distribusi wilayah dan brand, penilaian SLA, serta rekomendasi manajemen.'
                    : 'Generates publication-ready Marcomm Executive Reports with structured KPIs, regional and brand distributions, SLA assessments, and management recommendations.'}
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              <div className="lg:col-span-4 space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                    {isIndonesian ? 'Judul Laporan' : 'Report Title'}
                  </label>
                  <input
                    type="text"
                    value={reportTitle}
                    onChange={(e) => setReportTitle(e.target.value)}
                    className="w-full text-xs rounded-lg border border-slate-300 bg-white px-3 py-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-cyan-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                    {isIndonesian ? 'Periode Laporan' : 'Report Period'}
                  </label>
                  <input
                    type="text"
                    value={reportPeriod}
                    onChange={(e) => setReportPeriod(e.target.value)}
                    className="w-full text-xs rounded-lg border border-slate-300 bg-white px-3 py-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-cyan-500"
                  />
                </div>

                <button
                  type="button"
                  onClick={handleRunReportGenerator}
                  disabled={loading}
                  className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-cyan-600 text-white font-medium text-xs hover:bg-cyan-700 disabled:opacity-50 transition-colors shadow-xs cursor-pointer"
                >
                  {loading ? (
                    <RefreshCw className="w-4 h-4 animate-spin" />
                  ) : (
                    <FileText className="w-4 h-4" />
                  )}
                  {loading
                    ? isIndonesian ? 'Membuat Laporan...' : 'Generating Report...'
                    : isIndonesian ? 'Buat Laporan Eksekutif' : 'Generate Executive Report'}
                </button>
              </div>

              <div className="lg:col-span-8 bg-slate-50/70 rounded-xl p-5 border border-slate-200">
                {reportMarkdown ? (
                  <div className="space-y-3">
                    <div className="flex items-center justify-between pb-3 border-b border-slate-200">
                      <span className="text-xs font-bold text-slate-700">
                        {isIndonesian ? 'Pratinjau Laporan Resmi' : 'Official Report Preview'}
                      </span>
                      <button
                        onClick={() => handleCopy(reportMarkdown)}
                        className="inline-flex items-center gap-1.5 px-3 py-1 rounded bg-white border border-slate-200 text-xs font-medium text-slate-700 hover:bg-slate-50 cursor-pointer"
                      >
                        {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                        {copied ? (isIndonesian ? 'Tersalin' : 'Copied') : (isIndonesian ? 'Salin Markdown' : 'Copy Markdown')}
                      </button>
                    </div>
                    <div className="bg-white p-4 rounded-xl border border-slate-200 max-h-[500px] overflow-y-auto text-xs text-slate-800 font-mono whitespace-pre-wrap leading-relaxed">
                      {reportMarkdown}
                    </div>
                  </div>
                ) : (
                  <div className="h-full flex flex-col items-center justify-center text-center p-8 text-slate-400">
                    <FileText className="w-10 h-10 text-slate-300 mb-3" />
                    <p className="text-sm font-medium text-slate-600">
                      {isIndonesian ? 'Siap Membuat Laporan' : 'Ready to Generate Report'}
                    </p>
                    <p className="text-xs text-slate-400 max-w-sm mt-1">
                      {isIndonesian
                        ? 'Klik tombol untuk menyusun laporan eksekutif resmi divisi Marcomm.'
                        : 'Click the button to compile an official Marcomm division executive report.'}
                    </p>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* 9. AI KNOWLEDGE ASSISTANT */}
        {activeTab === 'knowledge_assistant' && (
          <div className="p-6 md:p-8 space-y-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-100">
              <div>
                <div className="flex items-center gap-2">
                  <BookOpen className="w-5 h-5 text-orange-600" />
                  <h2 className="text-lg font-bold text-slate-900">
                    {isIndonesian ? 'Asisten Pengetahuan AI' : 'AI Knowledge Assistant'}
                  </h2>
                </div>
                <p className="text-xs text-slate-500 mt-1">
                  {isIndonesian
                    ? 'Pusat tanya jawab operasional Marcomm Lyman Group: Kebijakan SLA (Mendesak 1h, Tinggi 3h, Sedang 7h, Rendah 14h), Direktori Brand Jakarta & Bandung, Daftar Tim, dan SOP Persetujuan Revisi.'
                    : 'Operational Q&A hub for Lyman Group Marcomm: SLA Policies (Urgent 1d, High 3d, Medium 7d, Low 14d), Jakarta & Bandung Brand Directory, Team Roster, and Revision Approval SOPs.'}
                </p>
              </div>
            </div>

            {/* Quick Prompts */}
            <div className="flex flex-wrap gap-2">
              <span className="text-xs font-semibold text-slate-500 self-center mr-1">
                {isIndonesian ? 'Pertanyaan Cepat:' : 'Quick Questions:'}
              </span>
              {(isIndonesian
                ? [
                    'Apa saja standar SLA divisi Marcomm?',
                    'Sebutkan daftar brand resmi di Wilayah Jakarta & Bandung',
                    'Siapa saja anggota tim Graphic Design dan Social Media?',
                    'Bagaimana prosedur standar pengajuan revisi permintaan?',
                  ]
                : [
                    'What are the Marcomm division SLA standards?',
                    'List the official brands across Jakarta & Bandung Regions',
                    'Who are the members of the Graphic Design and Social Media teams?',
                    'What is the standard procedure for request revision submissions?',
                  ]
              ).map((qp, i) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => {
                    setChatQuestion(qp);
                  }}
                  className="px-2.5 py-1 rounded-full bg-slate-100 text-slate-700 hover:bg-slate-200 text-xs font-medium transition-colors cursor-pointer"
                >
                  {qp}
                </button>
              ))}
            </div>

            {/* Chat Conversation Area */}
            <div className="space-y-4">
              <div className="h-[380px] overflow-y-auto bg-slate-50/70 p-4 rounded-xl border border-slate-200 space-y-3">
                {chatMessages.map((msg, idx) => (
                  <div
                    key={idx}
                    className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                  >
                    <div
                      className={`max-w-2xl rounded-xl p-3.5 text-xs leading-relaxed ${
                        msg.sender === 'user'
                          ? 'bg-indigo-600 text-white rounded-br-xs'
                          : 'bg-white text-slate-800 border border-slate-200 shadow-2xs rounded-bl-xs'
                      }`}
                    >
                      <div className="font-semibold text-[10px] uppercase tracking-wider mb-1 opacity-70">
                        {msg.sender === 'user' ? (isIndonesian ? 'Anda' : 'You') : 'Marcomm Knowledge AI'}
                      </div>
                      <div className="whitespace-pre-line">{msg.text}</div>
                    </div>
                  </div>
                ))}
                {loading && (
                  <div className="flex justify-start">
                    <div className="bg-white text-slate-500 border border-slate-200 rounded-xl p-3 text-xs flex items-center gap-2">
                      <RefreshCw className="w-3.5 h-3.5 animate-spin text-orange-500" />
                      <span>
                        {isIndonesian
                          ? 'Mencari di basis pengetahuan Marcomm Lyman...'
                          : 'Searching Lyman Marcomm knowledge base...'}
                      </span>
                    </div>
                  </div>
                )}
              </div>

              {/* Chat Input */}
              <form onSubmit={handleSendChatMessage} className="flex gap-2">
                <input
                  type="text"
                  value={chatQuestion}
                  onChange={(e) => setChatQuestion(e.target.value)}
                  placeholder={
                    isIndonesian
                      ? 'Ajukan pertanyaan seputar SOP Marcomm, SLA, brand, daftar tim, atau alur kerja...'
                      : 'Ask questions regarding Marcomm SOPs, SLAs, brands, team roster, or workflows...'
                  }
                  className="flex-1 text-xs rounded-xl border border-slate-300 bg-white px-3.5 py-2.5 text-slate-900 focus:outline-none focus:ring-2 focus:ring-orange-500"
                />
                <button
                  type="submit"
                  disabled={loading || !chatQuestion.trim()}
                  className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-orange-600 text-white font-medium text-xs hover:bg-orange-700 disabled:opacity-50 transition-colors shadow-xs cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5" />
                  {isIndonesian ? 'Kirim' : 'Send'}
                </button>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
