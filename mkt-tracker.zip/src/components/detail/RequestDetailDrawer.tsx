import React, { useState, useEffect, useCallback } from 'react';
import {
  X,
  Clock,
  User,
  Users,
  Building2,
  Calendar,
  AlertCircle,
  CheckCircle2,
  Paperclip,
  Link as LinkIcon,
  MessageSquare,
  History,
  ArrowRight,
  RotateCcw,
  ShieldCheck,
  Send,
  Upload,
  UploadCloud,
  FileImage,
  Film,
  Music,
  FileSpreadsheet,
  FileText,
  FileCode,
  Trash2,
  Download,
  Edit3,
  ExternalLink,
  ChevronRight,
  Info,
  Sparkles,
  RefreshCw,
  FileCheck,
  AlertTriangle,
  PauseCircle,
  PlayCircle,
  Ban,
  Layers,
  CheckSquare,
} from 'lucide-react';
import { SubItemTableView } from '../subitems/SubItemTableView';
import {
  RequestItem,
  RequestStatus,
  Attachment,
  DeliverableLink,
  Comment,
  ActivityLog,
  PRIORITY_SLA_DAYS,
} from '../../types';
import { useAuth } from '../../context/AuthContext';
import { useRequests } from '../../context/RequestContext';
import { useLanguage } from '../../context/LanguageContext';
import { StorageService } from '../../services/storageService';
import { StatusBadge, PriorityBadge, OverdueBadge, STATUS_LABELS } from '../common/StatusBadge';
import {
  AiService,
  BriefAnalysisResult,
  AssignmentRecommendationResult,
  DeadlineRiskResult,
} from '../../services/aiService';

export const ALLOWED_DELIVERABLE_EXTENSIONS = [
  'png',
  'jpg',
  'jpeg',
  'psd',
  'ai',
  'pdf',
  'docx',
  'xlsx',
  'mp4',
  'mov',
  'mpeg',
  'avi',
  'wav',
  'mp3',
];

export const DELIVERABLE_ACCEPT_ATTR =
  '.png,.jpg,.jpeg,.psd,.ai,.pdf,.docx,.xlsx,.mp4,.mov,.mpeg,.avi,.wav,.mp3';

export const MAX_DELIVERABLE_FILE_SIZE = 100 * 1024 * 1024; // 100MB

export const getDeliverableFileIcon = (fileName: string) => {
  const ext = fileName.split('.').pop()?.toLowerCase() || '';
  if (['png', 'jpg', 'jpeg'].includes(ext)) {
    return <FileImage className="w-4 h-4 text-emerald-600 shrink-0" />;
  }
  if (['psd', 'ai'].includes(ext)) {
    return <FileCode className="w-4 h-4 text-purple-600 shrink-0" />;
  }
  if (['mp4', 'mov', 'mpeg', 'avi'].includes(ext)) {
    return <Film className="w-4 h-4 text-rose-600 shrink-0" />;
  }
  if (['wav', 'mp3'].includes(ext)) {
    return <Music className="w-4 h-4 text-amber-600 shrink-0" />;
  }
  if (['xlsx'].includes(ext)) {
    return <FileSpreadsheet className="w-4 h-4 text-emerald-700 shrink-0" />;
  }
  return <FileText className="w-4 h-4 text-blue-600 shrink-0" />;
};

export const getDeliverableFormatBadge = (fileName: string) => {
  const ext = fileName.split('.').pop()?.toUpperCase() || 'FILE';
  let badgeColor = 'bg-slate-100 text-slate-700 border-slate-200';
  const e = ext.toLowerCase();
  if (['png', 'jpg', 'jpeg'].includes(e)) {
    badgeColor = 'bg-emerald-50 text-emerald-700 border-emerald-200';
  } else if (['psd', 'ai'].includes(e)) {
    badgeColor = 'bg-purple-50 text-purple-700 border-purple-200';
  } else if (['mp4', 'mov', 'mpeg', 'avi'].includes(e)) {
    badgeColor = 'bg-rose-50 text-rose-700 border-rose-200';
  } else if (['wav', 'mp3'].includes(e)) {
    badgeColor = 'bg-amber-50 text-amber-800 border-amber-200';
  } else if (['pdf', 'docx', 'xlsx'].includes(e)) {
    badgeColor = 'bg-blue-50 text-blue-700 border-blue-200';
  }
  return (
    <span className={`px-1.5 py-0.5 rounded text-[10px] font-mono font-bold border ${badgeColor}`}>
      {ext}
    </span>
  );
};

export const formatFileSize = (bytes: number) => {
  if (!bytes || bytes <= 0) return '0 KB';
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${Math.round(bytes / 1024)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
};

interface RequestDetailDrawerProps {
  requestId: string | null;
  onClose: () => void;
}

export const RequestDetailDrawer: React.FC<RequestDetailDrawerProps> = ({
  requestId,
  onClose,
}) => {
  const {
    currentUser,
    allUsers,
    csrfToken,
    isAdmin,
    isSuperAdmin,
    canEditRequestBrief,
    canAssignRequest,
    canSubmitDeliverables,
    canApproveOrRevise,
    canReopenRequest,
    canTransitionStatus,
    canPerformRequestAction,
    isAuthorizedForRequestActions,
  } = useAuth();
  const { language, isIndonesian } = useLanguage();

  const {
    requests,
    teams,
    changeStatus,
    assignRequest,
    updateCommittedDeadline,
    reopenRequest,
    addDeliverable,
    syncNow,
    syncVersion,
    showToast,
  } = useRequests();

  // Load active request from RequestContext D1 state
  const request = requestId ? requests.find((r) => r.id === requestId) : undefined;

  // Active tab in drawer: 'overview' | 'sub_items' | 'deliverables' | 'comments' | 'audit_trail'
  const [activeTab, setActiveTab] = useState<'overview' | 'sub_items' | 'deliverables' | 'comments' | 'audit_trail'>('overview');

  // Assignment form state
  const [isAssigning, setIsAssigning] = useState(false);
  const [assignedTeamId, setAssignedTeamId] = useState('');
  const [primaryAssigneeId, setPrimaryAssigneeId] = useState('');
  const [collaboratorIds, setCollaboratorIds] = useState<string[]>([]);
  const [reviewerId, setReviewerId] = useState('');
  const [committedDeadlineInput, setCommittedDeadlineInput] = useState('');
  const [assignmentReason, setAssignmentReason] = useState('');

  // Deadline edit state
  const [isEditingDeadline, setIsEditingDeadline] = useState(false);
  const [newDeadline, setNewDeadline] = useState('');
  const [deadlineReason, setDeadlineReason] = useState('');

  // Reopen modal state
  const [isReopenModalOpen, setIsReopenModalOpen] = useState(false);
  const [reopenReason, setReopenReason] = useState('');

  // Revision modal state
  const [isRevisionModalOpen, setIsRevisionModalOpen] = useState(false);
  const [revisionNote, setRevisionNote] = useState('');

  // Hold modal state
  const [isHoldModalOpen, setIsHoldModalOpen] = useState(false);
  const [holdReason, setHoldReason] = useState('');

  // Cancel modal state
  const [isCancelModalOpen, setIsCancelModalOpen] = useState(false);
  const [cancelReason, setCancelReason] = useState('');

  // Deliverable upload state (File Upload to R2: PNG, JPG, JPEG, PSD, AI, PDF, DOCX, XLSX, MP4, MOV, MPEG, AVI, WAV, MP3)
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
  const [deliverableFiles, setDeliverableFiles] = useState<File[]>([]);
  const [deliverableTitle, setDeliverableTitle] = useState('');
  const [deliverableUrl, setDeliverableUrl] = useState('');
  const [deliverableUploadError, setDeliverableUploadError] = useState('');
  const [isUploadingDeliverables, setIsUploadingDeliverables] = useState(false);
  const [isDraggingFile, setIsDraggingFile] = useState(false);

  // Comment input state
  const [newComment, setNewComment] = useState('');
  const [commentType, setCommentType] = useState<'general' | 'revision_note'>('general');
  const [isPostingComment, setIsPostingComment] = useState(false);
  const [isSubmittingAction, setIsSubmittingAction] = useState(false);

  // AI Feature States
  const [aiBriefAnalysis, setAiBriefAnalysis] = useState<BriefAnalysisResult | null>(null);
  const [isAnalyzingBrief, setIsAnalyzingBrief] = useState(false);
  const [aiAssignmentRec, setAiAssignmentRec] = useState<AssignmentRecommendationResult | null>(null);
  const [isRecommendingAssignee, setIsRecommendingAssignee] = useState(false);
  const [aiRiskPrediction, setAiRiskPrediction] = useState<DeadlineRiskResult | null>(null);
  const [isPredictingRisk, setIsPredictingRisk] = useState(false);

  // Activity logs & comments fetched from D1
  const [comments, setComments] = useState<Comment[]>([]);
  const [activityLogs, setActivityLogs] = useState<ActivityLog[]>([]);

  const loadDrawerDetails = useCallback(async () => {
    if (!requestId) {
      setComments([]);
      setActivityLogs([]);
      return;
    }
    try {
      const [cmRes, lgRes] = await Promise.all([
        fetch(`/api/requests/${encodeURIComponent(requestId)}/comments`, {
          credentials: 'include',
          cache: 'no-store',
        }),
        fetch(`/api/requests/${encodeURIComponent(requestId)}/logs`, {
          credentials: 'include',
          cache: 'no-store',
        }),
      ]);
      const [cmData, lgData] = await Promise.all([
        cmRes.json().catch(() => ({})),
        lgRes.json().catch(() => ({})),
      ]);
      if (cmRes.ok && Array.isArray(cmData.comments)) {
        setComments(cmData.comments);
      }
      if (lgRes.ok && Array.isArray(lgData.logs)) {
        setActivityLogs(lgData.logs);
      }
    } catch {
      // Preserve existing state on transient polling failure
    }
  }, [requestId]);

  useEffect(() => {
    loadDrawerDetails();
  }, [loadDrawerDetails, request?.updatedAt, request?.status, syncVersion]);

  const handleAnalyzeBrief = async () => {
    if (!request) return;
    setIsAnalyzingBrief(true);
    try {
      const lastComments = comments.map((c) => `${c.authorName}: ${c.content}`).join('\n');
      const res = await AiService.analyzeBrief({
        title: request.title,
        description: request.description,
        deliverables: request.deliverablesExpected,
        category: request.categoryId,
        comments: lastComments,
      });
      setAiBriefAnalysis(res);
      showToast(
        isIndonesian ? 'Analisis brief berhasil diselesaikan' : 'Brief analysis completed successfully',
        'success'
      );
    } catch (err: any) {
      showToast(isIndonesian ? 'Gagal menganalisis brief' : 'Failed to analyze brief', 'error');
    } finally {
      setIsAnalyzingBrief(false);
    }
  };

  const handleRecommendAssignment = async () => {
    if (!request) return;
    setIsRecommendingAssignee(true);
    try {
      const res = await AiService.recommendAssignment({
        category: request.categoryId,
        brand: request.brandName,
        priority: request.priority,
      });
      setAiAssignmentRec(res);
      const matchedUser = allUsers.find(
        (u) =>
          u.fullName.toLowerCase().includes(res.primaryAssignee.name.toLowerCase()) ||
          res.primaryAssignee.name.toLowerCase().includes(u.fullName.toLowerCase())
      );
      if (matchedUser) {
        setPrimaryAssigneeId(matchedUser.id);
        if (matchedUser.teams && matchedUser.teams[0]) setAssignedTeamId(matchedUser.teams[0]);
      }
      showToast(
        isIndonesian
          ? `Rekomendasi AI: ${res.primaryAssignee.name} (kecocokan ${res.primaryAssignee.matchScore}%)`
          : `AI Recommendation: ${res.primaryAssignee.name} (${res.primaryAssignee.matchScore}% match)`,
        'info'
      );
    } catch (err) {
      showToast(
        isIndonesian
          ? 'Gagal memproses rekomendasi penugasan'
          : 'Failed to process assignment recommendation',
        'error'
      );
    } finally {
      setIsRecommendingAssignee(false);
    }
  };

  const handlePredictRisk = async () => {
    if (!request) return;
    setIsPredictingRisk(true);
    try {
      const deadlineDate = request.committedDeadline
        ? new Date(request.committedDeadline)
        : new Date(request.requestedDeadline);
      const diffDays = Math.ceil((deadlineDate.getTime() - Date.now()) / (1000 * 60 * 60 * 24));
      const res = await AiService.predictDeadlineRisk({
        requestTitle: request.title,
        priority: request.priority,
        status: request.status,
        daysLeft: diffDays,
        isOverdue: Boolean(request.isOverdue),
        revisionsCount: request.reopenCount || 0,
      });
      setAiRiskPrediction(res);
    } catch (err) {
      showToast(
        isIndonesian ? 'Gagal memprediksi risiko tenggat waktu' : 'Failed to predict deadline risk',
        'error'
      );
    } finally {
      setIsPredictingRisk(false);
    }
  };

  if (!request) return null;

  // Initialize assignment form
  const handleOpenAssignModal = () => {
    setAssignedTeamId(request.assignedTeamId || (teams.length > 0 ? teams[0].id : ''));
    setPrimaryAssigneeId(request.primaryAssigneeId || '');
    setCollaboratorIds(request.collaboratorIds || []);
    setReviewerId(request.reviewerId || '');
    setCommittedDeadlineInput(request.committedDeadline || request.requestedDeadline || '');
    setAssignmentReason('');
    setIsAssigning(true);
  };

  const handleSaveAssignment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isSubmittingAction) return;
    if (!primaryAssigneeId) {
      showToast(
        isIndonesian ? 'Pelaksana Utama wajib dipilih.' : 'Primary Assignee must be selected.',
        'error'
      );
      return;
    }
    if (!committedDeadlineInput) {
      showToast(
        isIndonesian ? 'Tenggat Waktu Komitmen wajib ditentukan.' : 'Committed Deadline must be specified.',
        'error'
      );
      return;
    }

    setIsSubmittingAction(true);
    try {
      const res = await assignRequest(request.id, {
        assignedTeamId,
        primaryAssigneeId,
        collaboratorIds,
        reviewerId: reviewerId || undefined,
        committedDeadline: committedDeadlineInput,
        deadlineReason:
          assignmentReason ||
          (isIndonesian
            ? 'Penugasan tim dan jadwal penyelesaian yang dikomitmenkan'
            : 'Team assignment and committed delivery schedule'),
      });

      if (res.success) {
        setIsAssigning(false);
        await loadDrawerDetails();
      }
    } finally {
      setIsSubmittingAction(false);
    }
  };

  const handleSaveDeadlineUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isSubmittingAction) return;
    if (!newDeadline) {
      showToast(
        isIndonesian ? 'Tanggal tenggat baru wajib diisi.' : 'New deadline date is required.',
        'error'
      );
      return;
    }
    if (!deadlineReason.trim() || deadlineReason.trim().length < 5) {
      showToast(
        isIndonesian
          ? 'Alasan penyesuaian tenggat waktu minimal 5 karakter.'
          : 'Reason for deadline adjustment must be at least 5 characters.',
        'error'
      );
      return;
    }

    setIsSubmittingAction(true);
    try {
      const res = await updateCommittedDeadline(request.id, newDeadline, deadlineReason);
      if (res.success) {
        setIsEditingDeadline(false);
        setDeadlineReason('');
        await loadDrawerDetails();
      }
    } finally {
      setIsSubmittingAction(false);
    }
  };

  const handleSaveReopen = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isSubmittingAction) return;
    if (!reopenReason.trim() || reopenReason.trim().length < 5) {
      showToast(
        isIndonesian
          ? 'Alasan pembukaan ulang tiket minimal 5 karakter.'
          : 'Reopen reason must be at least 5 characters.',
        'error'
      );
      return;
    }

    setIsSubmittingAction(true);
    try {
      const res = await reopenRequest(request.id, reopenReason);
      if (res.success) {
        setIsReopenModalOpen(false);
        setReopenReason('');
        await loadDrawerDetails();
      }
    } finally {
      setIsSubmittingAction(false);
    }
  };

  const handleSaveRevisionRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isSubmittingAction) return;
    if (!revisionNote.trim() || revisionNote.trim().length < 5) {
      showToast(
        isIndonesian
          ? 'Catatan revisi minimal 5 karakter.'
          : 'Revision notes must be at least 5 characters.',
        'error'
      );
      return;
    }

    setIsSubmittingAction(true);
    try {
      const res = await changeStatus(request.id, 'revision', { revisionNote });
      if (res.success) {
        setIsRevisionModalOpen(false);
        setRevisionNote('');
        await loadDrawerDetails();
      }
    } finally {
      setIsSubmittingAction(false);
    }
  };

  const handlePutOnHold = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isSubmittingAction) return;
    if (!holdReason.trim() || holdReason.trim().length < 5) {
      showToast(
        isIndonesian
          ? 'Alasan penundaan minimal 5 karakter.'
          : 'Hold reason must be at least 5 characters.',
        'error'
      );
      return;
    }

    setIsSubmittingAction(true);
    try {
      const res = await changeStatus(request.id, 'on_hold', { holdReason: holdReason.trim() });
      if (res.success) {
        setIsHoldModalOpen(false);
        setHoldReason('');
        await loadDrawerDetails();
      }
    } finally {
      setIsSubmittingAction(false);
    }
  };

  const handleQuickStatusChange = async (targetStatus: 'in_progress' | 'pending_review' | 'completed') => {
    if (isSubmittingAction) return;
    setIsSubmittingAction(true);
    try {
      const res = await changeStatus(request.id, targetStatus);
      if (res.success) {
        await loadDrawerDetails();
      }
    } finally {
      setIsSubmittingAction(false);
    }
  };

  const handleResumeFromHold = async () => {
    if (isSubmittingAction) return;
    setIsSubmittingAction(true);
    try {
      const targetStatus = request.primaryAssigneeId ? 'in_progress' : 'todo';
      const res = await changeStatus(request.id, targetStatus);
      if (res.success) {
        await loadDrawerDetails();
      }
    } finally {
      setIsSubmittingAction(false);
    }
  };

  const handleCancelRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isSubmittingAction) return;
    if (!cancelReason.trim() || cancelReason.trim().length < 5) {
      showToast(
        isIndonesian
          ? 'Alasan pembatalan minimal 5 karakter.'
          : 'Cancellation reason must be at least 5 characters.',
        'error'
      );
      return;
    }

    setIsSubmittingAction(true);
    try {
      const res = await changeStatus(request.id, 'cancelled', { cancelReason: cancelReason.trim() });
      if (res.success) {
        setIsCancelModalOpen(false);
        setCancelReason('');
        await loadDrawerDetails();
      }
    } finally {
      setIsSubmittingAction(false);
    }
  };

  const handleReactivateCancelled = async () => {
    if (isSubmittingAction) return;
    setIsSubmittingAction(true);
    try {
      const targetStatus = request.primaryAssigneeId ? 'in_progress' : 'todo';
      const res = await changeStatus(request.id, targetStatus);
      if (res.success) {
        await loadDrawerDetails();
      }
    } finally {
      setIsSubmittingAction(false);
    }
  };

  const handleFilesSelected = (files: FileList | null) => {
    if (!files || files.length === 0) return;
    setDeliverableUploadError('');
    const newFiles: File[] = [];

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const ext = file.name.split('.').pop()?.toLowerCase() || '';

      if (!ALLOWED_DELIVERABLE_EXTENSIONS.includes(ext)) {
        setDeliverableUploadError(
          isIndonesian
            ? `Format file "${file.name}" tidak diizinkan. Gunakan format: PNG, JPG, JPEG, PSD, AI, PDF, DOCX, XLSX, MP4, MOV, MPEG, AVI, WAV, MP3.`
            : `File format "${file.name}" is not supported. Please use: PNG, JPG, JPEG, PSD, AI, PDF, DOCX, XLSX, MP4, MOV, MPEG, AVI, WAV, MP3.`
        );
        return;
      }

      if (file.size > MAX_DELIVERABLE_FILE_SIZE) {
        setDeliverableUploadError(
          isIndonesian
            ? `File "${file.name}" melebihi batas ukuran maksimal 100MB.`
            : `File "${file.name}" exceeds the maximum 100MB size limit.`
        );
        return;
      }
      newFiles.push(file);
    }

    setDeliverableFiles((prev) => [...prev, ...newFiles]);
  };

  const removeDeliverableFile = (index: number) => {
    setDeliverableFiles((prev) => prev.filter((_, i) => i !== index));
  };

  const handleAddDeliverable = async (e: React.FormEvent) => {
    e.preventDefault();
    setDeliverableUploadError('');

    if (deliverableFiles.length === 0 && !deliverableUrl.trim()) {
      setDeliverableUploadError(
        isIndonesian
          ? 'Silakan pilih setidaknya satu file deliverable (PNG, JPG, JPEG, PSD, AI, PDF, DOCX, XLSX, MP4, MOV, MPEG, AVI, WAV, MP3).'
          : 'Please select at least one deliverable file (PNG, JPG, JPEG, PSD, AI, PDF, DOCX, XLSX, MP4, MOV, MPEG, AVI, WAV, MP3).'
      );
      return;
    }

    const newAttachments: Attachment[] = [];
    setIsUploadingDeliverables(true);
    try {
      for (let i = 0; i < deliverableFiles.length; i++) {
        const file = deliverableFiles[i];
        const ext = file.name.split('.').pop()?.toLowerCase() || '';

        if (!ALLOWED_DELIVERABLE_EXTENSIONS.includes(ext)) {
          setDeliverableUploadError(
            isIndonesian
              ? `Format file "${file.name}" tidak didukung.`
              : `File format "${file.name}" is not supported.`
          );
          return;
        }

        const uploaded = await StorageService.uploadFileToR2(
          file,
          {
            scopeType: 'deliverable',
            requestId: request.id,
            brandId: request.brandId,
            regionId: request.regionId,
          },
          csrfToken
        );
        newAttachments.push(uploaded);
      }

      const optionalLink: DeliverableLink | undefined = deliverableUrl.trim()
        ? {
            id: `link-${Date.now()}`,
            title:
              deliverableTitle.trim() ||
              (isIndonesian ? 'Tautan Eksternal Hasil Pekerjaan' : 'Deliverable External Link'),
            url: deliverableUrl.trim(),
            createdAt: new Date().toISOString(),
            createdBy: currentUser.fullName,
          }
        : undefined;

      const res = await addDeliverable(request.id, {
        attachments: newAttachments.length > 0 ? newAttachments : undefined,
        attachment: newAttachments.length === 1 ? newAttachments[0] : undefined,
        link: optionalLink,
      });

      if (res.success) {
        setIsUploadModalOpen(false);
        setDeliverableFiles([]);
        setDeliverableTitle('');
        setDeliverableUrl('');
        setDeliverableUploadError('');
        await loadDrawerDetails();
      }
    } catch (err: any) {
      const msg =
        err?.message ||
        (isIndonesian ? 'Gagal mengunggah deliverable ke Cloudflare R2.' : 'Failed to upload deliverable to Cloudflare R2.');
      setDeliverableUploadError(msg);
      showToast(msg, 'error');
    } finally {
      setIsUploadingDeliverables(false);
    }
  };

  const handlePostComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newComment.trim() || isPostingComment) return;

    setIsPostingComment(true);
    try {
      const res = await fetch(`/api/requests/${encodeURIComponent(request.id)}/comments`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRF-Token': csrfToken || '',
        },
        credentials: 'include',
        cache: 'no-store',
        body: JSON.stringify({
          content: newComment.trim(),
          type: commentType,
        }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok || !data.success) {
        showToast(
          data.error || (isIndonesian ? 'Gagal mengirim komentar.' : 'Failed to post comment.'),
          'error'
        );
        return;
      }

      setNewComment('');
      if (data.comment) {
        setComments((prev) => [...prev, data.comment]);
      }
      showToast(
        commentType === 'revision_note'
          ? (isIndonesian ? 'Catatan revisi berhasil ditambahkan' : 'Revision note added')
          : (isIndonesian ? 'Komentar berhasil dikirim' : 'Comment posted successfully'),
        'success'
      );
      await Promise.all([loadDrawerDetails(), syncNow({ force: true })]);
    } catch {
      showToast(isIndonesian ? 'Koneksi bermasalah saat mengirim komentar.' : 'Connection error while posting comment.', 'error');
    } finally {
      setIsPostingComment(false);
    }
  };

  const teamMembers = allUsers.filter(
    (u) => u.role === 'team_member' || u.role === 'admin' || u.role === 'super_admin'
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-end bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white w-full max-w-3xl h-full shadow-2xl flex flex-col overflow-hidden animate-in slide-in-from-right duration-200">
        {/* Top Header */}
        <div className="p-4 sm:p-6 border-b border-slate-200 flex items-start justify-between bg-slate-50/70 gap-3">
          <div className="space-y-1.5 min-w-0 flex-1">
            <div className="flex items-center gap-1.5 sm:gap-2 flex-wrap">
              <span className="font-mono text-xs font-bold text-slate-900 bg-white px-2 py-0.5 rounded border border-slate-200 shrink-0">
                {request.ticketNumber}
              </span>
              <StatusBadge status={request.status} size="sm" />
              <PriorityBadge priority={request.priority} compact={true} />
              <OverdueBadge
                isOverdue={request.isOverdue}
                status={request.status}
                committedDeadline={request.committedDeadline}
                slaFulfilled={request.slaFulfilled}
              />
            </div>
            <h2 className="text-sm sm:text-base md:text-lg font-bold text-slate-900 leading-snug">
              {request.title}
            </h2>
            <div className="flex items-center gap-1.5 sm:gap-2 text-xs text-slate-500 flex-wrap">
              <span>{request.regionName}</span>
              <span aria-hidden="true" className="text-slate-300">·</span>
              <span className="font-medium text-slate-700">{request.brandName}</span>
              {request.unitName && (
                <>
                  <span aria-hidden="true" className="text-slate-300">·</span>
                  <span className="text-blue-700 font-semibold">{request.unitName}</span>
                </>
              )}
              <span aria-hidden="true" className="text-slate-300">·</span>
              <span>{request.categoryName}</span>
              <span aria-hidden="true" className="text-slate-300">·</span>
              <span className="inline-flex items-center gap-1 font-semibold text-slate-800 bg-white px-2 py-0.5 rounded border border-slate-200">
                <User className="w-3 h-3 text-[#065F46]" />
                <span>{isIndonesian ? 'Pemohon:' : 'Requestor:'} {request.requestorName || request.requesterName}</span>
              </span>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 sm:p-2 text-slate-400 hover:text-slate-600 rounded-xl hover:bg-slate-200/60 transition-colors shrink-0"
            aria-label={isIndonesian ? 'Tutup detail' : 'Close details'}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Workflow Action Bar — Strictly visible ONLY when authorized actions exist */}
        {(() => {
          const canStartWorking = request.status === 'todo' && canTransitionStatus(request, 'in_progress').allowed;
          const canSubmitReview = (request.status === 'in_progress' || request.status === 'revision') && canPerformRequestAction(request, 'submit_review').allowed;
          const canApproveOrReviseRequest = request.status === 'pending_review' && canApproveOrRevise(request);
          const canReopen = request.status === 'completed' && canReopenRequest(request);
          const canResume = request.status === 'on_hold' && canPerformRequestAction(request, 'resume').allowed;
          const canPutOnHold = request.status !== 'completed' && request.status !== 'cancelled' && request.status !== 'on_hold' && canPerformRequestAction(request, 'put_on_hold').allowed;
          const canCancel = request.status !== 'completed' && request.status !== 'cancelled' && canPerformRequestAction(request, 'cancel_request').allowed;
          const canReactivate = request.status === 'cancelled' && canTransitionStatus(request, 'todo').allowed;
          const canUpload = canSubmitDeliverables(request) && request.status !== 'completed' && request.status !== 'cancelled';

          const hasAnyWorkflowAction =
            canStartWorking ||
            canSubmitReview ||
            canApproveOrReviseRequest ||
            canReopen ||
            canResume ||
            canPutOnHold ||
            canCancel ||
            canReactivate ||
            canUpload;

          if (!hasAnyWorkflowAction) {
            return null;
          }

          return (
            <div className="px-4 sm:px-6 py-2.5 bg-slate-100/70 border-b border-slate-200 flex items-center justify-between gap-2 overflow-x-auto no-scrollbar">
              <div className="flex items-center gap-2 shrink-0">
                <span className="text-xs font-semibold text-slate-500 hidden sm:inline shrink-0">
                  {isIndonesian ? 'Aksi:' : 'Actions:'}
                </span>

                {/* To Do -> In Progress (Start Working) */}
                {canStartWorking && (
                  <button
                    disabled={isSubmittingAction}
                    onClick={() => handleQuickStatusChange('in_progress')}
                    className="px-3.5 py-1.5 text-xs font-bold text-white bg-[#065F46] hover:bg-[#044e39] disabled:opacity-60 rounded-xl shadow-xs transition-colors flex items-center gap-1.5 whitespace-nowrap shrink-0 active:scale-[0.98]"
                  >
                    <span>{isIndonesian ? 'Mulai Kerjakan' : 'Start Working'}</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                )}

                {/* In Progress / Revision -> Pending Review (Submit for Review) */}
                {canSubmitReview && (
                  <button
                    disabled={isSubmittingAction}
                    onClick={() => handleQuickStatusChange('pending_review')}
                    className="px-3.5 py-1.5 text-xs font-bold text-white bg-amber-600 hover:bg-amber-700 disabled:opacity-60 rounded-xl shadow-xs transition-colors flex items-center gap-1.5 whitespace-nowrap shrink-0"
                  >
                    <span>{isIndonesian ? 'Ajukan Review' : 'Submit for Review'}</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                )}

                {/* Pending Review Actions: Revision & Approve */}
                {canApproveOrReviseRequest && (
                  <>
                    <button
                      disabled={isSubmittingAction}
                      onClick={() => setIsRevisionModalOpen(true)}
                      className="px-3 py-1.5 text-xs font-bold text-orange-700 bg-orange-100 hover:bg-orange-200 disabled:opacity-60 border border-orange-300 rounded-xl transition-colors flex items-center gap-1.5 whitespace-nowrap shrink-0"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span>{isIndonesian ? 'Minta Revisi' : 'Request Revision'}</span>
                    </button>

                    <button
                      disabled={isSubmittingAction}
                      onClick={() => handleQuickStatusChange('completed')}
                      className="px-3.5 py-1.5 text-xs font-bold text-white bg-[#065F46] hover:bg-[#044e39] disabled:opacity-60 rounded-xl shadow-xs transition-colors flex items-center gap-1.5 whitespace-nowrap shrink-0 active:scale-[0.98]"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>{isIndonesian ? 'Setujui & Selesaikan' : 'Approve & Complete'}</span>
                    </button>
                  </>
                )}

                {/* Completed -> Reopen */}
                {canReopen && (
                  <button
                    disabled={isSubmittingAction}
                    onClick={() => setIsReopenModalOpen(true)}
                    className="px-3 py-1.5 text-xs font-bold text-slate-700 bg-white hover:bg-slate-100 disabled:opacity-60 border border-slate-300 rounded-xl transition-colors flex items-center gap-1.5 whitespace-nowrap shrink-0"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>{isIndonesian ? 'Buka Ulang Tiket' : 'Reopen Ticket'}</span>
                  </button>
                )}

                {/* On Hold Actions: Resume */}
                {canResume && (
                  <button
                    disabled={isSubmittingAction}
                    onClick={handleResumeFromHold}
                    className="px-3.5 py-1.5 text-xs font-bold text-white bg-[#065F46] hover:bg-[#044e39] disabled:opacity-60 rounded-xl shadow-xs transition-colors flex items-center gap-1.5 whitespace-nowrap shrink-0 active:scale-[0.98]"
                  >
                    <PlayCircle className="w-3.5 h-3.5" />
                    <span>{isIndonesian ? 'Lanjutkan Pekerjaan' : 'Resume Work'}</span>
                  </button>
                )}

                {/* Put On Hold button for active workflows */}
                {canPutOnHold && (
                  <button
                    disabled={isSubmittingAction}
                    onClick={() => setIsHoldModalOpen(true)}
                    className="px-3 py-1.5 text-xs font-bold text-amber-800 bg-amber-50 hover:bg-amber-100 disabled:opacity-60 border border-amber-300 rounded-xl transition-colors flex items-center gap-1.5 whitespace-nowrap shrink-0"
                  >
                    <PauseCircle className="w-3.5 h-3.5 text-amber-600" />
                    <span>{isIndonesian ? 'Tunda (On Hold)' : 'Put On Hold'}</span>
                  </button>
                )}

                {/* Cancel Request button */}
                {canCancel && (
                  <button
                    disabled={isSubmittingAction}
                    onClick={() => setIsCancelModalOpen(true)}
                    className="px-3 py-1.5 text-xs font-bold text-rose-700 bg-rose-50 hover:bg-rose-100 disabled:opacity-60 border border-rose-200 rounded-xl transition-colors flex items-center gap-1.5 whitespace-nowrap shrink-0"
                  >
                    <Ban className="w-3.5 h-3.5 text-rose-500" />
                    <span>{isIndonesian ? 'Batalkan Permintaan' : 'Cancel Request'}</span>
                  </button>
                )}

                {/* Cancelled Action: Reactivate */}
                {canReactivate && (
                  <button
                    disabled={isSubmittingAction}
                    onClick={handleReactivateCancelled}
                    className="px-3.5 py-1.5 text-xs font-bold text-slate-700 bg-white hover:bg-slate-100 disabled:opacity-60 border border-slate-300 rounded-xl transition-colors flex items-center gap-1.5 whitespace-nowrap shrink-0"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>{isIndonesian ? 'Aktifkan Ulang Tiket' : 'Reactivate Ticket'}</span>
                  </button>
                )}
              </div>

              {/* Deliverable upload trigger */}
              {canUpload && (
                <button
                  onClick={() => setIsUploadModalOpen(true)}
                  className="px-3.5 py-1.5 text-xs font-semibold text-[#065F46] bg-[#D1FAE5] hover:bg-[#A7F3D0] border border-[#A7F3D0] rounded-xl transition-colors flex items-center gap-1.5 whitespace-nowrap shrink-0"
                >
                  <Upload className="w-3.5 h-3.5" />
                  <span>{isIndonesian ? 'Unggah Hasil Pekerjaan' : 'Upload Deliverable'}</span>
                </button>
              )}
            </div>
          );
        })()}

        {/* Tab Navigation */}
        <div className="flex items-center gap-1 px-3 sm:px-6 border-b border-slate-200 bg-white text-xs font-semibold overflow-x-auto no-scrollbar shrink-0">
          <button
            onClick={() => setActiveTab('overview')}
            className={`py-2.5 sm:py-3 px-2.5 sm:px-3.5 border-b-2 transition-colors whitespace-nowrap shrink-0 ${
              activeTab === 'overview'
                ? 'border-[#065F46] text-[#065F46] font-bold'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            <span className="hidden sm:inline">
              {isIndonesian ? 'Ringkasan Brief & Penugasan' : 'Brief & Assignment Summary'}
            </span>
            <span className="sm:hidden">Brief</span>
          </button>
          <button
            onClick={() => setActiveTab('sub_items')}
            className={`py-2.5 sm:py-3 px-2.5 sm:px-3.5 border-b-2 transition-colors flex items-center gap-1.5 whitespace-nowrap shrink-0 ${
              activeTab === 'sub_items'
                ? 'border-[#065F46] text-[#065F46] font-bold'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            <span>Sub Items</span>
            <span className="font-mono text-[10px] px-1.5 py-0.2 rounded-full bg-emerald-100 text-[#065F46] font-bold">
              {request.subItems?.filter((s) => !s.deletedAt).length || 0}
            </span>
          </button>
          <button
            onClick={() => setActiveTab('deliverables')}
            className={`py-2.5 sm:py-3 px-2.5 sm:px-3.5 border-b-2 transition-colors flex items-center gap-1.5 whitespace-nowrap shrink-0 ${
              activeTab === 'deliverables'
                ? 'border-[#065F46] text-[#065F46] font-bold'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            <span>{isIndonesian ? 'Hasil Pekerjaan' : 'Deliverables'}</span>
            <span className="font-mono text-[10px] px-1.5 py-0.2 rounded-full bg-slate-100 text-slate-700">
              {(request.deliverableAttachments?.length || 0) + (request.deliverableLinks?.length || 0)}
            </span>
          </button>
          <button
            onClick={() => setActiveTab('comments')}
            className={`py-2.5 sm:py-3 px-2.5 sm:px-3.5 border-b-2 transition-colors flex items-center gap-1.5 whitespace-nowrap shrink-0 ${
              activeTab === 'comments'
                ? 'border-[#065F46] text-[#065F46] font-bold'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            <span className="hidden sm:inline">
              {isIndonesian ? 'Komentar & Masukan' : 'Comments & Feedback'}
            </span>
            <span className="sm:hidden">{isIndonesian ? 'Komentar' : 'Comments'}</span>
            <span className="font-mono text-[10px] px-1.5 py-0.2 rounded-full bg-slate-100 text-slate-700">
              {comments.length}
            </span>
          </button>
          <button
            onClick={() => setActiveTab('audit_trail')}
            className={`py-2.5 sm:py-3 px-2.5 sm:px-3.5 border-b-2 transition-colors flex items-center gap-1.5 whitespace-nowrap shrink-0 ${
              activeTab === 'audit_trail'
                ? 'border-[#065F46] text-[#065F46] font-bold'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            <span>{isIndonesian ? 'Jejak Audit' : 'Audit Trail'}</span>
            <span className="font-mono text-[10px] px-1.5 py-0.2 rounded-full bg-slate-100 text-slate-700">
              {activityLogs.length}
            </span>
          </button>
        </div>

        {/* Tab Body Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {activeTab === 'overview' && (
            <div className="space-y-6">
              {/* On Hold Status Alert Banner */}
              {request.status === 'on_hold' && (
                <div className="p-4 bg-amber-50/90 border border-amber-300 rounded-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-amber-900 shadow-2xs">
                  <div className="flex items-start gap-3 min-w-0">
                    <div className="p-2 bg-amber-100 text-amber-800 rounded-xl shrink-0 mt-0.5 sm:mt-0">
                      <PauseCircle className="w-5 h-5" />
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <h4 className="font-bold text-sm text-amber-900">
                          {isIndonesian ? 'Tugas Sedang Ditunda' : 'Task Currently On Hold'}
                        </h4>
                        <span className="font-mono text-[10px] uppercase font-bold px-2 py-0.5 rounded-full bg-amber-200 text-amber-900">
                          {isIndonesian ? 'Dijeda' : 'Paused'}
                        </span>
                      </div>
                      <p className="text-xs text-amber-800 mt-1 break-words">
                        <span className="font-bold">{isIndonesian ? 'Alasan Penundaan:' : 'Hold Reason:'}</span>{' '}
                        {request.holdReason || (isIndonesian ? 'Tidak ada alasan spesifik tercatat.' : 'No specific reason logged.')}
                      </p>
                      <span className="text-[11px] text-amber-700/80 mt-1 block">
                        {isIndonesian
                          ? 'Perhitungan lini masa SLA dan status keterlambatan dibekukan sementara selama ditunda.'
                          : 'SLA timeline calculations and overdue status are temporarily frozen while on hold.'}
                      </span>
                    </div>
                  </div>
                  {canTransitionStatus(request, 'in_progress') && (
                    <button
                      disabled={isSubmittingAction}
                      onClick={handleResumeFromHold}
                      className="px-3.5 py-1.5 text-xs font-bold text-white bg-amber-700 hover:bg-amber-800 disabled:opacity-60 rounded-xl transition-colors flex items-center gap-1.5 shrink-0 shadow-2xs self-end sm:self-auto"
                    >
                      <PlayCircle className="w-4 h-4" />
                      <span>{isIndonesian ? 'Lanjutkan Pekerjaan' : 'Resume Work'}</span>
                    </button>
                  )}
                </div>
              )}

              {/* Cancelled Status Alert Banner */}
              {request.status === 'cancelled' && (
                <div className="p-4 bg-rose-50/90 border border-rose-300 rounded-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-rose-900 shadow-2xs">
                  <div className="flex items-start gap-3 min-w-0">
                    <div className="p-2 bg-rose-100 text-rose-700 rounded-xl shrink-0 mt-0.5 sm:mt-0">
                      <Ban className="w-5 h-5" />
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <h4 className="font-bold text-sm text-rose-900">
                          {isIndonesian ? 'Permintaan Dibatalkan' : 'Request Cancelled'}
                        </h4>
                        <span className="font-mono text-[10px] uppercase font-bold px-2 py-0.5 rounded-full bg-rose-200 text-rose-900">
                          {isIndonesian ? 'Ditutup' : 'Closed'}
                        </span>
                      </div>
                      <p className="text-xs text-rose-800 mt-1 break-words">
                        <span className="font-bold">{isIndonesian ? 'Alasan Pembatalan:' : 'Cancellation Reason:'}</span>{' '}
                        {request.cancelReason || (isIndonesian ? 'Tidak ada alasan pembatalan tercatat.' : 'No cancellation reason logged.')}
                      </p>
                      <span className="text-[11px] text-rose-700/80 mt-1 block">
                        {isIndonesian
                          ? 'Permintaan ini ditutup dan dikecualikan dari metrik pemenuhan SLA aktif.'
                          : 'This request is closed and excluded from active SLA fulfillment metrics.'}
                      </span>
                    </div>
                  </div>
                  {canTransitionStatus(request, 'todo') && (
                    <button
                      disabled={isSubmittingAction}
                      onClick={handleReactivateCancelled}
                      className="px-3.5 py-1.5 text-xs font-bold text-slate-800 bg-white hover:bg-slate-100 disabled:opacity-60 border border-slate-300 rounded-xl transition-colors flex items-center gap-1.5 shrink-0 shadow-2xs self-end sm:self-auto"
                    >
                      <RotateCcw className="w-4 h-4" />
                      <span>{isIndonesian ? 'Aktifkan Ulang Tiket' : 'Reactivate Ticket'}</span>
                    </button>
                  )}
                </div>
              )}

              {/* Assignment & Commitment Panel */}
              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200">
                <div className="flex items-center justify-between pb-3 border-b border-slate-200">
                  <div className="flex items-center gap-2">
                    <User className="w-4 h-4 text-blue-600" />
                    <h3 className="text-xs font-bold text-slate-900">
                      {isIndonesian ? 'Penugasan Tim & Komitmen SLA' : 'Team Assignment & SLA Commitment'}
                    </h3>
                  </div>
                  {canAssignRequest(request) && (
                    <button
                      onClick={handleOpenAssignModal}
                      className="text-xs text-blue-600 hover:text-blue-800 font-semibold flex items-center gap-1"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                      <span>
                        {request.primaryAssigneeId
                          ? (isIndonesian ? 'Edit Penugasan' : 'Edit Assignment')
                          : (isIndonesian ? 'Tugaskan' : 'Assign Task')}
                      </span>
                    </button>
                  )}
                </div>

                {/* Requestor Profile Info Strip */}
                <div className="mt-3 p-3 bg-white rounded-xl border border-slate-200/90 shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div className="w-8 h-8 rounded-full bg-[#D1FAE5] text-[#065F46] font-bold text-xs flex items-center justify-center shrink-0 border border-[#A7F3D0]">
                      {(request.requestorName || request.requesterName || 'R').charAt(0).toUpperCase()}
                    </div>
                    <div className="min-w-0 truncate">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="text-[11px] text-slate-400">
                          {isIndonesian ? 'Nama Pemohon:' : "Requestor's Name:"}
                        </span>
                        <strong className="text-slate-900 font-bold text-xs">
                          {request.requestorName || request.requesterName}
                        </strong>
                      </div>
                      <div className="text-[11px] text-slate-500 truncate">
                        {request.requesterDepartment || (isIndonesian ? 'Departemen Umum' : 'General Department')} · {request.requesterEmail}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 self-start sm:self-auto shrink-0">
                    <span className="text-[11px] text-slate-400">
                      {isIndonesian ? 'Tenggat Diminta:' : 'Requested Deadline:'}
                    </span>
                    <span className="font-mono font-semibold text-slate-800 bg-slate-100 px-2 py-0.5 rounded text-[11px]">
                      {request.requestedDeadline}
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-3 text-xs">
                  <div className="p-3 bg-white rounded-xl border border-slate-200/80 shadow-2xs">
                    <span className="text-[11px] font-medium text-slate-400 block mb-1">
                      {isIndonesian ? 'Tim Ditugaskan' : 'Assigned Team'}
                    </span>
                    <strong className="text-slate-900 font-semibold block truncate">
                      {request.assignedTeamName || (isIndonesian ? 'Belum Dipilih' : 'Unselected')}
                    </strong>
                  </div>
                  <div className="p-3 bg-white rounded-xl border border-slate-200/80 shadow-2xs">
                    <span className="text-[11px] font-medium text-slate-400 block mb-1">
                      {isIndonesian ? 'Pelaksana Utama' : 'Primary Assignee'}
                    </span>
                    <strong className="text-slate-900 font-semibold block truncate">
                      {request.primaryAssigneeName || (isIndonesian ? 'Belum Ditugaskan' : 'Unassigned')}
                    </strong>
                  </div>
                  <div className="p-3 bg-white rounded-xl border border-slate-200/80 shadow-2xs">
                    <span className="text-[11px] font-medium text-slate-400 block mb-1">
                      {isIndonesian ? 'Reviewer Ditunjuk' : 'Designated Reviewer'}
                    </span>
                    <strong className="text-slate-900 font-semibold block truncate">
                      {request.reviewerName || (isIndonesian ? 'Admin / Pemohon' : 'Admin / Requester')}
                    </strong>
                  </div>
                  <div className="p-3 bg-white rounded-xl border border-slate-200/80 shadow-2xs">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-[11px] font-medium text-slate-400 block">
                        {isIndonesian ? 'Tenggat Komitmen' : 'Committed Deadline'}
                      </span>
                      {isAdmin && request.committedDeadline && (
                        <button
                          onClick={() => {
                            setNewDeadline(request.committedDeadline || '');
                            setIsEditingDeadline(true);
                          }}
                          className="text-[10px] text-blue-600 hover:text-blue-800 font-semibold hover:underline"
                        >
                          Edit
                        </button>
                      )}
                    </div>
                    <strong className="text-slate-900 font-mono font-bold block truncate">
                      {request.committedDeadline || (isIndonesian ? 'Belum Dijadwalkan' : 'Unscheduled')}
                    </strong>
                  </div>
                </div>

                {/* Collaborators list */}
                {request.collaboratorNames && request.collaboratorNames.length > 0 && (
                  <div className="mt-3 pt-2.5 border-t border-slate-200/80 text-xs">
                    <span className="text-slate-400">
                      {isIndonesian ? 'Kolaborator: ' : 'Collaborators: '}
                    </span>
                    <span className="text-slate-700 font-medium">
                      {request.collaboratorNames.join(', ')}
                    </span>
                  </div>
                )}

                {/* AI Deadline Risk Prediction Widget */}
                <div className="mt-3 pt-3 border-t border-slate-200/80">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5 text-xs font-bold text-slate-800">
                      <AlertTriangle className="w-3.5 h-3.5 text-rose-600" />
                      <span>
                        {isIndonesian ? 'Prediksi Risiko Tenggat AI' : 'AI Deadline Risk Prediction'}
                      </span>
                    </div>
                    <button
                      type="button"
                      onClick={handlePredictRisk}
                      disabled={isPredictingRisk}
                      className="text-[11px] font-semibold text-rose-600 hover:text-rose-800 flex items-center gap-1"
                    >
                      {isPredictingRisk ? <RefreshCw className="w-3 h-3 animate-spin" /> : <Sparkles className="w-3 h-3" />}
                      <span>
                        {aiRiskPrediction
                          ? (isIndonesian ? 'Hitung Ulang' : 'Recalculate')
                          : (isIndonesian ? 'Cek Risiko Terlambat' : 'Check Overdue Risk')}
                      </span>
                    </button>
                  </div>

                  {aiRiskPrediction && (
                    <div className="mt-2 p-3 bg-white rounded-xl border border-rose-200 text-xs space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-slate-900">
                          {isIndonesian ? 'Probabilitas Risiko Terlambat:' : 'Late Risk Probability:'}{' '}
                          {aiRiskPrediction.riskPercentage}%
                        </span>
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                            aiRiskPrediction.riskLevel === 'critical'
                              ? 'bg-rose-100 text-rose-800'
                              : aiRiskPrediction.riskLevel === 'high'
                              ? 'bg-orange-100 text-orange-800'
                              : 'bg-amber-100 text-amber-800'
                          }`}
                        >
                          {aiRiskPrediction.riskLevel.toUpperCase()} {isIndonesian ? 'RISIKO' : 'RISK'}
                        </span>
                      </div>
                      <p className="text-slate-600">{aiRiskPrediction.summary}</p>
                      {aiRiskPrediction.mitigationActions.length > 0 && (
                        <div className="text-[11px] text-emerald-800 bg-emerald-50 p-2 rounded border border-emerald-200">
                          <strong>{isIndonesian ? 'Rekomendasi Mitigasi:' : 'Recommended Mitigation:'}</strong>{' '}
                          {aiRiskPrediction.mitigationActions[0]}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>

              {/* Brief Content */}
              <div className="space-y-4">
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                      {isIndonesian ? 'Kebutuhan Brief & Ruang Lingkup' : 'Brief Requirements & Scope'}
                    </h4>
                    <button
                      type="button"
                      onClick={handleAnalyzeBrief}
                      disabled={isAnalyzingBrief}
                      className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-emerald-50 text-emerald-700 hover:bg-emerald-100 text-xs font-semibold border border-emerald-200 transition-colors"
                    >
                      {isAnalyzingBrief ? <RefreshCw className="w-3 h-3 animate-spin" /> : <FileCheck className="w-3.5 h-3.5" />}
                      <span>
                        {aiBriefAnalysis
                          ? (isIndonesian ? 'Audit Ulang Brief' : 'Re-Audit Brief')
                          : (isIndonesian ? 'Audit Brief dengan AI' : 'Audit Brief with AI')}
                      </span>
                    </button>
                  </div>

                  {aiBriefAnalysis && (
                    <div className="mb-3 p-3.5 bg-emerald-50/70 rounded-xl border border-emerald-200 text-xs space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-emerald-950">
                          {isIndonesian ? 'Skor Kelengkapan:' : 'Completeness Score:'} {aiBriefAnalysis.completenessScore}/100 ({aiBriefAnalysis.clarityGrade})
                        </span>
                      </div>
                      {aiBriefAnalysis.missingSpecs.length > 0 && (
                        <div className="text-rose-800 bg-white p-2 rounded border border-rose-200">
                          <strong className="block text-rose-900 mb-0.5">
                            {isIndonesian ? 'Spesifikasi yang Belum Lengkap:' : 'Missing Specifications:'}
                          </strong>
                          <ul className="list-disc list-inside space-y-0.5">
                            {aiBriefAnalysis.missingSpecs.map((s, idx) => (
                              <li key={idx}>{s}</li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </div>
                  )}

                  <div className="p-4 bg-white rounded-xl border border-slate-200 text-xs text-slate-700 leading-relaxed whitespace-pre-wrap">
                    {request.description}
                  </div>
                </div>

                <div>
                  <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-1.5">
                    {isIndonesian ? 'Hasil Pekerjaan yang Diharapkan' : 'Expected Deliverables'}
                  </h4>
                  <div className="p-3 bg-white rounded-xl border border-slate-200 text-xs text-slate-800 font-medium">
                    {request.deliverablesExpected}
                  </div>
                </div>

                {/* Sub Items Quick Summary Banner */}
                {(() => {
                  const activeSubItems = request.subItems?.filter((s) => !s.deletedAt) || [];
                  const total = activeSubItems.length;
                  const completed = activeSubItems.filter((s) => s.status === 'completed').length;
                  const eligible = activeSubItems.filter((s) => s.status !== 'cancelled').length;
                  const rate = eligible > 0 ? Math.round((completed / eligible) * 100) : null;

                  return (
                    <div className="p-4 bg-slate-50/80 rounded-2xl border border-slate-200/90 space-y-2.5">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className="p-1.5 bg-[#D1FAE5] text-[#065F46] rounded-lg">
                            <Layers className="w-4 h-4" />
                          </div>
                          <div>
                            <h4 className="text-xs font-bold text-slate-900">
                              {isIndonesian
                                ? `Sub Item / Hasil Multi-Kanal (${total})`
                                : `Sub Items / Multi-Channel Deliverables (${total})`}
                            </h4>
                            <p className="text-[11px] text-slate-500">
                              {isIndonesian
                                ? 'Pelacakan tugas terperinci per spesialis kreatif.'
                                : 'Granular task tracking per creative specialist.'}
                            </p>
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={() => setActiveTab('sub_items')}
                          className="px-2.5 py-1 text-xs font-semibold text-[#065F46] bg-[#D1FAE5] hover:bg-[#A7F3D0] rounded-lg transition-colors flex items-center gap-1 shadow-2xs"
                        >
                          <span>{isIndonesian ? 'Lihat Sub Item' : 'View Sub Items'}</span>
                          <ArrowRight className="w-3 h-3" />
                        </button>
                      </div>

                      {total > 0 && (
                        <div className="pt-1">
                          <div className="flex items-center justify-between text-[11px] mb-1">
                            <span className="text-slate-600 font-medium">
                              {isIndonesian ? 'Progres Sub Item:' : 'Sub Item Progress:'}
                            </span>
                            <span className="font-mono font-bold text-[#065F46]">
                              {rate !== null
                                ? `${rate}% (${completed}/${eligible} ${isIndonesian ? 'selesai' : 'completed'})`
                                : 'N/A'}
                            </span>
                          </div>
                          <div className="w-full bg-slate-200 rounded-full h-2 overflow-hidden">
                            <div
                              className="bg-[#065F46] h-2 rounded-full transition-all duration-300"
                              style={{ width: `${rate ?? 0}%` }}
                            />
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })()}

                {/* Brief Attachments */}
                <div>
                  <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-1.5">
                    {isIndonesian ? 'Lampiran Brief Pemohon' : 'Requester Brief Attachments'} ({request.briefAttachments?.length || 0})
                  </h4>
                  {(!request.briefAttachments || request.briefAttachments.length === 0) ? (
                    <p className="text-xs text-slate-400 italic">
                      {isIndonesian ? 'Tidak ada lampiran brief awal yang diunggah.' : 'No initial brief attachments uploaded.'}
                    </p>
                  ) : (
                    <div className="space-y-2">
                      {request.briefAttachments.map((att) => (
                        <div
                          key={att.id}
                          className="flex items-center justify-between p-3 bg-white rounded-xl border border-slate-200 text-xs"
                        >
                          <div className="flex items-center gap-2.5 truncate">
                            <Paperclip className="w-4 h-4 text-blue-600 shrink-0" />
                            <span className="font-semibold text-slate-900 truncate">{att.name}</span>
                            <span className="text-[11px] text-slate-400 font-mono">
                              ({Math.round(att.size / 1024)} KB)
                            </span>
                          </div>
                          <span className="text-[11px] text-slate-500">
                            {isIndonesian ? 'Diunggah' : 'Uploaded'} {att.uploadedAt ? att.uploadedAt.split('T')[0] : ''}
                          </span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Reopen history note if reopened */}
                {request.reopenCount > 0 && (
                  <div className="p-3.5 bg-amber-50 rounded-xl border border-amber-200 text-xs text-amber-900">
                    <strong className="font-bold flex items-center gap-1.5">
                      <RotateCcw className="w-3.5 h-3.5 text-amber-700" />
                      {isIndonesian
                        ? `Tugas Dibuka Ulang (${request.reopenCount}x)`
                        : `Task Reopened (${request.reopenCount}x)`}
                    </strong>
                    <p className="mt-1 text-[11px] leading-relaxed">
                      {isIndonesian ? 'Alasan terbaru:' : 'Latest reason:'} &quot;{request.reopenReason}&quot;
                    </p>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Sub Items Tab */}
          {activeTab === 'sub_items' && (
            <div className="space-y-6">
              {/* Header & Sub Items KPI Overview Cards */}
              {(() => {
                const active = request.subItems?.filter((s) => !s.deletedAt) || [];
                const total = active.length;
                const completed = active.filter((s) => s.status === 'completed').length;
                const inProgress = active.filter((s) => s.status === 'in_progress').length;
                const pendingReview = active.filter((s) => s.status === 'pending_review').length;
                const onHold = active.filter((s) => s.status === 'on_hold').length;
                const eligible = active.filter((s) => s.status !== 'cancelled').length;
                const completionRate = eligible > 0 ? Math.round((completed / eligible) * 100) : null;

                return (
                  <div className="space-y-4">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200">
                      <div>
                        <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                          <Layers className="w-4 h-4 text-[#065F46]" />
                          <span>
                            {isIndonesian
                              ? 'Sub Item / Rincian Hasil Pekerjaan'
                              : 'Sub Items / Deliverable Breakdown'}
                          </span>
                        </h3>
                        <p className="text-xs text-slate-500 mt-0.5">
                          {isIndonesian
                            ? `Hasil pekerjaan kreatif multi-kanal dilacak secara independen di bawah ${request.ticketNumber}.`
                            : `Multi-channel creative deliverables tracked independently under ${request.ticketNumber}.`}
                        </p>
                      </div>

                      {/* Completion Rate Badge */}
                      <div className="flex items-center gap-2 bg-slate-50 px-3 py-1.5 rounded-xl border border-slate-200 self-start sm:self-auto">
                        <span className="text-xs text-slate-500">
                          {isIndonesian ? 'Penyelesaian Sub Item:' : 'Sub Item Completion:'}
                        </span>
                        <span className="font-mono font-bold text-sm text-[#065F46]">
                          {completionRate !== null ? `${completionRate}%` : 'N/A'}
                        </span>
                      </div>
                    </div>

                    {/* KPI Metric Cards */}
                    <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5 text-xs">
                      <div className="p-3 bg-white rounded-xl border border-slate-200 shadow-2xs">
                        <span className="text-[11px] font-semibold text-slate-400 block mb-0.5">
                          {isIndonesian ? 'Total Sub Item' : 'Total Sub Items'}
                        </span>
                        <div className="font-mono text-base font-bold text-slate-900">{total}</div>
                      </div>
                      <div className="p-3 bg-white rounded-xl border border-emerald-200 shadow-2xs bg-emerald-50/20">
                        <span className="text-[11px] font-semibold text-emerald-700 block mb-0.5">
                          {isIndonesian ? 'Selesai' : 'Completed'}
                        </span>
                        <div className="font-mono text-base font-bold text-emerald-800">{completed}</div>
                      </div>
                      <div className="p-3 bg-white rounded-xl border border-blue-200 shadow-2xs bg-blue-50/20">
                        <span className="text-[11px] font-semibold text-blue-700 block mb-0.5">
                          {isIndonesian ? 'Sedang Dikerjakan' : 'In Progress'}
                        </span>
                        <div className="font-mono text-base font-bold text-blue-800">{inProgress}</div>
                      </div>
                      <div className="p-3 bg-white rounded-xl border border-amber-200 shadow-2xs bg-amber-50/20">
                        <span className="text-[11px] font-semibold text-amber-700 block mb-0.5">
                          {isIndonesian ? 'Menunggu Review' : 'Pending Review'}
                        </span>
                        <div className="font-mono text-base font-bold text-amber-800">{pendingReview}</div>
                      </div>
                      <div className="p-3 bg-white rounded-xl border border-slate-200 shadow-2xs">
                        <span className="text-[11px] font-semibold text-slate-500 block mb-0.5">
                          {isIndonesian ? 'Ditunda' : 'On Hold'}
                        </span>
                        <div className="font-mono text-base font-bold text-slate-700">{onHold}</div>
                      </div>
                    </div>
                  </div>
                );
              })()}

              {/* Sub Item Table View Component */}
              <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-2xs">
                <SubItemTableView parentRequest={request} />
              </div>
            </div>
          )}

          {/* Deliverables Tab */}
          {activeTab === 'deliverables' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-xs font-bold text-slate-900">
                    {isIndonesian ? 'Hasil Pekerjaan Tim Kreatif' : 'Creative Team Deliverables'}
                  </h3>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    {isIndonesian
                      ? 'File desain final, render video, dan tautan pratinjau eksternal untuk evaluasi dan persetujuan reviewer.'
                      : 'Final design files, video renders, and external preview links for reviewer evaluation and sign-off.'}
                  </p>
                </div>
                {canSubmitDeliverables(request) && (
                  <button
                    onClick={() => setIsUploadModalOpen(true)}
                    className="px-3 py-1.5 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-2xs flex items-center gap-1.5"
                  >
                    <Upload className="w-3.5 h-3.5" />
                    <span>{isIndonesian ? 'Tambah Deliverable' : 'Add Deliverable'}</span>
                  </button>
                )}
              </div>

              {/* Deliverable Attachments */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold text-slate-700">
                    {language === 'id' ? 'Lampiran File Hasil Pekerjaan (Deliverables)' : 'Deliverable File Attachments'}
                  </h4>
                  {request.deliverableAttachments && request.deliverableAttachments.length > 0 && (
                    <span className="text-[11px] font-semibold text-slate-500">
                      {request.deliverableAttachments.length} {language === 'id' ? 'file diunggah' : 'files uploaded'}
                    </span>
                  )}
                </div>
                {(!request.deliverableAttachments || request.deliverableAttachments.length === 0) ? (
                  <div className="p-6 bg-slate-50 rounded-xl border border-dashed border-slate-300 text-center text-xs text-slate-400">
                    {language === 'id'
                      ? 'Belum ada file deliverable yang diunggah oleh assignee.'
                      : 'No deliverable files uploaded by the assignee yet.'}
                  </div>
                ) : (
                  request.deliverableAttachments.map((del) => (
                    <div
                      key={del.id}
                      className="p-3.5 bg-white rounded-xl border border-slate-200 flex items-center justify-between gap-3 shadow-2xs hover:border-slate-300 transition-colors"
                    >
                      <div className="flex items-center gap-3 truncate min-w-0">
                        <div className="w-9 h-9 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-center shrink-0">
                          {getDeliverableFileIcon(del.name)}
                        </div>
                        <div className="truncate">
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-bold text-slate-900 truncate">{del.name}</span>
                            {getDeliverableFormatBadge(del.name)}
                          </div>
                          <div className="text-[11px] text-slate-500 mt-0.5 flex items-center gap-2">
                            <span className="font-medium text-slate-600">{formatFileSize(del.size)}</span>
                            <span>•</span>
                            <span>{language === 'id' ? 'Diunggah oleh' : 'Uploaded by'}: {del.uploadedBy}</span>
                            <span>•</span>
                            <span>{del.uploadedAt?.split('T')[0]}</span>
                          </div>
                        </div>
                      </div>
                      <a
                        href={del.url}
                        download={del.name}
                        target="_blank"
                        rel="noreferrer"
                        className="px-3 py-1.5 text-xs font-semibold text-blue-600 hover:text-blue-800 bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors flex items-center gap-1.5 shrink-0"
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span>{language === 'id' ? 'Unduh' : 'Download'}</span>
                      </a>
                    </div>
                  ))
                )}
              </div>

              {/* Deliverable External Links */}
              <div className="space-y-2 pt-2">
                <h4 className="text-xs font-bold text-slate-700">
                  {isIndonesian ? 'Tautan Kerja Eksternal' : 'External Work Links'}
                </h4>
                {(!request.deliverableLinks || request.deliverableLinks.length === 0) ? (
                  <div className="p-6 bg-slate-50 rounded-xl border border-dashed border-slate-300 text-center text-xs text-slate-400">
                    {isIndonesian
                      ? 'Belum ada tautan hasil pekerjaan eksternal (Google Drive / Figma / Preview) yang ditambahkan.'
                      : 'No external deliverable links (Google Drive / Figma / Preview) added yet.'}
                  </div>
                ) : (
                  request.deliverableLinks.map((link) => (
                    <div
                      key={link.id}
                      className="p-3.5 bg-white rounded-xl border border-slate-200 flex items-center justify-between gap-3 shadow-2xs"
                    >
                      <div className="flex items-center gap-3 truncate">
                        <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
                          <LinkIcon className="w-4 h-4" />
                        </div>
                        <div className="truncate">
                          <div className="text-xs font-bold text-slate-900 truncate">{link.title}</div>
                          <div className="text-[11px] text-blue-600 truncate hover:underline">
                            {link.url}
                          </div>
                        </div>
                      </div>
                      <a
                        href={link.url}
                        target="_blank"
                        rel="noreferrer"
                        className="px-3 py-1 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors flex items-center gap-1 shrink-0"
                      >
                        <span>{isIndonesian ? 'Buka Tautan' : 'Open Link'}</span>
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          {/* Comments Tab */}
          {activeTab === 'comments' && (
            <div className="space-y-5">
              {/* Comment input form */}
              <form onSubmit={handlePostComment} className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-900">
                    {isIndonesian ? 'Tambah Komentar atau Catatan Revisi' : 'Add Comment or Revision Feedback'}
                  </span>
                  {/* Toggle comment type */}
                  <div className="flex items-center gap-1 p-0.5 bg-slate-200 rounded-lg text-[11px] font-semibold">
                    <button
                      type="button"
                      onClick={() => setCommentType('general')}
                      className={`px-2.5 py-0.5 rounded-md transition-colors ${
                        commentType === 'general' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-600'
                      }`}
                    >
                      {isIndonesian ? 'Komentar Umum' : 'General Comment'}
                    </button>
                    <button
                      type="button"
                      onClick={() => setCommentType('revision_note')}
                      className={`px-2.5 py-0.5 rounded-md transition-colors ${
                        commentType === 'revision_note' ? 'bg-orange-600 text-white shadow-2xs' : 'text-slate-600'
                      }`}
                    >
                      {isIndonesian ? 'Catatan Revisi' : 'Revision Note'}
                    </button>
                  </div>
                </div>

                <textarea
                  rows={3}
                  value={newComment}
                  onChange={(e) => setNewComment(e.target.value)}
                  placeholder={
                    commentType === 'revision_note'
                      ? isIndonesian
                        ? 'Jelaskan penyesuaian, revisi, dan detail spesifik yang diperlukan...'
                        : 'Specify the exact adjustments, revisions, and details required...'
                      : isIndonesian
                      ? 'Tulis masukan, pertanyaan, atau pembaruan terkait tugas ini...'
                      : 'Write feedback, questions, or updates regarding this task...'
                  }
                  className="w-full p-3 text-xs bg-white border border-slate-300 rounded-xl focus:outline-hidden focus:border-blue-600 leading-relaxed"
                />

                <div className="flex items-center justify-between">
                  <span className="text-[11px] text-slate-400">
                    {commentType === 'revision_note'
                      ? isIndonesian
                        ? 'Catatan revisi akan ditandai dengan lencana sorotan khusus'
                        : 'Revision notes will be marked with a dedicated highlight badge'
                      : isIndonesian
                      ? 'Komentar dapat dilihat oleh semua pelaksana dan pemohon'
                      : 'Comments are visible to all assignees and requesters'}
                  </span>
                  <button
                    type="submit"
                    disabled={!newComment.trim()}
                    className="px-4 py-1.5 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 disabled:bg-slate-300 rounded-lg transition-colors flex items-center gap-1.5 shadow-2xs"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>{isIndonesian ? 'Kirim' : 'Send'}</span>
                  </button>
                </div>
              </form>

              {/* Comment list */}
              <div className="space-y-3">
                {comments.length === 0 ? (
                  <p className="text-center py-8 text-xs text-slate-400">
                    {isIndonesian ? 'Belum ada komentar pada permintaan ini.' : 'No comments on this request yet.'}
                  </p>
                ) : (
                  comments.map((c) => {
                    const isRevision = c.type === 'revision_note';
                    return (
                      <div
                        key={c.id}
                        className={`p-4 rounded-xl border transition-all ${
                          isRevision
                            ? 'bg-orange-50/70 border-orange-200'
                            : 'bg-white border-slate-200'
                        }`}
                      >
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-bold text-slate-900">{c.authorName}</span>
                            <span className="text-[10px] px-1.5 py-0.2 rounded bg-slate-100 text-slate-600 font-medium capitalize">
                              {c.role.replace('_', ' ')}
                            </span>
                            {isRevision && (
                              <span className="text-[10px] px-2 py-0.2 rounded bg-orange-100 text-orange-800 font-bold border border-orange-300">
                                {isIndonesian ? 'Catatan Revisi' : 'Revision Note'}
                              </span>
                            )}
                          </div>
                          <span className="text-[10px] text-slate-400 font-mono tabular-nums">
                            {c.createdAt ? c.createdAt.replace('T', ' ').slice(0, 16) : ''}
                          </span>
                        </div>
                        <p className="text-xs text-slate-700 leading-relaxed whitespace-pre-wrap">
                          {c.content}
                        </p>
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          )}

          {/* Audit Trail Tab */}
          {activeTab === 'audit_trail' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold text-slate-900">
                  {isIndonesian ? 'Riwayat Aktivitas & Log Audit' : 'Activity History & Audit Log'}
                </h3>
                <span className="text-[11px] text-slate-500">
                  {isIndonesian ? 'Diarsipkan permanen & tidak dapat diubah' : 'Permanently archived & immutable'}
                </span>
              </div>

              <div className="space-y-3">
                {activityLogs.length === 0 ? (
                  <p className="text-center py-8 text-xs text-slate-400">
                    {isIndonesian ? 'Belum ada riwayat aktivitas yang tercatat.' : 'No activity history recorded yet.'}
                  </p>
                ) : (
                  activityLogs.map((log) => (
                    <div
                      key={log.id}
                      className="p-3.5 bg-white rounded-xl border border-slate-200 text-xs space-y-1 shadow-2xs"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <strong className="font-semibold text-slate-900">{log.actorName}</strong>
                          <span className="text-[10px] text-slate-500 capitalize">
                            ({log.actorRole.replace('_', ' ')})
                          </span>
                        </div>
                        <span className="text-[10px] text-slate-400 font-mono tabular-nums">
                          {log.timestamp ? log.timestamp.replace('T', ' ').slice(0, 19) : ''}
                        </span>
                      </div>

                      <div className="text-slate-700">
                        {isIndonesian ? 'Aksi:' : 'Action:'}{' '}
                        <strong className="font-semibold text-blue-700">{log.actionType}</strong>
                        {log.fieldChanged && (
                          <span> · {isIndonesian ? 'Kolom:' : 'Field:'} {log.fieldChanged}</span>
                        )}
                      </div>

                      {(log.oldValue || log.newValue) && (
                        <div className="text-[11px] text-slate-600 bg-slate-50 p-2 rounded-lg font-mono">
                          {log.oldValue && (
                            <div>{isIndonesian ? 'Sebelum:' : 'Before:'} {log.oldValue}</div>
                          )}
                          {log.newValue && (
                            <div>{isIndonesian ? 'Sesudah:' : 'After:'} {log.newValue}</div>
                          )}
                        </div>
                      )}

                      {log.reason && (
                        <div className="text-[11px] text-slate-600 italic">
                          {isIndonesian ? 'Alasan:' : 'Reason:'} &quot;{log.reason}&quot;
                        </div>
                      )}
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </div>

        {/* Assignment Modal Dialog */}
        {isAssigning && (
          <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
            <div className="bg-white rounded-2xl p-6 max-w-lg w-full border border-slate-200 shadow-2xl space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-200">
                <h3 className="text-sm font-bold text-slate-900">
                  {isIndonesian
                    ? 'Atur Penugasan Tim & Tenggat Komitmen'
                    : 'Set Team Assignment & Committed Deadline'}
                </h3>
                <button onClick={() => setIsAssigning(false)} className="text-slate-400 hover:text-slate-600">
                  <X className="w-4 h-4" />
                </button>
              </div>

              <form onSubmit={handleSaveAssignment} className="space-y-3.5 text-xs">
                {/* Requestor & Task Context Strip */}
                <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between text-xs">
                  <div>
                    <span className="text-[10px] text-slate-400 block font-medium">
                      {isIndonesian ? 'Nama Pemohon' : "Requestor's Name"}
                    </span>
                    <strong className="text-slate-900 font-semibold flex items-center gap-1.5 mt-0.5">
                      <User className="w-3.5 h-3.5 text-[#065F46]" />
                      {request.requestorName || request.requesterName}
                    </strong>
                  </div>
                  <div className="text-right">
                    <span className="text-[10px] text-slate-400 block font-medium">
                      {isIndonesian ? 'Departemen & Entitas' : 'Department & Entity'}
                    </span>
                    <span className="text-slate-700 font-medium">
                      {request.requesterDepartment || (isIndonesian ? 'Umum' : 'General')} · {request.brandName}
                    </span>
                  </div>
                </div>

                {/* AI Assignment Optimizer Banner */}
                <div className="p-3 rounded-xl bg-blue-50 border border-blue-200 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-blue-600 shrink-0" />
                    <div>
                      <span className="font-bold text-blue-950 block">
                        {isIndonesian ? 'Pengoptimal Penugasan Tugas AI' : 'AI Task Assignment Optimizer'}
                      </span>
                      <span className="text-[11px] text-blue-800">
                        {isIndonesian
                          ? 'Rekomendasi cerdas berdasarkan kompetensi bidang & beban kerja aktif tim.'
                          : 'Smart recommendation based on domain competencies & active team workload.'}
                      </span>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={handleRecommendAssignment}
                    disabled={isRecommendingAssignee}
                    className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-blue-600 text-white font-medium text-xs hover:bg-blue-700 disabled:opacity-50 transition-colors shrink-0 shadow-xs"
                  >
                    {isRecommendingAssignee ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5" />}
                    {isRecommendingAssignee
                      ? (isIndonesian ? 'Mencocokkan...' : 'Matching...')
                      : (isIndonesian ? 'Rekomendasi AI' : 'AI Recommend')}
                  </button>
                </div>

                {aiAssignmentRec && (
                  <div className="p-3 bg-white rounded-xl border border-blue-200 text-xs space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-slate-900">
                        {aiAssignmentRec.primaryAssignee.name} ({isIndonesian ? 'Kecocokan' : 'Match'} {aiAssignmentRec.primaryAssignee.matchScore}%)
                      </span>
                      <span className="text-[10px] text-slate-500">
                        {isIndonesian ? 'Kolaborator:' : 'Collaborator:'} {aiAssignmentRec.collaborator.name}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-600">{aiAssignmentRec.primaryAssignee.rationale}</p>
                  </div>
                )}

                {/* Team selector */}
                <div>
                  <label className="block font-bold text-slate-800 mb-1">
                    {isIndonesian ? 'Tim Ditugaskan *' : 'Assigned Team *'}
                  </label>
                  <select
                    value={assignedTeamId}
                    onChange={(e) => setAssignedTeamId(e.target.value)}
                    className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg"
                  >
                    {teams.map((t) => (
                      <option key={t.id} value={t.id}>
                        {t.name}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Primary Assignee */}
                <div>
                  <label className="block font-bold text-slate-800 mb-1">
                    {isIndonesian ? 'Pelaksana Utama *' : 'Primary Assignee *'}
                  </label>
                  <select
                    value={primaryAssigneeId}
                    onChange={(e) => setPrimaryAssigneeId(e.target.value)}
                    className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg"
                  >
                    <option value="">
                      {isIndonesian ? 'Pilih Pelaksana Utama' : 'Select Primary Assignee'}
                    </option>
                    {teamMembers.map((m) => (
                      <option key={m.id} value={m.id}>
                        {m.fullName} ({m.competencies?.join(', ') || m.jobTitle})
                      </option>
                    ))}
                  </select>
                </div>

                {/* Reviewer */}
                <div>
                  <label className="block font-bold text-slate-800 mb-1">
                    {isIndonesian ? 'Reviewer Ditunjuk' : 'Designated Reviewer'}
                  </label>
                  <select
                    value={reviewerId}
                    onChange={(e) => setReviewerId(e.target.value)}
                    className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg"
                  >
                    <option value="">
                      {isIndonesian ? 'Default (Admin / Pemohon)' : 'Default (Admin / Requester)'}
                    </option>
                    {allUsers
                      .filter((u) => u.isReviewer || u.role === 'admin' || u.role === 'super_admin')
                      .map((u) => (
                        <option key={u.id} value={u.id}>
                          {u.fullName} ({u.jobTitle})
                        </option>
                      ))}
                  </select>
                </div>

                {/* Committed Deadline */}
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="font-bold text-slate-800">
                      {isIndonesian ? 'Tenggat Komitmen *' : 'Committed Deadline *'}
                    </label>
                    <button
                      type="button"
                      onClick={() => {
                        const baseDate = request.createdAt ? new Date(request.createdAt) : new Date();
                        baseDate.setDate(baseDate.getDate() + (PRIORITY_SLA_DAYS[request.priority] || 3));
                        setCommittedDeadlineInput(baseDate.toISOString().split('T')[0]);
                      }}
                      className="text-[10px] text-blue-600 hover:text-blue-800 font-semibold hover:underline"
                    >
                      {isIndonesian
                        ? `Terapkan SLA ${request.priority.toUpperCase()} (${PRIORITY_SLA_DAYS[request.priority]} Hari)`
                        : `Apply ${request.priority.toUpperCase()} SLA (${PRIORITY_SLA_DAYS[request.priority]} Days)`}
                    </button>
                  </div>
                  <input
                    type="date"
                    value={committedDeadlineInput}
                    onChange={(e) => setCommittedDeadlineInput(e.target.value)}
                    className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg font-mono"
                  />
                  <span className="text-[10px] text-slate-400 mt-1 block">
                    {isIndonesian
                      ? `Standar SLA ${request.priority.toUpperCase()}: ${PRIORITY_SLA_DAYS[request.priority]} hari kerja sejak pengajuan.`
                      : `Standard ${request.priority.toUpperCase()} SLA: ${PRIORITY_SLA_DAYS[request.priority]} business days from submission.`}
                  </span>
                </div>

                {/* Reason */}
                <div>
                  <label className="block font-bold text-slate-800 mb-1">
                    {isIndonesian ? 'Catatan Penugasan / Alasan Jadwal' : 'Assignment Note / Schedule Rationale'}
                  </label>
                  <input
                    type="text"
                    value={assignmentReason}
                    onChange={(e) => setAssignmentReason(e.target.value)}
                    placeholder={
                      isIndonesian
                        ? 'mis., Disesuaikan dengan antrean produksi dan ketersediaan spesialis saat ini'
                        : 'e.g., Aligned with current production queue and specialist availability'
                    }
                    className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg"
                  />
                </div>

                <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200">
                  <button
                    type="button"
                    onClick={() => setIsAssigning(false)}
                    className="px-4 py-2 font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
                  >
                    {isIndonesian ? 'Batal' : 'Cancel'}
                  </button>
                  <button
                    type="submit"
                    disabled={isSubmittingAction}
                    className="px-4 py-2 font-bold text-white bg-blue-600 hover:bg-blue-700 disabled:opacity-60 rounded-lg shadow-2xs"
                  >
                    {isSubmittingAction
                      ? isIndonesian
                        ? 'Menyimpan...'
                        : 'Saving...'
                      : isIndonesian
                        ? 'Simpan Penugasan'
                        : 'Save Assignment'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Change Deadline Modal */}
        {isEditingDeadline && (
          <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
            <div className="bg-white rounded-2xl p-6 max-w-md w-full border border-slate-200 shadow-2xl space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-200">
                <h3 className="text-sm font-bold text-slate-900">
                  {isIndonesian ? 'Perbarui Tenggat Komitmen' : 'Update Committed Deadline'}
                </h3>
                <button onClick={() => setIsEditingDeadline(false)} className="text-slate-400 hover:text-slate-600">
                  <X className="w-4 h-4" />
                </button>
              </div>

              <form onSubmit={handleSaveDeadlineUpdate} className="space-y-3.5 text-xs">
                <div>
                  <label className="block font-bold text-slate-800 mb-1">
                    {isIndonesian ? 'Tenggat Komitmen Baru *' : 'New Committed Deadline *'}
                  </label>
                  <input
                    type="date"
                    value={newDeadline}
                    onChange={(e) => setNewDeadline(e.target.value)}
                    className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg font-mono"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-800 mb-1">
                    {isIndonesian
                      ? 'Alasan Penyesuaian (Wajib untuk Audit) *'
                      : 'Reason for Adjustment (Mandatory for Audit) *'}
                  </label>
                  <textarea
                    rows={3}
                    value={deadlineReason}
                    onChange={(e) => setDeadlineReason(e.target.value)}
                    placeholder={
                      isIndonesian
                        ? 'Jelaskan alasan terperinci untuk menyesuaikan tenggat komitmen...'
                        : 'Explain the detailed reason for adjusting the committed deadline...'
                    }
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg"
                  />
                </div>

                <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200">
                  <button
                    type="button"
                    onClick={() => setIsEditingDeadline(false)}
                    className="px-4 py-2 font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
                  >
                    {isIndonesian ? 'Batal' : 'Cancel'}
                  </button>
                  <button
                    type="submit"
                    disabled={isSubmittingAction}
                    className="px-4 py-2 font-bold text-white bg-blue-600 hover:bg-blue-700 disabled:opacity-60 rounded-lg shadow-2xs"
                  >
                    {isSubmittingAction
                      ? isIndonesian
                        ? 'Menyimpan...'
                        : 'Saving...'
                      : isIndonesian
                        ? 'Simpan Penyesuaian'
                        : 'Save Adjustment'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Reopen Modal */}
        {isReopenModalOpen && (
          <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
            <div className="bg-white rounded-2xl p-6 max-w-md w-full border border-slate-200 shadow-2xl space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-200">
                <h3 className="text-sm font-bold text-slate-900">
                  {isIndonesian ? 'Buka Ulang Permintaan Selesai' : 'Reopen Completed Request'}
                </h3>
                <button onClick={() => setIsReopenModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                  <X className="w-4 h-4" />
                </button>
              </div>

              <form onSubmit={handleSaveReopen} className="space-y-3.5 text-xs">
                <div className="p-3 bg-amber-50 rounded-lg text-amber-900 text-xs">
                  {isIndonesian
                    ? 'Catatan penyelesaian sebelumnya dan riwayat SLA akan tetap tersimpan permanen di log audit.'
                    : 'The previous completion record and SLA history will remain permanently tracked in the audit log.'}
                </div>

                <div>
                  <label className="block font-bold text-slate-800 mb-1">
                    {isIndonesian ? 'Alasan Pembukaan Ulang (Wajib) *' : 'Reopen Rationale (Required) *'}
                  </label>
                  <textarea
                    rows={3}
                    value={reopenReason}
                    onChange={(e) => setReopenReason(e.target.value)}
                    placeholder={
                      isIndonesian
                        ? 'mis., Lingkup kampanye diperluas atau materi copy brand direvisi oleh manajemen korporat...'
                        : 'e.g., Campaign scope expanded or brand copy revised by corporate management...'
                    }
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg"
                  />
                </div>

                <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200">
                  <button
                    type="button"
                    onClick={() => setIsReopenModalOpen(false)}
                    className="px-4 py-2 font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
                  >
                    {isIndonesian ? 'Batal' : 'Cancel'}
                  </button>
                  <button
                    type="submit"
                    disabled={isSubmittingAction}
                    className="px-4 py-2 font-bold text-white bg-amber-600 hover:bg-amber-700 disabled:opacity-60 rounded-lg shadow-2xs"
                  >
                    {isSubmittingAction
                      ? isIndonesian
                        ? 'Menyimpan...'
                        : 'Saving...'
                      : isIndonesian
                        ? 'Konfirmasi Buka Ulang'
                        : 'Confirm Reopen'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Revision Request Modal */}
        {isRevisionModalOpen && (
          <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
            <div className="bg-white rounded-2xl p-6 max-w-md w-full border border-slate-200 shadow-2xl space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-200">
                <h3 className="text-sm font-bold text-slate-900">
                  {isIndonesian ? 'Minta Revisi Hasil Pekerjaan' : 'Request Deliverable Revision'}
                </h3>
                <button onClick={() => setIsRevisionModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                  <X className="w-4 h-4" />
                </button>
              </div>

              <form onSubmit={handleSaveRevisionRequest} className="space-y-3.5 text-xs">
                <div className="p-3 bg-orange-50 rounded-lg text-orange-900 text-xs">
                  {isIndonesian ? (
                    <>
                      Tugas ini akan berpindah ke status <strong>Perlu Revisi</strong>, dan pelaksana akan menerima notifikasi langsung beserta catatan Anda.
                    </>
                  ) : (
                    <>
                      This task will move to <strong>Revision</strong> status, and the assignee will receive an immediate notification with your feedback.
                    </>
                  )}
                </div>

                <div>
                  <label className="block font-bold text-slate-800 mb-1">
                    {isIndonesian
                      ? 'Catatan & Lingkup Revisi Wajib *'
                      : 'Mandatory Revision Feedback & Scope *'}
                  </label>
                  <textarea
                    rows={4}
                    value={revisionNote}
                    onChange={(e) => setRevisionNote(e.target.value)}
                    placeholder={
                      isIndonesian
                        ? 'Jelaskan aspek spesifik yang perlu diubah (warna, teks copy, dimensi, format, dll.)...'
                        : 'Specify the exact aspects that require modification (colors, copy, dimensions, formats, etc.)...'
                    }
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg leading-relaxed"
                  />
                </div>

                <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200">
                  <button
                    type="button"
                    onClick={() => setIsRevisionModalOpen(false)}
                    className="px-4 py-2 font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
                  >
                    {isIndonesian ? 'Batal' : 'Cancel'}
                  </button>
                  <button
                    type="submit"
                    disabled={isSubmittingAction}
                    className="px-4 py-2 font-bold text-white bg-orange-600 hover:bg-orange-700 disabled:opacity-60 rounded-lg shadow-2xs"
                  >
                    {isSubmittingAction
                      ? isIndonesian
                        ? 'Menyimpan...'
                        : 'Saving...'
                      : isIndonesian
                        ? 'Kirim Permintaan Revisi'
                        : 'Submit Revision Request'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Upload Deliverable Modal */}
        {isUploadModalOpen && (
          <div className="fixed inset-0 z-60 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-150">
            <div className="bg-white rounded-2xl p-5 sm:p-6 max-w-lg w-full border border-slate-200 shadow-2xl space-y-4 max-h-[92vh] flex flex-col overflow-hidden animate-in zoom-in-95 duration-150">
              <div className="flex items-center justify-between pb-3 border-b border-slate-200 shrink-0">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-emerald-50 text-[#065F46] flex items-center justify-center border border-emerald-200 shrink-0">
                    <UploadCloud className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-sm sm:text-base font-bold text-slate-900">
                      {isIndonesian ? 'Upload File Deliverable' : 'Upload Final Deliverable Files'}
                    </h3>
                    <p className="text-[11px] text-slate-500">
                      {isIndonesian
                        ? 'Unggah file hasil pekerjaan resmi (desain, video, dokumen, audio)'
                        : 'Upload finalized work assets (design, video, document, audio)'}
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setIsUploadModalOpen(false);
                    setDeliverableFiles([]);
                    setDeliverableUploadError('');
                  }}
                  className="text-slate-400 hover:text-slate-600 p-1.5 rounded-lg hover:bg-slate-100 transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <form onSubmit={handleAddDeliverable} className="space-y-4 text-xs overflow-y-auto flex-1 pr-1">
                {/* File Upload Zone - Replaces Deliverable URL Link */}
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="block font-bold text-slate-800 text-xs">
                      {isIndonesian
                        ? 'Upload File (PNG, JPG, JPEG, PSD, AI, PDF, DOCX, XLSX, MP4, MOV, MPEG, AVI, WAV, MP3) *'
                        : 'Upload File (PNG, JPG, JPEG, PSD, AI, PDF, DOCX, XLSX, MP4, MOV, MPEG, AVI, WAV, MP3) *'}
                    </label>
                    <span className="text-[10px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                      {isIndonesian ? '14 Format' : '14 Formats'}
                    </span>
                  </div>

                  {/* Format Pills Bar */}
                  <div className="flex flex-wrap gap-1 p-2 bg-slate-50/80 rounded-xl border border-slate-200 mb-2.5">
                    <span className="text-[10px] font-bold text-slate-500 self-center mr-1">
                      {isIndonesian ? 'Format:' : 'Formats:'}
                    </span>
                    {ALLOWED_DELIVERABLE_EXTENSIONS.map((fmt) => (
                      <span
                        key={fmt}
                        className="px-1.5 py-0.5 text-[9px] font-mono font-bold rounded-md bg-white border border-slate-200 text-slate-700 uppercase"
                      >
                        {fmt}
                      </span>
                    ))}
                  </div>

                  {/* Drag and Drop Box */}
                  <div
                    onDragOver={(e) => {
                      e.preventDefault();
                      setIsDraggingFile(true);
                    }}
                    onDragLeave={() => setIsDraggingFile(false)}
                    onDrop={(e) => {
                      e.preventDefault();
                      setIsDraggingFile(false);
                      handleFilesSelected(e.dataTransfer.files);
                    }}
                    className={`relative p-5 rounded-2xl border-2 border-dashed transition-all text-center cursor-pointer ${
                      isDraggingFile
                        ? 'border-emerald-500 bg-emerald-50/60 ring-4 ring-emerald-500/10'
                        : 'border-slate-300 hover:border-[#065F46] bg-slate-50/60 hover:bg-[#F0FDF4]/50'
                    }`}
                  >
                    <input
                      type="file"
                      multiple
                      accept={DELIVERABLE_ACCEPT_ATTR}
                      onChange={(e) => handleFilesSelected(e.target.files)}
                      className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                    />
                    <div className="flex flex-col items-center justify-center gap-1.5 pointer-events-none">
                      <div className="w-10 h-10 rounded-2xl bg-white border border-slate-200 text-[#065F46] flex items-center justify-center shadow-xs">
                        <UploadCloud className="w-5 h-5" />
                      </div>
                      <p className="text-xs font-bold text-slate-800 mt-1">
                        {isIndonesian
                          ? 'Klik untuk memilih file atau seret file ke sini'
                          : 'Click to choose files or drag and drop here'}
                      </p>
                      <p className="text-[11px] text-slate-500 max-w-sm">
                        PNG, JPG, JPEG, PSD, AI, PDF, DOCX, XLSX, MP4, MOV, MPEG, AVI, WAV, MP3
                      </p>
                      <span className="text-[10px] text-slate-400 mt-0.5 font-medium">
                        {isIndonesian ? 'Batas ukuran: Maksimal 100MB per file' : 'File limit: Maximum 100MB per file'}
                      </span>
                    </div>
                  </div>
                </div>

                {deliverableUploadError && (
                  <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 shrink-0 text-rose-500" />
                    <span>{deliverableUploadError}</span>
                  </div>
                )}

                {/* Selected Files Preview List */}
                {deliverableFiles.length > 0 && (
                  <div className="space-y-1.5 pt-1">
                    <div className="flex items-center justify-between text-[11px] font-bold text-slate-700">
                      <span>{isIndonesian ? 'File Siap Diunggah:' : 'Files Ready to Upload:'} ({deliverableFiles.length})</span>
                      <button
                        type="button"
                        onClick={() => setDeliverableFiles([])}
                        className="text-rose-600 hover:text-rose-800 font-semibold text-[10px] cursor-pointer"
                      >
                        {isIndonesian ? 'Hapus Semua' : 'Clear All'}
                      </button>
                    </div>
                    <div className="space-y-1.5 max-h-40 overflow-y-auto pr-0.5">
                      {deliverableFiles.map((file, idx) => (
                        <div
                          key={`${file.name}-${idx}`}
                          className="flex items-center justify-between p-2.5 bg-slate-50 rounded-xl border border-slate-200 text-xs gap-2"
                        >
                          <div className="flex items-center gap-2.5 min-w-0">
                            {getDeliverableFileIcon(file.name)}
                            <div className="min-w-0">
                              <div className="font-semibold text-slate-900 truncate text-xs">{file.name}</div>
                              <div className="text-[10px] text-slate-500 flex items-center gap-1.5 mt-0.5">
                                <span className="font-mono">{formatFileSize(file.size)}</span>
                                <span>·</span>
                                {getDeliverableFormatBadge(file.name)}
                              </div>
                            </div>
                          </div>
                          <button
                            type="button"
                            onClick={() => removeDeliverableFile(idx)}
                            className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 transition-colors shrink-0 cursor-pointer"
                            title={isIndonesian ? 'Hapus file' : 'Remove file'}
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Title / Description Note */}
                <div>
                  <label className="block font-bold text-slate-800 mb-1">
                    {isIndonesian ? 'Judul / Catatan Hasil Pekerjaan (Opsional)' : 'Deliverable Title / Note (Optional)'}
                  </label>
                  <input
                    type="text"
                    value={deliverableTitle}
                    onChange={(e) => setDeliverableTitle(e.target.value)}
                    placeholder={isIndonesian ? "Contoh: Final Ready Print Banner Lyman v2" : "e.g., Final Ready Print Banner Lyman v2"}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#065F46]/20 focus:border-[#065F46] text-xs"
                  />
                </div>

                {/* Optional Cloud Link Mirror */}
                <div className="pt-2 border-t border-slate-100">
                  <label className="block text-[11px] font-medium text-slate-600 mb-1 flex items-center gap-1">
                    <LinkIcon className="w-3 h-3 text-slate-400" />
                    <span>{isIndonesian ? 'Tautan Eksternal Cadangan (Opsional - Google Drive / Figma)' : 'Backup External Link (Optional - Google Drive / Figma)'}</span>
                  </label>
                  <input
                    type="url"
                    value={deliverableUrl}
                    onChange={(e) => setDeliverableUrl(e.target.value)}
                    placeholder={
                      isIndonesian
                        ? 'https://drive.google.com/... atau https://figma.com/...'
                        : 'https://drive.google.com/... or https://figma.com/...'
                    }
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white text-xs font-mono"
                  />
                </div>

                <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200 shrink-0">
                  <button
                    type="button"
                    onClick={() => {
                      setIsUploadModalOpen(false);
                      setDeliverableFiles([]);
                      setDeliverableUploadError('');
                    }}
                    className="px-4 py-2 font-semibold text-slate-700 bg-white border border-slate-300 rounded-xl hover:bg-slate-50 transition-colors cursor-pointer"
                  >
                    {isIndonesian ? 'Batal' : 'Cancel'}
                  </button>
                  <button
                    type="submit"
                    disabled={isUploadingDeliverables}
                    className="px-4 py-2 font-bold text-white bg-[#065F46] hover:bg-[#044e39] disabled:opacity-60 rounded-xl shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
                  >
                    <Upload className="w-3.5 h-3.5" />
                    <span>
                      {isUploadingDeliverables
                        ? isIndonesian
                          ? 'Mengunggah...'
                          : 'Uploading...'
                        : isIndonesian
                        ? 'Simpan Deliverable'
                        : 'Save Deliverable'}
                    </span>
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Put On Hold Modal */}
        {isHoldModalOpen && (
          <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
            <div className="bg-white rounded-2xl p-6 max-w-md w-full border border-slate-200 shadow-2xl space-y-4 animate-in fade-in zoom-in-95 duration-150">
              <div className="flex items-center justify-between pb-3 border-b border-slate-200">
                <div className="flex items-center gap-2">
                  <div className="p-1.5 rounded-lg bg-amber-100 text-amber-700">
                    <PauseCircle className="w-4 h-4" />
                  </div>
                  <h3 className="text-sm font-bold text-slate-900">
                    {isIndonesian ? 'Tunda Permintaan (On Hold)' : 'Put Request On Hold'}
                  </h3>
                </div>
                <button
                  onClick={() => setIsHoldModalOpen(false)}
                  className="text-slate-400 hover:text-slate-600 p-1 rounded-lg"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <form onSubmit={handlePutOnHold} className="space-y-3.5 text-xs">
                <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-amber-900 text-xs leading-relaxed">
                  {isIndonesian
                    ? 'Menunda tugas ini akan menjeda pekerjaan aktif dan membekukan pelacakan keterlambatan SLA hingga dilanjutkan kembali oleh tim atau pemohon.'
                    : 'Putting this task on hold will pause active work and freeze SLA overdue tracking until resumed by the team or requestor.'}
                </div>

                <div>
                  <label className="block font-bold text-slate-800 mb-1">
                    {isIndonesian ? 'Alasan Penundaan Wajib *' : 'Mandatory Reason for Hold *'}
                  </label>
                  <textarea
                    rows={4}
                    required
                    value={holdReason}
                    onChange={(e) => setHoldReason(e.target.value)}
                    placeholder={
                      isIndonesian
                        ? 'Sebutkan alasan (min 5 karakter), mis., Menunggu persetujuan naskah akhir dari tim legal...'
                        : 'State reason (min 5 characters), e.g., Awaiting final copy approval from legal team...'
                    }
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl leading-relaxed focus:bg-white focus:outline-none focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500 text-slate-900"
                  />
                  <p className="text-[11px] text-slate-400 mt-1">
                    {isIndonesian
                      ? 'Alasan ini akan dicatat dalam jejak audit dan dapat dilihat oleh seluruh pemangku kepentingan.'
                      : 'This reason will be logged in the audit trail and visible to all stakeholders.'}
                  </p>
                </div>

                <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200">
                  <button
                    type="button"
                    onClick={() => setIsHoldModalOpen(false)}
                    className="px-4 py-2 font-semibold text-slate-700 bg-white border border-slate-300 rounded-xl hover:bg-slate-50"
                  >
                    {isIndonesian ? 'Batal' : 'Cancel'}
                  </button>
                  <button
                    type="submit"
                    disabled={isSubmittingAction}
                    className="px-4 py-2 font-bold text-white bg-amber-600 hover:bg-amber-700 disabled:opacity-60 rounded-xl shadow-2xs"
                  >
                    {isSubmittingAction
                      ? isIndonesian
                        ? 'Menyimpan...'
                        : 'Saving...'
                      : isIndonesian
                        ? 'Konfirmasi Penundaan'
                        : 'Confirm Put On Hold'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Cancel Request Modal */}
        {isCancelModalOpen && (
          <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
            <div className="bg-white rounded-2xl p-6 max-w-md w-full border border-slate-200 shadow-2xl space-y-4 animate-in fade-in zoom-in-95 duration-150">
              <div className="flex items-center justify-between pb-3 border-b border-slate-200">
                <div className="flex items-center gap-2">
                  <div className="p-1.5 rounded-lg bg-rose-100 text-rose-700">
                    <Ban className="w-4 h-4" />
                  </div>
                  <h3 className="text-sm font-bold text-slate-900">
                    {isIndonesian ? 'Batalkan Permintaan' : 'Cancel Request'}
                  </h3>
                </div>
                <button
                  onClick={() => setIsCancelModalOpen(false)}
                  className="text-slate-400 hover:text-slate-600 p-1 rounded-lg"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <form onSubmit={handleCancelRequest} className="space-y-3.5 text-xs">
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-900 text-xs leading-relaxed">
                  {isIndonesian
                    ? 'Membatalkan permintaan ini akan segera menutup alur kerja. Permintaan tetap tersimpan dalam riwayat namun dikeluarkan dari antrean tugas aktif.'
                    : 'Cancelling this request will immediately close the workflow. The request will be retained in history but excluded from pending task queues.'}
                </div>

                <div>
                  <label className="block font-bold text-slate-800 mb-1">
                    {isIndonesian ? 'Alasan Pembatalan Wajib *' : 'Mandatory Cancellation Reason *'}
                  </label>
                  <textarea
                    rows={4}
                    required
                    value={cancelReason}
                    onChange={(e) => setCancelReason(e.target.value)}
                    placeholder={
                      isIndonesian
                        ? 'Sebutkan alasan (min 5 karakter), mis., Lingkup kampanye dihentikan oleh direktur pemasaran...'
                        : 'State reason (min 5 characters), e.g., Campaign scope discontinued by marketing director...'
                    }
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl leading-relaxed focus:bg-white focus:outline-none focus:ring-2 focus:ring-rose-500/20 focus:border-rose-500 text-slate-900"
                  />
                  <p className="text-[11px] text-slate-400 mt-1">
                    {isIndonesian
                      ? 'Alasan ini akan dicatat dalam jejak audit dan disimpan pada tiket ini.'
                      : 'This reason will be logged in the audit trail and saved with this ticket.'}
                  </p>
                </div>

                <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200">
                  <button
                    type="button"
                    onClick={() => setIsCancelModalOpen(false)}
                    className="px-4 py-2 font-semibold text-slate-700 bg-white border border-slate-300 rounded-xl hover:bg-slate-50"
                  >
                    {isIndonesian ? 'Kembali' : 'Back'}
                  </button>
                  <button
                    type="submit"
                    disabled={isSubmittingAction}
                    className="px-4 py-2 font-bold text-white bg-rose-600 hover:bg-rose-700 disabled:opacity-60 rounded-xl shadow-2xs"
                  >
                    {isSubmittingAction
                      ? isIndonesian
                        ? 'Menyimpan...'
                        : 'Saving...'
                      : isIndonesian
                        ? 'Konfirmasi Pembatalan'
                        : 'Confirm Cancellation'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
