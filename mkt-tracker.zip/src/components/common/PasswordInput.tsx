import React, { useState } from 'react';
import { Eye, EyeOff, ShieldAlert, ShieldCheck, Key } from 'lucide-react';
import { useLanguage } from '../../context/LanguageContext';

interface PasswordInputProps {
  id?: string;
  name?: string;
  label: string;
  value: string;
  onChange: (val: string) => void;
  placeholder?: string;
  required?: boolean;
  disabled?: boolean;
  autoComplete?: string;
  showStrength?: boolean;
  helpText?: string;
  error?: string;
}

export function calculatePasswordStrength(pass: string, isIndonesian = true): {
  score: number; // 0 to 4
  label: string;
  color: string;
  bgColor: string;
  feedback: string;
} {
  if (!pass) {
    return {
      score: 0,
      label: isIndonesian ? 'Lemah' : 'Weak',
      color: 'text-slate-400',
      bgColor: 'bg-slate-200',
      feedback: isIndonesian ? 'Minimal 12 karakter' : 'Minimum 12 characters',
    };
  }

  let score = 0;
  if (pass.length >= 12) score += 1;
  if (pass.length >= 16) score += 1;
  if (/[A-Z]/.test(pass) && /[a-z]/.test(pass)) score += 1;
  if (/[0-9]/.test(pass) && /[^A-Za-z0-9]/.test(pass)) score += 1;

  if (pass.length < 12) {
    return {
      score: 1,
      label: isIndonesian ? 'Lemah' : 'Weak',
      color: 'text-rose-600',
      bgColor: 'bg-rose-500',
      feedback: isIndonesian
        ? 'Terlalu pendek (minimal 12 karakter)'
        : 'Too short (minimum 12 characters)',
    };
  }

  if (score <= 2) {
    return {
      score: 2,
      label: isIndonesian ? 'Cukup' : 'Fair',
      color: 'text-amber-600',
      bgColor: 'bg-amber-500',
      feedback: isIndonesian
        ? 'Cukup, tambahkan simbol/angka agar lebih aman'
        : 'Fair, add symbols/numbers for stronger security',
    };
  }

  if (score === 3) {
    return {
      score: 3,
      label: isIndonesian ? 'Kuat' : 'Good',
      color: 'text-blue-600',
      bgColor: 'bg-blue-500',
      feedback: isIndonesian
        ? 'Kuat dan memenuhi standar keamanan Lyman Group'
        : 'Strong and meets Lyman Group security standards',
    };
  }

  return {
    score: 4,
    label: isIndonesian ? 'Sangat Kuat' : 'Strong',
    color: 'text-emerald-600',
    bgColor: 'bg-emerald-600',
    feedback: isIndonesian
      ? 'Sangat kuat (Standar keamanan enterprise)'
      : 'Very strong (Enterprise security grade)',
  };
}

export function generateStrongPassword(): string {
  const words = ['Lyman', 'Devindo', 'Marcomm', 'Creative', 'Sanctuary', 'Domain', 'Wisma46', 'Horizon', 'Summit'];
  const symbols = ['#', '!', '$', '%', '&', '@'];
  const randomWord1 = words[Math.floor(Math.random() * words.length)];
  const randomWord2 = words[Math.floor(Math.random() * words.length)];
  const randomNum = Math.floor(100 + Math.random() * 900);
  const randomSym = symbols[Math.floor(Math.random() * symbols.length)];
  return `${randomWord1}${randomSym}${randomWord2}${randomNum}!`;
}

export const PasswordInput: React.FC<PasswordInputProps> = ({
  id,
  name,
  label,
  value,
  onChange,
  placeholder = '••••••••••••',
  required = false,
  disabled = false,
  autoComplete = 'current-password',
  showStrength = false,
  helpText,
  error,
}) => {
  const { isIndonesian } = useLanguage();
  const [showPassword, setShowPassword] = useState(false);
  const strength = showStrength ? calculatePasswordStrength(value, isIndonesian) : null;

  return (
    <div className="space-y-1.5 text-left">
      <div className="flex items-center justify-between">
        <label htmlFor={id} className="block text-xs font-semibold text-slate-700">
          {label} {required && <span className="text-rose-500">*</span>}
        </label>
        {strength && value.length > 0 && (
          <span className={`text-[11px] font-bold ${strength.color}`}>
            {strength.label}
          </span>
        )}
      </div>

      <div className="relative">
        <input
          id={id}
          name={name}
          type={showPassword ? 'text' : 'password'}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder}
          required={required}
          disabled={disabled}
          autoComplete={autoComplete}
          className={`w-full px-3.5 py-2.5 pr-11 text-xs rounded-xl border bg-white text-slate-900 transition-colors focus:outline-none focus:ring-2 focus:ring-[#065F46]/20 focus:border-[#065F46] ${
            error
              ? 'border-rose-400 focus:border-rose-500 focus:ring-rose-500/20'
              : 'border-slate-300'
          } ${disabled ? 'bg-slate-100 cursor-not-allowed text-slate-400' : ''}`}
        />
        <button
          type="button"
          onClick={() => setShowPassword(!showPassword)}
          tabIndex={-1}
          aria-label={
            showPassword
              ? isIndonesian
                ? 'Sembunyikan password'
                : 'Hide password'
              : isIndonesian
              ? 'Tampilkan password'
              : 'Show password'
          }
          className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 transition-colors p-1"
        >
          {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
        </button>
      </div>

      {showStrength && value.length > 0 && strength && (
        <div className="space-y-1 pt-1">
          <div className="flex items-center gap-1.5 h-1.5 w-full">
            {[1, 2, 3, 4].map((step) => (
              <div
                key={step}
                className={`h-full flex-1 rounded-full transition-all duration-300 ${
                  strength.score >= step ? strength.bgColor : 'bg-slate-200'
                }`}
              />
            ))}
          </div>
          <p className="text-[10px] text-slate-500 flex items-center gap-1">
            {strength.score >= 3 ? (
              <ShieldCheck className="w-3 h-3 text-emerald-600 shrink-0" />
            ) : (
              <ShieldAlert className="w-3 h-3 text-amber-500 shrink-0" />
            )}
            <span>{strength.feedback}</span>
          </p>
        </div>
      )}

      {error ? (
        <p className="text-[11px] text-rose-600 font-medium">{error}</p>
      ) : helpText ? (
        <p className="text-[11px] text-slate-500">{helpText}</p>
      ) : null}
    </div>
  );
};
