import React from 'react';
import { Languages, Check } from 'lucide-react';
import { useLanguage } from '../../context/LanguageContext';

interface LanguageSwitcherProps {
  variant?: 'compact' | 'segmented' | 'full';
}

export const LanguageSwitcher: React.FC<LanguageSwitcherProps> = ({ variant = 'compact' }) => {
  const { language, setLanguage, toggleLanguage, isIndonesian } = useLanguage();

  if (variant === 'segmented') {
    return (
      <div className="inline-flex items-center p-0.5 rounded-xl bg-slate-100 border border-slate-200 text-xs font-semibold">
        <button
          type="button"
          onClick={() => setLanguage('id')}
          className={`px-2.5 py-1 rounded-lg transition-all flex items-center gap-1.5 ${
            isIndonesian
              ? 'bg-white text-[#065F46] font-bold shadow-2xs border border-emerald-200/60'
              : 'text-slate-500 hover:text-slate-900'
          }`}
          title="Ganti ke Bahasa Indonesia"
        >
          <span>🇮🇩</span>
          <span>Bahasa</span>
        </button>
        <button
          type="button"
          onClick={() => setLanguage('en')}
          className={`px-2.5 py-1 rounded-lg transition-all flex items-center gap-1.5 ${
            !isIndonesian
              ? 'bg-white text-[#065F46] font-bold shadow-2xs border border-emerald-200/60'
              : 'text-slate-500 hover:text-slate-900'
          }`}
          title="Switch to English"
        >
          <span>🇬🇧</span>
          <span>English</span>
        </button>
      </div>
    );
  }

  return (
    <button
      type="button"
      onClick={toggleLanguage}
      className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold rounded-xl bg-slate-50 hover:bg-slate-100 border border-slate-200 text-slate-700 hover:text-slate-900 transition-colors shadow-2xs group"
      title={isIndonesian ? 'Ganti ke Bahasa Inggris (Switch to English)' : 'Switch to Bahasa Indonesia'}
    >
      <Languages className="w-3.5 h-3.5 text-[#065F46]" />
      <span className="font-bold">
        {isIndonesian ? '🇮🇩 ID' : '🇬🇧 EN'}
      </span>
      <span className="text-[10px] text-slate-400 group-hover:text-slate-600 hidden md:inline">
        {isIndonesian ? 'Bahasa' : 'English'}
      </span>
    </button>
  );
};
