import React from 'react';
import { RequestStatus, RequestPriority } from '../../types';
import { useLanguage } from '../../context/LanguageContext';

export const STATUS_LABELS: Record<RequestStatus, string> = {
  todo: 'To Do / Backlog',
  in_progress: 'In Progress',
  pending_review: 'Pending Review / Approval',
  revision: 'Revision',
  completed: 'Completed',
  on_hold: 'On Hold',
  cancelled: 'Cancelled',
};

export const STATUS_LABELS_ID: Record<RequestStatus, string> = {
  todo: 'Antrean (To Do)',
  in_progress: 'Sedang Dikerjakan',
  pending_review: 'Menunggu Review',
  revision: 'Perlu Revisi',
  completed: 'Selesai Disetujui',
  on_hold: 'Ditunda (On Hold)',
  cancelled: 'Dibatalkan',
};

export const STATUS_STYLES: Record<RequestStatus, { bg: string; text: string; dot: string; border: string }> = {
  todo: {
    bg: 'bg-slate-100',
    text: 'text-slate-700',
    dot: 'bg-slate-400',
    border: 'border-slate-200',
  },
  in_progress: {
    bg: 'bg-blue-50',
    text: 'text-blue-700',
    dot: 'bg-blue-500',
    border: 'border-blue-200',
  },
  pending_review: {
    bg: 'bg-purple-50',
    text: 'text-purple-700',
    dot: 'bg-purple-500',
    border: 'border-purple-200',
  },
  revision: {
    bg: 'bg-amber-50',
    text: 'text-amber-800',
    dot: 'bg-amber-500',
    border: 'border-amber-200',
  },
  completed: {
    bg: 'bg-emerald-50',
    text: 'text-emerald-800',
    dot: 'bg-[#10B981]',
    border: 'border-emerald-200',
  },
  on_hold: {
    bg: 'bg-amber-50/90',
    text: 'text-amber-900',
    dot: 'bg-amber-500',
    border: 'border-amber-300',
  },
  cancelled: {
    bg: 'bg-rose-50',
    text: 'text-rose-700',
    dot: 'bg-rose-500',
    border: 'border-rose-200',
  },
};

export const StatusBadge: React.FC<{
  status: RequestStatus;
  size?: 'sm' | 'md';
  compact?: boolean;
}> = ({ status, size = 'md', compact = false }) => {
  const { isIndonesian } = useLanguage();
  const style = STATUS_STYLES[status] || STATUS_STYLES.todo;
  const labelsMap = isIndonesian ? STATUS_LABELS_ID : STATUS_LABELS;
  const rawLabel = labelsMap[status] || status;

  // Compact label for tight columns / kanban
  const label = compact
    ? status === 'pending_review'
      ? (isIndonesian ? 'Review' : 'In Review')
      : status === 'in_progress'
      ? (isIndonesian ? 'Dikerjakan' : 'In Progress')
      : status === 'todo'
      ? (isIndonesian ? 'Antrean' : 'To Do')
      : status === 'on_hold'
      ? (isIndonesian ? 'Ditunda' : 'On Hold')
      : status === 'cancelled'
      ? (isIndonesian ? 'Batal' : 'Cancelled')
      : (isIndonesian ? 'Selesai' : rawLabel)
    : rawLabel;

  return (
    <span
      className={`inline-flex items-center gap-1.5 font-semibold rounded-lg border whitespace-nowrap select-none transition-colors ${
        style.bg
      } ${style.text} ${style.border} ${
        size === 'sm' ? 'px-2 py-0.5 text-[11px]' : 'px-2.5 py-1 text-xs'
      }`}
    >
      <span className={`w-1.5 h-1.5 rounded-full shrink-0 ${style.dot}`} aria-hidden="true" />
      <span className="leading-none">{label}</span>
    </span>
  );
};

export const PRIORITY_LABELS: Record<RequestPriority, string> = {
  urgent: 'Urgent (1 Day)',
  high: 'High (3 Days)',
  medium: 'Medium (7 Days)',
  low: 'Low (14 Days)',
};

export const PRIORITY_LABELS_ID: Record<RequestPriority, string> = {
  urgent: 'Mendesak (1 Hari)',
  high: 'Tinggi (3 Hari)',
  medium: 'Sedang (7 Hari)',
  low: 'Rendah (14 Hari)',
};

export const PriorityBadge: React.FC<{
  priority: RequestPriority;
  showSla?: boolean;
  compact?: boolean;
}> = ({ priority, showSla = true, compact = false }) => {
  const { isIndonesian } = useLanguage();
  const configs: Record<
    RequestPriority,
    { bg: string; text: string; border: string; dot: string; short: string; shortId: string }
  > = {
    urgent: {
      bg: 'bg-rose-50/90',
      text: 'text-rose-700',
      border: 'border-rose-200/90',
      dot: 'bg-rose-500',
      short: 'Urgent · 1d',
      shortId: 'Mendesak · 1h',
    },
    high: {
      bg: 'bg-amber-50/90',
      text: 'text-amber-800',
      border: 'border-amber-200/90',
      dot: 'bg-amber-500',
      short: 'High · 3d',
      shortId: 'Tinggi · 3h',
    },
    medium: {
      bg: 'bg-sky-50/90',
      text: 'text-sky-700',
      border: 'border-sky-200/90',
      dot: 'bg-sky-500',
      short: 'Med · 7d',
      shortId: 'Sedang · 7h',
    },
    low: {
      bg: 'bg-slate-50/90',
      text: 'text-slate-600',
      border: 'border-slate-200/90',
      dot: 'bg-slate-400',
      short: 'Low · 14d',
      shortId: 'Rendah · 14h',
    },
  };

  const c = configs[priority] || configs.medium;
  const labelsMap = isIndonesian ? PRIORITY_LABELS_ID : PRIORITY_LABELS;
  const label = compact
    ? (isIndonesian ? c.shortId : c.short)
    : showSla
    ? labelsMap[priority]
    : isIndonesian
    ? (priority === 'urgent' ? 'Mendesak' : priority === 'high' ? 'Tinggi' : priority === 'medium' ? 'Sedang' : 'Rendah')
    : priority.charAt(0).toUpperCase() + priority.slice(1);

  return (
    <span
      className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-md text-[11px] font-semibold border whitespace-nowrap select-none transition-colors ${c.bg} ${c.text} ${c.border}`}
    >
      <span className={`w-1.5 h-1.5 rounded-full shrink-0 ${c.dot}`} aria-hidden="true" />
      <span className="leading-none">{label}</span>
    </span>
  );
};

export const OverdueBadge: React.FC<{
  isOverdue?: boolean;
  status: RequestStatus;
  committedDeadline?: string;
  slaFulfilled?: boolean;
}> = ({ isOverdue = false, status, committedDeadline, slaFulfilled }) => {
  const { isIndonesian } = useLanguage();

  if (status === 'completed') {
    if (slaFulfilled === false) {
      return (
        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-semibold bg-rose-50 text-rose-700 border border-rose-200 whitespace-nowrap">
          <span className="w-1.5 h-1.5 rounded-full bg-rose-500 shrink-0" />
          <span>{isIndonesian ? 'Selesai Terlambat' : 'Completed Late'}</span>
        </span>
      );
    }
    return (
      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200 whitespace-nowrap">
        <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 shrink-0" />
        <span>{isIndonesian ? 'Tepat Waktu' : 'On-Time'}</span>
      </span>
    );
  }

  if (status === 'cancelled') {
    return (
      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-medium bg-slate-100 text-slate-500 border border-slate-200 whitespace-nowrap">
        <span className="w-1.5 h-1.5 rounded-full bg-slate-400 shrink-0" />
        <span>{isIndonesian ? 'Dibatalkan' : 'Cancelled'}</span>
      </span>
    );
  }

  if (status === 'on_hold') {
    return (
      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-semibold bg-amber-50 text-amber-800 border border-amber-200 whitespace-nowrap">
        <span className="w-1.5 h-1.5 rounded-full bg-amber-500 shrink-0" />
        <span>{isIndonesian ? 'Ditunda' : 'On Hold'}</span>
      </span>
    );
  }

  if (!committedDeadline) {
    return (
      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-medium bg-slate-100 text-slate-600 border border-slate-200 whitespace-nowrap">
        <span className="w-1.5 h-1.5 rounded-full bg-slate-400 shrink-0" />
        <span>{isIndonesian ? 'Belum Dijadwalkan' : 'Unscheduled'}</span>
      </span>
    );
  }

  if (isOverdue) {
    return (
      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-bold bg-rose-100/90 text-rose-800 border border-rose-300 whitespace-nowrap shadow-2xs">
        <span className="w-1.5 h-1.5 rounded-full bg-rose-600 shrink-0 animate-ping" />
        <span>{isIndonesian ? 'Terlambat' : 'Overdue'}</span>
      </span>
    );
  }

  return (
    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200 whitespace-nowrap">
      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 shrink-0" />
      <span>{isIndonesian ? 'Sesuai Jadwal' : 'On-Track'}</span>
    </span>
  );
};
