import React, { useState } from 'react';
import {
  Briefcase,
  Users,
  CheckCircle2,
  Clock,
  AlertTriangle,
  Layers,
  Sparkles,
  RefreshCw,
  ArrowRight,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useRequests } from '../../context/RequestContext';
import { useLanguage } from '../../context/LanguageContext';
import { AiService, WorkloadOptimizerResult } from '../../services/aiService';

interface WorkloadViewProps {
  onSelectRequest: (requestId: string) => void;
}

export const WorkloadView: React.FC<WorkloadViewProps> = ({ onSelectRequest }) => {
  const { allUsers } = useAuth();
  const { requests, teams } = useRequests();
  const { isIndonesian } = useLanguage();

  // Active requests (not completed)
  const activeRequests = requests.filter((r) => r.status !== 'completed');

  // Filter team members only
  const teamMembers = allUsers.filter(
    (u) => u.role === 'team_member' || u.role === 'admin' || u.role === 'super_admin'
  );

  // Compute workloads per user: Primary vs Collaborator
  const memberWorkload = teamMembers.map((member) => {
    const primaryActive = activeRequests.filter((r) => r.primaryAssigneeId === member.id);
    const collaboratorActive = activeRequests.filter(
      (r) =>
        r.primaryAssigneeId !== member.id &&
        r.collaboratorIds &&
        r.collaboratorIds.includes(member.id)
    );
    const overdueCount = primaryActive.filter((r) => r.isOverdue).length;

    return {
      user: member,
      primaryCount: primaryActive.length,
      primaryRequests: primaryActive,
      collaboratorCount: collaboratorActive.length,
      collaboratorRequests: collaboratorActive,
      overdueCount,
    };
  });

  const maxPrimaryCount = Math.max(...memberWorkload.map((m) => m.primaryCount), 1);

  const [aiOpt, setAiOpt] = useState<WorkloadOptimizerResult | null>(null);
  const [isOptimizing, setIsOptimizing] = useState(false);

  const handleRunOptimizer = async () => {
    setIsOptimizing(true);
    try {
      const res = await AiService.optimizeWorkload({
        teamStats: {
          totalRequests: requests.length,
          activeRequests: activeRequests.length,
          overdue: activeRequests.filter((r) => r.isOverdue).length,
        },
      });
      setAiOpt(res);
    } catch (err) {
      console.error(err);
    } finally {
      setIsOptimizing(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="p-6 bg-white rounded-2xl border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-slate-900">
            {isIndonesian ? 'Beban Kerja Tim & Distribusi Kapasitas' : 'Team Workload & Capacity Distribution'}
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            {isIndonesian
              ? 'Permintaan aktif dalam produksi (Antrean, Sedang Dikerjakan, Review, Revisi) dihitung berdasarkan Pelaksana Utama. Peran kolaborator dilacak terpisah untuk menghindari penghitungan ganda.'
              : 'Active requests in production (Backlog, In Progress, Review, Revision) are calculated by Primary Assignee. Collaborator roles are tracked separately to avoid double-counting.'}
          </p>
        </div>
        <button
          type="button"
          onClick={handleRunOptimizer}
          disabled={isOptimizing}
          className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-[#065F46] hover:bg-[#044e39] text-white text-xs font-bold transition-all shrink-0 shadow-xs active:scale-[0.98]"
        >
          {isOptimizing ? <RefreshCw className="w-3.5 h-3.5 animate-spin text-[#A7F3D0]" /> : <Sparkles className="w-3.5 h-3.5 text-[#A7F3D0]" />}
          <span>
            {aiOpt
              ? (isIndonesian ? 'Jalankan Ulang Pengoptimal' : 'Re-run Optimizer')
              : (isIndonesian ? 'Pengoptimal Beban Kerja AI' : 'AI Workload Optimizer')}
          </span>
        </button>
      </div>

      {/* AI Rebalancing Recommendation Banner */}
      {aiOpt && (
        <div className="p-4 bg-amber-50/80 rounded-2xl border border-amber-200 text-xs space-y-3">
          <div className="flex items-center justify-between">
            <span className="font-bold text-amber-950 uppercase tracking-wider">
              {isIndonesian ? 'Hasil Diagnostik Beban Kerja AI:' : 'AI Workload Diagnostic Result:'} {aiOpt.capacityHealth}
            </span>
          </div>
          {aiOpt.rebalancingRecommendations.length > 0 && (
            <div className="space-y-1.5">
              <span className="text-[11px] font-semibold text-amber-900 block">
                {isIndonesian ? 'Rekomendasi Penyeimbangan Beban Kerja:' : 'Workload Rebalancing Recommendations:'}
              </span>
              {aiOpt.rebalancingRecommendations.map((rec, idx) => (
                <div key={idx} className="flex items-center gap-2 bg-white p-2.5 rounded-lg border border-amber-200 text-slate-800">
                  <span className="font-bold text-rose-700">{rec.from}</span>
                  <ArrowRight className="w-3 h-3 text-slate-400" />
                  <span className="font-bold text-emerald-700">{rec.to}</span>
                  <span className="text-slate-500 ml-2">({rec.suggestion})</span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Team Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {teams.map((team) => {
          const teamActive = activeRequests.filter((r) => r.assignedTeamId === team.id);
          const overdue = teamActive.filter((r) => r.isOverdue).length;

          return (
            <div
              key={team.id}
              className="p-4 bg-white rounded-2xl border border-slate-200 shadow-2xs space-y-2"
            >
              <div className="flex items-center justify-between">
                <span
                  className="w-2.5 h-2.5 rounded-full"
                  style={{ backgroundColor: team.color }}
                />
                <span className="text-[11px] font-mono text-slate-400">
                  {teamActive.length} {isIndonesian ? 'aktif' : 'active'}
                </span>
              </div>
              <h3 className="text-xs font-bold text-slate-900 leading-snug">{team.name}</h3>
              <p className="text-[11px] text-slate-500 line-clamp-2 leading-relaxed">
                {team.description}
              </p>
              {overdue > 0 && (
                <div className="pt-2 text-[11px] text-rose-600 font-semibold flex items-center gap-1">
                  <AlertTriangle className="w-3 h-3" />
                  <span>{overdue} {isIndonesian ? 'Tugas Terlambat' : 'Overdue Tasks'}</span>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Member Workload Detail Table & Bars */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-6 space-y-6">
        <div>
          <h3 className="text-sm font-bold text-slate-900">
            {isIndonesian ? 'Beban Kerja per Anggota Tim' : 'Workload by Team Member'}
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            {isIndonesian
              ? 'Alokasi tugas untuk setiap anggota tim spesialis (Desain Grafis, Media Sosial & Produksi, Pemasaran Digital, Dukungan TI).'
              : 'Task allocation across specialist team members (Graphic Design, Social Media & Production, Digital Marketing, IT Support).'}
          </p>
        </div>

        {activeRequests.length === 0 && (
          <div className="p-3.5 bg-emerald-50/70 border border-emerald-200/80 rounded-xl text-xs text-[#065F46] flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-500" />
              <span>
                {isIndonesian
                  ? 'Alur produksi saat ini bersih. Tidak ada tugas aktif dalam antrean.'
                  : 'Production Pipeline is currently clear. Zero active tasks in queue.'}
              </span>
            </div>
            <span className="font-semibold text-[11px] text-emerald-800 hidden sm:inline">
              {isIndonesian ? 'Semua Spesialis Tersedia' : 'All Specialists Available'}
            </span>
          </div>
        )}

        <div className="space-y-4">
          {memberWorkload.map(({ user, primaryCount, primaryRequests, collaboratorCount, overdueCount }) => {
            const barWidth = Math.round((primaryCount / maxPrimaryCount) * 100);

            return (
              <div
                key={user.id}
                className="p-4 bg-slate-50/70 rounded-xl border border-slate-200 space-y-3"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div className="flex items-center gap-3">
                    <img
                      src={
                        user.avatarUrl ||
                        'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80'
                      }
                      alt={user.fullName}
                      className="w-10 h-10 rounded-full object-cover border border-slate-200"
                    />
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <strong className="text-xs font-bold text-slate-900">
                          {user.fullName}
                        </strong>
                        <span className="text-[10px] px-2 py-0.2 rounded bg-slate-200 text-slate-700 font-medium">
                          {user.jobTitle}
                        </span>
                        {user.isReviewer && (
                          <span className="text-[10px] px-1.5 py-0.2 rounded bg-amber-100 text-amber-800 font-semibold border border-amber-300">
                            Reviewer
                          </span>
                        )}
                      </div>
                      <div className="flex items-center gap-1.5 mt-1 text-[11px] text-slate-500 flex-wrap">
                        {user.competencies?.map((comp) => (
                          <span key={comp} className="text-blue-700 bg-blue-50 px-1.5 py-0.2 rounded font-medium">
                            {comp}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Counters */}
                  <div className="flex items-center gap-4 text-xs font-mono tabular-nums self-end sm:self-auto">
                    <div>
                      <span className="text-[11px] text-slate-400 block">
                        {isIndonesian ? 'Pelaksana Utama:' : 'Primary Assignee:'}
                      </span>
                      <strong className="text-sm font-extrabold text-blue-700">
                        {primaryCount} {isIndonesian ? 'Tugas' : primaryCount === 1 ? 'Task' : 'Tasks'}
                      </strong>
                    </div>
                    <div>
                      <span className="text-[11px] text-slate-400 block">
                        {isIndonesian ? 'Kolaborator:' : 'Collaborator:'}
                      </span>
                      <span className="text-sm font-bold text-slate-600">
                        {collaboratorCount} {isIndonesian ? 'Tugas' : collaboratorCount === 1 ? 'Task' : 'Tasks'}
                      </span>
                    </div>
                    {overdueCount > 0 && (
                      <div className="text-rose-600">
                        <span className="text-[11px] text-rose-500 block">
                          {isIndonesian ? 'Terlambat:' : 'Overdue:'}
                        </span>
                        <strong className="text-sm font-extrabold">
                          {overdueCount}
                        </strong>
                      </div>
                    )}
                  </div>
                </div>

                {/* Progress bar */}
                <div>
                  <div className="w-full h-2 rounded-full bg-slate-200 overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all duration-300 ${
                        overdueCount > 0 ? 'bg-rose-500' : 'bg-blue-600'
                      }`}
                      style={{ width: `${barWidth}%` }}
                    />
                  </div>
                </div>

                {/* Active Task Chips */}
                {primaryRequests.length > 0 && (
                  <div className="pt-2 border-t border-slate-200/60">
                    <span className="text-[11px] font-semibold text-slate-500 block mb-1.5">
                      {isIndonesian ? 'Penugasan Utama Aktif:' : 'Active Primary Assignments:'}
                    </span>
                    <div className="flex items-center gap-2 flex-wrap">
                      {primaryRequests.map((req) => (
                        <button
                          key={req.id}
                          onClick={() => onSelectRequest(req.id)}
                          className="px-2.5 py-1 bg-white hover:bg-blue-50 hover:border-blue-300 border border-slate-200 rounded-lg text-left text-xs transition-colors flex items-center gap-2 group shadow-2xs"
                        >
                          <span className="font-mono text-[10px] font-bold text-slate-700 group-hover:text-blue-600">
                            {req.ticketNumber}
                          </span>
                          <span className="truncate max-w-[160px] text-slate-800">
                            {req.title}
                          </span>
                          {req.isOverdue && (
                            <span className="w-1.5 h-1.5 rounded-full bg-rose-500 shrink-0" />
                          )}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
