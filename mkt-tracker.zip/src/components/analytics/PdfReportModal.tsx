import React from 'react';
import { X, Printer, Download, CheckCircle2, FileText, Calendar, User } from 'lucide-react';
import { useRequests } from '../../context/RequestContext';
import { useAuth } from '../../context/AuthContext';
import { useLanguage } from '../../context/LanguageContext';
import { STATUS_LABELS, STATUS_LABELS_ID, PRIORITY_LABELS, PRIORITY_LABELS_ID } from '../common/StatusBadge';

interface PdfReportModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PdfReportModal: React.FC<PdfReportModalProps> = ({ isOpen, onClose }) => {
  const { filteredRequests, analytics, filters } = useRequests();
  const { currentUser, allUsers } = useAuth();
  const { isIndonesian } = useLanguage();

  if (!isOpen) return null;

  const handlePrint = () => {
    window.print();
  };

  // Format current timestamp in Asia/Jakarta (WIB)
  const printTimestamp = new Intl.DateTimeFormat(isIndonesian ? 'id-ID' : 'en-GB', {
    dateStyle: 'full',
    timeStyle: 'medium',
    timeZone: 'Asia/Jakarta',
  }).format(new Date());

  const activeAssigneeName =
    filters.assigneeId === 'all'
      ? (isIndonesian ? 'Semua Pelaksana Utama' : 'All Primary Assignees')
      : allUsers.find((u) => u.id === filters.assigneeId)?.fullName || filters.assigneeId;

  const activeRequestorName =
    !filters.requesterId || filters.requesterId === 'all'
      ? (isIndonesian ? 'Semua Pemohon' : 'All Requestors')
      : allUsers.find((u) => u.id === filters.requesterId)?.fullName || filters.requesterId;

  const statusLabels = isIndonesian ? STATUS_LABELS_ID : STATUS_LABELS;
  const priorityLabels = isIndonesian ? PRIORITY_LABELS_ID : PRIORITY_LABELS;

  const formatPeriodLabel = (range: string) => {
    if (!isIndonesian) {
      if (range === 'all') return 'All Time';
      if (range === '7d') return 'Last 7 Days';
      if (range === '30d') return 'Last 30 Days';
      if (range === '90d') return 'Last 90 Days';
      return range;
    }
    if (range === 'all') return 'Semua Waktu';
    if (range === '7d') return '7 Hari Terakhir';
    if (range === '30d') return '30 Hari Terakhir';
    if (range === '90d') return '90 Hari Terakhir';
    return range;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-4xl w-full max-h-[92vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Modal Controls (No print) */}
        <div className="p-3.5 sm:p-4 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-50 no-print">
          <div>
            <h3 className="text-sm font-bold text-slate-900">
              {isIndonesian
                ? 'Pratinjau Laporan Kinerja Komunikasi Pemasaran'
                : 'Marketing Communications Performance Report Preview'}
            </h3>
            <p className="text-xs text-slate-500">
              {isIndonesian
                ? 'Siap dicetak atau diekspor sebagai PDF menggunakan dialog cetak browser Anda.'
                : 'Ready to print or export as PDF using your browser print dialog.'}
            </p>
          </div>
          <div className="flex items-center gap-2 self-end sm:self-auto shrink-0">
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-3.5 sm:px-4 py-2 text-xs font-bold text-white bg-[#065F46] hover:bg-[#044e39] rounded-xl transition-colors shadow-xs active:scale-[0.98]"
            >
              <Printer className="w-4 h-4 shrink-0" />
              <span>{isIndonesian ? 'Cetak / Simpan PDF' : 'Print / Save as PDF'}</span>
            </button>
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-200/60 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Document Sheet */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-8 bg-white text-slate-900 space-y-6 print:p-0">
          {/* Document Header */}
          <div className="border-b-2 border-slate-900 pb-4 sm:pb-5 flex flex-col sm:flex-row items-start justify-between gap-3">
            <div>
              <span className="text-xs font-mono tracking-widest text-blue-700 uppercase font-bold block mb-1">
                {isIndonesian
                  ? 'Lyman Group · Komunikasi Pemasaran'
                  : 'Lyman Group · Marketing Communications'}
              </span>
              <h1 className="text-lg sm:text-xl font-extrabold text-slate-900">
                {isIndonesian
                  ? 'LAPORAN EKSEKUTIF KINERJA & PELACAKAN TUGAS'
                  : 'EXECUTIVE PERFORMANCE & TASK TRACKING REPORT'}
              </h1>
              <p className="text-xs text-slate-500 mt-1">
                {isIndonesian
                  ? 'Wilayah Jakarta & Bandung · Divisi Marketing Communications'
                  : 'Jakarta & Bandung Regions · Marketing Communications Division'}
              </p>
            </div>
            <div className="text-left sm:text-right text-xs space-y-0.5 shrink-0">
              <div className="font-mono text-slate-500 text-[11px]">
                {isIndonesian ? 'Dibuat Pada:' : 'Generated On:'}
              </div>
              <div className="font-semibold text-slate-800">{printTimestamp} (WIB)</div>
              <div className="text-slate-500 text-[11px]">
                {isIndonesian ? 'Disiapkan Oleh:' : 'Prepared By:'} {currentUser.fullName}
              </div>
              <div className="text-slate-500 text-[10px]">
                {isIndonesian ? 'Jabatan:' : 'Position:'} {currentUser.jobTitle}
              </div>
            </div>
          </div>

          {/* Filter Scope Information */}
          <div className="grid grid-cols-2 sm:grid-cols-6 gap-2.5 sm:gap-3 p-3 sm:p-3.5 bg-slate-50 rounded-xl border border-slate-200 text-xs">
            <div>
              <span className="text-slate-400 block text-[10px]">
                {isIndonesian ? 'Cakupan Status:' : 'Status Scope:'}
              </span>
              <strong className="text-slate-800 truncate block">
                {filters.status === 'all'
                  ? (isIndonesian ? 'Semua Status' : 'All Statuses')
                  : statusLabels[filters.status]}
              </strong>
            </div>
            <div>
              <span className="text-slate-400 block text-[10px]">
                {isIndonesian ? 'Cakupan Wilayah:' : 'Region Scope:'}
              </span>
              <strong className="text-slate-800 truncate block">
                {filters.regionId === 'all' ? 'Jakarta & Bandung' : filters.regionId}
              </strong>
            </div>
            <div>
              <span className="text-slate-400 block text-[10px]">
                {isIndonesian ? 'Cakupan Pemohon:' : 'Requestor Scope:'}
              </span>
              <strong className="text-slate-800 truncate block">
                {activeRequestorName}
              </strong>
            </div>
            <div>
              <span className="text-slate-400 block text-[10px]">
                {isIndonesian ? 'Pelaksana Utama:' : 'Primary Assignee:'}
              </span>
              <strong className="text-slate-800 truncate block">
                {activeAssigneeName}
              </strong>
            </div>
            <div>
              <span className="text-slate-400 block text-[10px]">
                {isIndonesian ? 'Prioritas:' : 'Priority:'}
              </span>
              <strong className="text-slate-800 truncate block">
                {filters.priority === 'all'
                  ? (isIndonesian ? 'Semua Prioritas' : 'All Priorities')
                  : priorityLabels[filters.priority]}
              </strong>
            </div>
            <div>
              <span className="text-slate-400 block text-[10px]">
                {isIndonesian ? 'Periode:' : 'Period:'}
              </span>
              <strong className="text-slate-800 truncate block">
                {formatPeriodLabel(filters.dateRange)}
              </strong>
            </div>
          </div>

          {/* Key Executive Metrics Summary */}
          <div>
            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-2.5">
              {isIndonesian ? 'Ringkasan KPI & SLA Eksekutif' : 'Executive KPI & SLA Summary'}
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 sm:gap-3 text-center">
              <div className="p-2.5 sm:p-3 bg-slate-50 rounded-xl border border-slate-200">
                <span className="text-[10px] sm:text-[11px] text-slate-500 block">
                  {isIndonesian ? 'Total Permintaan' : 'Total Requests'}
                </span>
                <span className="text-lg sm:text-xl font-bold font-mono tabular-nums text-slate-900">
                  {analytics.totalRequests}
                </span>
              </div>
              <div className="p-2.5 sm:p-3 bg-slate-50 rounded-xl border border-slate-200">
                <span className="text-[10px] sm:text-[11px] text-slate-500 block">
                  {isIndonesian ? 'Item Kerja Selesai' : 'Completed Work Items'}
                </span>
                <span className="text-lg sm:text-xl font-bold font-mono tabular-nums text-emerald-700">
                  {analytics.completedWorkItems}
                </span>
                <span className="text-[9px] text-slate-400 block mt-0.5">
                  {isIndonesian
                    ? `Dari ${analytics.contributingParentRequests} Permintaan Induk (${analytics.completedParentRequests} tiket)`
                    : `Across ${analytics.contributingParentRequests} Parent Reqs (${analytics.completedParentRequests} tickets)`}
                </span>
              </div>
              <div className="p-2.5 sm:p-3 bg-slate-50 rounded-xl border border-slate-200">
                <span className="text-[10px] sm:text-[11px] text-slate-500 block">
                  {isIndonesian ? 'Tingkat Kepatuhan SLA' : 'SLA Compliance Rate'}
                </span>
                <span className="text-lg sm:text-xl font-bold font-mono tabular-nums text-blue-700">
                  {analytics.slaFulfillmentRate !== null ? `${analytics.slaFulfillmentRate}%` : '—'}
                </span>
              </div>
              <div className="p-2.5 sm:p-3 bg-slate-50 rounded-xl border border-slate-200">
                <span className="text-[10px] sm:text-[11px] text-slate-500 block">
                  {isIndonesian ? 'Rata-rata Waktu Selesai' : 'Avg Turnaround Time'}
                </span>
                <span className="text-lg sm:text-xl font-bold font-mono tabular-nums text-slate-900">
                  {analytics.avgCompletionDays !== null
                    ? `${analytics.avgCompletionDays} ${isIndonesian ? 'Hari' : 'Days'}`
                    : '—'}
                </span>
              </div>
            </div>
          </div>

          {/* Breakdown Table */}
          <div>
            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-2.5">
              {isIndonesian
                ? `Rincian Detail Permintaan (${filteredRequests.length} Item)`
                : `Request Details Breakdown (${filteredRequests.length} Items)`}
            </h3>
            <div className="overflow-x-auto border border-slate-200 rounded-lg">
            <table className="w-full min-w-[640px] text-left text-[11px]">
              <thead className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
                <tr>
                  <th className="py-2 px-2.5">{isIndonesian ? 'ID Tiket' : 'Ticket ID'}</th>
                  <th className="py-2 px-2.5">{isIndonesian ? 'Judul' : 'Title'}</th>
                  <th className="py-2 px-2.5">{isIndonesian ? 'Nama Pemohon' : "Requestor's Name"}</th>
                  <th className="py-2 px-2.5">{isIndonesian ? 'Brand / Entitas' : 'Brand / Entity'}</th>
                  <th className="py-2 px-2.5">Status</th>
                  <th className="py-2 px-2.5">{isIndonesian ? 'Pelaksana' : 'Assignee'}</th>
                  <th className="py-2 px-2.5">{isIndonesian ? 'Tenggat Komitmen' : 'Committed Deadline'}</th>
                  <th className="py-2 px-2.5">{isIndonesian ? 'Hasil SLA' : 'SLA Outcome'}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-mono">
                {filteredRequests.map((req) => (
                  <tr key={req.id}>
                    <td className="py-2 px-2.5 font-bold text-slate-900">{req.ticketNumber}</td>
                    <td className="py-2 px-2.5 font-sans font-medium text-slate-800 max-w-[180px] truncate">
                      {req.title}
                    </td>
                    <td className="py-2 px-2.5 font-sans font-semibold text-slate-800 whitespace-nowrap">
                      {req.requestorName || req.requesterName}
                    </td>
                    <td className="py-2 px-2.5 font-sans text-slate-600">{req.brandName}</td>
                    <td className="py-2 px-2.5 font-sans text-slate-700">{statusLabels[req.status]}</td>
                    <td className="py-2 px-2.5 font-sans text-slate-700">
                      {req.primaryAssigneeName || '-'}
                    </td>
                    <td className="py-2 px-2.5 text-slate-600">
                      {req.committedDeadline || (isIndonesian ? 'Belum Dijadwalkan' : 'Unscheduled')}
                    </td>
                    <td className="py-2 px-2.5 font-sans">
                      {req.status === 'completed'
                        ? req.slaFulfilled
                          ? (isIndonesian ? 'Tepat Waktu' : 'On-Time')
                          : (isIndonesian ? 'Terlambat' : 'Late')
                        : req.isOverdue
                        ? (isIndonesian ? 'Terlambat' : 'Overdue')
                        : (isIndonesian ? 'Aktif' : 'Active')}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            </div>
          </div>

          {/* Signoff Footer */}
          <div className="pt-8 border-t border-slate-200 grid grid-cols-2 gap-8 text-xs text-center">
            <div>
              <span className="text-slate-400 block mb-12">
                {isIndonesian ? 'Disiapkan Oleh:' : 'Prepared By:'}
              </span>
              <strong className="text-slate-900 block">{currentUser.fullName}</strong>
              <span className="text-slate-500 text-[10px]">{currentUser.jobTitle}</span>
            </div>
            <div>
              <span className="text-slate-400 block mb-12">
                {isIndonesian ? 'Diketahui & Disetujui Oleh:' : 'Acknowledged & Approved By:'}
              </span>
              <strong className="text-slate-900 block">
                {isIndonesian ? 'Kepala Komunikasi Pemasaran' : 'Head of Marketing Communications'}
              </strong>
              <span className="text-slate-500 text-[10px]">Lyman Devindo</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
