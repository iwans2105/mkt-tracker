import React, { useState } from 'react';
import {
  BarChart3,
  TrendingUp,
  Clock,
  CheckCircle2,
  AlertTriangle,
  FileText,
  Filter,
  Download,
  Printer,
  HelpCircle,
  ArrowUpRight,
  PieChart,
  Sparkles,
  RefreshCw,
  Users,
  UserCheck,
  User,
  X,
} from 'lucide-react';
import { useRequests } from '../../context/RequestContext';
import { useAuth } from '../../context/AuthContext';
import { useLanguage } from '../../context/LanguageContext';
import {
  STATUS_LABELS,
  STATUS_LABELS_ID,
  STATUS_STYLES,
  PRIORITY_LABELS,
  PRIORITY_LABELS_ID,
} from '../common/StatusBadge';
import { RequestStatus, RequestPriority, PRIORITY_SLA_DAYS, FilterState } from '../../types';
import { AiService, ExecutiveInsightsResult } from '../../services/aiService';
import { StorageService } from '../../services/storageService';

interface AnalyticsDashboardProps {
  onOpenPdfReport: () => void;
  onFilterByStatus: (status: RequestStatus) => void;
}

export const AnalyticsDashboard: React.FC<AnalyticsDashboardProps> = ({
  onOpenPdfReport,
  onFilterByStatus,
}) => {
  const {
    filteredRequests,
    requests,
    analytics,
    exportCsv,
    brands,
    categories,
    departments,
    teams,
    filters,
    setFilters,
    resetFilters,
  } = useRequests();
  const { currentUser, allUsers } = useAuth();
  const { isIndonesian } = useLanguage();

  const [aiInsights, setAiInsights] = useState<ExecutiveInsightsResult | null>(null);
  const [isGeneratingInsights, setIsGeneratingInsights] = useState(false);

  const handleGenerateInsights = async () => {
    setIsGeneratingInsights(true);
    try {
      const res = await AiService.getExecutiveInsights({
        summaryData: {
          total: analytics.totalRequests,
          completed: analytics.completedRequests,
          inProgress: analytics.activeRequests,
          overdue: analytics.overdueRequests,
          complianceRate: analytics.slaFulfillmentRate || 0,
          avgCompletionDays: analytics.avgCompletionDays || 0,
        },
      });
      setAiInsights(res);
    } catch (err) {
      console.error(err);
    } finally {
      setIsGeneratingInsights(false);
    }
  };

  // Metric definitions for tooltip
  const tooltips = isIndonesian
    ? {
        total: 'Total permintaan kerja yang diajukan dalam filter dan rentang tanggal yang aktif.',
        completed: 'Jumlah permintaan kerja berstatus Selesai Disetujui dalam filter aktif.',
        active: 'Jumlah permintaan yang masih berjalan di alur kerja (Antrean, Dikerjakan, Review, Revisi, Ditunda).',
        onTrack: 'Tugas aktif yang saat ini masih berada dalam batas tenggat waktu komitmen (snapshot real-time).',
        overdue: 'Tugas aktif yang telah melewati tenggat waktu komitmen (snapshot real-time).',
        unscheduled: 'Permintaan yang belum ditetapkan tenggat waktu komitmennya oleh Admin.',
        avgTime: 'Rata-rata durasi kalender sejak tanggal pengajuan hingga persetujuan akhir dan penyelesaian.',
        sla: 'Persentase permintaan selesai yang dikirimkan tepat waktu atau sebelum tenggat komitmen.',
      }
    : {
        total: 'Total work requests submitted within the active filter and date range criteria.',
        completed: 'Number of work requests with Completed status within active filters.',
        active: 'Number of incomplete requests currently in pipeline (To Do, In Progress, Pending Review, Revision, On Hold).',
        onTrack: 'Active tasks currently within their committed deadline (real-time snapshot).',
        overdue: 'Active tasks that have exceeded their committed deadline (real-time snapshot).',
        unscheduled: 'Requests where a committed deadline has not yet been assigned by Admin.',
        avgTime: 'Average calendar duration from request creation date to final approval and completion.',
        sla: 'Percentage of completed requests delivered on or before the committed deadline.',
      };

  // Dynamic Work Item status breakdown (Dynamic Work Item Counting System)
  const statusCounts: Record<RequestStatus, number> = {
    todo: analytics.todoWorkItems || 0,
    in_progress: analytics.inProgressWorkItems || 0,
    pending_review: analytics.pendingReviewWorkItems || 0,
    revision: 0,
    completed: analytics.completedWorkItems || 0,
    on_hold: analytics.onHoldWorkItems || 0,
    cancelled: analytics.cancelledWorkItems || 0,
  };


  // Priority breakdown
  const priorityCounts: Record<RequestPriority, number> = {
    urgent: 0,
    high: 0,
    medium: 0,
    low: 0,
  };
  for (const r of filteredRequests) {
    priorityCounts[r.priority] = (priorityCounts[r.priority] || 0) + 1;
  }

  // Volume by brand
  const brandCounts: Record<string, number> = {};
  for (const r of filteredRequests) {
    brandCounts[r.brandName] = (brandCounts[r.brandName] || 0) + 1;
  }
  const topBrands = Object.entries(brandCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 6);

  // Volume by category (normalized and deduplicated across the 7 Task Categories)
  const categoryCounts: Record<string, number> = {};
  for (const r of filteredRequests) {
    const canonicalName = StorageService.normalizeCategoryName(r.categoryName, r.categoryId);
    categoryCounts[canonicalName] = (categoryCounts[canonicalName] || 0) + 1;
  }
  const topCategories = Object.entries(categoryCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 7);

  // Volume by department
  const deptCounts: Record<string, number> = {};
  for (const r of filteredRequests) {
    deptCounts[r.requesterDepartment] = (deptCounts[r.requesterDepartment] || 0) + 1;
  }
  const topDepts = Object.entries(deptCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5);

  // Volume by Requestor's Name
  const requestorCounts: Record<string, { name: string; count: number; userId?: string }> = {};
  for (const r of filteredRequests) {
    const reqName = r.requestorName || r.requesterName || (isIndonesian ? 'Pemohon Tidak Diketahui' : 'Unknown Requestor');
    if (!requestorCounts[reqName]) {
      requestorCounts[reqName] = { name: reqName, count: 0, userId: r.requesterId };
    }
    requestorCounts[reqName].count += 1;
  }
  const topRequestors = Object.values(requestorCounts)
    .sort((a, b) => b.count - a.count)
    .slice(0, 6);
  const maxRequestorCount = Math.max(...topRequestors.map((r) => r.count), 1);

  // Volume & Performance by Primary Assignee
  const assigneeStats: Record<
    string,
    {
      id: string;
      name: string;
      role: string;
      avatarUrl?: string;
      total: number;
      completed: number;
      active: number;
      overdue: number;
    }
  > = {};

  for (const r of filteredRequests) {
    const key = r.primaryAssigneeId || 'unassigned';
    const name = r.primaryAssigneeName || (isIndonesian ? 'Belum Ditugaskan' : 'Unassigned');

    if (!assigneeStats[key]) {
      const u = allUsers.find((usr) => usr.id === key);
      assigneeStats[key] = {
        id: key,
        name: name,
        role:
          u?.jobTitle ||
          (key === 'unassigned'
            ? isIndonesian
              ? 'PIC Belum Ditugaskan'
              : 'Unassigned PIC'
            : isIndonesian
            ? 'Tim Marcomm'
            : 'Marcomm Team'),
        avatarUrl: u?.avatarUrl,
        total: 0,
        completed: 0,
        active: 0,
        overdue: 0,
      };
    }
    assigneeStats[key].total += 1;
    if (r.status === 'completed') {
      assigneeStats[key].completed += 1;
    } else {
      assigneeStats[key].active += 1;
      if (r.isOverdue) {
        assigneeStats[key].overdue += 1;
      }
    }
  }

  const topAssignees = Object.values(assigneeStats).sort((a, b) => b.total - a.total);
  const maxAssigneeCount = Math.max(...topAssignees.map((a) => a.total), 1);
  const maxBrandCount = Math.max(...topBrands.map((b) => b[1]), 1);
  const maxCategoryCount = Math.max(...topCategories.map((c) => c[1]), 1);
  const maxDeptCount = Math.max(...topDepts.map((d) => d[1]), 1);

  // Marcomm team members for filter dropdown
  const teamAssignees = allUsers.filter(
    (u) => u.role === 'admin' || u.role === 'super_admin' || u.role === 'team_member'
  );

  const activeAssigneeUser =
    filters.assigneeId !== 'all'
      ? allUsers.find((u) => u.id === filters.assigneeId)
      : null;

  const activeRequestorUser =
    filters.requesterId && filters.requesterId !== 'all'
      ? allUsers.find((u) => u.id === filters.requesterId)
      : null;

  const activeCategory =
    filters.categoryId !== 'all'
      ? categories.find((c) => c.id === filters.categoryId)
      : null;

  return (
    <div className="space-y-6">
      {/* Top Action Header */}
      <div className="bg-white p-4 sm:p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 sm:gap-4">
          <div className="min-w-0">
            <h2 className="text-base sm:text-lg font-bold text-slate-900 truncate">
              {isIndonesian ? 'Laporan Analitik & Kinerja SLA' : 'Analytics & SLA Performance Reports'}
            </h2>
            <p className="text-xs text-slate-500 mt-1 leading-relaxed">
              {isIndonesian
                ? 'Distribusi beban kerja, analitik pelaksana utama, durasi penyelesaian, dan pemantauan kepatuhan SLA Marcomm.'
                : 'Workload distribution, primary assignee analytics, delivery duration, and Marcomm SLA compliance tracking.'}
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={exportCsv}
              className="flex-1 sm:flex-initial flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-xl transition-colors shadow-2xs"
            >
              <Download className="w-3.5 h-3.5 text-slate-500 shrink-0" />
              <span className="truncate">{isIndonesian ? 'Ekspor CSV' : 'Export CSV'}</span>
            </button>

            <button
              onClick={onOpenPdfReport}
              className="flex-1 sm:flex-initial flex items-center justify-center gap-1.5 px-3.5 py-2 text-xs font-bold text-white bg-[#065F46] hover:bg-[#044e39] rounded-xl transition-colors shadow-xs"
            >
              <Printer className="w-3.5 h-3.5 shrink-0" />
              <span className="truncate">{isIndonesian ? 'Cetak Laporan PDF' : 'Print PDF Report'}</span>
            </button>
          </div>
        </div>

        {/* Analytics Filter Bar with Primary Assignee Category */}
        <div className="pt-3 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 text-xs">
          <div className="flex items-center gap-2 flex-wrap flex-1 min-w-0">
            <div className="flex items-center gap-1 text-slate-500 font-semibold text-xs shrink-0">
              <Filter className="w-3.5 h-3.5 text-slate-400" />
              <span>{isIndonesian ? 'Filter Analitik:' : 'Filter Analytics:'}</span>
            </div>

            {/* Primary Assignee Selector */}
            <div className="min-w-[170px] flex-1 sm:flex-initial">
              <select
                value={filters.assigneeId}
                onChange={(e) =>
                  setFilters((prev) => ({ ...prev, assigneeId: e.target.value }))
                }
                className={`w-full h-8 px-2.5 bg-slate-50 hover:bg-white border rounded-lg font-medium transition-colors cursor-pointer truncate ${
                  filters.assigneeId !== 'all'
                    ? 'border-blue-500 bg-blue-50/50 text-blue-700 font-semibold'
                    : 'border-slate-200 text-slate-700'
                }`}
              >
                <option value="all">{isIndonesian ? 'Semua Pelaksana Utama' : 'All Primary Assignees'}</option>
                {teamAssignees.map((asg) => (
                  <option key={asg.id} value={asg.id}>
                    {isIndonesian ? 'Pelaksana:' : 'Assignee:'} {asg.fullName}
                  </option>
                ))}
              </select>
            </div>

            {/* Task Category Selector */}
            <div className="min-w-[170px] flex-1 sm:flex-initial">
              <select
                value={filters.categoryId}
                onChange={(e) =>
                  setFilters((prev) => ({ ...prev, categoryId: e.target.value }))
                }
                className={`w-full h-8 px-2.5 bg-slate-50 hover:bg-white border rounded-lg font-medium transition-colors cursor-pointer truncate ${
                  filters.categoryId !== 'all'
                    ? 'border-emerald-600 bg-emerald-50/70 text-emerald-800 font-semibold'
                    : 'border-slate-200 text-slate-700'
                }`}
              >
                <option value="all">{isIndonesian ? 'Semua Kategori Tugas' : 'All Task Categories'}</option>
                {categories.map((cat) => (
                  <option key={cat.id} value={cat.id}>
                    {cat.name}
                  </option>
                ))}
              </select>
            </div>

            {/* Requestor's Name Selector */}
            <div className="min-w-[170px] flex-1 sm:flex-initial">
              <select
                value={filters.requesterId || 'all'}
                onChange={(e) =>
                  setFilters((prev) => ({ ...prev, requesterId: e.target.value }))
                }
                className={`w-full h-8 px-2.5 bg-slate-50 hover:bg-white border rounded-lg font-medium transition-colors cursor-pointer truncate ${
                  filters.requesterId && filters.requesterId !== 'all'
                    ? 'border-[#065F46] bg-[#D1FAE5]/60 text-[#065F46] font-semibold'
                    : 'border-slate-200 text-slate-700'
                }`}
                title={isIndonesian ? 'Filter analitik berdasarkan Nama Pemohon' : "Filter analytics by Requestor's Name"}
              >
                <option value="all">{isIndonesian ? 'Semua Pemohon' : 'All Requestors'}</option>
                {allUsers.map((reqUser) => (
                  <option key={reqUser.id} value={reqUser.id}>
                    {isIndonesian ? 'Pemohon:' : 'Requestor:'} {reqUser.fullName}
                  </option>
                ))}
              </select>
            </div>

            {/* Region Selector */}
            <div className="min-w-[130px] flex-1 sm:flex-initial">
              <select
                value={filters.regionId}
                onChange={(e) =>
                  setFilters((prev) => ({
                    ...prev,
                    regionId: e.target.value,
                    brandId: 'all',
                  }))
                }
                className="w-full h-8 px-2.5 bg-slate-50 hover:bg-white border border-slate-200 rounded-lg text-slate-700 font-medium transition-colors cursor-pointer truncate"
              >
                <option value="all">{isIndonesian ? 'Semua Wilayah' : 'All Regions'}</option>
                <option value="reg-jkt">Jakarta</option>
                <option value="reg-bdg">Bandung</option>
              </select>
            </div>

            {/* Period & Date Range Filter */}
            <div className="flex items-center gap-1.5 flex-wrap sm:flex-nowrap flex-1 sm:flex-initial">
              <div className="min-w-[140px] flex-1 sm:flex-initial">
                <select
                  value={filters.dateRange}
                  onChange={(e) => {
                    const val = e.target.value as FilterState['dateRange'];
                    if (val === 'custom') {
                      const today = new Date().toISOString().split('T')[0];
                      const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000)
                        .toISOString()
                        .split('T')[0];
                      setFilters((prev) => ({
                        ...prev,
                        dateRange: 'custom',
                        startDate: prev.startDate || thirtyDaysAgo,
                        endDate: prev.endDate || today,
                      }));
                    } else {
                      setFilters((prev) => ({
                        ...prev,
                        dateRange: val,
                        startDate: undefined,
                        endDate: undefined,
                      }));
                    }
                  }}
                  className={`w-full h-8 px-2.5 bg-slate-50 hover:bg-white border rounded-lg font-medium transition-colors cursor-pointer truncate ${
                    filters.dateRange !== 'all'
                      ? 'border-indigo-500 bg-indigo-50/50 text-indigo-700 font-semibold'
                      : 'border-slate-200 text-slate-700'
                  }`}
                >
                  <option value="all">{isIndonesian ? 'Semua Periode' : 'All Periods'}</option>
                  <option value="today">{isIndonesian ? 'Hari Ini' : 'Today'}</option>
                  <option value="this_week">{isIndonesian ? '7 Hari Terakhir' : 'Last 7 Days'}</option>
                  <option value="this_month">{isIndonesian ? 'Bulan Ini' : 'This Month'}</option>
                  <option value="custom">{isIndonesian ? 'Rentang Tanggal Kustom' : 'Custom Date Range'}</option>
                </select>
              </div>

              {/* Custom Date Inputs (Appears when custom is active) */}
              {filters.dateRange === 'custom' && (
                <div className="flex items-center gap-1.5 bg-indigo-50/70 px-2 py-1 rounded-lg border border-indigo-200 text-xs">
                  <div className="flex items-center gap-1">
                    <span className="text-[10px] text-indigo-700 font-bold">{isIndonesian ? 'Dari:' : 'From:'}</span>
                    <input
                      type="date"
                      value={filters.startDate || ''}
                      onChange={(e) =>
                        setFilters((prev) => ({ ...prev, startDate: e.target.value }))
                      }
                      className="h-6 px-1.5 text-xs bg-white border border-indigo-200 rounded text-slate-800 font-mono focus:outline-none focus:ring-1 focus:ring-indigo-500"
                    />
                  </div>
                  <span className="text-indigo-400 font-bold">-</span>
                  <div className="flex items-center gap-1">
                    <span className="text-[10px] text-indigo-700 font-bold">{isIndonesian ? 'Sampai:' : 'To:'}</span>
                    <input
                      type="date"
                      value={filters.endDate || ''}
                      onChange={(e) =>
                        setFilters((prev) => ({ ...prev, endDate: e.target.value }))
                      }
                      className="h-6 px-1.5 text-xs bg-white border border-indigo-200 rounded text-slate-800 font-mono focus:outline-none focus:ring-1 focus:ring-indigo-500"
                    />
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Active Filter Indicators & Reset */}
          <div className="flex items-center gap-2 flex-wrap self-start sm:self-auto shrink-0">
            {filters.assigneeId !== 'all' && (
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-blue-50 border border-blue-200 text-blue-700 font-semibold text-[11px]">
                <Users className="w-3 h-3 text-blue-500" />
                <span>PIC: {activeAssigneeUser?.fullName || filters.assigneeId}</span>
                <button
                  type="button"
                  onClick={() => setFilters((prev) => ({ ...prev, assigneeId: 'all' }))}
                  className="hover:text-blue-900 ml-0.5 cursor-pointer"
                  title={isIndonesian ? 'Hapus filter pelaksana' : 'Clear assignee filter'}
                >
                  <X className="w-3 h-3" />
                </button>
              </span>
            )}

            {filters.requesterId && filters.requesterId !== 'all' && (
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-[#D1FAE5] border border-[#A7F3D0] text-[#065F46] font-semibold text-[11px]">
                <User className="w-3 h-3 text-[#065F46]" />
                <span>{isIndonesian ? 'Pemohon:' : 'Requestor:'} {activeRequestorUser?.fullName || filters.requesterId}</span>
                <button
                  type="button"
                  onClick={() => setFilters((prev) => ({ ...prev, requesterId: 'all' }))}
                  className="hover:text-emerald-950 ml-0.5 cursor-pointer"
                  title={isIndonesian ? 'Hapus filter pemohon' : 'Clear requestor filter'}
                >
                  <X className="w-3 h-3" />
                </button>
              </span>
            )}

            {filters.dateRange !== 'all' && (
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-indigo-50 border border-indigo-200 text-indigo-700 font-semibold text-[11px]">
                <span>
                  {isIndonesian ? 'Periode:' : 'Period:'}{' '}
                  {filters.dateRange === 'custom'
                    ? `${filters.startDate || (isIndonesian ? 'Awal' : 'Start')} ${isIndonesian ? 's/d' : 'to'} ${filters.endDate || (isIndonesian ? 'Hari Ini' : 'Today')}`
                    : filters.dateRange === 'today'
                    ? isIndonesian ? 'Hari Ini' : 'Today'
                    : filters.dateRange === 'this_week'
                    ? isIndonesian ? '7 Hari Terakhir' : 'Last 7 Days'
                    : isIndonesian ? 'Bulan Ini' : 'This Month'}
                </span>
                <button
                  type="button"
                  onClick={() =>
                    setFilters((prev) => ({
                      ...prev,
                      dateRange: 'all',
                      startDate: undefined,
                      endDate: undefined,
                    }))
                  }
                  className="hover:text-indigo-900 ml-0.5 cursor-pointer"
                  title={isIndonesian ? 'Hapus filter tanggal' : 'Clear date filter'}
                >
                  <X className="w-3 h-3" />
                </button>
              </span>
            )}

            {filters.categoryId !== 'all' && (
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-emerald-50 border border-emerald-200 text-emerald-800 font-semibold text-[11px]">
                <PieChart className="w-3 h-3 text-emerald-600" />
                <span>{isIndonesian ? 'Kategori:' : 'Category:'} {activeCategory?.name || filters.categoryId}</span>
                <button
                  type="button"
                  onClick={() => setFilters((prev) => ({ ...prev, categoryId: 'all' }))}
                  className="hover:text-emerald-950 ml-0.5 cursor-pointer"
                  title={isIndonesian ? 'Hapus filter kategori' : 'Clear category filter'}
                >
                  <X className="w-3 h-3" />
                </button>
              </span>
            )}

            {(filters.assigneeId !== 'all' ||
              (filters.requesterId && filters.requesterId !== 'all') ||
              filters.categoryId !== 'all' ||
              filters.dateRange !== 'all' ||
              filters.regionId !== 'all') && (
              <button
                type="button"
                onClick={resetFilters}
                className="text-[11px] font-semibold text-rose-600 hover:text-rose-700 underline cursor-pointer ml-1"
              >
                {isIndonesian ? 'Reset Filter' : 'Reset Filters'}
              </button>
            )}
          </div>
        </div>
      </div>

      {/* AI Executive Insights Banner */}
      <div className="bg-gradient-to-r from-[#065F46] via-[#047857] to-[#0f172a] rounded-2xl p-5 text-white shadow-md border border-emerald-700/40 space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-[#A7F3D0]" />
            <span className="text-xs font-bold uppercase tracking-wider text-[#A7F3D0]">
              {isIndonesian ? 'Analitik AI & Wawasan Eksekutif' : 'AI Analytics & Executive Insights'}
            </span>
          </div>
          <button
            type="button"
            onClick={handleGenerateInsights}
            disabled={isGeneratingInsights}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/15 hover:bg-white/25 text-[#A7F3D0] border border-white/20 text-xs font-semibold transition-colors shrink-0"
          >
            {isGeneratingInsights ? (
              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
            ) : (
              <TrendingUp className="w-3.5 h-3.5" />
            )}
            <span>
              {aiInsights
                ? isIndonesian ? 'Perbarui Wawasan' : 'Refresh Insights'
                : isIndonesian ? 'Analisis Kinerja SLA' : 'Analyze SLA Performance'}
            </span>
          </button>
        </div>

        {aiInsights ? (
          <div className="space-y-3 pt-2 border-t border-slate-700/60 text-xs">
            <p className="text-sm font-semibold text-white leading-relaxed">
              {aiInsights.executiveHeadline}
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-slate-300 text-[11px]">
              <div className="p-3 bg-slate-800/60 rounded-xl border border-slate-700/50">
                <span className="font-bold text-teal-300 block mb-1">
                  {isIndonesian ? 'Kecepatan & Kesehatan SLA:' : 'Velocity & SLA Health:'}
                </span>
                <p>{aiInsights.operationalVelocity}</p>
                <p className="mt-1 text-slate-400">{aiInsights.slaHealthDiagnosis}</p>
              </div>
              <div className="p-3 bg-slate-800/60 rounded-xl border border-slate-700/50">
                <span className="font-bold text-teal-300 block mb-1">
                  {isIndonesian ? 'Rekomendasi Strategis:' : 'Strategic Recommendations:'}
                </span>
                <ul className="list-disc list-inside space-y-0.5">
                  {aiInsights.strategicRoadmap.map((r, i) => (
                    <li key={i}>{r}</li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        ) : (
          <p className="text-xs text-slate-300 leading-relaxed">
            {isIndonesian
              ? `Klik "Analisis Kinerja SLA" untuk menyusun wawasan eksekutif otomatis terkait kepatuhan SLA prioritas (${analytics.slaFulfillmentRate || 0}%), kecepatan penyelesaian, dan rekomendasi strategis bagi divisi Marcomm.`
              : `Click "Analyze SLA Performance" to synthesize automated executive insights covering priority SLA compliance (${analytics.slaFulfillmentRate || 0}%), delivery velocity, and strategic recommendations for the Marcomm division.`}
          </p>
        )}
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-2.5 sm:gap-4">
        {/* Total Requests */}
        <div className="p-3.5 sm:p-4 bg-white rounded-2xl border border-slate-200 shadow-2xs relative group min-w-0">
          <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
            <span className="truncate">{isIndonesian ? 'Total Permintaan' : 'Total Requests'}</span>
            <div className="relative group/tip cursor-help shrink-0">
              <HelpCircle className="w-3.5 h-3.5 text-slate-400" />
              <div className="absolute right-0 bottom-full mb-1 hidden group-hover/tip:block w-48 p-2 bg-slate-900 text-white text-[11px] rounded-lg shadow-xl z-20">
                {tooltips.total}
              </div>
            </div>
          </div>
          <div className="text-xl sm:text-2xl font-extrabold text-slate-900 font-mono tabular-nums">
            {analytics.totalRequests}
          </div>
          <div className="text-[10px] sm:text-[11px] text-slate-500 mt-1 truncate">
            {analytics.totalWorkItems} {isIndonesian ? 'Item Kerja' : 'Work Items'} ({analytics.totalSubItems} Sub Item)
          </div>
        </div>


        {/* Completed Work Items */}
        <div className="p-3.5 sm:p-4 bg-white rounded-2xl border border-slate-200 shadow-2xs min-w-0">
          <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
            <span className="truncate">{isIndonesian ? 'Item Kerja Selesai' : 'Completed Work Items'}</span>
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
          </div>
          <div className="text-xl sm:text-2xl font-extrabold text-emerald-700 font-mono tabular-nums">
            {analytics.completedWorkItems}
          </div>
          <div className="text-[10px] sm:text-[11px] text-emerald-600/90 mt-1 truncate font-medium">
            {isIndonesian
              ? `Dari ${analytics.contributingParentRequests} Permintaan Induk (${analytics.completedParentRequests} selesai)`
              : `Across ${analytics.contributingParentRequests} Parent Requests (${analytics.completedParentRequests} archived)`}
          </div>
        </div>

        {/* SLA Fulfillment Rate */}
        <div className="p-3.5 sm:p-4 bg-white rounded-2xl border border-slate-200 shadow-2xs min-w-0">
          <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
            <span className="truncate">{isIndonesian ? 'Tingkat Kepatuhan SLA' : 'SLA Compliance Rate'}</span>
            <TrendingUp className="w-3.5 h-3.5 text-blue-600 shrink-0" />
          </div>
          <div className="text-xl sm:text-2xl font-extrabold text-blue-700 font-mono tabular-nums">
            {analytics.slaFulfillmentRate !== null ? `${analytics.slaFulfillmentRate}%` : '—'}
          </div>
          <div className="text-[10px] sm:text-[11px] text-slate-400 mt-1 truncate">
            {analytics.slaFulfillmentRate !== null
              ? isIndonesian ? 'Memenuhi tenggat komitmen' : 'Met committed deadline'
              : isIndonesian ? 'Belum ada data' : 'No data yet'}
          </div>
        </div>

        {/* Average Completion Days */}
        <div className="p-3.5 sm:p-4 bg-white rounded-2xl border border-slate-200 shadow-2xs min-w-0">
          <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
            <span className="truncate">{isIndonesian ? 'Rata-rata Waktu Penyelesaian' : 'Avg Turnaround Time'}</span>
            <Clock className="w-3.5 h-3.5 text-amber-600 shrink-0" />
          </div>
          <div className="text-xl sm:text-2xl font-extrabold text-slate-900 font-mono tabular-nums">
            {analytics.avgCompletionDays !== null
              ? `${analytics.avgCompletionDays} ${isIndonesian ? 'Hari' : 'Days'}`
              : '—'}
          </div>
          <div className="text-[10px] sm:text-[11px] text-slate-400 mt-1 truncate">
            {isIndonesian ? 'Pengajuan hingga persetujuan' : 'Submission to approval'}
          </div>
        </div>

        {/* Active Requests */}
        <div className="p-3.5 sm:p-4 bg-white rounded-2xl border border-slate-200 shadow-2xs min-w-0">
          <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
            <span className="truncate">{isIndonesian ? 'Permintaan Aktif' : 'Active Requests'}</span>
            <FileText className="w-3.5 h-3.5 text-sky-600 shrink-0" />
          </div>
          <div className="text-xl sm:text-2xl font-extrabold text-sky-700 font-mono tabular-nums">
            {analytics.activeRequests}
          </div>
          <div className="text-[10px] sm:text-[11px] text-slate-400 mt-1 truncate">
            {isIndonesian ? 'Dalam antrean & pengerjaan' : 'In queue & production'}
          </div>
        </div>

        {/* On-Track (Snapshot) */}
        <div className="p-3.5 sm:p-4 bg-white rounded-2xl border border-slate-200 shadow-2xs min-w-0">
          <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
            <span className="truncate">{isIndonesian ? 'Sesuai Jadwal' : 'On Track'}</span>
            <span className="w-2 h-2 rounded-full bg-emerald-500 shrink-0" />
          </div>
          <div className="text-xl sm:text-2xl font-extrabold text-emerald-700 font-mono tabular-nums">
            {analytics.onTrackRequests}
          </div>
          <div className="text-[10px] sm:text-[11px] text-slate-400 mt-1 truncate">
            {isIndonesian ? 'Tepat waktu' : 'On schedule'}
          </div>
        </div>

        {/* Overdue (Snapshot) */}
        <div className="p-3.5 sm:p-4 bg-white rounded-2xl border border-rose-200 bg-rose-50/20 shadow-2xs min-w-0">
          <div className="flex items-center justify-between text-xs text-rose-800 mb-1 font-semibold">
            <span className="truncate">{isIndonesian ? 'Terlambat' : 'Overdue'}</span>
            <AlertTriangle className="w-3.5 h-3.5 text-rose-600 shrink-0" />
          </div>
          <div className="text-xl sm:text-2xl font-extrabold text-rose-700 font-mono tabular-nums">
            {analytics.overdueRequests}
          </div>
          <div className="text-[10px] sm:text-[11px] text-rose-600 mt-1 truncate">
            {isIndonesian ? 'Melewati tenggat komitmen' : 'Past committed deadline'}
          </div>
        </div>

        {/* Belum Dijadwalkan */}
        <div className="p-3.5 sm:p-4 bg-white rounded-2xl border border-slate-200 shadow-2xs min-w-0">
          <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
            <span className="truncate">{isIndonesian ? 'Belum Dijadwalkan' : 'Unscheduled'}</span>
            <Clock className="w-3.5 h-3.5 text-slate-400 shrink-0" />
          </div>
          <div className="text-xl sm:text-2xl font-extrabold text-slate-600 font-mono tabular-nums">
            {analytics.unscheduledRequests}
          </div>
          <div className="text-[10px] sm:text-[11px] text-slate-400 mt-1 truncate">
            {isIndonesian ? 'Belum ada tenggat' : 'No deadline set'}
          </div>
        </div>
      </div>

      {/* Visual Chart Grids */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Status Distribution */}
        <div className="p-6 bg-white rounded-2xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900">
              {isIndonesian ? 'Distribusi Status Alur Kerja' : 'Workflow Status Distribution'}
            </h3>
            <span className="text-xs text-slate-400">
              {isIndonesian ? 'Klik status untuk memfilter' : 'Click status to filter'}
            </span>
          </div>

          <div className="space-y-3">
            {(Object.keys(statusCounts) as RequestStatus[]).map((st) => {
              const count = statusCounts[st];
              const totalItems = analytics.totalWorkItems || analytics.totalRequests;
              const pct =
                totalItems > 0
                  ? Math.round((count / totalItems) * 100)
                  : 0;
              const style = STATUS_STYLES[st];


              return (
                <div
                  key={st}
                  onClick={() => onFilterByStatus(st)}
                  className="cursor-pointer group p-2 rounded-xl hover:bg-slate-50 transition-colors"
                >
                  <div className="flex items-center justify-between text-xs mb-1">
                    <span className="font-semibold text-slate-800 group-hover:text-blue-600 transition-colors flex items-center gap-1.5">
                      <span className={`w-2 h-2 rounded-full ${style.dot}`} />
                      <span>{isIndonesian ? STATUS_LABELS_ID[st] : STATUS_LABELS[st]}</span>
                    </span>
                    <span className="font-mono text-slate-600 tabular-nums">
                      <strong>{count}</strong> ({pct}%)
                    </span>
                  </div>
                  <div className="w-full h-2 rounded-full bg-slate-100 overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all duration-300 ${style.dot}`}
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Priority Distribution */}
        <div className="p-6 bg-white rounded-2xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900">
              {isIndonesian ? 'Distribusi Tingkat Prioritas' : 'Priority Level Distribution'}
            </h3>
            <span className="text-xs text-slate-400">
              {isIndonesian ? 'Distribusi urgensi tugas' : 'Task urgency distribution'}
            </span>
          </div>

          <div className="space-y-3">
            {(Object.keys(priorityCounts) as RequestPriority[]).map((pr) => {
              const count = priorityCounts[pr];
              const pct =
                analytics.totalRequests > 0
                  ? Math.round((count / analytics.totalRequests) * 100)
                  : 0;
              const colors: Record<RequestPriority, string> = {
                urgent: 'bg-rose-500',
                high: 'bg-amber-500',
                medium: 'bg-blue-500',
                low: 'bg-slate-400',
              };

              return (
                <div key={pr} className="p-2 rounded-xl hover:bg-slate-50 transition-colors">
                  <div className="flex items-center justify-between text-xs mb-1">
                    <span className="font-semibold text-slate-800 flex items-center gap-1.5">
                      <span className={`w-2 h-2 rounded-full ${colors[pr]}`} />
                      <span>
                        {isIndonesian ? PRIORITY_LABELS_ID[pr] : PRIORITY_LABELS[pr]} (SLA: {PRIORITY_SLA_DAYS[pr]} {isIndonesian ? 'Hari' : 'Days'})
                      </span>
                    </span>
                    <span className="font-mono text-slate-600 tabular-nums">
                      <strong>{count}</strong> ({pct}%)
                    </span>
                  </div>
                  <div className="w-full h-2 rounded-full bg-slate-100 overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all duration-300 ${colors[pr]}`}
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Volume by Brand */}
        <div className="p-4 sm:p-6 bg-white rounded-2xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900">
              {isIndonesian ? 'Volume Permintaan per Brand / Entitas' : 'Request Volume by Brand / Entity'}
            </h3>
            <span className="text-xs text-slate-400">
              {isIndonesian ? '6 Brand Teratas' : 'Top 6 Active Brands'}
            </span>
          </div>

          <div className="space-y-3">
            {topBrands.length === 0 ? (
              <p className="text-xs text-slate-400 italic">
                {isIndonesian ? 'Tidak ada data brand tersedia.' : 'No brand data available.'}
              </p>
            ) : (
              topBrands.map(([brandName, count]) => {
                const barWidth = Math.round((count / maxBrandCount) * 100);
                return (
                  <div key={brandName} className="p-1.5">
                    <div className="flex items-center justify-between text-xs mb-1">
                      <span className="font-semibold text-slate-800 truncate flex-1 min-w-0 mr-2">
                        {brandName}
                      </span>
                      <span className="font-mono text-slate-700 font-bold tabular-nums shrink-0">
                        {count} {isIndonesian ? 'permintaan' : count === 1 ? 'request' : 'requests'}
                      </span>
                    </div>
                    <div className="w-full h-2 rounded-full bg-slate-100 overflow-hidden">
                      <div
                        className="h-full rounded-full bg-[#065F46] transition-all duration-300"
                        style={{ width: `${barWidth}%` }}
                      />
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Volume by Category */}
        <div className="p-4 sm:p-6 bg-white rounded-2xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <PieChart className="w-4 h-4 text-[#065F46]" />
                <span>{isIndonesian ? 'Volume Permintaan per Kategori' : 'Request Volume by Category'}</span>
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                {isIndonesian
                  ? 'Distribusi lintas disiplin layanan kreatif & pemasaran (Klik untuk filter)'
                  : 'Distribution across creative & marketing service disciplines (Click to filter)'}
              </p>
            </div>
            <span className="text-xs text-slate-500 font-medium shrink-0">
              {topCategories.length} {isIndonesian ? 'Kategori' : 'Categories'}
            </span>
          </div>

          <div className="space-y-2.5">
            {topCategories.length === 0 ? (
              <p className="text-xs text-slate-400 italic">
                {isIndonesian
                  ? 'Tidak ada data kategori yang tercatat untuk kriteria filter yang dipilih.'
                  : 'No category data recorded for the selected filter criteria.'}
              </p>
            ) : (
              topCategories.map(([catName, count]) => {
                const barWidth = Math.round((count / maxCategoryCount) * 100);
                const matchingCat = categories.find(
                  (c) => c.name.toLowerCase() === catName.toLowerCase()
                );
                const isSelected = matchingCat && filters.categoryId === matchingCat.id;
                const pct = filteredRequests.length > 0 ? Math.round((count / filteredRequests.length) * 100) : 0;

                return (
                  <div
                    key={catName}
                    onClick={() => {
                      if (matchingCat) {
                        setFilters((prev) => ({
                          ...prev,
                          categoryId: prev.categoryId === matchingCat.id ? 'all' : matchingCat.id,
                        }));
                      }
                    }}
                    className={`p-2.5 rounded-xl border transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-emerald-50/80 border-[#065F46] ring-1 ring-[#065F46] shadow-2xs'
                        : 'bg-slate-50/60 hover:bg-slate-100/70 border-slate-200/80'
                    }`}
                  >
                    <div className="flex items-center justify-between text-xs mb-1.5">
                      <div className="flex items-center gap-2 min-w-0 flex-1 mr-2">
                        <span className="w-2 h-2 rounded-full bg-[#065F46] shrink-0" />
                        <span className="font-semibold text-slate-900 truncate">
                          {catName}
                        </span>
                      </div>
                      <div className="flex items-center gap-1.5 shrink-0">
                        <span className="font-mono text-slate-800 font-bold tabular-nums">
                          {count} {isIndonesian ? 'permintaan' : count === 1 ? 'request' : 'requests'}
                        </span>
                        <span className="text-[10px] font-semibold text-emerald-800 bg-emerald-100/80 px-1.5 py-0.5 rounded-md">
                          {pct}%
                        </span>
                      </div>
                    </div>
                    <div className="w-full h-2 rounded-full bg-slate-200/70 overflow-hidden">
                      <div
                        className="h-full rounded-full bg-gradient-to-r from-[#065F46] to-[#10B981] transition-all duration-300"
                        style={{ width: `${barWidth}%` }}
                      />
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Category: Workload by Primary Assignee */}
        <div className="p-4 sm:p-6 bg-white rounded-2xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <Users className="w-4 h-4 text-blue-600" />
                <span>{isIndonesian ? 'Distribusi per Pelaksana Utama' : 'Distribution by Primary Assignee'}</span>
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                {isIndonesian
                  ? 'Beban kerja PIC Marcomm & progres penyelesaian (Klik nama untuk filter)'
                  : 'Marcomm PIC workload & fulfillment progress (Click name to filter)'}
              </p>
            </div>
            <span className="text-xs text-slate-400 font-medium shrink-0">
              {topAssignees.length} {isIndonesian ? 'PIC Dipantau' : 'PICs Tracked'}
            </span>
          </div>

          <div className="space-y-2.5">
            {topAssignees.length === 0 ? (
              <p className="text-xs text-slate-400 italic">
                {isIndonesian ? 'Tidak ada data beban kerja pelaksana.' : 'No assignee workload data available.'}
              </p>
            ) : (
              topAssignees.map((asg) => {
                const isSelected = filters.assigneeId === asg.id;
                const isUnassigned = asg.id === 'unassigned';

                return (
                  <div
                    key={asg.id}
                    onClick={() =>
                      setFilters((prev) => ({
                        ...prev,
                        assigneeId: prev.assigneeId === asg.id ? 'all' : asg.id,
                      }))
                    }
                    className={`p-2.5 rounded-xl border transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-blue-50/80 border-blue-400 shadow-xs ring-1 ring-blue-400'
                        : 'bg-slate-50/60 hover:bg-slate-100/70 border-slate-200/80'
                    }`}
                    title={isIndonesian ? `Filter analitik untuk ${asg.name}` : `Filter analytics for ${asg.name}`}
                  >
                    <div className="flex items-center justify-between text-xs mb-1.5 gap-2">
                      <div className="flex items-center gap-2 min-w-0">
                        {asg.avatarUrl ? (
                          <img
                            src={asg.avatarUrl}
                            alt={asg.name}
                            className="w-6 h-6 rounded-full object-cover shrink-0 ring-1 ring-slate-200"
                          />
                        ) : (
                          <div
                            className={`w-6 h-6 rounded-full flex items-center justify-center font-bold text-[10px] shrink-0 ${
                              isUnassigned
                                ? 'bg-slate-200 text-slate-600'
                                : 'bg-blue-100 text-blue-700'
                            }`}
                          >
                            {isUnassigned ? '?' : asg.name.charAt(0)}
                          </div>
                        )}
                        <div className="min-w-0 truncate">
                          <span className="font-semibold text-slate-800 truncate block">
                            {asg.name}
                          </span>
                          <span className="text-[10px] text-slate-400 truncate block">
                            {asg.role}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 shrink-0 font-mono text-xs">
                        <span className="text-[11px] text-slate-500 hidden sm:inline">
                          <span className="text-emerald-600 font-semibold">
                            {asg.completed} {isIndonesian ? 'selesai' : 'completed'}
                          </span>
                          {asg.active > 0 && (
                            <> · <span className="text-blue-600 font-semibold">{asg.active} {isIndonesian ? 'aktif' : 'active'}</span></>
                          )}
                          {asg.overdue > 0 && (
                            <> · <span className="text-rose-600 font-semibold">{asg.overdue} {isIndonesian ? 'terlambat' : 'overdue'}</span></>
                          )}
                        </span>
                        <span className="font-bold text-slate-900 bg-white px-2 py-0.5 rounded-md border border-slate-200 tabular-nums">
                          {asg.total} {isIndonesian ? 'tugas' : asg.total === 1 ? 'task' : 'tasks'}
                        </span>
                      </div>
                    </div>

                    {/* Progress Bar: Completed (Emerald) + Active (Blue) + Overdue (Rose) */}
                    <div className="w-full h-2 rounded-full bg-slate-200/70 overflow-hidden flex">
                      <div
                        className="h-full bg-emerald-500 transition-all duration-300"
                        style={{ width: `${(asg.completed / maxAssigneeCount) * 100}%` }}
                      />
                      <div
                        className="h-full bg-blue-500 transition-all duration-300"
                        style={{
                          width: `${(Math.max(0, asg.active - asg.overdue) / maxAssigneeCount) * 100}%`,
                        }}
                      />
                      {asg.overdue > 0 && (
                        <div
                          className="h-full bg-rose-500 transition-all duration-300"
                          style={{ width: `${(asg.overdue / maxAssigneeCount) * 100}%` }}
                        />
                      )}
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Volume by Requester Department */}
        <div className="p-4 sm:p-6 bg-white rounded-2xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900">
              {isIndonesian ? 'Volume per Departemen Pemohon' : 'Volume by Requester Department'}
            </h3>
            <span className="text-xs text-slate-400">
              {isIndonesian ? '5 Departemen Teratas' : 'Top 5 Departments'}
            </span>
          </div>

          <div className="space-y-3">
            {topDepts.length === 0 ? (
              <p className="text-xs text-slate-400 italic">
                {isIndonesian ? 'Tidak ada data departemen tersedia.' : 'No department data available.'}
              </p>
            ) : (
              topDepts.map(([deptName, count]) => {
                const barWidth = Math.round((count / maxDeptCount) * 100);
                return (
                  <div key={deptName} className="p-1.5">
                    <div className="flex items-center justify-between text-xs mb-1">
                      <span className="font-semibold text-slate-800 truncate flex-1 min-w-0 mr-2">
                        {deptName}
                      </span>
                      <span className="font-mono text-slate-700 font-bold tabular-nums shrink-0">
                        {count} {isIndonesian ? 'permintaan' : count === 1 ? 'request' : 'requests'}
                      </span>
                    </div>
                    <div className="w-full h-2 rounded-full bg-slate-100 overflow-hidden">
                      <div
                        className="h-full rounded-full bg-teal-600 transition-all duration-300"
                        style={{ width: `${barWidth}%` }}
                      />
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Request Volume by Requestor's Name */}
        <div className="p-4 sm:p-6 bg-white rounded-2xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <User className="w-4 h-4 text-[#065F46]" />
                <span>{isIndonesian ? 'Volume Permintaan per Pemohon' : 'Request Volume by Requestor'}</span>
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                {isIndonesian
                  ? 'Pemohon brief korporat teratas dan jumlah pengajuan (Klik nama untuk filter)'
                  : 'Top corporate brief requestors and submission counts (Click name to filter)'}
              </p>
            </div>
            <span className="text-xs text-slate-400 font-medium shrink-0">
              {topRequestors.length} {isIndonesian ? 'Pemohon' : 'Requestors'}
            </span>
          </div>

          <div className="space-y-2.5">
            {topRequestors.length === 0 ? (
              <p className="text-xs text-slate-400 italic">
                {isIndonesian
                  ? 'Tidak ada data pemohon tercatat untuk kriteria filter yang dipilih.'
                  : 'No requestor data recorded for the selected filter criteria.'}
              </p>
            ) : (
              topRequestors.map((reqItem) => {
                const barWidth = Math.round((reqItem.count / maxRequestorCount) * 100);
                const isSelected = !!reqItem.userId && filters.requesterId === reqItem.userId;
                const pct = filteredRequests.length > 0 ? Math.round((reqItem.count / filteredRequests.length) * 100) : 0;

                return (
                  <div
                    key={reqItem.name}
                    onClick={() => {
                      if (reqItem.userId) {
                        setFilters((prev) => ({
                          ...prev,
                          requesterId: prev.requesterId === reqItem.userId ? 'all' : reqItem.userId,
                        }));
                      }
                    }}
                    className={`p-2.5 rounded-xl border transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-emerald-50/80 border-[#065F46] ring-1 ring-[#065F46] shadow-2xs'
                        : 'bg-slate-50/60 hover:bg-slate-100/70 border-slate-200/80'
                    }`}
                    title={
                      isIndonesian
                        ? `Filter analitik untuk pemohon ${reqItem.name}`
                        : `Filter analytics for requestor ${reqItem.name}`
                    }
                  >
                    <div className="flex items-center justify-between text-xs mb-1.5">
                      <div className="flex items-center gap-2 min-w-0 flex-1 mr-2">
                        <div className="w-5 h-5 rounded-full bg-[#D1FAE5] text-[#065F46] font-bold text-[10px] flex items-center justify-center shrink-0 border border-[#A7F3D0]">
                          {reqItem.name.charAt(0)}
                        </div>
                        <span className="font-semibold text-slate-900 truncate">
                          {reqItem.name}
                        </span>
                      </div>
                      <div className="flex items-center gap-1.5 shrink-0">
                        <span className="font-mono text-slate-800 font-bold tabular-nums">
                          {reqItem.count} {isIndonesian ? 'permintaan' : reqItem.count === 1 ? 'request' : 'requests'}
                        </span>
                        <span className="text-[10px] font-semibold text-emerald-800 bg-emerald-100/80 px-1.5 py-0.5 rounded-md">
                          {pct}%
                        </span>
                      </div>
                    </div>
                    <div className="w-full h-2 rounded-full bg-slate-200/70 overflow-hidden">
                      <div
                        className="h-full rounded-full bg-gradient-to-r from-[#065F46] to-[#10B981] transition-all duration-300"
                        style={{ width: `${barWidth}%` }}
                      />
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
