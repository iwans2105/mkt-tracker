import React, { useState, useEffect, useRef, useCallback } from 'react';

interface AnimatedLoginIllustrationProps {
  focusedField: 'email' | 'password' | null;
  showPassword?: boolean;
  isLoading?: boolean;
  hasError?: boolean;
  isSuccess?: boolean;
  className?: string;
}

export const AnimatedLoginIllustration: React.FC<AnimatedLoginIllustrationProps> = ({
  focusedField,
  showPassword = false,
  isLoading = false,
  hasError = false,
  isSuccess = false,
  className = '',
}) => {
  const containerRef = useRef<HTMLDivElement>(null);

  // Parallax pointer tracking state (clamped to max ±6px horizontal, ±4px vertical)
  const [pointerOffset, setPointerOffset] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isPointerInside, setIsPointerInside] = useState(false);
  const [isTouchDevice, setIsTouchDevice] = useState(false);
  const [prefersReducedMotion, setPrefersReducedMotion] = useState(false);
  const [isTabVisible, setIsTabVisible] = useState(true);

  // Detect pointer capability & reduced motion preferences
  useEffect(() => {
    const pointerQuery = window.matchMedia('(pointer: fine)');
    const motionQuery = window.matchMedia('(prefers-reduced-motion: reduce)');

    setIsTouchDevice(!pointerQuery.matches);
    setPrefersReducedMotion(motionQuery.matches);

    const handlePointerChange = (e: MediaQueryListEvent) => setIsTouchDevice(!e.matches);
    const handleMotionChange = (e: MediaQueryListEvent) => setPrefersReducedMotion(e.matches);

    pointerQuery.addEventListener('change', handlePointerChange);
    motionQuery.addEventListener('change', handleMotionChange);

    const handleVisibilityChange = () => {
      setIsTabVisible(!document.hidden);
    };
    document.addEventListener('visibilitychange', handleVisibilityChange);

    return () => {
      pointerQuery.removeEventListener('change', handlePointerChange);
      motionQuery.removeEventListener('change', handleMotionChange);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, []);

  // Pointer move handler with rAF throttling
  const rafId = useRef<number | null>(null);

  const handlePointerMove = useCallback(
    (e: React.PointerEvent<HTMLDivElement>) => {
      if (isTouchDevice || prefersReducedMotion || !containerRef.current) return;

      const rect = containerRef.current.getBoundingClientRect();
      const relativeX = e.clientX - rect.left;
      const relativeY = e.clientY - rect.top;

      // Normalize coordinates [-1, 1] relative to center
      const normalizedX = ((relativeX / rect.width) * 2 - 1);
      const normalizedY = ((relativeY / rect.height) * 2 - 1);

      // Clamp max offsets: horizontal max 6px, vertical max 4px
      const targetX = Math.max(-6, Math.min(6, normalizedX * 6));
      const targetY = Math.max(-4, Math.min(4, normalizedY * 4));

      if (rafId.current !== null) {
        cancelAnimationFrame(rafId.current);
      }

      rafId.current = requestAnimationFrame(() => {
        setPointerOffset({ x: targetX, y: targetY });
      });
    },
    [isTouchDevice, prefersReducedMotion]
  );

  const handlePointerEnter = useCallback(() => {
    if (!isTouchDevice && !prefersReducedMotion) {
      setIsPointerInside(true);
    }
  }, [isTouchDevice, prefersReducedMotion]);

  const handlePointerLeave = useCallback(() => {
    if (rafId.current !== null) {
      cancelAnimationFrame(rafId.current);
    }
    setIsPointerInside(false);
    setPointerOffset({ x: 0, y: 0 });
  }, []);

  // Compute form interaction transform offsets
  let formOffsetX = 0;
  let formOffsetY = 0;
  let formRotate = 0;
  let formScale = 1;

  if (!prefersReducedMotion) {
    if (isSuccess) {
      formScale = 1.025;
      formOffsetY = -3;
    } else if (isLoading) {
      formScale = 0.99;
    } else if (hasError) {
      formOffsetX = -3;
    } else if (focusedField === 'password') {
      if (!showPassword) {
        // Privacy turn away from the right-hand login form:
        // Turns -3.5deg and shifts -6px to the left
        formRotate = -3.5;
        formOffsetX = -6;
      } else {
        // Show password returns character to attentive neutral position
        formRotate = 0;
        formOffsetX = 0;
      }
    } else if (focusedField === 'email') {
      // Gentle attentive lean toward the form (+3px to right)
      formOffsetX = 3;
      formScale = 1.015;
    }
  }

  // Combined total transform applied to illustration
  const totalX = (isPointerInside ? pointerOffset.x : 0) + formOffsetX;
  const totalY = (isPointerInside ? pointerOffset.y : 0) + formOffsetY;

  return (
    <div
      ref={containerRef}
      onPointerMove={handlePointerMove}
      onPointerEnter={handlePointerEnter}
      onPointerLeave={handlePointerLeave}
      className={`relative w-full h-64 sm:h-72 lg:h-80 my-3 sm:my-4 flex items-center justify-center select-none ${className}`}
      style={{ perspective: 1000 }}
    >
      {/* Layer A: Ambient Emerald Glow Behind the Desk */}
      <div
        aria-hidden="true"
        className={`absolute w-52 sm:w-64 h-32 sm:h-40 rounded-full bg-[#10B981]/25 blur-[45px] pointer-events-none transition-opacity duration-700 ${
          prefersReducedMotion || !isTabVisible
            ? 'opacity-25'
            : isLoading
            ? 'animate-pulse opacity-45'
            : 'animate-[marcommGlow_5.5s_easeInOut_infinite]'
        }`}
        style={{
          transform: `translate3d(${totalX * 0.4}px, ${totalY * 0.4}px, 0)`,
        }}
      />

      {/* Layer A: Interactive Illustration Container with Idle Floating and Parallax */}
      <div
        className={`relative z-10 w-full h-full flex items-center justify-center will-change-transform ${
          prefersReducedMotion || !isTabVisible
            ? ''
            : isLoading
            ? 'animate-[marcommWaitPulse_1.4s_easeInOut_infinite]'
            : 'animate-[marcommFloat_5.2s_easeInOut_infinite]'
        }`}
        style={{
          transform: prefersReducedMotion
            ? 'none'
            : `translate3d(${totalX}px, ${totalY}px, 0) rotate(${formRotate}deg) scale(${formScale})`,
          transition: isPointerInside
            ? 'transform 0.28s cubic-bezier(0.2, 0.8, 0.2, 1)'
            : 'transform 0.45s cubic-bezier(0.25, 1, 0.5, 1)',
        }}
      >
        <img
          src="/assets/aistudio/Forest_green_login_interface_Trans_b3501649.png"
          alt="MARCOMM Creative Desk Illustration"
          className="max-h-full max-w-full w-auto object-contain pointer-events-none select-none filter drop-shadow-md"
          loading="eager"
          decoding="async"
          onError={(e) => {
            const target = e.currentTarget;
            if (!target.src.includes('/public/')) {
              target.src = '/public/assets/aistudio/Forest_green_login_interface_Trans_b3501649.png';
            }
          }}
        />
      </div>

      {/* Embedded High-Performance Keyframe Animations */}
      <style>{`
        @keyframes marcommFloat {
          0%, 100% {
            transform: translateY(0px);
          }
          50% {
            transform: translateY(-4px);
          }
        }

        @keyframes marcommGlow {
          0%, 100% {
            opacity: 0.22;
            transform: scale(0.96);
          }
          50% {
            opacity: 0.38;
            transform: scale(1.05);
          }
        }

        @keyframes marcommWaitPulse {
          0%, 100% {
            transform: scale(1);
          }
          50% {
            transform: scale(0.985);
          }
        }
      `}</style>
    </div>
  );
};
