import React, { useState } from 'react';
import { Eye, EyeOff, AlertCircle, X, CheckCircle2, RefreshCw } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useLanguage } from '../../context/LanguageContext';
import { AnimatedLoginIllustration } from './AnimatedLoginIllustration';

export const LoginPage: React.FC = () => {
  const { login, forgotPassword, resetPassword } = useAuth();
  const { language, setLanguage } = useLanguage();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [focusedField, setFocusedField] = useState<'email' | 'password' | null>(null);
  const [isSuccess, setIsSuccess] = useState(false);

  // Forgot password modal state
  const [isForgotModalOpen, setIsForgotModalOpen] = useState(false);
  const [forgotEmail, setForgotEmail] = useState('');
  const [forgotSubmitting, setForgotSubmitting] = useState(false);
  const [forgotNotice, setForgotNotice] = useState<string | null>(null);
  const [showTokenReset, setShowTokenReset] = useState(false);
  const [resetToken, setResetToken] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [resetSuccess, setResetSuccess] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!email.trim()) {
      setErrorMessage(
        language === 'id' ? 'Silakan masukkan alamat email.' : 'Please enter your email address.'
      );
      return;
    }

    if (!password) {
      setErrorMessage(
        language === 'id' ? 'Silakan masukkan password.' : 'Please enter your password.'
      );
      return;
    }

    setIsLoading(true);
    try {
      const res = await login(email.trim(), password);
      if (res.success) {
        setIsSuccess(true);
      } else {
        setErrorMessage(
          res.error ||
            (language === 'id' ? 'Email atau password tidak sesuai.' : 'Invalid email or password.')
        );
      }
    } catch {
      setErrorMessage(
        language === 'id'
          ? 'Koneksi bermasalah. Silakan coba kembali.'
          : 'Network error. Please try again.'
      );
    } finally {
      setIsLoading(false);
    }
  };

  const handleForgotPasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!forgotEmail.trim()) return;
    setForgotSubmitting(true);
    try {
      const res = await forgotPassword(forgotEmail.trim());
      setForgotNotice(res.message);
    } finally {
      setForgotSubmitting(false);
    }
  };

  const handleResetPasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!forgotEmail.trim() || !resetToken.trim() || !newPassword.trim()) return;
    setForgotSubmitting(true);
    try {
      const res = await resetPassword(forgotEmail.trim(), resetToken.trim(), newPassword.trim());
      if (res.success) {
        setResetSuccess(res.message);
        setTimeout(() => {
          setIsForgotModalOpen(false);
          setEmail(forgotEmail);
          setPassword(newPassword);
          setResetSuccess(null);
          setForgotNotice(null);
          setShowTokenReset(false);
        }, 1500);
      } else {
        setForgotNotice(
          res.error || (language === 'id' ? 'Gagal mereset password.' : 'Failed to reset password.')
        );
      }
    } finally {
      setForgotSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen w-full bg-[#F7FAF8] flex items-center justify-center p-4 sm:p-6 lg:p-10 relative overflow-hidden selection:bg-[#065F46] selection:text-white font-sans">
      {/* Subtle Ambient Glows matching screenshot */}
      <div
        className="absolute top-0 right-0 w-[500px] h-[500px] bg-purple-200/40 rounded-full blur-[120px] pointer-events-none -mr-40 -mt-40"
        aria-hidden="true"
      />
      <div
        className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-emerald-200/30 rounded-full blur-[140px] pointer-events-none -ml-40 -mb-40"
        aria-hidden="true"
      />

      {/* Language Switcher Float */}
      <div className="absolute top-5 right-5 z-20 flex items-center gap-2 bg-white/90 backdrop-blur-xs border border-slate-200/80 rounded-full px-3 py-1.5 shadow-2xs text-xs font-semibold text-slate-600">
        <button
          type="button"
          onClick={() => setLanguage('id')}
          className={`px-2 py-0.5 rounded-full transition-colors ${
            language === 'id' ? 'bg-[#065F46] text-white shadow-2xs' : 'hover:text-slate-900'
          }`}
        >
          ID
        </button>
        <span className="text-slate-300">|</span>
        <button
          type="button"
          onClick={() => setLanguage('en')}
          className={`px-2 py-0.5 rounded-full transition-colors ${
            language === 'en' ? 'bg-[#065F46] text-white shadow-2xs' : 'hover:text-slate-900'
          }`}
        >
          EN
        </button>
      </div>

      {/* Main Centered White Container */}
      <div className="bg-white rounded-[28px] sm:rounded-[36px] shadow-2xl border border-slate-200/60 p-4 sm:p-6 lg:p-8 max-w-4xl w-full grid grid-cols-1 lg:grid-cols-12 gap-6 sm:gap-8 relative z-10">
        {/* Left Branding Panel (Deep Forest Emerald) */}
        <div className="lg:col-span-6 bg-[#065F46] rounded-[24px] sm:rounded-[30px] p-6 sm:p-8 text-white flex flex-col justify-between overflow-hidden relative shadow-inner min-h-[380px] lg:min-h-[540px]">
          <div>
            <h1 className="text-xl sm:text-2xl font-extrabold tracking-tight text-white leading-tight">
              MARCOMM TASK AND
              <br />
              REQUEST TRACKER
            </h1>
            <p className="text-xs sm:text-[13px] text-emerald-50/90 mt-3 sm:mt-4 leading-relaxed font-normal max-w-xs">
              {language === 'id'
                ? 'Pelacakan tugas, manajemen penugasan kreatif, peninjauan, revisi, dan analitik SLA untuk Divisi Marketing Communications.'
                : 'Task tracking, creative assignment management, reviews, revisions, and SLA analytics for the Marketing Communications Division.'}
            </p>
          </div>

          {/* Interactive Animated Creative Desk Illustration */}
          <AnimatedLoginIllustration
            focusedField={focusedField}
            showPassword={showPassword}
            isLoading={isLoading}
            hasError={Boolean(errorMessage)}
            isSuccess={isSuccess}
          />

          {/* Footer Subtext */}
          <div className="pt-2 text-[11px] text-emerald-200/80 font-medium flex items-center justify-between border-t border-emerald-500/20">
            <span>PT Lyman Devindo</span>
            <span>{language === 'id' ? 'Divisi Marcomm' : 'Marcomm Division'}</span>
          </div>
        </div>

        {/* Right Login Form Panel */}
        <div className="lg:col-span-6 flex flex-col justify-center px-2 sm:px-6 py-4 sm:py-6">
          <div className="mb-6 sm:mb-8 flex flex-col sm:flex-row items-center lg:items-center justify-center lg:justify-start gap-3 text-center lg:text-left">
            <img
              src="/assets/aistudio/Marcom-Task-Request-Tracker_cfd946e5.png"
              alt="MARCOMM Task-Request Tracker"
              className="w-12 h-12 object-contain shrink-0 select-none"
              loading="eager"
              decoding="async"
              onError={(e) => {
                const target = e.currentTarget;
                if (!target.src.includes('/public/')) {
                  target.src = '/public/assets/aistudio/Marcom-Task-Request-Tracker_cfd946e5.png';
                }
              }}
            />
            <div>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-[#1E293B] tracking-tight">
                MARCOMM TASK
              </h2>
              <p className="text-xs sm:text-sm text-slate-400 mt-0.5 font-normal">
                {language === 'id' ? 'Silakan login ke akun Anda' : 'Please Login to your account'}
              </p>
            </div>
          </div>

          {/* Error Banner */}
          {errorMessage && (
            <div className="mb-5 p-3.5 bg-rose-50 border border-rose-200 rounded-xl text-rose-700 text-xs flex items-start gap-2.5 animate-in fade-in duration-150">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-rose-600" />
              <div className="leading-relaxed font-medium">{errorMessage}</div>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Email Field */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5 sr-only">
                Email
              </label>
              <div className="relative">
                <input
                  type="email"
                  value={email}
                  onChange={(e) => {
                    setEmail(e.target.value);
                    if (errorMessage) setErrorMessage(null);
                  }}
                  onFocus={() => setFocusedField('email')}
                  onBlur={() => setFocusedField((cur) => (cur === 'email' ? null : cur))}
                  placeholder="Email"
                  autoComplete="email"
                  className="w-full px-4 py-3.5 bg-[#F8FAFC] border border-slate-200/90 rounded-xl text-xs sm:text-sm text-slate-800 placeholder-slate-400 focus:bg-white focus:outline-none focus:border-[#065F46] focus:ring-2 focus:ring-[#065F46]/20 transition-all font-normal"
                />
              </div>
            </div>

            {/* Password Field */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5 sr-only">
                Password
              </label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => {
                    setPassword(e.target.value);
                    if (errorMessage) setErrorMessage(null);
                  }}
                  onFocus={() => setFocusedField('password')}
                  onBlur={() => setFocusedField((cur) => (cur === 'password' ? null : cur))}
                  placeholder="Password"
                  autoComplete="current-password"
                  className="w-full px-4 py-3.5 pr-11 bg-[#F8FAFC] border border-slate-200/90 rounded-xl text-xs sm:text-sm text-slate-800 placeholder-slate-400 focus:bg-white focus:outline-none focus:border-[#065F46] focus:ring-2 focus:ring-[#065F46]/20 transition-all font-normal"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  aria-label={
                    showPassword
                      ? language === 'id'
                        ? 'Sembunyikan password'
                        : 'Hide password'
                      : language === 'id'
                      ? 'Tampilkan password'
                      : 'Show password'
                  }
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 transition-colors p-1"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Forgot Password Link */}
            <div className="flex justify-end pt-0.5">
              <button
                type="button"
                onClick={() => {
                  setForgotEmail(email);
                  setForgotNotice(null);
                  setIsForgotModalOpen(true);
                }}
                className="text-xs text-slate-400 hover:text-[#065F46] font-medium transition-colors"
              >
                {language === 'id' ? 'Lupa Password?' : 'Forgot Password'}
              </button>
            </div>

            {/* Large Green Login Button */}
            <div className="pt-2">
              <button
                type="submit"
                disabled={isLoading}
                className="w-full py-3.5 px-6 rounded-xl bg-[#065F46] hover:bg-[#044e39] text-white font-semibold text-sm shadow-xs hover:shadow-md transition-all active:scale-[0.99] disabled:opacity-70 disabled:cursor-not-allowed flex items-center justify-center gap-2 cursor-pointer"
              >
                {isLoading ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>
                      {language === 'id' ? 'Memverifikasi akun...' : 'Signing in...'}
                    </span>
                  </>
                ) : (
                  <span>{language === 'id' ? 'Masuk' : 'Login'}</span>
                )}
              </button>
            </div>
          </form>
        </div>
      </div>

      {/* Forgot Password Modal */}
      {isForgotModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-150">
          <div className="bg-white rounded-2xl p-6 max-w-md w-full border border-slate-200 shadow-2xl space-y-4 animate-in zoom-in-95 duration-150">
            <div className="flex items-start justify-between pb-3 border-b border-slate-200">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-[#065F46]" />
                <h3 className="text-sm sm:text-base font-bold text-slate-900">
                  {language === 'id' ? 'Pemulihan Password Akun' : 'Account Password Recovery'}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setIsForgotModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1 rounded-lg"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {resetSuccess ? (
              <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 text-xs flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                <span>{resetSuccess}</span>
              </div>
            ) : !showTokenReset ? (
              <form onSubmit={handleForgotPasswordSubmit} className="space-y-3.5 text-xs">
                <p className="text-slate-600 leading-relaxed">
                  {language === 'id'
                    ? 'Masukkan alamat email korporat Anda yang terdaftar pada sistem MARCOMM TASK untuk memverifikasi akun Anda.'
                    : 'Enter your corporate email address registered with MARCOMM TASK to initiate identity recovery.'}
                </p>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    {language === 'id' ? 'Email Terdaftar' : 'Registered Email'}
                  </label>
                  <input
                    type="email"
                    required
                    value={forgotEmail}
                    onChange={(e) => setForgotEmail(e.target.value)}
                    placeholder={language === 'id' ? 'nama@lyman.co.id' : 'name@lyman.co.id'}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:bg-white text-slate-900"
                  />
                </div>

                {forgotNotice && (
                  <div className="p-3 bg-blue-50 border border-blue-200 rounded-xl text-blue-800 leading-relaxed space-y-2">
                    <p>{forgotNotice}</p>
                    <div className="pt-1 border-t border-blue-200/80 flex items-center justify-between">
                      <span className="text-[11px] font-semibold text-blue-900">
                        {language === 'id' ? 'Punya Token Reset dari Admin?' : 'Have a Reset Token?'}
                      </span>
                      <button
                        type="button"
                        onClick={() => setShowTokenReset(true)}
                        className="text-[11px] font-bold text-blue-700 hover:underline"
                      >
                        {language === 'id' ? 'Masukkan Token' : 'Enter Token'}
                      </button>
                    </div>
                  </div>
                )}

                <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-200">
                  <button
                    type="button"
                    onClick={() => setIsForgotModalOpen(false)}
                    className="px-4 py-2 font-semibold text-slate-700 bg-white border border-slate-300 rounded-xl hover:bg-slate-50"
                  >
                    {language === 'id' ? 'Batal' : 'Cancel'}
                  </button>
                  <button
                    type="submit"
                    disabled={forgotSubmitting}
                    className="px-4 py-2 font-bold text-white bg-[#065F46] hover:bg-[#044e39] rounded-xl shadow-xs"
                  >
                    {forgotSubmitting
                      ? language === 'id'
                        ? 'Memproses...'
                        : 'Processing...'
                      : language === 'id'
                      ? 'Kirim Permintaan'
                      : 'Submit Request'}
                  </button>
                </div>
              </form>
            ) : (
              <form onSubmit={handleResetPasswordSubmit} className="space-y-3.5 text-xs">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Email</label>
                  <input
                    type="email"
                    readOnly
                    value={forgotEmail}
                    className="w-full p-2.5 bg-slate-100 border border-slate-300 rounded-xl text-slate-700 font-mono"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    {language === 'id' ? 'Token Pemulihan' : 'Recovery Token'}
                  </label>
                  <input
                    type="text"
                    required
                    value={resetToken}
                    onChange={(e) => setResetToken(e.target.value)}
                    placeholder={
                      language === 'id'
                        ? 'Masukkan token dari Administrator...'
                        : 'Enter token from Administrator...'
                    }
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:bg-white text-slate-900 font-mono"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    {language === 'id'
                      ? 'Password Baru (min. 8 karakter)'
                      : 'New Password (min 8 characters)'}
                  </label>
                  <input
                    type="password"
                    required
                    minLength={8}
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    placeholder={language === 'id' ? 'Password baru...' : 'New password...'}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:bg-white text-slate-900"
                  />
                </div>

                <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-200">
                  <button
                    type="button"
                    onClick={() => setShowTokenReset(false)}
                    className="px-3 py-2 text-slate-600 hover:text-slate-800"
                  >
                    {language === 'id' ? 'Kembali' : 'Back'}
                  </button>
                  <button
                    type="submit"
                    disabled={forgotSubmitting}
                    className="px-4 py-2 font-bold text-white bg-[#065F46] hover:bg-[#044e39] rounded-xl shadow-xs"
                  >
                    {forgotSubmitting
                      ? language === 'id'
                        ? 'Menyimpan...'
                        : 'Saving...'
                      : language === 'id'
                      ? 'Perbarui Password'
                      : 'Update Password'}
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
