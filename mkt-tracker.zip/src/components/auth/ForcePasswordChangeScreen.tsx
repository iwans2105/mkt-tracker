import React, { useState } from 'react';
import { ShieldAlert, CheckCircle2, Lock, KeyRound, LogOut, Sparkles } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useLanguage } from '../../context/LanguageContext';
import { PasswordInput, generateStrongPassword } from '../common/PasswordInput';

export const ForcePasswordChangeScreen: React.FC = () => {
  const { currentUser, changePassword, logout } = useAuth();
  const { isIndonesian } = useLanguage();

  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmNewPassword, setConfirmNewPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  const handleGeneratePassword = () => {
    const generated = generateStrongPassword();
    setNewPassword(generated);
    setConfirmNewPassword(generated);
    setErrorMsg('');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    if (!currentPassword || !newPassword || !confirmNewPassword) {
      setErrorMsg(
        isIndonesian
          ? 'Semua kolom password wajib diisi.'
          : 'All password fields are required.'
      );
      return;
    }

    if (newPassword.length < 12) {
      setErrorMsg(
        isIndonesian
          ? 'Password baru minimal 12 karakter untuk standar keamanan PT Lyman Devindo.'
          : 'New password must be at least 12 characters to meet PT Lyman Devindo security standards.'
      );
      return;
    }

    if (newPassword !== confirmNewPassword) {
      setErrorMsg(
        isIndonesian
          ? 'Konfirmasi password baru tidak cocok.'
          : 'New password confirmation does not match.'
      );
      return;
    }

    if (currentPassword === newPassword) {
      setErrorMsg(
        isIndonesian
          ? 'Password baru tidak boleh sama dengan password saat ini.'
          : 'New password cannot be the same as your current password.'
      );
      return;
    }

    setIsLoading(true);
    try {
      const res = await changePassword(currentPassword, newPassword, confirmNewPassword);
      if (res.success) {
        setSuccessMsg(
          res.message ||
            (isIndonesian
              ? 'Password berhasil diperbarui! Mengalihkan ke sistem...'
              : 'Password updated successfully! Redirecting...')
        );
      } else {
        setErrorMsg(
          res.error ||
            (isIndonesian
              ? 'Gagal mengubah password. Silakan periksa password saat ini.'
              : 'Failed to change password. Please verify your current password.')
        );
      }
    } catch {
      setErrorMsg(
        isIndonesian
          ? 'Koneksi bermasalah. Silakan coba kembali.'
          : 'Network error. Please try again.'
      );
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#F7FAF8] flex items-center justify-center p-4">
      <div className="w-full max-w-lg bg-white rounded-3xl shadow-xl border border-slate-200 overflow-hidden">
        {/* Header Banner */}
        <div className="bg-[#065F46] p-6 text-white text-center relative">
          <div className="w-14 h-14 rounded-2xl bg-white/10 backdrop-blur-xs flex items-center justify-center mx-auto mb-3 border border-white/20">
            <KeyRound className="w-7 h-7 text-emerald-300" />
          </div>
          <h1 className="text-xl font-bold tracking-tight">
            {isIndonesian ? 'Pembaruan Password Wajib' : 'Mandatory Password Update'}
          </h1>
          <p className="text-xs text-emerald-100/90 mt-1 max-w-sm mx-auto">
            {isIndonesian
              ? 'MARCOMM TASK — Keamanan Enterprise PT Lyman Devindo'
              : 'MARCOMM TASK — PT Lyman Devindo Enterprise Security'}
          </p>
        </div>

        {/* Content Body */}
        <div className="p-6 sm:p-8 space-y-6">
          <div className="p-4 bg-amber-50 rounded-2xl border border-amber-200/80 flex items-start gap-3 text-xs text-amber-900 leading-relaxed">
            <ShieldAlert className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
            <div>
              <strong className="block font-bold">
                {isIndonesian ? 'Akses Modul Sementara Ditangguhkan' : 'Module Access Temporarily Paused'}
              </strong>
              <span>
                {isIndonesian ? (
                  <>
                    Administrator mewajibkan akun <strong>{currentUser.email}</strong> untuk memperbarui password sebelum melanjutkan akses operasional.
                  </>
                ) : (
                  <>
                    Administrator requires account <strong>{currentUser.email}</strong> to update its password before continuing operations.
                  </>
                )}
              </span>
            </div>
          </div>

          {errorMsg && (
            <div className="p-3.5 bg-rose-50 text-rose-700 text-xs font-semibold rounded-xl border border-rose-200">
              {errorMsg}
            </div>
          )}

          {successMsg && (
            <div className="p-3.5 bg-emerald-50 text-emerald-800 text-xs font-semibold rounded-xl border border-emerald-200 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{successMsg}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <PasswordInput
              id="force-current-password"
              label={isIndonesian ? 'Password Saat Ini / Sementara' : 'Current / Temporary Password'}
              value={currentPassword}
              onChange={setCurrentPassword}
              placeholder={isIndonesian ? 'Masukkan password saat ini' : 'Enter current password'}
              required
              disabled={isLoading}
            />

            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <span className="text-[11px] text-slate-500 font-medium">
                  {isIndonesian
                    ? 'Buat password kuat minimal 12 karakter:'
                    : 'Create a strong password (min. 12 characters):'}
                </span>
                <button
                  type="button"
                  onClick={handleGeneratePassword}
                  className="text-[11px] font-bold text-emerald-700 hover:text-emerald-900 flex items-center gap-1 hover:underline"
                >
                  <Sparkles className="w-3 h-3 text-emerald-600" />
                  <span>{isIndonesian ? 'Buat Password Otomatis' : 'Generate Password'}</span>
                </button>
              </div>

              <PasswordInput
                id="force-new-password"
                label={isIndonesian ? 'Password Baru' : 'New Password'}
                value={newPassword}
                onChange={setNewPassword}
                placeholder={isIndonesian ? 'Minimal 12 karakter unik' : 'Minimum 12 unique characters'}
                required
                showStrength
                disabled={isLoading}
              />
            </div>

            <PasswordInput
              id="force-confirm-password"
              label={isIndonesian ? 'Konfirmasi Password Baru' : 'Confirm New Password'}
              value={confirmNewPassword}
              onChange={setConfirmNewPassword}
              placeholder={isIndonesian ? 'Ulangi password baru' : 'Repeat new password'}
              required
              disabled={isLoading}
              error={
                confirmNewPassword && newPassword !== confirmNewPassword
                  ? isIndonesian
                    ? 'Konfirmasi password tidak cocok'
                    : 'Password confirmation does not match'
                  : undefined
              }
            />

            <div className="pt-2 flex flex-col sm:flex-row items-center gap-3">
              <button
                type="submit"
                disabled={isLoading || (confirmNewPassword.length > 0 && newPassword !== confirmNewPassword)}
                className="w-full sm:flex-1 py-3 px-5 text-xs font-bold text-white bg-[#065F46] hover:bg-[#044e39] disabled:bg-slate-300 rounded-xl transition-all shadow-md active:scale-[0.99] flex items-center justify-center gap-2"
              >
                <Lock className="w-3.5 h-3.5" />
                <span>
                  {isLoading
                    ? isIndonesian
                      ? 'Menyimpan Password...'
                      : 'Saving Password...'
                    : isIndonesian
                    ? 'Simpan Password & Masuk'
                    : 'Save Password & Continue'}
                </span>
              </button>

              <button
                type="button"
                onClick={() => logout()}
                className="w-full sm:w-auto py-3 px-4 text-xs font-semibold text-slate-600 hover:text-rose-600 hover:bg-rose-50 rounded-xl transition-colors flex items-center justify-center gap-1.5"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>{isIndonesian ? 'Keluar' : 'Logout'}</span>
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
