import React, { useState, useEffect } from 'react';
import {
  Layers,
  AlertTriangle,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  Clock,
} from 'lucide-react';
import { BrandQuotaSummary, RequestPriority } from '../../types';
import { useRequests } from '../../context/RequestContext';
import { useAuth } from '../../context/AuthContext';
import { useLanguage } from '../../context/LanguageContext';

interface PriorityQuotaWidgetProps {
  onNavigateToQuotaSettings?: () => void;
}

export const PriorityQuotaWidget: React.FC<PriorityQuotaWidgetProps> = ({
  onNavigateToQuotaSettings,
}) => {
  const { brands, fetchAllBrandQuotas, syncVersion } = useRequests();
  const { isAdmin, isSuperAdmin } = useAuth();
  const { language } = useLanguage();

  const [summaries, setSummaries] = useState<BrandQuotaSummary[]>([]);
  const [selectedBrandId, setSelectedBrandId] = useState<string>(brands[0]?.id || 'brand-wahoo');
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (brands.length > 0 && !brands.some((b) => b.id === selectedBrandId)) {
      setSelectedBrandId(brands[0].id);
    }
  }, [brands, selectedBrandId]);

  useEffect(() => {
    let isMounted = true;
    const load = async () => {
      setIsLoading(true);
      try {
        const data = await fetchAllBrandQuotas();
        if (isMounted) {
          setSummaries(data);
        }
      } finally {
        if (isMounted) setIsLoading(false);
      }
    };
    load();
    return () => {
      isMounted = false;
    };
  }, [fetchAllBrandQuotas, syncVersion, brands.length]);

  const activeSummary = summaries.find((s) => s.brandId === selectedBrandId) || summaries[0];
  const totalWarningBrands = summaries.filter((s) => s.warningCount > 0 || s.exhaustedCount > 0);

  return (
    <div className="p-5 sm:p-6 bg-white rounded-2xl border border-slate-200 shadow-xs space-y-4">
      {/* Widget Header */}
      <div className="flex items-center justify-between flex-wrap gap-2 pb-3 border-b border-slate-100">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-emerald-50 text-[#065F46] flex items-center justify-center border border-emerald-200">
            <Layers className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-900">
              {language === 'id' ? 'Ringkasan Kuota Prioritas Tahunan' : 'Annual Priority Quota Overview'}
            </h3>
            <p className="text-[11px] text-slate-500">
              {language === 'id'
                ? 'Pantau sisa kuota prioritas Mendesak, Tinggi, dan Sedang per entitas Brand.'
                : 'Track remaining Urgent, High, and Medium priority allowances per brand entity.'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Brand Switcher */}
          <select
            value={selectedBrandId}
            onChange={(e) => setSelectedBrandId(e.target.value)}
            className="px-2.5 py-1 text-xs font-semibold bg-slate-50 border border-slate-200 rounded-lg text-slate-800"
          >
            {brands.map((b) => (
              <option key={b.id} value={b.id}>
                {b.name}
              </option>
            ))}
          </select>

          {(isAdmin || isSuperAdmin) && onNavigateToQuotaSettings && (
            <button
              type="button"
              onClick={onNavigateToQuotaSettings}
              className="px-2.5 py-1 text-xs font-semibold text-[#065F46] bg-emerald-50 hover:bg-emerald-100 rounded-lg border border-emerald-200 transition-colors flex items-center gap-1"
            >
              <span>{language === 'id' ? 'Kelola' : 'Manage'}</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          )}
        </div>
      </div>

      {/* Warnings Banner if any brand is low/exhausted */}
      {totalWarningBrands.length > 0 && (
        <div className="p-3 bg-amber-50/70 border border-amber-200 rounded-xl flex items-center justify-between text-xs text-amber-900 gap-2">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
            <span className="font-medium text-[11px]">
              {language === 'id'
                ? `${totalWarningBrands.length} Brand memiliki kuota prioritas yang menipis (≤1 unit tersisa) atau telah habis.`
                : `${totalWarningBrands.length} Brand entities have low priority quotas (≤1 remaining) or exhausted limits.`}
            </span>
          </div>
          <span className="text-[10px] font-mono font-bold bg-amber-100 px-2 py-0.5 rounded border border-amber-300">
            {language === 'id' ? 'Perlu Perhatian' : 'Attention Needed'}
          </span>
        </div>
      )}

      {/* Active Brand Priority Bars */}
      {activeSummary ? (
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {(['urgent', 'high', 'medium'] as RequestPriority[]).map((prio) => {
            const info = activeSummary.priorities[prio];
            const isExhausted = Boolean(info?.isExhausted);
            const isWarning = info?.remaining === 1;
            const prioLabel =
              language === 'id'
                ? prio === 'urgent'
                  ? 'Mendesak'
                  : prio === 'high'
                  ? 'Tinggi'
                  : 'Sedang'
                : prio;

            return (
              <div
                key={prio}
                className={`p-3.5 rounded-xl border bg-slate-50/60 space-y-2 ${
                  isExhausted
                    ? 'border-rose-200 bg-rose-50/20'
                    : isWarning
                    ? 'border-amber-200 bg-amber-50/20'
                    : 'border-slate-200'
                }`}
              >
                <div className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-1.5 font-bold capitalize text-slate-800">
                    <span
                      className={`w-2 h-2 rounded-full ${
                        prio === 'urgent'
                          ? 'bg-rose-500'
                          : prio === 'high'
                          ? 'bg-amber-500'
                          : 'bg-blue-500'
                      }`}
                    />
                    <span>{prioLabel}</span>
                  </div>
                  <span className="text-[10px] font-mono text-slate-500">
                    {language === 'id' ? `SLA ${info.slaDays} Hari` : `${info.slaDays} Day SLA`}
                  </span>
                </div>

                <div className="flex items-baseline justify-between text-xs">
                  <span className="text-xl font-extrabold font-mono text-slate-900">
                    {info.remaining}{' '}
                    <span className="text-[11px] font-normal text-slate-400">
                      / {info.annualLimit}
                    </span>
                  </span>
                  <span
                    className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                      isExhausted
                        ? 'bg-rose-100 text-rose-800 border border-rose-200'
                        : isWarning
                        ? 'bg-amber-100 text-amber-800 border border-amber-200'
                        : 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                    }`}
                  >
                    {isExhausted
                      ? language === 'id'
                        ? 'Habis'
                        : 'Exhausted'
                      : isWarning
                      ? language === 'id'
                        ? 'Sisa 1'
                        : '1 Left'
                      : language === 'id'
                      ? 'Tersedia'
                      : 'Available'}
                  </span>
                </div>

                {/* Progress bar */}
                <div className="w-full h-1.5 rounded-full bg-slate-200 overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all duration-300 ${
                      isExhausted
                        ? 'bg-rose-500'
                        : isWarning
                        ? 'bg-amber-500'
                        : 'bg-[#10B981]'
                    }`}
                    style={{ width: `${info.utilizationPercent}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="py-4 text-center text-xs text-slate-400 italic">
          {isLoading
            ? language === 'id'
              ? 'Memuat kuota prioritas...'
              : 'Loading priority quotas...'
            : language === 'id'
            ? 'Belum ada data kuota.'
            : 'No quota data available.'}
        </div>
      )}
    </div>
  );
};
