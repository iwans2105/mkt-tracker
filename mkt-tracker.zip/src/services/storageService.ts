import {
  Team,
  RequestItem,
  AnalyticsSummary,
  Attachment,
} from '../types';
import { computeDynamicWorkItems } from '../utils/workItemCounting';
import { getClientCsrfToken } from './csrfStore';

const LEGACY_KEYS = {
  REGIONS: 'marcomm_regions_v1',
  BRANDS: 'marcomm_brands_v1',
  UNITS: 'marcomm_units_v1',
  DEPARTMENTS: 'marcomm_departments_v1',
  CATEGORIES: 'marcomm_categories_v2',
  TEAMS: 'marcomm_teams_v2',
  USERS: 'marcomm_users_v1',
  REQUESTS_PROD: 'marcomm_requests_prod_v1',
  REQUESTS_LEGACY: 'marcomm_requests_v1',
  COMMENTS_PROD: 'marcomm_comments_prod_v1',
  COMMENTS_LEGACY: 'marcomm_comments_v1',
  LOGS_PROD: 'marcomm_logs_prod_v1',
  LOGS_LEGACY: 'marcomm_logs_v1',
  QUOTAS: 'marcomm_priority_quotas_v1',
};

function safeReadLocalJson<T>(key: string): T | null {
  try {
    if (typeof localStorage === 'undefined') return null;
    const raw = localStorage.getItem(key);
    if (!raw) return null;
    return JSON.parse(raw) as T;
  } catch {
    return null;
  }
}

export interface R2UploadOptions {
  scopeType: 'brief' | 'deliverable' | 'subitem' | 'avatar';
  brandId?: string;
  regionId?: string;
  requestId?: string;
  subItemId?: string;
}

export class StorageService {
  // Region normalization helper
  static normalizeRegionName(name?: string): string {
    if (!name) return '';
    return name.replace(/^Wilayah\s+/i, '').trim();
  }

  static normalizeTeam(team: Team): Team {
    let name = team.name;
    let description = team.description;

    if (team.id === 'team-design' || name === 'Design Graphic') {
      name = 'Graphic Design';
      if (/penanganan|grafis/i.test(description)) {
        description =
          'Visual branding, digital & print layout design, marketing collateral, and motion graphics production.';
      }
    } else if (team.id === 'team-socmed-doc' || name === 'Social Media & Dokumentasi') {
      name = 'Social Media & Documentation';
      if (/manajemen|peliputan/i.test(description)) {
        description =
          'Social media channel management, video reels/feed production, editorial schedules, and photo & video event coverage.';
      }
    } else if (team.id === 'team-digital-marketing' || name === 'Digital Marketing') {
      name = 'Digital Marketing';
      if (/pengelolaan|periklanan/i.test(description)) {
        description =
          'Multi-platform advertising campaigns (Google Ads & Meta Ads), search engine optimization (SEO), and conversion analytics.';
      }
    } else if (team.id === 'team-it-support' || name === 'IT Support') {
      name = 'IT Support & Systems';
      if (/dukungan|teknis/i.test(description)) {
        description =
          'Technical infrastructure, digital portal management, media asset hosting, and marcomm application support.';
      }
    }

    return { ...team, name, description };
  }

  // Category normalization: aligns with the 7 Task Categories
  static normalizeCategoryName(name?: string, id?: string): string {
    if (id === 'cat-graphic') return 'Graphic Design';
    if (id === 'cat-motion') return 'Motion Graphics & Video Editing';
    if (id === 'cat-socmed') return 'Social Media Management';
    if (id === 'cat-doc') return 'Photo & Video Documentation';
    if (id === 'cat-digital') return 'Digital Marketing';
    if (id === 'cat-it') return 'IT Support';
    if (id === 'cat-other') return 'Other Requests';

    const n = (name || '').trim();
    if (!n) return 'Other Requests';
    if (/^graphic/i.test(n) || /desain grafis/i.test(n) || /design graphic/i.test(n)) return 'Graphic Design';
    if (/motion|video editing/i.test(n)) return 'Motion Graphics & Video Editing';
    if (/social media|socmed|sosmed/i.test(n)) return 'Social Media Management';
    if (/foto|photo|dokumentasi|documentation/i.test(n)) return 'Photo & Video Documentation';
    if (/digital marketing|marketing digital|ads/i.test(n)) return 'Digital Marketing';
    if (/it support|helpdesk|portal/i.test(n)) return 'IT Support';
    if (/other|lainnya/i.test(n)) return 'Other Requests';

    return n;
  }

  // Competency normalization: aligns with the 7 Task Categories & prevents duplicates
  static normalizeCompetencies(competencies?: string[]): string[] {
    if (!competencies || !Array.isArray(competencies)) return [];
    const mapped = competencies.map((comp) => {
      const c = (comp || '').trim();
      return StorageService.normalizeCategoryName(c);
    });
    return Array.from(new Set(mapped.filter(Boolean)));
  }

  // Upload file directly to Cloudflare R2 private storage via Workers API
  static async uploadFileToR2(
    file: File,
    opts: R2UploadOptions,
    csrfToken?: string | null
  ): Promise<Attachment> {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('scopeType', opts.scopeType);
    if (opts.brandId) formData.append('brandId', opts.brandId);
    if (opts.regionId) formData.append('regionId', opts.regionId);
    if (opts.requestId) formData.append('requestId', opts.requestId);
    if (opts.subItemId) formData.append('subItemId', opts.subItemId);

    const token = csrfToken ?? getClientCsrfToken();
    const res = await fetch('/api/files/upload', {
      method: 'POST',
      headers: token ? { 'X-CSRF-Token': token } : {},
      credentials: 'include',
      cache: 'no-store',
      body: formData,
    });

    const data = await res.json().catch(() => ({}));
    if (!res.ok || !data.success || !data.file) {
      throw new Error(data.error || `Gagal mengunggah file "${file.name}" ke penyimpanan R2.`);
    }

    return data.file as Attachment;
  }

  // Read-only browser localStorage snapshot exporter for multi-device migration into D1/R2.
  // Never mutates or deletes any legacy localStorage keys; strips session tokens and plaintext credentials.
  static exportLocalStorageSnapshot(deviceLabel: string = 'browser-snapshot'): {
    schemaVersion: string;
    deviceLabel: string;
    exportedAt: string;
    recordCounts: {
      requests: number;
      comments: number;
      activityLogs: number;
      users: number;
    };
    data: Record<string, unknown>;
  } {
    const prodReqs = safeReadLocalJson<any[]>(LEGACY_KEYS.REQUESTS_PROD) || [];
    const oldReqs = safeReadLocalJson<any[]>(LEGACY_KEYS.REQUESTS_LEGACY) || [];
    const reqMap = new Map<string, any>();
    for (const r of [...oldReqs, ...prodReqs]) {
      if (r?.id) reqMap.set(String(r.id), r);
    }

    const prodComments = safeReadLocalJson<any[]>(LEGACY_KEYS.COMMENTS_PROD) || [];
    const oldComments = safeReadLocalJson<any[]>(LEGACY_KEYS.COMMENTS_LEGACY) || [];
    const commentMap = new Map<string, any>();
    for (const c of [...oldComments, ...prodComments]) {
      if (c?.id) commentMap.set(String(c.id), c);
    }

    const prodLogs = safeReadLocalJson<any[]>(LEGACY_KEYS.LOGS_PROD) || [];
    const oldLogs = safeReadLocalJson<any[]>(LEGACY_KEYS.LOGS_LEGACY) || [];
    const logMap = new Map<string, any>();
    for (const l of [...oldLogs, ...prodLogs]) {
      if (l?.id) logMap.set(String(l.id), l);
    }

    const rawUsers = safeReadLocalJson<any[]>(LEGACY_KEYS.USERS) || [];
    const sanitizedUsers = rawUsers.map(({ passwordHash: _ph, ...rest }) => rest);

    const quotaStore = safeReadLocalJson<any>(LEGACY_KEYS.QUOTAS);
    const quotaPolicies: any[] = [];
    const quotaLedger: any[] = [];
    if (quotaStore && typeof quotaStore === 'object') {
      if (Array.isArray(quotaStore.policies)) quotaPolicies.push(...quotaStore.policies);
      if (Array.isArray(quotaStore.ledger)) quotaLedger.push(...quotaStore.ledger);
    }

    const requests = Array.from(reqMap.values());
    const comments = Array.from(commentMap.values());
    const activityLogs = Array.from(logMap.values());

    return {
      schemaVersion: 'legacy-browser-v1',
      deviceLabel,
      exportedAt: new Date().toISOString(),
      recordCounts: {
        requests: requests.length,
        comments: comments.length,
        activityLogs: activityLogs.length,
        users: sanitizedUsers.length,
      },
      data: {
        regions: safeReadLocalJson<any[]>(LEGACY_KEYS.REGIONS) || [],
        brands: safeReadLocalJson<any[]>(LEGACY_KEYS.BRANDS) || [],
        units: safeReadLocalJson<any[]>(LEGACY_KEYS.UNITS) || [],
        departments: safeReadLocalJson<any[]>(LEGACY_KEYS.DEPARTMENTS) || [],
        categories: safeReadLocalJson<any[]>(LEGACY_KEYS.CATEGORIES) || [],
        teams: safeReadLocalJson<any[]>(LEGACY_KEYS.TEAMS) || [],
        users: sanitizedUsers,
        requests,
        comments,
        activityLogs,
        quotaPolicies,
        quotaLedger,
      },
    };
  }

  // Analytics Computation with Dynamic Work Item Counting
  static computeAnalytics(filteredRequests: RequestItem[]): AnalyticsSummary {
    const totalRequests = filteredRequests.length;
    const workItems = computeDynamicWorkItems(filteredRequests);

    const completed = filteredRequests.filter((r) => r.status === 'completed');
    const completedRequests = completed.length;
    const activeRequests = filteredRequests.filter(
      (r) => r.status !== 'completed' && r.status !== 'cancelled'
    ).length;

    const nowStr = new Date().toISOString().split('T')[0];
    const overdueRequests = filteredRequests.filter((r) => {
      if (r.status === 'completed' || r.status === 'cancelled' || r.status === 'on_hold') return false;
      return r.committedDeadline && r.committedDeadline < nowStr;
    }).length;

    const unscheduledRequests = filteredRequests.filter(
      (r) => !r.committedDeadline && r.status !== 'cancelled'
    ).length;
    const onTrackRequests = filteredRequests.filter((r) => {
      if (r.status === 'completed' || r.status === 'cancelled' || r.status === 'on_hold') return false;
      if (!r.committedDeadline) return false;
      return r.committedDeadline >= nowStr;
    }).length;

    let avgCompletionDays: number | null = null;
    if (completedRequests > 0) {
      let totalDays = 0;
      let countWithDates = 0;
      for (const r of completed) {
        if (r.completedAt && r.createdAt) {
          const diffMs = new Date(r.completedAt).getTime() - new Date(r.createdAt).getTime();
          const days = Math.max(0.5, Math.round((diffMs / (1000 * 60 * 60 * 24)) * 10) / 10);
          totalDays += days;
          countWithDates++;
        }
      }
      if (countWithDates > 0) {
        avgCompletionDays = Math.round((totalDays / countWithDates) * 10) / 10;
      }
    }

    let slaFulfillmentRate: number | null = null;
    const completedWithCommittedDeadline = completed.filter((r) => r.committedDeadline);
    if (completedWithCommittedDeadline.length > 0) {
      const onTimeCount = completedWithCommittedDeadline.filter((r) => {
        if (r.slaFulfilled !== undefined) return r.slaFulfilled;
        if (!r.completedAt || !r.committedDeadline) return true;
        const compDate = r.completedAt.split('T')[0];
        return compDate <= r.committedDeadline;
      }).length;
      slaFulfillmentRate = Math.round((onTimeCount / completedWithCommittedDeadline.length) * 1000) / 10;
    }

    return {
      ...workItems,
      totalRequests,
      completedRequests,
      activeRequests,
      onTrackRequests,
      overdueRequests,
      unscheduledRequests,
      avgCompletionDays,
      slaFulfillmentRate,
    };
  }

  // Export CSV
  static exportRequestsToCsv(requests: RequestItem[], isIndonesian: boolean = true): void {
    const statusLabelsId: Record<string, string> = {
      todo: 'Antrean (To Do)',
      in_progress: 'Sedang Dikerjakan',
      pending_review: 'Menunggu Review',
      revision: 'Perlu Revisi',
      completed: 'Selesai Disetujui',
      on_hold: 'Ditunda (On Hold)',
      cancelled: 'Dibatalkan',
    };

    const statusLabelsEn: Record<string, string> = {
      todo: 'To Do / Backlog',
      in_progress: 'In Progress',
      pending_review: 'Pending Review',
      revision: 'Revision',
      completed: 'Completed',
      on_hold: 'On Hold',
      cancelled: 'Cancelled',
    };

    const priorityLabelsId: Record<string, string> = {
      urgent: 'Mendesak (1 Hari)',
      high: 'Tinggi (3 Hari)',
      medium: 'Sedang (7 Hari)',
      low: 'Rendah (14 Hari)',
    };

    const priorityLabelsEn: Record<string, string> = {
      urgent: 'Urgent (1 Day)',
      high: 'High (3 Days)',
      medium: 'Medium (7 Days)',
      low: 'Low (14 Days)',
    };

    const headers = isIndonesian
      ? [
          'No. Tiket',
          'Judul Permintaan',
          'Wilayah',
          'Brand / Entitas',
          'Unit Internal',
          'Departemen Pemohon',
          'Kategori',
          'Prioritas',
          'Status',
          'Nama Pemohon',
          'Tim Eksekusi',
          'Pelaksana Utama',
          'Reviewer',
          'Tenggat Diminta',
          'Tenggat Komitmen',
          'Status SLA',
          'Tanggal Dibuat',
          'Tanggal Selesai',
        ]
      : [
          'Ticket Number',
          'Title',
          'Region',
          'Brand / Entity',
          'Internal Unit',
          'Requester Department',
          'Category',
          'Priority',
          'Status',
          "Requestor's Name",
          'Assigned Team',
          'Primary Assignee',
          'Reviewer',
          'Requested Deadline',
          'Committed Deadline',
          'SLA Status',
          'Created Date',
          'Completed Date',
        ];

    const rows = requests.map((r) => {
      const slaStatus =
        r.status === 'completed'
          ? r.slaFulfilled
            ? isIndonesian
              ? 'Tepat Waktu (SLA Terpenuhi)'
              : 'On-Time (SLA Fulfilled)'
            : isIndonesian
            ? 'Selesai Terlambat'
            : 'Completed Late'
          : r.status === 'cancelled'
          ? isIndonesian
            ? `Dibatalkan (${r.cancelReason || 'Tanpa alasan'})`
            : `Cancelled (${r.cancelReason || 'No reason provided'})`
          : r.status === 'on_hold'
          ? isIndonesian
            ? `Ditunda (${r.holdReason || 'Dijeda'})`
            : `On Hold (${r.holdReason || 'Paused'})`
          : r.isOverdue
          ? isIndonesian
            ? 'Terlambat'
            : 'Overdue'
          : r.committedDeadline
          ? isIndonesian
            ? 'Sesuai Jadwal'
            : 'On-Track'
          : isIndonesian
          ? 'Belum Dijadwalkan'
          : 'Unscheduled';

      const priorityText = isIndonesian
        ? priorityLabelsId[r.priority] || r.priority.toUpperCase()
        : priorityLabelsEn[r.priority] || r.priority.toUpperCase();

      const statusText = isIndonesian
        ? statusLabelsId[r.status] || r.status
        : statusLabelsEn[r.status] || r.status;

      return [
        r.ticketNumber,
        `"${(r.title || '').replace(/"/g, '""')}"`,
        r.regionName,
        r.brandName,
        r.unitName || '-',
        r.requesterDepartment,
        r.categoryName,
        `"${priorityText}"`,
        `"${statusText}"`,
        `"${(r.requestorName || r.requesterName || '').replace(/"/g, '""')}"`,
        r.assignedTeamName || '-',
        r.primaryAssigneeName || '-',
        r.reviewerName || '-',
        r.requestedDeadline || '-',
        r.committedDeadline || '-',
        `"${slaStatus.replace(/"/g, '""')}"`,
        r.createdAt ? r.createdAt.split('T')[0] : '-',
        r.completedAt ? r.completedAt.split('T')[0] : '-',
      ];
    });

    const csvContent =
      '\uFEFF' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\r\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute(
      'download',
      `${isIndonesian ? 'Laporan_Permintaan_Marcomm_' : 'Marcomm_Requests_Report_'}${
        new Date().toISOString().split('T')[0]
      }.csv`
    );
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
}
