import { getClientCsrfToken } from './csrfStore';

// Client-side AI Service calling authenticated Cloudflare Worker Gemini endpoints

export interface RequestAssistantResult {
  title: string;
  recommendedCategory: string;
  recommendedPriority: 'urgent' | 'high' | 'medium' | 'low';
  slaRationale: string;
  description: string;
  deliverables: string[];
  technicalSpecs: string;
  tips: string;
}

export interface BriefAnalysisResult {
  completenessScore: number;
  clarityGrade: string;
  missingSpecs: string[];
  strengths: string[];
  recommendations: string[];
  revisionAnalysis?: {
    hasRevisionNotes: boolean;
    sentiment: string;
    actionableItems: string[];
  };
}

export interface AssignmentRecommendationResult {
  primaryAssignee: {
    name: string;
    matchScore: number;
    rationale: string;
  };
  collaborator: {
    name: string;
    role: string;
  };
  workloadNotice: string;
  reviewSuggestion: string;
}

export interface WorkloadOptimizerResult {
  capacityHealth: string;
  bottlenecks: string[];
  rebalancingRecommendations: Array<{
    from: string;
    to: string;
    suggestion: string;
  }>;
  operationalTips: string[];
}

export interface DeadlineRiskResult {
  riskLevel: 'low' | 'medium' | 'high' | 'critical';
  riskPercentage: number;
  summary: string;
  riskFactors: string[];
  mitigationActions: string[];
}

export interface CreativeAssistantResult {
  creativeConcept: string;
  headlines: string[];
  socialCaptions: {
    short: string;
    detailed: string;
  };
  hashtags: string[];
  artDirection: {
    colorPalette: string;
    visualElements: string;
    ctaWording: string;
  };
}

export interface ExecutiveInsightsResult {
  executiveHeadline: string;
  operationalVelocity: string;
  slaHealthDiagnosis: string;
  brandDemandTrends: string;
  topAchievements: string[];
  criticalRisks: string[];
  strategicRoadmap: string[];
}

export interface KnowledgeAssistantResult {
  answer: string;
}

async function postAiJson<T = any>(endpoint: string, payload: unknown, errorMessage: string): Promise<T> {
  const csrf = getClientCsrfToken();
  const res = await fetch(endpoint, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      ...(csrf ? { 'X-CSRF-Token': csrf } : {}),
    },
    credentials: 'include',
    cache: 'no-store',
    body: JSON.stringify(payload),
  });
  if (!res.ok) {
    const errBody = await res.json().catch(() => ({}));
    throw new Error(errBody.error || errorMessage);
  }
  return res.json();
}

export const AiService = {
  // 1. AI Request Assistant
  async getRequestAssistant(params: {
    prompt: string;
    brand?: string;
    category?: string;
    rawDescription?: string;
  }): Promise<RequestAssistantResult> {
    const data = await postAiJson<{ data: RequestAssistantResult }>(
      '/api/ai/request-assistant',
      params,
      'Failed to reach AI Request Assistant'
    );
    return data.data;
  },

  // 2. AI Brief & Feedback Analyzer
  async analyzeBrief(params: {
    title: string;
    description: string;
    deliverables: string;
    category?: string;
    comments?: string;
  }): Promise<BriefAnalysisResult> {
    const data = await postAiJson<{ data: BriefAnalysisResult }>(
      '/api/ai/analyze-brief',
      params,
      'Failed to analyze creative brief'
    );
    return data.data;
  },

  // 3. AI Task Assignment Recommendation
  async recommendAssignment(params: {
    category: string;
    brand: string;
    priority: string;
    availableMembers?: any[];
  }): Promise<AssignmentRecommendationResult> {
    const data = await postAiJson<{ data: AssignmentRecommendationResult }>(
      '/api/ai/recommend-assignment',
      params,
      'Failed to obtain assignment recommendation'
    );
    return data.data;
  },

  // 4. AI Workload Optimizer
  async optimizeWorkload(params: { teamStats: any }): Promise<WorkloadOptimizerResult> {
    const data = await postAiJson<{ data: WorkloadOptimizerResult }>(
      '/api/ai/workload-optimizer',
      params,
      'Failed to optimize workload'
    );
    return data.data;
  },

  // 5. AI Deadline Risk Prediction
  async predictDeadlineRisk(params: {
    requestTitle: string;
    priority: string;
    status: string;
    daysLeft: number;
    isOverdue: boolean;
    revisionsCount?: number;
  }): Promise<DeadlineRiskResult> {
    const data = await postAiJson<{ data: DeadlineRiskResult }>(
      '/api/ai/predict-risk',
      params,
      'Failed to predict deadline risk'
    );
    return data.data;
  },

  // 6. AI Creative & Marketing Assistant
  async generateCreativeIdeas(params: {
    brand?: string;
    campaignTheme?: string;
    medium?: string;
    tone?: string;
    targetAudience?: string;
    objective?: string;
  }): Promise<CreativeAssistantResult> {
    const data = await postAiJson<{ data: CreativeAssistantResult }>(
      '/api/ai/creative-assistant',
      params,
      'Failed to generate creative concepts'
    );
    return data.data;
  },

  // 7. AI Analytics & Executive Insights
  async getExecutiveInsights(params: { summaryData: any }): Promise<ExecutiveInsightsResult> {
    const data = await postAiJson<{ data: ExecutiveInsightsResult }>(
      '/api/ai/executive-insights',
      params,
      'Failed to formulate executive insights'
    );
    return data.data;
  },

  // 8. AI Report Generator
  async generateExecutiveReport(params: {
    title?: string;
    period?: string;
    stats?: any;
    brandBreakdown?: any;
  }): Promise<string> {
    const data = await postAiJson<{ reportMarkdown: string }>(
      '/api/ai/report-generator',
      params,
      'Failed to generate executive report'
    );
    return data.reportMarkdown;
  },

  // 9. AI Knowledge Assistant
  async askKnowledgeAssistant(params: {
    question: string;
    history?: any[];
  }): Promise<KnowledgeAssistantResult> {
    return postAiJson<KnowledgeAssistantResult>(
      '/api/ai/knowledge-assistant',
      params,
      'Failed to contact knowledge assistant'
    );
  },
};
