import fs from 'node:fs';
import path from 'node:path';
import type { D1Database, D1PreparedStatement, D1Result, R2Bucket, R2Object, R2ObjectBody } from '@cloudflare/workers-types';
import { hashPassword } from '../worker/crypto';
import { INITIAL_USERS } from '../data/initialData';

type SqliteModule = {
  DatabaseSync: new (path: string) => {
    exec: (sql: string) => void;
    prepare: (sql: string) => {
      all: (...args: unknown[]) => Record<string, unknown>[];
      get: (...args: unknown[]) => Record<string, unknown> | undefined;
      run: (...args: unknown[]) => { changes: number | bigint; lastInsertRowid: number | bigint };
    };
    close: () => void;
  };
};

function getSqliteModule(): SqliteModule {
  const mod = (process as unknown as { getBuiltinModule?: (name: string) => unknown }).getBuiltinModule?.('node:sqlite');
  if (!mod) {
    throw new Error('Node 22 built-in module node:sqlite is required for local preview / Vitest D1 adapter.');
  }
  return mod as SqliteModule;
}

class LocalD1PreparedStatement implements D1PreparedStatement {
  private readonly db: InstanceType<SqliteModule['DatabaseSync']>;
  public readonly sql: string;
  public readonly params: unknown[];

  constructor(db: InstanceType<SqliteModule['DatabaseSync']>, sql: string, params: unknown[] = []) {
    this.db = db;
    this.sql = sql;
    this.params = params;
  }

  bind(...values: unknown[]): D1PreparedStatement {
    return new LocalD1PreparedStatement(
      this.db,
      this.sql,
      values.map((v) => (v === undefined ? null : v))
    );
  }

  async first<T = Record<string, unknown>>(colName?: string): Promise<T | null> {
    const stmt = this.db.prepare(this.sql);
    const row = stmt.get(...this.params);
    if (!row) return null;
    if (colName) {
      return (row[colName] as T) ?? null;
    }
    return row as T;
  }

  async run<T = Record<string, unknown>>(): Promise<D1Result<T>> {
    const stmt = this.db.prepare(this.sql);
    const info = stmt.run(...this.params);
    return {
      success: true,
      results: [] as T[],
      meta: {
        duration: 0,
        size_after: 0,
        rows_read: 0,
        rows_written: Number(info.changes || 0),
        last_row_id: Number(info.lastInsertRowid || 0),
        changed_db: Number(info.changes || 0) > 0,
        changes: Number(info.changes || 0),
      },
    };
  }

  async all<T = Record<string, unknown>>(): Promise<D1Result<T>> {
    const stmt = this.db.prepare(this.sql);
    const rows = stmt.all(...this.params) as T[];
    return {
      success: true,
      results: rows,
      meta: {
        duration: 0,
        size_after: 0,
        rows_read: rows.length,
        rows_written: 0,
        last_row_id: 0,
        changed_db: false,
        changes: 0,
      },
    };
  }

  async raw<T = unknown[]>(options: { columnNames: true }): Promise<[string[], ...T[]]>;
  async raw<T = unknown[]>(options?: { columnNames?: false }): Promise<T[]>;
  async raw<T = unknown[]>(options?: { columnNames?: boolean }): Promise<T[] | [string[], ...T[]]> {
    const stmt = this.db.prepare(this.sql);
    const rows = stmt.all(...this.params);
    if (rows.length === 0) return [];
    const cols = Object.keys(rows[0]);
    const values = rows.map((r) => cols.map((c) => r[c]));
    if (options?.columnNames) {
      return [cols, ...(values as T[])] as [string[], ...T[]];
    }
    return values as unknown as T[];
  }
}

export function createNodeSqliteD1Adapter(sqliteDbPath: string): {
  db: D1Database;
  rawExec: (sql: string) => void;
  checkpoint: () => void;
  close: () => void;
} {
  if (sqliteDbPath !== ':memory:') {
    fs.mkdirSync(path.dirname(sqliteDbPath), { recursive: true });
  }
  const { DatabaseSync } = getSqliteModule();
  const sqlite = new DatabaseSync(sqliteDbPath);
  let isClosed = false;
  sqlite.exec('PRAGMA foreign_keys = ON;');
  if (sqliteDbPath !== ':memory:') {
    sqlite.exec('PRAGMA journal_mode = WAL; PRAGMA busy_timeout = 5000;');
  }

  const d1: D1Database = {
    prepare(query: string): D1PreparedStatement {
      return new LocalD1PreparedStatement(sqlite, query, []);
    },
    async batch<T = unknown>(statements: D1PreparedStatement[]): Promise<D1Result<T>[]> {
      sqlite.exec('BEGIN IMMEDIATE;');
      try {
        const results: D1Result<T>[] = [];
        for (const s of statements) {
          const localStmt = s as unknown as LocalD1PreparedStatement;
          const trimmed = localStmt.sql.trim().toUpperCase();
          if (trimmed.startsWith('SELECT') || trimmed.startsWith('PRAGMA')) {
            results.push(await localStmt.all<T>());
          } else {
            results.push(await localStmt.run<T>());
          }
        }
        sqlite.exec('COMMIT;');
        return results;
      } catch (err) {
        try {
          sqlite.exec('ROLLBACK;');
        } catch {
          // SQLite may auto-rollback on ABORT trigger error
        }
        throw err;
      }
    },
    async exec(query: string) {
      sqlite.exec(query);
      return { count: 1, duration: 0 };
    },
    async dump(): Promise<ArrayBuffer> {
      return new ArrayBuffer(0);
    },
    withSession() {
      return d1 as unknown as ReturnType<D1Database['withSession']>;
    },
  } as unknown as D1Database;

  const checkpoint = () => {
    if (isClosed || sqliteDbPath === ':memory:') return;
    try {
      sqlite.exec('PRAGMA wal_checkpoint(TRUNCATE);');
    } catch {
      // Ignore if already closed
    }
  };

  return {
    db: d1,
    rawExec: (sql: string) => sqlite.exec(sql),
    checkpoint,
    close: () => {
      if (!isClosed) {
        checkpoint();
        isClosed = true;
        sqlite.close();
      }
    },
  };
}

interface StoredR2Entry {
  bytes: Uint8Array;
  httpMetadata?: { contentType?: string };
  customMetadata?: Record<string, string>;
  uploaded: Date;
}

export function createLocalDiskR2Adapter(baseDirOrMemory: string | 'memory'): R2Bucket {
  const isMemory = baseDirOrMemory === 'memory';
  const memStore = new Map<string, StoredR2Entry>();
  if (!isMemory) {
    fs.mkdirSync(baseDirOrMemory, { recursive: true });
  }

  function resolveSafePath(key: string): string {
    const normalized = key.replace(/^\/+/, '').replace(/\.\./g, '_');
    return path.join(baseDirOrMemory, normalized);
  }

  async function toUint8Array(value: unknown): Promise<Uint8Array> {
    if (value instanceof Uint8Array) return value;
    if (value instanceof ArrayBuffer) return new Uint8Array(value);
    if (typeof value === 'string') return new TextEncoder().encode(value);
    if (value && typeof (value as ReadableStream).getReader === 'function') {
      const resp = new Response(value as ReadableStream);
      return new Uint8Array(await resp.arrayBuffer());
    }
    return new Uint8Array(0);
  }

  function wrapR2Object(key: string, entry: StoredR2Entry): R2ObjectBody {
    const bytes = entry.bytes;
    return {
      key,
      version: 'local-v1',
      size: bytes.byteLength,
      etag: `"local-${bytes.byteLength}"`,
      httpEtag: `"local-${bytes.byteLength}"`,
      checksums: {},
      uploaded: entry.uploaded,
      httpMetadata: entry.httpMetadata || {},
      customMetadata: entry.customMetadata || {},
      range: undefined,
      storageClass: 'Standard',
      writeHttpMetadata(headers: Headers) {
        if (entry.httpMetadata?.contentType) {
          headers.set('content-type', entry.httpMetadata.contentType);
        }
      },
      get body() {
        return new ReadableStream<Uint8Array>({
          start(controller) {
            controller.enqueue(bytes);
            controller.close();
          },
        });
      },
      bodyUsed: false,
      async arrayBuffer() {
        return bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength) as ArrayBuffer;
      },
      async text() {
        return new TextDecoder().decode(bytes);
      },
      async json<T>() {
        return JSON.parse(new TextDecoder().decode(bytes)) as T;
      },
      async blob() {
        return new Blob([bytes as BlobPart]);
      },
      async bytes() {
        return bytes;
      },
    } as unknown as R2ObjectBody;
  }

  return {
    async put(key: string, value: unknown, options?: { httpMetadata?: { contentType?: string }; customMetadata?: Record<string, string> }) {
      const bytes = await toUint8Array(value);
      const entry: StoredR2Entry = {
        bytes,
        httpMetadata: options?.httpMetadata,
        customMetadata: options?.customMetadata,
        uploaded: new Date(),
      };
      if (isMemory) {
        memStore.set(key, entry);
      } else {
        const filePath = resolveSafePath(key);
        fs.mkdirSync(path.dirname(filePath), { recursive: true });
        fs.writeFileSync(filePath, bytes);
        fs.writeFileSync(
          `${filePath}.meta.json`,
          JSON.stringify({
            httpMetadata: entry.httpMetadata || {},
            customMetadata: entry.customMetadata || {},
            uploaded: entry.uploaded.toISOString(),
          })
        );
      }
      return {
        key,
        size: bytes.byteLength,
        etag: `"local-${bytes.byteLength}"`,
      } as unknown as R2Object;
    },
    async get(key: string) {
      if (isMemory) {
        const entry = memStore.get(key);
        return entry ? wrapR2Object(key, entry) : null;
      }
      const filePath = resolveSafePath(key);
      if (!fs.existsSync(filePath)) return null;
      const bytes = new Uint8Array(fs.readFileSync(filePath));
      let meta: { httpMetadata?: { contentType?: string }; customMetadata?: Record<string, string>; uploaded?: string } = {};
      if (fs.existsSync(`${filePath}.meta.json`)) {
        try {
          meta = JSON.parse(fs.readFileSync(`${filePath}.meta.json`, 'utf8'));
        } catch {
          meta = {};
        }
      }
      return wrapR2Object(key, {
        bytes,
        httpMetadata: meta.httpMetadata,
        customMetadata: meta.customMetadata,
        uploaded: meta.uploaded ? new Date(meta.uploaded) : new Date(),
      });
    },
    async head(key: string) {
      if (isMemory) {
        const entry = memStore.get(key);
        if (!entry) return null;
        return { key, size: entry.bytes.byteLength, uploaded: entry.uploaded } as unknown as R2Object;
      }
      const filePath = resolveSafePath(key);
      if (!fs.existsSync(filePath)) return null;
      const stat = fs.statSync(filePath);
      return { key, size: stat.size, uploaded: stat.mtime } as unknown as R2Object;
    },
    async delete(keys: string | string[]) {
      const list = Array.isArray(keys) ? keys : [keys];
      for (const k of list) {
        if (isMemory) {
          memStore.delete(k);
        } else {
          const p = resolveSafePath(k);
          if (fs.existsSync(p)) fs.unlinkSync(p);
          if (fs.existsSync(`${p}.meta.json`)) fs.unlinkSync(`${p}.meta.json`);
        }
      }
    },
    async list() {
      return { objects: [], truncated: false, delimitedPrefixes: [] };
    },
  } as unknown as R2Bucket;
}

export function applyLocalSqlMigrations(rawExec: (sql: string) => void, rootDir = process.cwd()) {
  const migDir = path.join(rootDir, 'migrations');
  const files = [
    '0001_initial_schema.sql',
    '0002_quota_atomic_triggers.sql',
    '0003_seed_master_data.sql',
    '0004_public_request_form.sql',
  ];
  for (const file of files) {
    const sqlPath = path.join(migDir, file);
    if (fs.existsSync(sqlPath)) {
      const sql = fs.readFileSync(sqlPath, 'utf8');
      rawExec(sql);
    }
  }
}

export async function seedLocalPreviewData(
  db: D1Database,
  options: { pepper?: string; rootDir?: string; readLegacyDataFolder?: boolean } = {}
) {
  const rootDir = options.rootDir || process.cwd();
  const dataDir = path.join(rootDir, 'data');
  const countRes = await db.prepare('SELECT COUNT(*) AS cnt FROM users').first<{ cnt: number }>();

  if (Number(countRes?.cnt || 0) === 0) {
    let legacyUsers: any[] = [];
    const legacyUsersPath = path.join(dataDir, 'server_users.json');
    if (options.readLegacyDataFolder !== false && fs.existsSync(legacyUsersPath)) {
      try {
        legacyUsers = JSON.parse(fs.readFileSync(legacyUsersPath, 'utf8'));
      } catch {
        legacyUsers = [];
      }
    }

    const defaultPasswordHash = await hashPassword('LymanMarcomm2026!', options.pepper);
    const sourceList = legacyUsers.length > 0 ? legacyUsers : INITIAL_USERS;

    for (const u of sourceList) {
      const pwHash =
        typeof u.passwordHash === 'string' && u.passwordHash.length > 16
          ? u.passwordHash
          : defaultPasswordHash;
      await db
        .prepare(
          `INSERT OR IGNORE INTO users
           (id, email, full_name, avatar_url, job_title, department, role, is_reviewer,
            teams_json, competencies_json, assigned_regions_json, assigned_brands_json,
            is_active, password_hash, must_change_password, created_at, updated_at, last_login_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
        )
        .bind(
          u.id,
          String(u.email).toLowerCase(),
          u.fullName,
          u.avatarUrl || null,
          u.jobTitle || '',
          u.department || 'Marketing Komunikasi',
          u.role,
          u.isReviewer ? 1 : 0,
          JSON.stringify(u.teams || []),
          JSON.stringify(u.competencies || []),
          JSON.stringify(u.assignedRegions || []),
          JSON.stringify(u.assignedBrands || []),
          u.isActive === false ? 0 : 1,
          pwHash,
          u.mustChangePassword ? 1 : 0,
          u.createdAt || new Date().toISOString(),
          new Date().toISOString(),
          u.lastLoginAt || null
        )
        .run();
    }
  }

  // Optionally read-only seed canonical brand policies & audit logs if tables are empty
  if (options.readLegacyDataFolder !== false) {
    const polCount = await db
      .prepare('SELECT COUNT(*) AS cnt FROM priority_quota_policies')
      .first<{ cnt: number }>();
    const polPath = path.join(dataDir, 'quota_policies.json');
    if (Number(polCount?.cnt || 0) === 0 && fs.existsSync(polPath)) {
      try {
        const policies = JSON.parse(fs.readFileSync(polPath, 'utf8')) as any[];
        const validBrandsRes = await db.prepare('SELECT id FROM brands').all<{ id: string }>();
        const validBrands = new Set((validBrandsRes.results || []).map((b) => b.id));
        for (const p of policies) {
          if (!validBrands.has(p.brandId)) continue;
          await db
            .prepare(
              `INSERT OR IGNORE INTO priority_quota_policies
               (id, brand_id, year, priority, annual_limit, used_count, sla_days, created_at, updated_at)
               VALUES (?, ?, ?, ?, ?, 0, ?, ?, ?)`
            )
            .bind(
              p.id,
              p.brandId,
              p.year,
              p.priority,
              p.annualLimit,
              p.slaDays || 3,
              p.createdAt || new Date().toISOString(),
              p.updatedAt || new Date().toISOString()
            )
            .run();
        }
      } catch {
        // non-fatal during preview bootstrap
      }
    }

    const auditCount = await db
      .prepare('SELECT COUNT(*) AS cnt FROM security_audit_logs')
      .first<{ cnt: number }>();
    const auditPath = path.join(dataDir, 'server_audit_logs.json');
    if (Number(auditCount?.cnt || 0) === 0 && fs.existsSync(auditPath)) {
      try {
        const logs = JSON.parse(fs.readFileSync(auditPath, 'utf8')) as any[];
        for (const l of logs.slice(0, 150)) {
          await db
            .prepare(
              `INSERT OR IGNORE INTO security_audit_logs (id, timestamp, action, actor_id, actor_name, actor_role, target_id, target_type, summary, details_json)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
            )
            .bind(
              l.id,
              l.timestamp || new Date().toISOString(),
              l.action,
              l.actorId || 'system',
              l.actorName || 'System',
              l.actorRole || 'system',
              l.targetId || null,
              l.targetType || null,
              l.summary || '',
              JSON.stringify(l.details || {})
            )
            .run();
        }
      } catch {
        // non-fatal
      }
    }
  }
}
