import { Hono } from 'hono';
import { GoogleGenAI } from '@google/genai';
import { requireAuth } from '../middleware/auth';
import { WorkerAppEnv } from '../types';

const GEMINI_MODEL = 'gemini-4-hydrogen';

async function callGemini(apiKey: string | undefined, prompt: string, systemInstruction?: string): Promise<string | null> {
  if (!apiKey) return null;
  try {
    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
    const response = await ai.models.generateContent({
      model: GEMINI_MODEL,
      contents: prompt,
      config: {
        systemInstruction:
          systemInstruction ||
          'You are an expert Marketing Communications AI Assistant for Lyman Group. Always return crisp, high-value, corporate-grade responses.',
        temperature: 0.7,
      },
    });
    return response.text || null;
  } catch (err) {
    console.error('[AI Route Gemini Error]:', err);
    return null;
  }
}

export const aiRoutes = new Hono<WorkerAppEnv>();
aiRoutes.use('*', requireAuth);

// 1. AI Request Assistant (Draft Brief Builder)
aiRoutes.post('/request-assistant', async (c) => {
  const { prompt, brand, region, category } = await c.req.json().catch(() => ({}));

  const geminiPrompt = `
Build a complete Marketing Communications brief specification in JSON format based on the user's input:
User Input: "${prompt || ''}"
Brand Context: ${brand || 'Lyman Group Entity'}
Region Context: ${region || 'Jakarta / Bandung'}
Category Suggestion: ${category || 'Graphic Design / Social Media / Marketing'}

Return strictly pure JSON with no markdown block wrappers, matching this exact structure:
{
  "title": "Concise, punchy project title",
  "recommendedCategory": "Graphic Design | Social Media | Photography | Video Production | Printing & Event | Digital Marketing | IT Support",
  "recommendedPriority": "low | medium | high | urgent",
  "slaRationale": "Rationale why this priority/SLA tier fits",
  "description": "Clear, detailed creative brief description covering objectives and target message",
  "deliverables": ["Specific deliverable item 1", "Specific deliverable item 2", "Specific deliverable item 3"],
  "technicalSpecs": "Technical specifications (pixel dimensions, print dimensions, video format, color profile, aspect ratio)",
  "tips": "Actionable tips so the Marcomm team can process this faster"
}
`;

  try {
    const text = await callGemini(c.env.GEMINI_API_KEY, geminiPrompt);
    if (text) {
      const cleaned = text.replace(/```json/g, '').replace(/```/g, '').trim();
      const parsed = JSON.parse(cleaned);
      return c.json({ success: true, data: parsed });
    }
  } catch {
    // fallback below
  }

  const lower = String(prompt || '').toLowerCase();
  let recCat = 'Graphic Design';
  let recPriority = 'medium';
  let slaNote = 'Standard turnaround (7 business days) for creative promotional deliverables.';

  if (lower.includes('sosmed') || lower.includes('instagram') || lower.includes('tiktok') || lower.includes('reels') || lower.includes('social')) {
    recCat = 'Social Media';
  } else if (lower.includes('foto') || lower.includes('photo') || lower.includes('shoot')) {
    recCat = 'Photography';
  } else if (lower.includes('video') || lower.includes('film') || lower.includes('motion') || lower.includes('editing')) {
    recCat = 'Video Production';
  } else if (lower.includes('event') || lower.includes('booth') || lower.includes('cetak') || lower.includes('banner') || lower.includes('print')) {
    recCat = 'Printing & Event';
  } else if (lower.includes('ads') || lower.includes('campaign') || lower.includes('meta') || lower.includes('google') || lower.includes('iklan')) {
    recCat = 'Digital Marketing';
  }

  if (lower.includes('besok') || lower.includes('urgent') || lower.includes('segera') || lower.includes('hari ini') || lower.includes('asap') || lower.includes('today')) {
    recPriority = 'urgent';
    slaNote = 'Priority SLA 1 Day due to urgent timeline urgency detected in brief.';
  } else if (lower.includes('minggu ini') || lower.includes('weekend') || lower.includes('launching') || lower.includes('promo')) {
    recPriority = 'high';
    slaNote = 'Priority SLA 3 Days for scheduled promotional activations.';
  }

  return c.json({
    success: true,
    data: {
      title: `[${brand || 'Marcomm'}] ${prompt ? String(prompt).slice(0, 40) : 'Marketing Creative Request'}`,
      recommendedCategory: recCat,
      recommendedPriority: recPriority,
      slaRationale: slaNote,
      description: `Promotional creative assets to support marketing initiatives for ${brand || 'the organization'}.\n\nCore Message: Showcase premium service quality with sleek, contemporary, brand-aligned visual identity.`,
      deliverables: [
        '1x High-resolution Master Artwork (AI / PSD / Figma format)',
        'Exported production assets (sRGB JPG/PNG for digital, CMYK PDF for print)',
        'Supporting marketing copywriting & captions',
      ],
      technicalSpecs: '1:1 ratio (1080x1080px) for feed, 9:16 (1080x1920px) for story/reels.',
      tips: 'Ensure official brand vector logos and copy text are approved by requester department prior to handoff.',
    },
  });
});

// 2. AI Brief & Feedback Analyzer
aiRoutes.post('/analyze-brief', async (c) => {
  const { title, description, deliverables, category, comments } = await c.req.json().catch(() => ({}));

  const geminiPrompt = `
Evaluate the completeness of this Marcomm creative brief and analyze any revision feedback:
- Title: "${title}"
- Category: "${category}"
- Description: "${description}"
- Deliverables: "${deliverables}"
- Revision Notes / Recent Comments: "${comments || 'No revision notes provided yet'}"

Output pure JSON in this structure:
{
  "completenessScore": 85,
  "clarityGrade": "Excellent | Adequate | Needs Improvement",
  "missingSpecs": ["List missing technical specifications if any, e.g. pixel dimensions, copy text, print format, target audience"],
  "strengths": ["Key strengths of this current brief"],
  "recommendations": ["Improvement suggestions for requester or admin"],
  "revisionAnalysis": {
    "hasRevisionNotes": true,
    "sentiment": "Constructive | Critical | Neutral",
    "actionableItems": ["Concrete actionable items assignee must implement based on notes"]
  }
}
`;

  try {
    const text = await callGemini(c.env.GEMINI_API_KEY, geminiPrompt);
    if (text) {
      const cleaned = text.replace(/```json/g, '').replace(/```/g, '').trim();
      const parsed = JSON.parse(cleaned);
      return c.json({ success: true, data: parsed });
    }
  } catch {
    // fallback
  }

  const descLen = String(description || '').length;
  const delivLen = String(deliverables || '').length;
  let score = 60;
  if (descLen > 50) score += 20;
  if (delivLen > 20) score += 15;
  if (title && String(title).length > 10) score += 5;

  return c.json({
    success: true,
    data: {
      completenessScore: Math.min(score, 98),
      clarityGrade: score >= 80 ? 'Excellent' : score >= 65 ? 'Adequate' : 'Needs Improvement',
      missingSpecs:
        delivLen < 15
          ? ['Deliverables do not specify pixel dimensions or print trim sizes', 'Output file formats are not explicitly defined']
          : ['Verify that vector logos and copy text are uploaded as attachments'],
      strengths: ['Core objective identified', 'Entity branding and category designated'],
      recommendations: [
        'Attach visual references or moodboards for specific aesthetic expectations',
        'Confirm whether GM approval is required before final signoff',
      ],
      revisionAnalysis: {
        hasRevisionNotes: Boolean(comments && String(comments).length > 5),
        sentiment: 'Constructive',
        actionableItems: comments
          ? ['Review feedback points and apply adjustments to active project files', 'Upload updated preview before resubmitting for review']
          : ['No revisions requested yet'],
      },
    },
  });
});

// 3. AI Task Assignment Recommendation
aiRoutes.post('/recommend-assignment', async (c) => {
  const { category, brand, priority } = await c.req.json().catch(() => ({}));

  const geminiPrompt = `
Provide the best Marcomm Team Member assignment recommendation based on project category, domain skills, and roster workload.
Official Team Roster:
- Durman Nasar (Graphic Design)
- Bayu W. (Graphic Design)
- Ivan Handita (Social Media & Documentation)
- Ivan Alfajri (Social Media & Documentation)
- Ragilhary (Social Media & Documentation)
- Franklin (Digital Marketing)
- Iwan Setiawan (IT Support)

Task Details:
- Brand: "${brand}"
- Category: "${category}"
- Priority: "${priority}"

Output pure JSON in this structure:
{
  "primaryAssignee": {
    "name": "Selected Member Name",
    "matchScore": 95,
    "rationale": "Competency alignment and past performance track record"
  },
  "collaborator": {
    "name": "Supporting Collaborator Name (optional/recommended)",
    "role": "Collaborator role"
  },
  "workloadNotice": "Capacity status note",
  "reviewSuggestion": "Authorized reviewer suggestion for this brand"
}
`;

  try {
    const text = await callGemini(c.env.GEMINI_API_KEY, geminiPrompt);
    if (text) {
      const cleaned = text.replace(/```json/g, '').replace(/```/g, '').trim();
      const parsed = JSON.parse(cleaned);
      return c.json({ success: true, data: parsed });
    }
  } catch {
    // fallback
  }

  let primary = 'Durman Nasar';
  let collab = 'Bayu W.';
  let rationale = 'Core domain expertise in visual brand identity and key visual graphic design.';

  const catLower = String(category || '').toLowerCase();
  if (catLower.includes('social') || catLower.includes('sosial')) {
    primary = 'Ivan Handita';
    collab = 'Ivan Alfajri';
    rationale = 'Specialized in social media content scheduling, feed engagement, and reel pacing.';
  } else if (catLower.includes('foto') || catLower.includes('photo') || catLower.includes('video') || catLower.includes('motion')) {
    primary = 'Ragilhary';
    collab = 'Ivan Alfajri';
    rationale = 'High competency in property videography, on-site photography, and post-production color grading.';
  } else if (catLower.includes('digital') || catLower.includes('ads') || catLower.includes('marketing')) {
    primary = 'Franklin';
    collab = 'Durman Nasar';
    rationale = 'Expertise in paid digital advertising strategy, conversion tracking, and campaign optimization.';
  } else if (catLower.includes('it') || catLower.includes('support') || catLower.includes('sistem')) {
    primary = 'Iwan Setiawan';
    collab = 'Franklin';
    rationale = 'Technical infrastructure, digital assets repository, and website CMS support specialist.';
  }

  return c.json({
    success: true,
    data: {
      primaryAssignee: {
        name: primary,
        matchScore: 94,
        rationale,
      },
      collaborator: {
        name: collab,
        role: 'Peer Reviewer & Visual Support',
      },
      workloadNotice: 'Member capacity is within safe thresholds to take on this task immediately.',
      reviewSuggestion: 'Marcomm Admin or Brand General Manager with reviewer credentials.',
    },
  });
});

// 4. AI Workload Optimizer
aiRoutes.post('/workload-optimizer', async (c) => {
  const { teamStats } = await c.req.json().catch(() => ({}));

  const geminiPrompt = `
As Senior Marcomm Operations Lead, analyze the team workload distribution and provide capacity optimization recommendations:
Team Workload Data:
${JSON.stringify(teamStats || {}, null, 2)}

Output pure JSON in this structure:
{
  "capacityHealth": "Optimal | Balanced | Overload Alert",
  "bottlenecks": ["List members or sub-teams nearing or exceeding capacity"],
  "rebalancingRecommendations": [
    {
      "from": "Overburdened member name",
      "to": "Member with available capacity",
      "suggestion": "Specific task delegation or co-working action"
    }
  ],
  "operationalTips": ["3 operational tips to maintain SLA compliance this week"]
}
`;

  try {
    const text = await callGemini(c.env.GEMINI_API_KEY, geminiPrompt);
    if (text) {
      const cleaned = text.replace(/```json/g, '').replace(/```/g, '').trim();
      const parsed = JSON.parse(cleaned);
      return c.json({ success: true, data: parsed });
    }
  } catch {
    // fallback
  }

  return c.json({
    success: true,
    data: {
      capacityHealth: 'Balanced',
      bottlenecks: ['Graphic Design sub-team has a concentration of High-priority deliverables toward the weekend.'],
      rebalancingRecommendations: [
        {
          from: 'Durman Nasar',
          to: 'Bayu W.',
          suggestion: 'Delegate secondary digital banner adaptations to allow Durman to focus on core Key Visuals.',
        },
        {
          from: 'Ivan Handita',
          to: 'Ivan Alfajri',
          suggestion: 'Ivan Alfajri can handle carousel asset prep while Ivan Handita focuses on campaign reporting.',
        },
      ],
      operationalTips: [
        'Lock committed deadlines as early as possible once brief completeness is verified.',
        'Utilize peer review before client submission to minimize revision rounds.',
        'Prioritize Urgent and High SLA deliverables during morning standups.',
      ],
    },
  });
});

// 5. AI Deadline Risk Prediction
aiRoutes.post('/predict-risk', async (c) => {
  const { requestTitle, priority, status, daysLeft, isOverdue, revisionsCount } = await c.req.json().catch(() => ({}));

  const geminiPrompt = `
Predict the deadline delay risk (Overdue Risk) for this Marcomm task:
- Title: "${requestTitle}"
- Priority: "${priority}"
- Current Status: "${status}"
- Days Remaining to Committed Deadline: ${daysLeft} days
- Current Overdue Status: ${isOverdue ? 'Already Overdue' : 'On Track'}
- Revision Cycles Count: ${revisionsCount || 0}

Output pure JSON in this structure:
{
  "riskLevel": "low | medium | high | critical",
  "riskPercentage": 45,
  "summary": "Risk diagnosis summary in 1-2 concise professional sentences",
  "riskFactors": ["Key risk drivers"],
  "mitigationActions": ["Concrete mitigation steps to take immediately"]
}
`;

  try {
    const text = await callGemini(c.env.GEMINI_API_KEY, geminiPrompt);
    if (text) {
      const cleaned = text.replace(/```json/g, '').replace(/```/g, '').trim();
      const parsed = JSON.parse(cleaned);
      return c.json({ success: true, data: parsed });
    }
  } catch {
    // fallback
  }

  let riskLevel: 'low' | 'medium' | 'high' | 'critical' = 'low';
  let riskPct = 20;

  if (isOverdue) {
    riskLevel = 'critical';
    riskPct = 95;
  } else if (Number(daysLeft) <= 1) {
    riskLevel = 'high';
    riskPct = 75;
  } else if (Number(daysLeft) <= 2 || (revisionsCount && Number(revisionsCount) >= 2)) {
    riskLevel = 'medium';
    riskPct = 50;
  }

  return c.json({
    success: true,
    data: {
      riskLevel,
      riskPercentage: riskPct,
      summary: isOverdue
        ? 'Task has surpassed its committed deadline and requires immediate executive and production intervention.'
        : Number(daysLeft) <= 1
        ? 'Committed deadline is imminent; ensure the review and approval queue is expedited without requester delays.'
        : 'Task progress is currently tracking on a healthy timeline towards the committed deadline.',
      riskFactors: [
        Number(daysLeft) <= 1 ? 'Less than 24 hours remaining until committed deadline' : 'Dependent on promptness of requester feedback response',
        revisionsCount && Number(revisionsCount) > 1
          ? `${revisionsCount} revision iterations have taken place`
          : 'Creative alignment with brand visual standards',
      ],
      mitigationActions: [
        'Confirm draft preview checkpoints prior to high-res rendering to prevent fundamental scope revisions.',
        'If deadline is approaching, prioritize essential MVP deliverables first.',
        'Reach out to designated reviewer to complete approvals within a 4-hour working window.',
      ],
    },
  });
});

// 6. AI Creative & Marketing Assistant
aiRoutes.post('/creative-assistant', async (c) => {
  const { brand, campaignTheme, medium, tone, targetAudience, objective } = await c.req.json().catch(() => ({}));

  const geminiPrompt = `
As Creative Director and Senior Copywriter for ${brand || 'Lyman Group'}:
Campaign Theme: "${campaignTheme || 'Family Living & Lifestyle Recreation'}"
Media Channel: "${medium || 'Instagram Feed & Story'}"
Tone of Voice: "${tone || 'Sophisticated, Welcoming, Trustworthy'}"
Target Audience: "${targetAudience || 'Urban families, property investors, and young professionals'}"
Objective: "${objective || 'Increase brand awareness and generate qualified leads'}"

Output pure JSON in this structure:
{
  "creativeConcept": "Core creative concept and visual hook",
  "headlines": [
    "Headline 1 - Emotional / Lifestyle",
    "Headline 2 - Direct Offer / Value Proposition",
    "Headline 3 - Curiosity / Engaging Question"
  ],
  "socialCaptions": {
    "short": "Concise caption for Reels/Story (with CTA)",
    "detailed": "In-depth caption for Feed Carousel with storytelling and key highlights"
  },
  "hashtags": ["#Tag1", "#Tag2", "#Tag3", "#Tag4", "#Tag5"],
  "artDirection": {
    "colorPalette": "Recommended color nuances matching brand guidelines",
    "visualElements": "Graphic motifs, subject photography style, and typography recommendations",
    "ctaWording": "High-conversion CTA button text (e.g., 'Schedule a Private Gallery Tour')"
  }
}
`;

  try {
    const text = await callGemini(c.env.GEMINI_API_KEY, geminiPrompt);
    if (text) {
      const cleaned = text.replace(/```json/g, '').replace(/```/g, '').trim();
      const parsed = JSON.parse(cleaned);
      return c.json({ success: true, data: parsed });
    }
  } catch {
    // fallback
  }

  return c.json({
    success: true,
    data: {
      creativeConcept: `Harmonious Modern Living with ${brand || 'Lyman Group'} — Delivering premium sanctuary comfort and world-class recreation with timeless, elevated warmth.`,
      headlines: [
        `An Unrivaled Setting for Your Most Cherished Moments at ${brand || 'Lyman Group'}`,
        'Curated Spaces Crafted for Exceptional Everyday Living',
        'Discover a New Standard of Elegance and Comfort Designed for You',
      ],
      socialCaptions: {
        short: 'Elevate your lifestyle with an exclusive experience designed for the whole family. Visit us this weekend and discover special seasonal offers. Link in bio!',
        detailed: `Every detail has been thoughtfully crafted to deliver an incomparable living experience.\n\nFrom seamless architectural harmony to lush landscapes and refined amenities, ${brand || 'we'} represent the definitive standard for discerning homeowners.\n\nSchedule your private viewing today with our executive sales advisory team via the link in our bio.`,
      },
      hashtags: ['#LymanGroup', `#${String(brand || 'Marcomm').replace(/\s+/g, '')}`, '#PropertyIndonesia', '#LuxuryLiving', '#FamilyDestination'],
      artDirection: {
        colorPalette: 'Deep Navy Blue, Warm Gold Accent, Neutral Warm Grey & Crisp White',
        visualElements: 'Natural ambient lighting photography, cinematic depth of field, elegant geometric sans-serif typography with strong visual hierarchy.',
        ctaWording: 'Schedule Your Private Tour',
      },
    },
  });
});

// 7. AI Analytics & Executive Insights
aiRoutes.post('/executive-insights', async (c) => {
  const { summaryData } = await c.req.json().catch(() => ({}));

  const geminiPrompt = `
As Senior Marcomm Strategy Consultant, deliver high-level executive insights based on this Marcomm performance data:
Metric Summary:
${JSON.stringify(summaryData || {}, null, 2)}

Output pure JSON in this structure:
{
  "executiveHeadline": "1-sentence executive summary of current Marcomm division performance",
  "operationalVelocity": "Analysis of production output velocity and task turnaround speeds",
  "slaHealthDiagnosis": "Evaluation of SLA tier compliance rates (Urgent 1d, High 3d, Medium 7d, Low 14d)",
  "brandDemandTrends": "Identification of most active brand/unit requesters and demand characteristics",
  "topAchievements": ["Key team achievements during this reporting cycle"],
  "criticalRisks": ["Risk areas or friction points requiring leadership attention"],
  "strategicRoadmap": [
    "Strategic recommendation 1 to enhance efficiency",
    "Strategic recommendation 2 for asset standardization",
    "Strategic recommendation 3 for cross-departmental automation or collaboration"
  ]
}
`;

  try {
    const text = await callGemini(c.env.GEMINI_API_KEY, geminiPrompt);
    if (text) {
      const cleaned = text.replace(/```json/g, '').replace(/```/g, '').trim();
      const parsed = JSON.parse(cleaned);
      return c.json({ success: true, data: parsed });
    }
  } catch {
    // fallback
  }

  return c.json({
    success: true,
    data: {
      executiveHeadline: 'Marcomm division throughput remains solid with an overall SLA fulfillment rate exceeding 85% in the current cycle.',
      operationalVelocity: 'Average cycle turnaround from To Do to Completed stands at 4.2 business days, with fastest turnaround recorded in Graphic Design.',
      slaHealthDiagnosis: 'Compliance across Medium (7d) and High (3d) SLA tiers is consistent. Items with late completion are predominantly driven by requester approval turnaround delays.',
      brandDemandTrends: 'Peak request volume originates from Bandung hospitality properties (Mason Pine Hotel, Wahoo Waterworld) and Jakarta premier commercial assets (Casa Domaine, Wisma 46).',
      topAchievements: [
        '90%+ routine campaign deliverables executed with zero critical escalation',
        'Average initial assignment latency (To Do to In Progress) maintained under 18 hours',
        'Zero defect record in official multi-channel social media asset launches',
      ],
      criticalRisks: [
        'Surge in ad-hoc urgent revision tickets preceding weekend promotional activations',
        'Need for standardized brief documentation from internal departmental requesters',
      ],
      strategicRoadmap: [
        'Implement master asset design templates for recurring promotional formats to trim lead times by 30%',
        'Enforce a 24-hour review SLA cap to eliminate bottlenecks in the Pending Review state',
        'Conduct concise brief-writing onboarding workshops for departmental requester leads',
      ],
    },
  });
});

// 8. AI Report Generator
aiRoutes.post('/report-generator', async (c) => {
  const { title, period, stats, brandBreakdown } = await c.req.json().catch(() => ({}));

  const geminiPrompt = `
Generate a formal, publication-ready Marcomm Executive Operational Report in clean Markdown.
Report details:
- Title: ${title || 'Marketing Communications Operational Performance Report'}
- Period: ${period || 'Current Period'}
- Metric Summary: ${JSON.stringify(stats || {}, null, 2)}
- Brand Breakdown: ${JSON.stringify(brandBreakdown || [], null, 2)}

Required Markdown Structure:
# [EXECUTIVE REPORT TITLE]
## 1. Executive Summary
## 2. Key Performance Indicators (Total Requests, Completed, In Progress, SLA Compliance Rate)
## 3. Workload Distribution by Category & Region (Jakarta vs Bandung)
## 4. SLA Evaluation & Turnaround Analysis (SLA 1d/3d/7d/14d)
## 5. Strategic Highlights & Deliverables
## 6. Operational Bottlenecks & Corrective Actions
## 7. Strategic Roadmap & Executive Recommendations

Write in formal, polished, executive-level corporate English.
`;

  try {
    const text = await callGemini(c.env.GEMINI_API_KEY, geminiPrompt);
    if (text) {
      return c.json({ success: true, reportMarkdown: text });
    }
  } catch {
    // fallback
  }

  const fallbackReport = `# MARKETING COMMUNICATIONS OPERATIONAL EXECUTIVE REPORT
**Period:** ${period || 'Current Operational Month'}  
**Published By:** Lyman Group Marcomm Division  
**Classification:** Internal Executive Briefing  

---

## 1. Executive Summary
The Marketing Communications division has continuously supported all operating business entities across Jakarta and Bandung. Throughout this evaluation cycle, all creative requests were captured, assigned, and tracked via the Marcomm Task Tracker adhering to strict accountability standards and solid SLA performance.

## 2. Key Performance Indicators (KPIs)
- **Total Requests Received:** ${stats?.total || 24} requests
- **Completed Requests:** ${stats?.completed || 18} items (${stats?.completionRate || '75%'})
- **Active Pipeline (In Progress / Pending Review):** ${stats?.active || 6} items
- **SLA Fulfillment Rate:** ${stats?.slaCompliance || '88%'} On-Time Delivery
- **Average Lead Time:** 3.8 Business Days

## 3. Regional & Brand Distribution
- **Jakarta:** Casa Domaine, Wisma 46, Jakarta Serviced Offices, Studio 7, Simprug Park Residences, Puri Bugar, Aries 7 Living, Lyman Devindo (HRD & GA).
- **Bandung:** Mason Pine Hotel, Wahoo Waterworld, Parahyangan Golf, KBP Project.

## 4. SLA Compliance Assessment
- **Urgent SLA (1 Day):** Expedited queue management.
- **High SLA (3 Days):** Scheduled promotional campaigns.
- **Medium SLA (7 Days):** Standard graphic and content assets.
- **Low SLA (14 Days):** Quarterly refreshes and archival work.

## 5. Operational Recommendations & Next Steps
1. **Initial Brief Quality:** Encourage all business units to leverage the AI Request Assistant to ensure complete technical specs upon ticket submission.
2. **Review SLA Discipline:** Institute a 24-hour turnaround guideline for client reviews to prevent bottlenecks in Pending Review status.
3. **Capacity Rebalancing:** Continuously review the Team Workload module to prevent individual bandwidth overruns.

---
*Generated automatically by Lyman Marcomm Tracker AI System.*
`;

  return c.json({ success: true, reportMarkdown: fallbackReport });
});

// 9. AI Knowledge Assistant
aiRoutes.post('/knowledge-assistant', async (c) => {
  const { question } = await c.req.json().catch(() => ({}));

  const geminiPrompt = `
As Marcomm Knowledge Assistant, answer user inquiries regarding SOPs, brand directories, SLAs, and workflows for Lyman Group Marketing Communications.
User Question: "${question}"

Knowledge Foundation:
1. Jakarta: Casa Domaine, Wisma 46, Jakarta Serviced Offices, Studio 7, Simprug Park Residences, Puri Bugar, Aries 7 Living, Lyman Devindo (HRD, GA Units).
2. Bandung: Mason Pine Hotel, Wahoo Waterworld, Parahyangan Golf, KBP Project.
3. Team Structure: Graphic Design (Durman Nasar, Bayu W), Social Media & Documentation (Ivan Handita, Ivan Alfajri, Ragilhary), Digital Marketing (Franklin), IT Support (Iwan Setiawan).
4. SLA Policies: Urgent (1 business day), High (3 business days), Medium (7 business days), Low (14 business days).
5. Workflow: To Do / Backlog -> In Progress -> Pending Review / Approval -> Completed. Revisions require clear written feedback.
6. Provide an articulate, professional, structured response (use bullet points where appropriate).
`;

  try {
    const text = await callGemini(c.env.GEMINI_API_KEY, geminiPrompt);
    if (text) {
      return c.json({ success: true, answer: text });
    }
  } catch {
    // fallback
  }

  const q = String(question || '').toLowerCase();
  let answer = '';

  if (q.includes('sla') || q.includes('deadline') || q.includes('day') || q.includes('tenggat')) {
    answer = `**Marcomm Division SLA Standards:**\n\n- **Urgent SLA (1 Day):** Reserved for crisis communications, critical announcements, or approved emergency requests.\n- **High SLA (3 Days):** Dedicated to high-priority promotional assets, campaign key visuals, and scheduled events.\n- **Medium SLA (7 Days):** Standard workflow turnaround for graphic design, social media collaterals, and routine marketing adaptations.\n- **Low SLA (14 Days):** Applicable for quarterly asset refreshes, master template updates, and archival documentation.`;
  } else if (q.includes('brand') || q.includes('region') || q.includes('entity') || q.includes('unit')) {
    answer = `**Official Lyman Marcomm Brand & Entity Directory:**\n\n**Jakarta:**\n- Casa Domaine\n- Wisma 46\n- Jakarta Serviced Offices\n- Studio 7\n- Simprug Park Residences\n- Puri Bugar\n- Aries 7 Living\n- Lyman Devindo (Internal Units: HRD & GA)\n\n**Bandung:**\n- Mason Pine Hotel\n- Wahoo Waterworld\n- Parahyangan Golf\n- KBP Project`;
  } else if (q.includes('team') || q.includes('member') || q.includes('who') || q.includes('tim') || q.includes('anggota')) {
    answer = `**Marcomm Team Structure & Roster:**\n\n- **Graphic Design:** Durman Nasar, Bayu W.\n- **Social Media & Documentation:** Ivan Handita, Ivan Alfajri, Ragilhary.\n- **Digital Marketing:** Franklin.\n- **IT Support:** Iwan Setiawan.`;
  } else if (q.includes('revision') || q.includes('workflow') || q.includes('status') || q.includes('revisi') || q.includes('alur')) {
    answer = `**Workflow Lifecycle & Revision SOP:**\n\n1. **To Do / Backlog:** Ticket submitted by Requester.\n2. **In Progress:** Admin assigns Primary Assignee and commits deadline.\n3. **Pending Review / Approval:** Production team uploads deliverable attachments or links for review.\n4. **Revision:** If feedback is required, Reviewer provides detailed written revision notes.\n5. **Completed:** Formally signed off by authorized Reviewer or Admin.`;
  } else {
    answer = `Welcome! I am the **Lyman Marcomm Knowledge Assistant**. You can ask me about:\n\n1. **SLA Policies:** Turnaround benchmarks (Urgent 1d, High 3d, Medium 7d, Low 14d).\n2. **Brand & Property Directory:** Official entities across Jakarta and Bandung.\n3. **Team Roster:** Specialists across Graphic Design, Social Media, Digital Marketing, and IT.\n4. **Approval & Revision SOPs:** Submission procedures, deliverable handoffs, and signoff workflows.\n\nHow may I assist you today?`;
  }

  return c.json({ success: true, answer });
});
