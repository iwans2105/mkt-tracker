import { Hono } from 'hono';
import {
  requireAuth,
  requireRole,
  revokeUserSessions,
  writeSecurityAuditLog,
} from '../middleware/auth';
import { hashPassword, randomHex, validatePasswordStrength } from '../crypto';
import { rowToUser, sanitizeUser, WorkerAppEnv } from '../types';
import type { UserRole } from '../../types';

export const userRoutes = new Hono<WorkerAppEnv>();

// 1. List users (authenticated)
userRoutes.get('/', requireAuth, async (c) => {
  const rows = await c.env.DB.prepare(
    "SELECT * FROM users WHERE id != 'public-requester' ORDER BY created_at ASC"
  ).all<Record<string, unknown>>();
  const users = (rows.results || []).map((r) => sanitizeUser(rowToUser(r)));
  return c.json({ success: true, data: users });
});

// 2. Create user (Super Admin & Marcomm Admin)
userRoutes.post('/', requireRole(['super_admin', 'admin']), async (c) => {
  const actor = c.get('user')!;
  const body = await c.req.json().catch(() => ({}));

  const email = typeof body.email === 'string' ? body.email.trim().toLowerCase() : '';
  const fullName = typeof body.fullName === 'string' ? body.fullName.trim() : '';
  const role: UserRole = body.role || 'requester';

  if (!email || !fullName) {
    return c.json({ success: false, error: 'Nama lengkap dan email wajib diisi.' }, 400);
  }

  if (role === 'super_admin' && actor.role !== 'super_admin') {
    return c.json(
      { success: false, error: 'Hanya Super Admin yang berwenang membuat akun Super Admin.' },
      403
    );
  }

  const existing = await c.env.DB.prepare('SELECT id FROM users WHERE lower(email) = lower(?)')
    .bind(email)
    .first();
  if (existing) {
    return c.json({ success: false, error: 'Alamat email sudah terdaftar.' }, 409);
  }

  let initialPassword = typeof body.initialPassword === 'string' ? body.initialPassword : '';
  if (initialPassword) {
    const check = validatePasswordStrength(initialPassword);
    if (!check.valid) return c.json({ success: false, error: check.error }, 400);
  } else {
    // High-entropy random per-account password requiring reset/admin issuance
    initialPassword = `Lyman#${randomHex(12)}!`;
  }

  const id = typeof body.id === 'string' && body.id ? body.id : `user-${Date.now()}`;
  const nowIso = new Date().toISOString();
  const passwordHash = await hashPassword(initialPassword, c.env.PASSWORD_PEPPER);

  await c.env.DB.prepare(
    `INSERT INTO users (
      id, email, full_name, avatar_url, job_title, department, role, is_reviewer,
      teams_json, competencies_json, assigned_regions_json, assigned_brands_json,
      is_active, password_hash, must_change_password, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  )
    .bind(
      id,
      email,
      fullName,
      body.avatarUrl || null,
      String(body.jobTitle || 'Staff'),
      String(body.department || 'General Affairs (GA)'),
      role,
      body.isReviewer ? 1 : 0,
      JSON.stringify(Array.isArray(body.teams) ? body.teams : []),
      JSON.stringify(Array.isArray(body.competencies) ? body.competencies : []),
      JSON.stringify(Array.isArray(body.assignedRegions) ? body.assignedRegions : ['all']),
      JSON.stringify(Array.isArray(body.assignedBrands) ? body.assignedBrands : ['all']),
      body.isActive === false ? 0 : 1,
      passwordHash,
      1,
      nowIso,
      nowIso
    )
    .run();

  const createdRow = await c.env.DB.prepare('SELECT * FROM users WHERE id = ?')
    .bind(id)
    .first<Record<string, unknown>>();

  await writeSecurityAuditLog(c.env.DB, {
    action: 'user_created',
    actorId: actor.id,
    actorName: actor.fullName,
    actorRole: actor.role,
    targetId: id,
    targetType: 'user',
    summary: `Created user account: ${fullName} (${email}, role=${role})`,
  });

  return c.json({ success: true, user: sanitizeUser(rowToUser(createdRow!)) }, 201);
});

// 3. Update user (Admin updates any; non-admin may only update own non-privileged profile fields)
userRoutes.put('/:id', requireAuth, async (c) => {
  const actor = c.get('user')!;
  const targetId = c.req.param('id') || '';
  const body = await c.req.json().catch(() => ({}));

  const targetRow = await c.env.DB.prepare('SELECT * FROM users WHERE id = ?')
    .bind(targetId)
    .first<Record<string, unknown>>();
  if (!targetRow) {
    return c.json({ success: false, error: 'Pengguna tidak ditemukan.' }, 404);
  }
  const target = rowToUser(targetRow);

  const isPrivileged = actor.role === 'super_admin' || actor.role === 'admin';
  const isSelf = actor.id === targetId;

  if (!isPrivileged && !isSelf) {
    return c.json({ success: false, error: 'Akses ditolak (403 Forbidden).' }, 403);
  }

  if (target.role === 'super_admin' && actor.role !== 'super_admin' && !isSelf) {
    return c.json(
      { success: false, error: 'Hanya Super Admin yang berwenang mengubah akun Super Admin.' },
      403
    );
  }

  const nextFullName =
    typeof body.fullName === 'string' && body.fullName.trim() ? body.fullName.trim() : target.fullName;
  const nextJobTitle = typeof body.jobTitle === 'string' ? body.jobTitle.trim() : target.jobTitle;
  const nextDepartment =
    typeof body.department === 'string' ? body.department.trim() : target.department;
  const nextAvatarUrl =
    body.avatarUrl !== undefined ? (body.avatarUrl ? String(body.avatarUrl) : null) : target.avatarUrl || null;
  const nextEmail =
    isSelf || isPrivileged
      ? typeof body.email === 'string' && body.email.trim()
        ? body.email.trim().toLowerCase()
        : target.email
      : target.email;

  // Privileged fields
  let nextRole = target.role;
  let nextIsReviewer = target.isReviewer;
  let nextTeams = target.teams;
  let nextCompetencies = target.competencies;
  let nextRegions = target.assignedRegions;
  let nextBrands = target.assignedBrands;
  let nextIsActive = target.isActive;

  if (isPrivileged && !(!isSelf && target.role === 'super_admin' && actor.role !== 'super_admin')) {
    if (body.role) {
      if (body.role === 'super_admin' && actor.role !== 'super_admin') {
        return c.json(
          { success: false, error: 'Hanya Super Admin yang dapat menetapkan peran Super Admin.' },
          403
        );
      }
      nextRole = body.role;
    }
    if (typeof body.isReviewer === 'boolean') nextIsReviewer = body.isReviewer;
    if (Array.isArray(body.teams)) nextTeams = body.teams;
    if (Array.isArray(body.competencies)) nextCompetencies = body.competencies;
    if (Array.isArray(body.assignedRegions)) nextRegions = body.assignedRegions;
    if (Array.isArray(body.assignedBrands)) nextBrands = body.assignedBrands;
    if (typeof body.isActive === 'boolean') {
      if ((target.email === 'sosmeda217@gmail.com' || target.id === 'user-superadmin') && !body.isActive) {
        return c.json(
          { success: false, error: 'Akun Super Admin utama sistem tidak dapat dinonaktifkan.' },
          400
        );
      }
      nextIsActive = body.isActive;
    }
  }

  const nowIso = new Date().toISOString();
  await c.env.DB.prepare(
    `UPDATE users SET
      email = ?, full_name = ?, avatar_url = ?, job_title = ?, department = ?,
      role = ?, is_reviewer = ?, teams_json = ?, competencies_json = ?,
      assigned_regions_json = ?, assigned_brands_json = ?, is_active = ?, updated_at = ?
     WHERE id = ?`
  )
    .bind(
      nextEmail,
      nextFullName,
      nextAvatarUrl,
      nextJobTitle,
      nextDepartment,
      nextRole,
      nextIsReviewer ? 1 : 0,
      JSON.stringify(nextTeams),
      JSON.stringify(nextCompetencies),
      JSON.stringify(nextRegions),
      JSON.stringify(nextBrands),
      nextIsActive ? 1 : 0,
      nowIso,
      targetId
    )
    .run();

  // Immediately revoke active sessions if user deactivated or role changed
  if (!nextIsActive || nextRole !== target.role) {
    await revokeUserSessions(c.env.DB, targetId);
  }

  if (isPrivileged && !isSelf) {
    await writeSecurityAuditLog(c.env.DB, {
      action: 'user_updated',
      actorId: actor.id,
      actorName: actor.fullName,
      actorRole: actor.role,
      targetId,
      targetType: 'user',
      summary: `Updated user ${nextFullName} (${nextEmail}), role=${nextRole}, isActive=${nextIsActive}`,
    });
  }

  const updatedRow = await c.env.DB.prepare('SELECT * FROM users WHERE id = ?')
    .bind(targetId)
    .first<Record<string, unknown>>();
  return c.json({ success: true, user: sanitizeUser(rowToUser(updatedRow!)) });
});

// 4. Delete / Deactivate user
userRoutes.delete('/:id', requireRole(['super_admin', 'admin']), async (c) => {
  const actor = c.get('user')!;
  const targetId = c.req.param('id') || '';

  if (actor.id === targetId) {
    return c.json(
      { success: false, error: 'Tidak dapat menghapus akun Anda sendiri yang sedang aktif digunakan.' },
      400
    );
  }

  const targetRow = await c.env.DB.prepare('SELECT * FROM users WHERE id = ?')
    .bind(targetId)
    .first<Record<string, unknown>>();
  if (!targetRow) {
    return c.json({ success: false, error: 'Pengguna tidak ditemukan.' }, 404);
  }
  const target = rowToUser(targetRow);

  if (target.email === 'sosmeda217@gmail.com' || target.id === 'user-superadmin') {
    return c.json(
      { success: false, error: 'Akun Super Admin utama sistem dilindungi dan tidak dapat dihapus.' },
      403
    );
  }
  if (target.role === 'super_admin' && actor.role !== 'super_admin') {
    return c.json(
      { success: false, error: 'Hanya Super Admin yang berhak menghapus sesama akun Super Admin.' },
      403
    );
  }

  // Revoke all sessions immediately
  await revokeUserSessions(c.env.DB, targetId);

  // Check if user has historical operational references; if so preserve referential integrity by soft-deactivating
  const refReq = await c.env.DB.prepare(
    'SELECT id FROM requests WHERE requester_id = ? OR primary_assignee_id = ? LIMIT 1'
  )
    .bind(targetId, targetId)
    .first();

  if (refReq) {
    await c.env.DB.prepare('UPDATE users SET is_active = 0, updated_at = ? WHERE id = ?')
      .bind(new Date().toISOString(), targetId)
      .run();
  } else {
    await c.env.DB.prepare('DELETE FROM notifications WHERE user_id = ?').bind(targetId).run();
    await c.env.DB.prepare('DELETE FROM users WHERE id = ?').bind(targetId).run();
  }

  await writeSecurityAuditLog(c.env.DB, {
    action: 'user_deleted',
    actorId: actor.id,
    actorName: actor.fullName,
    actorRole: actor.role,
    targetId,
    targetType: 'user',
    summary: `Removed/deactivated user account ${target.fullName} (${target.email})`,
  });

  return c.json({
    success: true,
    message: `Akun pengguna ${target.fullName} (${target.email}) berhasil dihapus.`,
  });
});
