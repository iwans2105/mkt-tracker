import { Hono } from 'hono';
import { requireAuth, requireRole, writeSecurityAuditLog } from '../middleware/auth';
import { randomHex, sha256Hex } from '../crypto';
import { WorkerAppEnv } from '../types';
import { ensurePublicFormConfig, normalizeAllowedEmailDomains } from './public';

export const systemRoutes = new Hono<WorkerAppEnv>();

// 1. Live Cloudflare Service Readiness Diagnostics (Zero simulation; real probes only)
systemRoutes.get('/services-status', requireRole(['super_admin', 'admin']), async (c) => {
  const checkedAt = new Date().toISOString();

  // D1 probe
  let d1Status: { status: 'CONNECTED' | 'ERROR'; latencyMs: number; detail?: string } = {
    status: 'CONNECTED',
    latencyMs: 0,
  };
  try {
    const t0 = Date.now();
    await c.env.DB.prepare('SELECT 1 AS ok').first();
    d1Status = {
      status: 'CONNECTED',
      latencyMs: Date.now() - t0,
      detail: `Environment: ${c.env.ENVIRONMENT || 'local'}`,
    };
  } catch (err: unknown) {
    d1Status = {
      status: 'ERROR',
      latencyMs: 0,
      detail: err instanceof Error ? err.message : String(err),
    };
  }

  // R2 probe
  let r2Status: { status: 'CONNECTED' | 'ERROR'; latencyMs: number; detail?: string } = {
    status: 'CONNECTED',
    latencyMs: 0,
  };
  try {
    const t0 = Date.now();
    await c.env.FILES_BUCKET.head('_healthcheck/probe.txt');
    r2Status = {
      status: 'CONNECTED',
      latencyMs: Date.now() - t0,
      detail: 'Private R2 Bucket Bound (FILES_BUCKET)',
    };
  } catch (err: unknown) {
    r2Status = {
      status: 'ERROR',
      latencyMs: 0,
      detail: err instanceof Error ? err.message : String(err),
    };
  }

  const smtpConfigured = Boolean(c.env.SMTP_HOST && c.env.SMTP_USER && c.env.SMTP_PASS);
  const customDomain = c.env.APP_ORIGIN || 'Placeholder (workers.dev / localhost)';

  return c.json({
    success: true,
    checkedAt,
    environment: c.env.ENVIRONMENT || 'local',
    services: {
      workers_api: { status: 'CONNECTED', runtime: 'Cloudflare Workers + Hono' },
      cloudflare_d1: d1Status,
      cloudflare_r2: r2Status,
      gemini_ai: {
        status: c.env.GEMINI_API_KEY ? 'CONFIGURED' : 'FALLBACK_MODE',
        detail: c.env.GEMINI_API_KEY
          ? 'GEMINI_API_KEY Worker Secret active'
          : 'GEMINI_API_KEY unset — rule-based fallbacks active',
      },
      secrets: {
        session_secret: Boolean(c.env.SESSION_SECRET),
        password_pepper: Boolean(c.env.PASSWORD_PEPPER),
        bootstrap_admin_token: Boolean(c.env.BOOTSTRAP_ADMIN_TOKEN),
      },
      custom_domain: {
        status: c.env.CUSTOM_DOMAIN_STATUS || 'placeholder',
        origin: customDomain,
      },
      smtp_email: {
        status: smtpConfigured ? 'CONFIGURED' : 'BLOCKED',
        detail: smtpConfigured
          ? `SMTP Host: ${c.env.SMTP_HOST}`
          : 'No real SMTP relay credentials configured in Worker Secrets.',
      },
    },
  });
});

// 2. List verified backups
systemRoutes.get('/backups', requireRole(['super_admin', 'admin']), async (c) => {
  const res = await c.env.DB.prepare('SELECT * FROM backups ORDER BY created_at DESC LIMIT 50').all<
    Record<string, unknown>
  >();
  const backups = (res.results || []).map((r) => ({
    id: String(r.id),
    filename: String(r.filename),
    r2Key: String(r.r2_key),
    checksumSha256: String(r.checksum_sha256),
    recordCounts: r.record_counts_json ? JSON.parse(String(r.record_counts_json)) : {},
    integrityStatus: String(r.integrity_status || 'valid'),
    createdBy: String(r.created_by),
    createdAt: String(r.created_at),
  }));
  return c.json({ success: true, backups });
});

// 3. Create verified full D1 backup in R2 + backups index
systemRoutes.post('/backup', requireRole(['super_admin', 'admin']), async (c) => {
  const actor = c.get('user')!;
  const nowIso = new Date().toISOString();
  const backupId = `bkp-${Date.now()}-${randomHex(4)}`;
  const filename = `marcomm_d1_backup_${nowIso.replace(/[:.]/g, '-')}.json`;
  const r2Key = `backups/${filename}`;

  const [
    regions,
    brands,
    units,
    departments,
    categories,
    teams,
    users,
    requests,
    subItems,
    comments,
    activityLogs,
    quotaPolicies,
    quotaLedger,
    quotaReconciliations,
    attachments,
    notifications,
    auditLogs,
  ] = await Promise.all([
    c.env.DB.prepare('SELECT * FROM regions').all(),
    c.env.DB.prepare('SELECT * FROM brands').all(),
    c.env.DB.prepare('SELECT * FROM units').all(),
    c.env.DB.prepare('SELECT * FROM departments').all(),
    c.env.DB.prepare('SELECT * FROM categories').all(),
    c.env.DB.prepare('SELECT * FROM teams').all(),
    c.env.DB.prepare(
      'SELECT id, email, full_name, avatar_url, job_title, department, role, is_reviewer, teams_json, competencies_json, assigned_regions_json, assigned_brands_json, is_active, must_change_password, created_at, updated_at, last_login_at FROM users'
    ).all(),
    c.env.DB.prepare('SELECT * FROM requests').all(),
    c.env.DB.prepare('SELECT * FROM sub_items').all(),
    c.env.DB.prepare('SELECT * FROM comments').all(),
    c.env.DB.prepare('SELECT * FROM activity_logs').all(),
    c.env.DB.prepare('SELECT * FROM priority_quota_policies').all(),
    c.env.DB.prepare('SELECT * FROM priority_quota_ledger').all(),
    c.env.DB.prepare('SELECT * FROM priority_quota_reconciliations').all(),
    c.env.DB.prepare('SELECT * FROM attachments').all(),
    c.env.DB.prepare('SELECT * FROM notifications').all(),
    c.env.DB.prepare('SELECT * FROM security_audit_logs ORDER BY timestamp DESC LIMIT 1000').all(),
  ]);

  const payload = {
    schemaVersion: 'd1-v2-cloudflare',
    exportedAt: nowIso,
    exportedBy: { id: actor.id, email: actor.email, fullName: actor.fullName },
    data: {
      regions: regions.results || [],
      brands: brands.results || [],
      units: units.results || [],
      departments: departments.results || [],
      categories: categories.results || [],
      teams: teams.results || [],
      users: users.results || [],
      requests: requests.results || [],
      sub_items: subItems.results || [],
      comments: comments.results || [],
      activity_logs: activityLogs.results || [],
      priority_quota_policies: quotaPolicies.results || [],
      priority_quota_ledger: quotaLedger.results || [],
      priority_quota_reconciliations: quotaReconciliations.results || [],
      attachments: attachments.results || [],
      notifications: notifications.results || [],
      security_audit_logs: auditLogs.results || [],
    },
  };

  const jsonText = JSON.stringify(payload, null, 2);
  const checksum = await sha256Hex(jsonText);

  await c.env.FILES_BUCKET.put(r2Key, jsonText, {
    httpMetadata: { contentType: 'application/json' },
    customMetadata: { sha256: checksum, backupId, createdBy: actor.id },
  });

  const recordCounts = {
    users: payload.data.users.length,
    requests: payload.data.requests.length,
    subItems: payload.data.sub_items.length,
    quotaLedger: payload.data.priority_quota_ledger.length,
    attachments: payload.data.attachments.length,
  };

  await c.env.DB.prepare(
    `INSERT INTO backups (id, filename, r2_key, checksum_sha256, record_counts_json, integrity_status, created_by, created_at)
     VALUES (?, ?, ?, ?, ?, 'valid', ?, ?)`
  )
    .bind(backupId, filename, r2Key, checksum, JSON.stringify(recordCounts), actor.fullName, nowIso)
    .run();

  await writeSecurityAuditLog(c.env.DB, {
    action: 'system_backup_created',
    actorId: actor.id,
    actorName: actor.fullName,
    actorRole: actor.role,
    targetId: backupId,
    targetType: 'backup',
    summary: `D1 verified backup exported to R2 (${filename}, SHA-256: ${checksum.slice(0, 12)}...)`,
  });

  return c.json({
    success: true,
    backup: {
      id: backupId,
      filename,
      r2Key,
      checksumSha256: checksum,
      recordCounts,
      integrityStatus: 'valid',
      createdBy: actor.fullName,
      createdAt: nowIso,
    },
    content: jsonText,
  });
});

// 4. Download backup with checksum integrity check
systemRoutes.get('/backups/:id/download', requireRole(['super_admin', 'admin']), async (c) => {
  const backupId = c.req.param('id');
  const row = await c.env.DB.prepare('SELECT * FROM backups WHERE id = ?')
    .bind(backupId)
    .first<Record<string, unknown>>();
  if (!row) {
    return c.json({ success: false, error: 'Backup tidak ditemukan.' }, 404);
  }

  const r2Obj = await c.env.FILES_BUCKET.get(String(row.r2_key));
  if (!r2Obj) {
    return c.json({ success: false, error: 'File backup tidak ditemukan pada R2.' }, 404);
  }

  const text = await r2Obj.text();
  const actualSha = await sha256Hex(text);
  const expectedSha = String(row.checksum_sha256);
  if (actualSha !== expectedSha) {
    await c.env.DB.prepare("UPDATE backups SET integrity_status = 'corrupted' WHERE id = ?")
      .bind(backupId)
      .run();
    return c.json(
      { success: false, error: 'Integritas backup gagal diverifikasi (SHA-256 mismatch).' },
      500
    );
  }

  return new Response(text, {
    status: 200,
    headers: {
      'Content-Type': 'application/json',
      'Content-Disposition': `attachment; filename="${String(row.filename)}"`,
      'Cache-Control': 'private, no-store',
      'X-File-SHA256': actualSha,
    },
  });
});

// 5. Purge operational data cleanly (Super Admin only - preserves users & master data, resets quota used_count to 0)
systemRoutes.post('/purge-operational', requireRole(['super_admin']), async (c) => {
  const actor = c.get('user')!;
  const body = await c.req.json().catch(() => ({}));
  if (body.confirmText !== 'RESET') {
    return c.json(
      { success: false, error: 'Konfirmasi gagal: Ketik "RESET" untuk mengosongkan data operasional D1.' },
      400
    );
  }

  await c.env.DB.batch([
    c.env.DB.prepare('DELETE FROM priority_quota_idempotency'),
    c.env.DB.prepare('DELETE FROM priority_quota_ledger'),
    c.env.DB.prepare('DELETE FROM priority_quota_reconciliations'),
    c.env.DB.prepare('UPDATE priority_quota_policies SET used_count = 0'),
    c.env.DB.prepare('DELETE FROM notifications'),
    c.env.DB.prepare('DELETE FROM activity_logs'),
    c.env.DB.prepare('DELETE FROM comments'),
    c.env.DB.prepare('DELETE FROM sub_items'),
    c.env.DB.prepare("UPDATE attachments SET deleted_at = ? WHERE scope_type IN ('brief', 'deliverable', 'subitem')").bind(
      new Date().toISOString()
    ),
    c.env.DB.prepare('DELETE FROM requests'),
  ]);

  await writeSecurityAuditLog(c.env.DB, {
    action: 'system_operational_purged',
    actorId: actor.id,
    actorName: actor.fullName,
    actorRole: actor.role,
    summary: 'Super Admin purged all operational request tickets and reset quota counters to zero (Zero-Mock Production Reset).',
  });

  return c.json({
    success: true,
    message: 'Seluruh data tiket operasional D1 dan penggunaan kuota telah dikosongkan.',
  });
});

// 6. Public Request Form Link & Security Configuration (Super Admin & Admin)
systemRoutes.get('/public-form-config', requireRole(['super_admin', 'admin']), async (c) => {
  const cfg = await ensurePublicFormConfig(c.env.DB);
  return c.json({
    success: true,
    config: {
      enabled: cfg.enabled,
      requireToken: cfg.requireToken,
      allowAttachments: cfg.allowAttachments,
      accessToken: cfg.accessToken,
      allowedEmailDomains: cfg.allowedEmailDomains,
      updatedBy: cfg.updatedBy,
      updatedAt: cfg.updatedAt,
    },
  });
});

systemRoutes.put('/public-form-config', requireRole(['super_admin', 'admin']), async (c) => {
  const actor = c.get('user')!;
  const cfg = await ensurePublicFormConfig(c.env.DB);
  const body = await c.req.json().catch(() => ({}));

  const enabled = typeof body.enabled === 'boolean' ? body.enabled : cfg.enabled;
  const requireToken = typeof body.requireToken === 'boolean' ? body.requireToken : cfg.requireToken;
  const allowAttachments =
    typeof body.allowAttachments === 'boolean' ? body.allowAttachments : cfg.allowAttachments;
  const allowedEmailDomains =
    body.allowedEmailDomains !== undefined
      ? normalizeAllowedEmailDomains(body.allowedEmailDomains)
      : cfg.allowedEmailDomains;

  const nowIso = new Date().toISOString();
  await c.env.DB.prepare(
    `UPDATE public_form_config
     SET enabled = ?, require_token = ?, allow_attachments = ?, allowed_email_domains_json = ?, updated_by = ?, updated_at = ?
     WHERE id = 'default'`
  )
    .bind(
      enabled ? 1 : 0,
      requireToken ? 1 : 0,
      allowAttachments ? 1 : 0,
      JSON.stringify(allowedEmailDomains),
      actor.fullName,
      nowIso
    )
    .run();

  await writeSecurityAuditLog(c.env.DB, {
    action: 'public_form_config_updated',
    actorId: actor.id,
    actorName: actor.fullName,
    actorRole: actor.role,
    targetId: 'default',
    targetType: 'public_form_config',
    summary: `Updated public form config (enabled=${enabled}, requireToken=${requireToken}, allowAttachments=${allowAttachments}, domains=${allowedEmailDomains.join(',') || 'any'})`,
  });

  return c.json({
    success: true,
    config: {
      enabled,
      requireToken,
      allowAttachments,
      accessToken: cfg.accessToken,
      allowedEmailDomains,
      updatedBy: actor.fullName,
      updatedAt: nowIso,
    },
  });
});

systemRoutes.post('/public-form-config/rotate', requireRole(['super_admin', 'admin']), async (c) => {
  const actor = c.get('user')!;
  await ensurePublicFormConfig(c.env.DB);

  const nextToken = randomHex(16);
  const nextHash = await sha256Hex(nextToken);
  const nowIso = new Date().toISOString();

  await c.env.DB.prepare(
    `UPDATE public_form_config
     SET access_token = ?, token_hash = ?, updated_by = ?, updated_at = ?
     WHERE id = 'default'`
  )
    .bind(nextToken, nextHash, actor.fullName, nowIso)
    .run();

  await writeSecurityAuditLog(c.env.DB, {
    action: 'public_form_token_rotated',
    actorId: actor.id,
    actorName: actor.fullName,
    actorRole: actor.role,
    targetId: 'default',
    targetType: 'public_form_config',
    summary: `Rotated public request form access token (previous link invalidated)`,
  });

  const updated = await ensurePublicFormConfig(c.env.DB);
  return c.json({
    success: true,
    config: {
      enabled: updated.enabled,
      requireToken: updated.requireToken,
      allowAttachments: updated.allowAttachments,
      accessToken: updated.accessToken,
      allowedEmailDomains: updated.allowedEmailDomains,
      updatedBy: updated.updatedBy,
      updatedAt: updated.updatedAt,
    },
  });
});

// Public health probe (no secrets)
systemRoutes.get('/health', async (c) => {
  try {
    await c.env.DB.prepare('SELECT 1 AS ok').first();
    return c.json({
      success: true,
      status: 'ok',
      runtime: 'cloudflare-workers-d1-r2',
      environment: c.env.ENVIRONMENT || 'local',
    });
  } catch (err: unknown) {
    return c.json(
      { success: false, status: 'error', error: err instanceof Error ? err.message : String(err) },
      500
    );
  }
});
