import { Hono } from 'hono';
import type { D1Database } from '@cloudflare/workers-types';
import type {
  BrandQuotaSummary,
  PeriodReportingMetrics,
  PriorityAvailability,
  PriorityPeriodMetric,
  ReportingPeriodMode,
  RequestItem,
  RequestPriority,
} from '../../types';
import {
  isUserWithinBrandScope,
  requireAuth,
  requireRole,
  writeSecurityAuditLog,
} from '../middleware/auth';
import { randomHex } from '../crypto';
import {
  rowToQuotaLedger,
  rowToQuotaPolicy,
  rowToRequest,
  StoredUserRecord,
  WorkerAppEnv,
} from '../types';
import { getWibYear, getWibYearFromIso, normalizeQuotaYear } from '../utils/wib';

export const DEFAULT_ANNUAL_LIMITS: Record<RequestPriority, number> = {
  urgent: 3,
  high: 6,
  medium: 9,
  low: -1,
};

export const DEFAULT_SLA_DAYS: Record<RequestPriority, number> = {
  urgent: 1,
  high: 3,
  medium: 7,
  low: 14,
};

export async function ensureBrandPoliciesD1(db: D1Database, brandId: string, year: number) {
  const existing = await db
    .prepare('SELECT priority FROM priority_quota_policies WHERE brand_id = ? AND year = ?')
    .bind(brandId, year)
    .all<{ priority: string }>();

  const existingSet = new Set((existing.results || []).map((r) => r.priority));
  const now = new Date().toISOString();
  const stmts = [];

  for (const prio of ['urgent', 'high', 'medium', 'low'] as RequestPriority[]) {
    if (!existingSet.has(prio)) {
      stmts.push(
        db
          .prepare(
            `INSERT OR IGNORE INTO priority_quota_policies
             (id, brand_id, year, priority, annual_limit, used_count, sla_days, created_at, updated_at)
             VALUES (?, ?, ?, ?, ?, 0, ?, ?, ?)`
          )
          .bind(
            `pol-${brandId}-${year}-${prio}`,
            brandId,
            year,
            prio,
            DEFAULT_ANNUAL_LIMITS[prio],
            DEFAULT_SLA_DAYS[prio],
            now,
            now
          )
      );
    }
  }
  if (stmts.length > 0) {
    await db.batch(stmts);
  }
}

export async function getBrandQuotaSummaryD1(
  db: D1Database,
  brandId: string,
  brandName: string,
  rawYear?: number | string | null
): Promise<BrandQuotaSummary> {
  const year = normalizeQuotaYear(rawYear);
  await ensureBrandPoliciesD1(db, brandId, year);

  const [polRes, ledRes] = await Promise.all([
    db
      .prepare('SELECT * FROM priority_quota_policies WHERE brand_id = ? AND year = ?')
      .bind(brandId, year)
      .all<Record<string, unknown>>(),
    db
      .prepare('SELECT priority, quantity FROM priority_quota_ledger WHERE brand_id = ? AND year = ?')
      .bind(brandId, year)
      .all<{ priority: string; quantity: number }>(),
  ]);

  const policies = (polRes.results || []).map(rowToQuotaPolicy);
  const ledgerRows = ledRes.results || [];

  const priorities: Record<RequestPriority, PriorityAvailability> = {} as Record<
    RequestPriority,
    PriorityAvailability
  >;
  let warningCount = 0;
  let exhaustedCount = 0;

  for (const prio of ['urgent', 'high', 'medium', 'low'] as RequestPriority[]) {
    const policy = policies.find((p) => p.priority === prio);
    const limit = policy ? policy.annualLimit : DEFAULT_ANNUAL_LIMITS[prio];
    const sla = policy ? policy.slaDays : DEFAULT_SLA_DAYS[prio];

    if (limit === -1) {
      priorities[prio] = {
        priority: prio,
        name: prio.charAt(0).toUpperCase() + prio.slice(1),
        slaDays: sla,
        annualLimit: -1,
        used: 0,
        remaining: -1,
        utilizationPercent: 0,
        isExhausted: false,
        statusLabel: 'Unlimited',
      };
    } else {
      const ledgerUsed = ledgerRows
        .filter((r) => r.priority === prio)
        .reduce((acc, r) => acc - Number(r.quantity), 0);
      const used = Math.max(policy?.usedCount || 0, Math.max(0, ledgerUsed));
      const remaining = Math.max(0, limit - used);
      const isExhausted = remaining === 0;
      const utilizationPercent = limit > 0 ? Math.min(100, Math.round((used / limit) * 100)) : 0;
      if (remaining === 1) warningCount++;
      if (isExhausted) exhaustedCount++;

      priorities[prio] = {
        priority: prio,
        name: prio.charAt(0).toUpperCase() + prio.slice(1),
        slaDays: sla,
        annualLimit: limit,
        used,
        remaining,
        utilizationPercent,
        isExhausted,
        statusLabel: isExhausted ? 'Quota Exhausted' : 'Available',
      };
    }
  }

  return {
    brandId,
    brandName,
    year,
    priorities,
    warningCount,
    exhaustedCount,
    lastUpdated: new Date().toISOString(),
  };
}

export async function consumeQuotaAtomicallyD1(params: {
  db: D1Database;
  brandId: string;
  brandName: string;
  priority: RequestPriority;
  requestId: string;
  ticketNumber: string;
  actor: StoredUserRecord;
  reason?: string;
  idempotencyKey?: string;
  year?: number;
}): Promise<{ success: boolean; remaining?: number; deduplicated?: boolean; error?: string }> {
  const { db, brandId, brandName, priority, requestId, ticketNumber, actor, reason, idempotencyKey } =
    params;
  const year = normalizeQuotaYear(params.year);

  if (priority === 'low') {
    return { success: true, remaining: -1 };
  }

  await ensureBrandPoliciesD1(db, brandId, year);

  // Fast idempotency check
  if (idempotencyKey) {
    const dup = await db
      .prepare('SELECT idempotency_key FROM priority_quota_idempotency WHERE idempotency_key = ?')
      .bind(idempotencyKey)
      .first();
    if (dup) {
      const summary = await getBrandQuotaSummaryD1(db, brandId, brandName, year);
      return { success: true, remaining: summary.priorities[priority].remaining, deduplicated: true };
    }
  }

  const existingReqLedger = await db
    .prepare(
      "SELECT id FROM priority_quota_ledger WHERE request_id = ? AND year = ? AND priority = ? AND transaction_type = 'deduction'"
    )
    .bind(requestId, year, priority)
    .first();
  if (existingReqLedger) {
    const summary = await getBrandQuotaSummaryD1(db, brandId, brandName, year);
    return { success: true, remaining: summary.priorities[priority].remaining, deduplicated: true };
  }

  // Ensure referenced request exists before inserting deduction ledger row (foreign key + trigger integrity)
  const reqExists = await db.prepare('SELECT id FROM requests WHERE id = ?').bind(requestId).first();
  if (!reqExists) {
    return {
      success: false,
      error: 'Request harus dibuat dalam transaksi atomik /api/requests atau sudah terdaftar di D1.',
    };
  }

  const nowIso = new Date().toISOString();
  const ledgerId = `qled-${Date.now()}-${randomHex(4)}`;
  const effIdempKey = idempotencyKey || `req-${requestId}-${year}-${priority}`;

  try {
    await db.batch([
      db
        .prepare(
          `INSERT INTO priority_quota_idempotency (idempotency_key, request_id, brand_id, year, priority, created_at)
           VALUES (?, ?, ?, ?, ?, ?)`
        )
        .bind(effIdempKey, requestId, brandId, year, priority, nowIso),
      db
        .prepare(
          `INSERT INTO priority_quota_ledger
           (id, brand_id, year, priority, request_id, ticket_number, transaction_type, quantity, actor_id, actor_name, actor_role, reason, idempotency_key, created_at)
           VALUES (?, ?, ?, ?, ?, ?, 'deduction', -1, ?, ?, ?, ?, ?, ?)`
        )
        .bind(
          ledgerId,
          brandId,
          year,
          priority,
          requestId,
          ticketNumber,
          actor.id,
          actor.fullName,
          actor.role,
          reason || `Request submission (${ticketNumber})`,
          effIdempKey,
          nowIso
        ),
    ]);
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err);
    if (msg.includes('UNIQUE') && msg.includes('idempotency')) {
      const summary = await getBrandQuotaSummaryD1(db, brandId, brandName, year);
      return { success: true, remaining: summary.priorities[priority].remaining, deduplicated: true };
    }
    const summary = await getBrandQuotaSummaryD1(db, brandId, brandName, year);
    const avail = summary.priorities[priority];
    return {
      success: false,
      error: `Kuota tahunan untuk prioritas ${avail.name} pada brand ${brandName} telah habis (0/${avail.annualLimit} tersisa). Silakan pilih prioritas lain yang masih tersedia.`,
    };
  }

  const summary = await getBrandQuotaSummaryD1(db, brandId, brandName, year);
  return { success: true, remaining: summary.priorities[priority].remaining };
}

export async function reallocateQuotaAtomicallyD1(params: {
  db: D1Database;
  brandId: string;
  brandName: string;
  oldPriority: RequestPriority;
  newPriority: RequestPriority;
  requestId: string;
  ticketNumber: string;
  actor: StoredUserRecord;
  reason: string;
  year?: number;
}): Promise<{ success: boolean; error?: string }> {
  const { db, brandId, brandName, oldPriority, newPriority, requestId, ticketNumber, actor, reason } =
    params;
  const year = normalizeQuotaYear(params.year);

  if (oldPriority === newPriority) return { success: true };

  await ensureBrandPoliciesD1(db, brandId, year);
  const nowIso = new Date().toISOString();
  const stmts = [];

  if (oldPriority !== 'low') {
    stmts.push(
      db
        .prepare(
          `INSERT INTO priority_quota_ledger
           (id, brand_id, year, priority, request_id, ticket_number, transaction_type, quantity, actor_id, actor_name, actor_role, reason, created_at)
           VALUES (?, ?, ?, ?, ?, ?, 'release', 1, ?, ?, ?, ?, ?)`
        )
        .bind(
          `qled-rel-${Date.now()}-${randomHex(4)}`,
          brandId,
          year,
          oldPriority,
          requestId,
          ticketNumber,
          actor.id,
          actor.fullName,
          actor.role,
          `Priority changed from ${oldPriority} to ${newPriority}: ${reason}`,
          nowIso
        )
    );
  }

  if (newPriority !== 'low') {
    stmts.push(
      db
        .prepare(
          `INSERT INTO priority_quota_ledger
           (id, brand_id, year, priority, request_id, ticket_number, transaction_type, quantity, actor_id, actor_name, actor_role, reason, created_at)
           VALUES (?, ?, ?, ?, ?, ?, 'deduction', -1, ?, ?, ?, ?, ?)`
        )
        .bind(
          `qled-ded-${Date.now()}-${randomHex(4)}`,
          brandId,
          year,
          newPriority,
          requestId,
          ticketNumber,
          actor.id,
          actor.fullName,
          actor.role,
          `Priority changed to ${newPriority}: ${reason}`,
          nowIso
        )
    );
  }

  stmts.push(
    db
      .prepare('UPDATE requests SET priority = ?, updated_at = ? WHERE id = ?')
      .bind(newPriority, nowIso, requestId)
  );

  try {
    await db.batch(stmts);
    return { success: true };
  } catch {
    const summary = await getBrandQuotaSummaryD1(db, brandId, brandName, year);
    const newAvail = summary.priorities[newPriority];
    return {
      success: false,
      error: `Gagal mengubah prioritas: Kuota untuk ${newAvail.name} pada brand ${brandName} telah habis (0/${newAvail.annualLimit} tersisa).`,
    };
  }
}

export const quotaRoutes = new Hono<WorkerAppEnv>();

// 0. Discover available years dynamically (static route BEFORE /:brandId)
quotaRoutes.get('/years', requireAuth, async (c) => {
  const activeYear = getWibYear();
  const yearSet = new Set<number>([activeYear]);

  const [polYears, ledYears, recYears] = await Promise.all([
    c.env.DB.prepare('SELECT DISTINCT year FROM priority_quota_policies').all<{ year: number }>(),
    c.env.DB.prepare('SELECT DISTINCT year, created_at FROM priority_quota_ledger').all<{
      year: number;
      created_at: string;
    }>(),
    c.env.DB.prepare('SELECT DISTINCT year FROM priority_quota_reconciliations').all<{
      year: number;
    }>(),
  ]);

  for (const r of polYears.results || []) {
    if (Number.isInteger(r.year) && r.year >= 1900 && r.year <= 9999) yearSet.add(r.year);
  }
  for (const r of ledYears.results || []) {
    if (Number.isInteger(r.year) && r.year >= 1900 && r.year <= 9999) yearSet.add(r.year);
    const yr = getWibYearFromIso(r.created_at);
    if (yr) yearSet.add(yr);
  }
  for (const r of recYears.results || []) {
    if (Number.isInteger(r.year) && r.year >= 1900 && r.year <= 9999) yearSet.add(r.year);
  }

  return c.json({
    success: true,
    activeYear,
    years: Array.from(yearSet).sort((a, b) => b - a),
  });
});

// 1. Quota Reporting Period Metrics & Activity (MUST stay before /:brandId)
quotaRoutes.get('/reporting', requireAuth, async (c) => {
  const user = c.get('user')!;
  const brandId = c.req.query('brandId') || 'all';
  const brandName = c.req.query('brandName') || brandId;
  const startDate = c.req.query('startDate');
  const endDate = c.req.query('endDate');
  const yearParam = c.req.query('year');
  const modeParam = c.req.query('mode') as ReportingPeriodMode | undefined;

  if (brandId !== 'all' && !isUserWithinBrandScope(user, undefined, brandId)) {
    return c.json({ success: false, error: 'Akses brand di luar cakupan Anda.' }, 403);
  }

  if (startDate && endDate && startDate > endDate) {
    return c.json({ success: false, error: 'Start Date tidak boleh lebih besar dari End Date.' }, 400);
  }

  const currentWibYear = getWibYear();
  const mode: ReportingPeriodMode =
    modeParam || (startDate && endDate ? 'custom_range' : 'calendar_year');
  const targetYear = yearParam ? normalizeQuotaYear(yearParam) : currentWibYear;
  const effectiveStartDate =
    mode === 'calendar_year' || !startDate || !endDate ? `${targetYear}-01-01` : startDate;
  const effectiveEndDate =
    mode === 'calendar_year' || !startDate || !endDate ? `${targetYear}-12-31` : endDate;

  const startIsoWib = `${effectiveStartDate}T00:00:00+07:00`;
  const endIsoWib = `${effectiveEndDate}T23:59:59.999+07:00`;
  const startMs = new Date(startIsoWib).getTime();
  const endMs = new Date(endIsoWib).getTime();

  const startY = parseInt(effectiveStartDate.split('-')[0], 10);
  const endY = parseInt(effectiveEndDate.split('-')[0], 10);
  const affectedYears: number[] = [];
  for (let y = Math.min(startY, endY); y <= Math.max(startY, endY); y++) {
    affectedYears.push(y);
  }

  const res =
    brandId === 'all'
      ? await c.env.DB.prepare('SELECT * FROM priority_quota_ledger ORDER BY created_at DESC').all<
          Record<string, unknown>
        >()
      : await c.env.DB.prepare(
          'SELECT * FROM priority_quota_ledger WHERE brand_id = ? ORDER BY created_at DESC'
        )
          .bind(brandId)
          .all<Record<string, unknown>>();

  const periodEntries = (res.results || [])
    .map(rowToQuotaLedger)
    .filter((entry) => {
      if (brandId === 'all' && !isUserWithinBrandScope(user, undefined, entry.brandId)) {
        return false;
      }
      const ms = new Date(entry.createdAt).getTime();
      return ms >= startMs && ms <= endMs;
    });

  let totalConsumed = 0;
  let totalReleased = 0;
  let totalAdjusted = 0;
  let totalNetUsage = 0;
  const distinctRequests = new Set<string>();

  const priorities: Record<RequestPriority, PriorityPeriodMetric> = {
    urgent: { priority: 'urgent', consumed: 0, released: 0, adjusted: 0, netUsage: 0, requestCount: 0 },
    high: { priority: 'high', consumed: 0, released: 0, adjusted: 0, netUsage: 0, requestCount: 0 },
    medium: { priority: 'medium', consumed: 0, released: 0, adjusted: 0, netUsage: 0, requestCount: 0 },
    low: { priority: 'low', consumed: 0, released: 0, adjusted: 0, netUsage: 0, requestCount: 0 },
  };
  const prioRequests: Record<RequestPriority, Set<string>> = {
    urgent: new Set(),
    high: new Set(),
    medium: new Set(),
    low: new Set(),
  };

  for (const entry of periodEntries) {
    const prio = entry.priority;
    if (entry.requestId) {
      distinctRequests.add(entry.requestId);
      prioRequests[prio]?.add(entry.requestId);
    }
    if (entry.transactionType === 'deduction' || entry.transactionType === 'reconciliation') {
      const amt = Math.abs(entry.quantity);
      totalConsumed += amt;
      totalNetUsage += amt;
      priorities[prio].consumed += amt;
      priorities[prio].netUsage += amt;
    } else if (entry.transactionType === 'release') {
      const amt = Math.abs(entry.quantity);
      totalReleased += amt;
      totalNetUsage -= amt;
      priorities[prio].released += amt;
      priorities[prio].netUsage -= amt;
    } else if (entry.transactionType === 'adjustment') {
      totalAdjusted += entry.quantity;
      totalNetUsage -= entry.quantity;
      priorities[prio].adjusted += entry.quantity;
      priorities[prio].netUsage -= entry.quantity;
    }
  }

  for (const prio of ['urgent', 'high', 'medium', 'low'] as RequestPriority[]) {
    priorities[prio].requestCount = prioRequests[prio].size;
  }

  const metrics: PeriodReportingMetrics = {
    mode,
    brandId,
    brandName,
    startDate: effectiveStartDate,
    endDate: effectiveEndDate,
    startIsoWib,
    endIsoWib,
    affectedYears,
    totalRequestCount: distinctRequests.size,
    totalConsumed,
    totalReleased,
    totalAdjusted,
    totalNetUsage,
    priorities,
    ledgerEntries: periodEntries,
  };

  return c.json({ success: true, metrics });
});

// 2. Quota Audit Ledger History (MUST stay before /:brandId)
quotaRoutes.get('/ledger/history', requireRole(['super_admin', 'admin']), async (c) => {
  const year = c.req.query('year') ? parseInt(c.req.query('year')!, 10) : undefined;
  const brandId = c.req.query('brandId');

  const res = await c.env.DB.prepare(
    'SELECT * FROM priority_quota_ledger ORDER BY created_at DESC LIMIT 1000'
  ).all<Record<string, unknown>>();
  let ledger = (res.results || []).map(rowToQuotaLedger);
  if (year) ledger = ledger.filter((e) => e.year === year);
  if (brandId && brandId !== 'all') ledger = ledger.filter((e) => e.brandId === brandId);

  return c.json({ success: true, ledger });
});

// 3. Get Quota Summaries for All Brands
quotaRoutes.get('/', requireAuth, async (c) => {
  const user = c.get('user')!;
  const year = normalizeQuotaYear(c.req.query('year'));
  const brandsJson = c.req.query('brands');
  let brands: { id: string; name: string }[] = [];

  if (brandsJson) {
    try {
      brands = JSON.parse(brandsJson);
    } catch {
      brands = [];
    }
  }

  if (brands.length === 0) {
    const dbBrands = await c.env.DB.prepare('SELECT id, name FROM brands WHERE is_active = 1').all<{
      id: string;
      name: string;
    }>();
    brands = dbBrands.results || [];
  }

  const scopedBrands = brands.filter((b) => isUserWithinBrandScope(user, undefined, b.id));
  const summaries = await Promise.all(
    scopedBrands.map((b) => getBrandQuotaSummaryD1(c.env.DB, b.id, b.name, year))
  );
  return c.json({ success: true, year, summaries });
});

// 4. Consume quota endpoint (for direct calls / backward compatibility)
quotaRoutes.post('/consume', requireAuth, async (c) => {
  const user = c.get('user')!;
  const body = await c.req.json().catch(() => ({}));
  const { brandId, brandName, priority, requestId, ticketNumber, reason, idempotencyKey, year } = body;

  if (!brandId || !priority || !requestId || !ticketNumber) {
    return c.json(
      { success: false, error: 'Data tidak lengkap (brandId, priority, requestId, ticketNumber wajib ada).' },
      400
    );
  }

  if (!isUserWithinBrandScope(user, undefined, brandId)) {
    return c.json({ success: false, error: 'Akses ditolak: Brand di luar cakupan akun Anda.' }, 403);
  }

  const result = await consumeQuotaAtomicallyD1({
    db: c.env.DB,
    brandId,
    brandName: brandName || brandId,
    priority,
    requestId,
    ticketNumber,
    actor: user,
    reason,
    idempotencyKey,
    year,
  });

  if (!result.success) {
    await writeSecurityAuditLog(c.env.DB, {
      action: 'quota_consumption_rejected',
      actorId: user.id,
      actorName: user.fullName,
      actorRole: user.role,
      summary: `Penolakan konsumsi kuota ${priority} pada brand ${brandName || brandId}: ${result.error}`,
    });
    return c.json({ success: false, error: result.error }, 409);
  }

  return c.json({ success: true, remaining: result.remaining });
});

// 5. Controlled Manual Quota Adjustment (Super Admin & Marcomm Admin)
quotaRoutes.post('/adjust', requireRole(['super_admin', 'admin']), async (c) => {
  const actor = c.get('user')!;
  const body = await c.req.json().catch(() => ({}));
  const { brandId, brandName, priority, quantity, reason, year } = body;

  if (!brandId || !priority || typeof quantity !== 'number' || !reason || reason.trim().length < 5) {
    return c.json(
      { success: false, error: 'brandId, priority, quantity, dan reason (>= 5 karakter) wajib disertakan.' },
      400
    );
  }

  if (!isUserWithinBrandScope(actor, undefined, brandId)) {
    return c.json({ success: false, error: 'Akses ditolak: Brand di luar cakupan Anda.' }, 403);
  }

  const targetYear = normalizeQuotaYear(year);
  await ensureBrandPoliciesD1(c.env.DB, brandId, targetYear);

  try {
    await c.env.DB.prepare(
      `INSERT INTO priority_quota_ledger
       (id, brand_id, year, priority, transaction_type, quantity, actor_id, actor_name, actor_role, reason, created_at)
       VALUES (?, ?, ?, ?, 'adjustment', ?, ?, ?, ?, ?, ?)`
    )
      .bind(
        `qled-adj-${Date.now()}-${randomHex(4)}`,
        brandId,
        targetYear,
        priority,
        quantity,
        actor.id,
        actor.fullName,
        actor.role,
        reason.trim(),
        new Date().toISOString()
      )
      .run();
  } catch (err: unknown) {
    return c.json(
      {
        success: false,
        error: err instanceof Error ? err.message : 'Penyesuaian kuota melebihi batas kebijakan.',
      },
      400
    );
  }

  await writeSecurityAuditLog(c.env.DB, {
    action: 'quota_manual_adjustment',
    actorId: actor.id,
    actorName: actor.fullName,
    actorRole: actor.role,
    summary: `Penyesuaian kuota manual (${quantity > 0 ? `+${quantity}` : quantity}) untuk [${priority}] pada ${brandName || brandId}. Alasan: ${reason}`,
  });

  const summary = await getBrandQuotaSummaryD1(c.env.DB, brandId, brandName || brandId, targetYear);
  return c.json({ success: true, newRemaining: summary.priorities[priority as RequestPriority].remaining });
});

// 6. Update Annual Quota Limits
quotaRoutes.put('/policies', requireRole(['super_admin', 'admin']), async (c) => {
  const actor = c.get('user')!;
  const body = await c.req.json().catch(() => ({}));
  const { brandId, year, limits } = body;

  if (!brandId || !limits) {
    return c.json({ success: false, error: 'brandId dan limits wajib disertakan.' }, 400);
  }

  if (!isUserWithinBrandScope(actor, undefined, brandId)) {
    return c.json({ success: false, error: 'Akses ditolak: Brand di luar cakupan Anda.' }, 403);
  }

  const targetYear = normalizeQuotaYear(year);
  await ensureBrandPoliciesD1(c.env.DB, brandId, targetYear);
  const nowIso = new Date().toISOString();

  for (const prio of ['urgent', 'high', 'medium'] as const) {
    if (limits[prio] !== undefined) {
      const nextLimit = Math.max(0, Number(limits[prio]));
      const curPol = await c.env.DB.prepare(
        'SELECT used_count FROM priority_quota_policies WHERE brand_id = ? AND year = ? AND priority = ?'
      )
        .bind(brandId, targetYear, prio)
        .first<{ used_count: number }>();
      if (curPol && nextLimit < curPol.used_count) {
        return c.json(
          {
            success: false,
            error: `Batas kuota ${prio} (${nextLimit}) tidak boleh lebih kecil dari pemakaian aktif (${curPol.used_count}).`,
          },
          400
        );
      }
      await c.env.DB.prepare(
        'UPDATE priority_quota_policies SET annual_limit = ?, updated_at = ? WHERE brand_id = ? AND year = ? AND priority = ?'
      )
        .bind(nextLimit, nowIso, brandId, targetYear, prio)
        .run();
    }
  }

  await writeSecurityAuditLog(c.env.DB, {
    action: 'quota_policy_updated',
    actorId: actor.id,
    actorName: actor.fullName,
    actorRole: actor.role,
    summary: `Pembaruan batas kuota tahunan brand ${brandId} untuk tahun ${targetYear}: ${JSON.stringify(limits)}`,
  });

  return c.json({ success: true });
});

// 7. Historical Reconciliation Preview (queries authoritative D1 requests, or accepts fallback array)
quotaRoutes.post('/reconciliation/preview', requireRole(['super_admin', 'admin']), async (c) => {
  const body = await c.req.json().catch(() => ({}));
  const year = normalizeQuotaYear(body.year);

  const recRow = await c.env.DB.prepare('SELECT * FROM priority_quota_reconciliations WHERE year = ?')
    .bind(year)
    .first<Record<string, unknown>>();

  const dbBrands = await c.env.DB.prepare('SELECT id, name FROM brands WHERE is_active = 1').all<{
    id: string;
    name: string;
  }>();
  const brands: { id: string; name: string }[] =
    Array.isArray(body.brands) && body.brands.length > 0 ? body.brands : dbBrands.results || [];

  const dbReqRows = await c.env.DB.prepare(
    'SELECT * FROM requests WHERE deleted_at IS NULL'
  ).all<Record<string, unknown>>();
  const dbRequests = (dbReqRows.results || []).map((r) => rowToRequest(r, []));
  const requests: RequestItem[] = dbRequests.length > 0 ? dbRequests : body.requests || [];

  const eligible = requests.filter((r) => {
    if (r.deletedAt || !r.createdAt) return false;
    const wibY = getWibYearFromIso(r.createdAt);
    const reqY = wibY ?? parseInt(r.createdAt.split('T')[0].split('-')[0], 10);
    return reqY === year;
  });

  const brandPreviews = await Promise.all(
    brands.map(async (b) => {
      const brandRequests = eligible.filter((r) => r.brandId === b.id);
      const summary = await getBrandQuotaSummaryD1(c.env.DB, b.id, b.name, year);

      const priorities = (['urgent', 'high', 'medium'] as RequestPriority[]).map((prio) => {
        const prioRequests = brandRequests.filter((r) => r.priority === prio);
        const currentUsed = summary.priorities[prio].used;
        const limit = summary.priorities[prio].annualLimit;
        const projectedUsage = prioRequests.length;
        const projectedRemaining = Math.max(0, limit - projectedUsage);

        return {
          priority: prio,
          currentUsed,
          projectedUsage,
          limit,
          projectedRemaining,
          requestCount: prioRequests.length,
          requests: prioRequests.map((r) => ({
            id: r.id,
            ticketNumber: r.ticketNumber,
            title: r.title,
            createdAt: r.createdAt,
          })),
        };
      });

      return { brandId: b.id, brandName: b.name, priorities };
    })
  );

  return c.json({
    success: true,
    preview: {
      year,
      totalEligibleRequests: eligible.length,
      isApplied: Boolean(recRow),
      appliedAt: recRow?.applied_at ? String(recRow.applied_at) : undefined,
      appliedBy: recRow?.applied_by_name ? String(recRow.applied_by_name) : undefined,
      brands: brandPreviews,
    },
  });
});

// 8. Apply Historical Reconciliation (Super Admin Only, idempotent)
quotaRoutes.post('/reconciliation/apply', requireRole(['super_admin']), async (c) => {
  const actor = c.get('user')!;
  const body = await c.req.json().catch(() => ({}));
  const year = normalizeQuotaYear(body.year);

  const existingRec = await c.env.DB.prepare(
    'SELECT id FROM priority_quota_reconciliations WHERE year = ?'
  )
    .bind(year)
    .first();
  if (existingRec) {
    return c.json(
      {
        success: false,
        error: `Rekonsiliasi kuota historis untuk tahun ${year} sudah pernah diterapkan sebelumnya.`,
      },
      400
    );
  }

  const dbReqRows = await c.env.DB.prepare(
    'SELECT * FROM requests WHERE deleted_at IS NULL'
  ).all<Record<string, unknown>>();
  const requests = (dbReqRows.results || []).map((r) => rowToRequest(r, []));

  const eligible = requests.filter((r) => {
    if (r.deletedAt || !r.createdAt || r.priority === 'low') return false;
    const wibY = getWibYearFromIso(r.createdAt);
    const reqY = wibY ?? parseInt(r.createdAt.split('T')[0].split('-')[0], 10);
    return reqY === year;
  });

  const existingLedger = await c.env.DB.prepare(
    'SELECT DISTINCT request_id FROM priority_quota_ledger WHERE request_id IS NOT NULL'
  ).all<{ request_id: string }>();
  const loggedReqSet = new Set((existingLedger.results || []).map((r) => r.request_id));

  const nowIso = new Date().toISOString();
  const stmts = [];
  let appliedCount = 0;

  for (const req of eligible) {
    if (loggedReqSet.has(req.id)) continue;
    await ensureBrandPoliciesD1(c.env.DB, req.brandId, year);
    stmts.push(
      c.env.DB.prepare(
        `INSERT INTO priority_quota_ledger
         (id, brand_id, year, priority, request_id, ticket_number, transaction_type, quantity, actor_id, actor_name, actor_role, reason, created_at)
         VALUES (?, ?, ?, ?, ?, ?, 'reconciliation', -1, ?, ?, ?, ?, ?)`
      ).bind(
        `qled-rec-${Date.now()}-${randomHex(4)}`,
        req.brandId,
        year,
        req.priority,
        req.id,
        req.ticketNumber,
        actor.id,
        actor.fullName,
        actor.role,
        `Historical reconciliation for ${year} ticket: ${req.ticketNumber} (${req.title})`,
        nowIso
      )
    );
    appliedCount++;
  }

  stmts.push(
    c.env.DB.prepare(
      `INSERT INTO priority_quota_reconciliations (id, brand_id, year, total_reconciled, applied_by, applied_by_name, applied_at)
       VALUES (?, 'all', ?, ?, ?, ?, ?)`
    ).bind(`rec-${year}-${Date.now()}`, year, appliedCount, actor.id, actor.fullName, nowIso)
  );

  await c.env.DB.batch(stmts);

  await writeSecurityAuditLog(c.env.DB, {
    action: 'quota_historical_reconciliation_applied',
    actorId: actor.id,
    actorName: actor.fullName,
    actorRole: actor.role,
    summary: `Super Admin menyetujui rekonsiliasi kuota historis tahun ${year}: ${appliedCount} tiket tercatat ke ledger.`,
  });

  return c.json({ success: true, appliedCount });
});

// 9. Get Quota Summary for a single Brand (dynamic param AFTER static routes)
quotaRoutes.get('/:brandId', requireAuth, async (c) => {
  const user = c.get('user')!;
  const brandId = c.req.param('brandId') || '';
  const brandName = c.req.query('brandName') || brandId;
  const year = normalizeQuotaYear(c.req.query('year'));

  if (!isUserWithinBrandScope(user, undefined, brandId)) {
    return c.json({ success: false, error: 'Akses brand di luar cakupan Anda.' }, 403);
  }

  const summary = await getBrandQuotaSummaryD1(c.env.DB, brandId, brandName, year);
  return c.json({ success: true, summary });
});
