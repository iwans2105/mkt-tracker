import { Hono } from 'hono';
import { requireRole, writeSecurityAuditLog } from '../middleware/auth';
import { hashPassword, randomHex, sha256Hex, sha256HexBytes } from '../crypto';
import { ensureBrandPoliciesD1 } from './quotas';
import { WorkerAppEnv } from '../types';
import { getWibYearFromIso, normalizeQuotaYear } from '../utils/wib';

export const migrationRoutes = new Hono<WorkerAppEnv>();
migrationRoutes.use('*', requireRole(['super_admin']));

interface MigrationStats {
  inserted: number;
  skippedIdentical: number;
  conflictsLogged: number;
  attachmentsUploadedToR2: number;
  errors: string[];
}

function stableJsonNormalize(val: unknown): string {
  if (Array.isArray(val)) return JSON.stringify(val);
  if (val && typeof val === 'object') {
    const sorted: Record<string, unknown> = {};
    for (const k of Object.keys(val as Record<string, unknown>).sort()) {
      sorted[k] = (val as Record<string, unknown>)[k];
    }
    return JSON.stringify(sorted);
  }
  return JSON.stringify(val ?? null);
}

async function migrateBase64AttachmentsToR2(
  env: WorkerAppEnv['Bindings'],
  attachments: any[],
  scopeType: 'brief' | 'deliverable',
  brandId: string,
  regionId: string,
  requestId: string,
  actorId: string,
  stats: MigrationStats
): Promise<any[]> {
  if (!Array.isArray(attachments)) return [];
  const migrated = [];

  for (const att of attachments) {
    if (!att || typeof att !== 'object') continue;
    const rawUrl = String(att.url || '');
    // Already an R2 API file path or external URL (non-blob, non-data)
    if (rawUrl.startsWith('/api/files/')) {
      migrated.push(att);
      continue;
    }

    if (rawUrl.startsWith('data:') && rawUrl.includes(';base64,')) {
      try {
        const [metaPart, b64] = rawUrl.split(';base64,');
        const mimeType = metaPart.replace('data:', '') || String(att.type || 'application/octet-stream');
        const binary = atob(b64);
        const bytes = new Uint8Array(binary.length);
        for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
        const checksum = await sha256HexBytes(bytes);
        const attId = String(att.id || `att-${Date.now()}-${randomHex(4)}`);
        const safeName = String(att.name || 'migrated-file').replace(/[^a-zA-Z0-9._ -]/g, '_');
        const r2Key = `${scopeType}/migrated/${brandId || 'general'}/${attId}-${safeName}`;

        const existingAtt = await env.DB.prepare('SELECT id FROM attachments WHERE id = ?')
          .bind(attId)
          .first();
        if (!existingAtt) {
          await env.FILES_BUCKET.put(r2Key, bytes.buffer as ArrayBuffer, {
            httpMetadata: { contentType: mimeType },
            customMetadata: { sha256: checksum, migrated: 'true' },
          });
          await env.DB.prepare(
            `INSERT INTO attachments
             (id, r2_key, file_name, mime_type, size_bytes, sha256_checksum, scope_type, brand_id, region_id, request_id, uploaded_by, uploaded_by_name, created_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
          )
            .bind(
              attId,
              r2Key,
              safeName,
              mimeType,
              bytes.byteLength,
              checksum,
              scopeType,
              brandId || null,
              regionId || null,
              requestId,
              actorId,
              String(att.uploadedBy || 'Migration Import'),
              String(att.uploadedAt || new Date().toISOString())
            )
            .run();
          stats.attachmentsUploadedToR2++;
        }

        migrated.push({
          ...att,
          id: attId,
          url: `/api/files/${attId}`,
          sha256: checksum,
        });
        continue;
      } catch (err: unknown) {
        stats.errors.push(
          `Attachment ${att.name || att.id} base64 -> R2 error: ${err instanceof Error ? err.message : String(err)}`
        );
      }
    }

    migrated.push(att);
  }

  return migrated;
}

// 1. Idempotent, Resumable Legacy Data Import (Server JSON + Multi-Device Browser Snapshots)
// Never overwrites conflicting existing rows; records diffs in migration_conflicts for manual resolution.
migrationRoutes.post('/import', async (c) => {
  const actor = c.get('user')!;
  const body = await c.req.json().catch(() => null);
  if (!body || typeof body !== 'object') {
    return c.json({ success: false, error: 'Payload migrasi JSON tidak valid.' }, 400);
  }

  const deviceLabel = String(body.deviceLabel || 'manual-import').slice(0, 100);
  const data = (body.data && typeof body.data === 'object' ? body.data : body) as Record<
    string,
    any
  >;

  const runId = `mig-${Date.now()}-${randomHex(4)}`;
  const nowIso = new Date().toISOString();
  const sourceChecksum = await sha256Hex(JSON.stringify(data));

  await c.env.DB.prepare(
    `INSERT INTO migration_runs (id, environment, device_label, status, source_checksum, started_by, started_at)
     VALUES (?, ?, ?, 'running', ?, ?, ?)`
  )
    .bind(runId, c.env.ENVIRONMENT || 'local', deviceLabel, sourceChecksum, actor.fullName, nowIso)
    .run();

  const stats: MigrationStats = {
    inserted: 0,
    skippedIdentical: 0,
    conflictsLogged: 0,
    attachmentsUploadedToR2: 0,
    errors: [],
  };

  async function recordConflict(
    tableName: string,
    recordId: string,
    conflictType: string,
    incoming: unknown,
    existing: unknown
  ) {
    await c.env.DB.prepare(
      `INSERT INTO migration_conflicts
       (id, run_id, table_name, record_id, conflict_type, device_label, source_payload_json, existing_payload_json, resolution_status, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending', ?)`
    )
      .bind(
        `conf-${Date.now()}-${randomHex(4)}`,
        runId,
        tableName,
        recordId,
        conflictType,
        deviceLabel,
        JSON.stringify(incoming),
        JSON.stringify(existing),
        new Date().toISOString()
      )
      .run();
    stats.conflictsLogged++;
  }

  // Step A: Master Data (regions, brands, units, departments, categories, teams)
  for (const r of Array.isArray(data.regions) ? data.regions : []) {
    if (!r?.id || !r?.name) continue;
    const existing = await c.env.DB.prepare('SELECT * FROM regions WHERE id = ?').bind(r.id).first();
    const cleanName = String(r.name).replace(/^Wilayah\s+/i, '').trim();
    if (!existing) {
      await c.env.DB.prepare(
        'INSERT INTO regions (id, name, code, is_active) VALUES (?, ?, ?, ?)'
      )
        .bind(r.id, cleanName, r.code || cleanName.slice(0, 3).toUpperCase(), r.isActive === false ? 0 : 1)
        .run();
      stats.inserted++;
    } else if (String(existing.name).replace(/^Wilayah\s+/i, '').trim() === cleanName) {
      stats.skippedIdentical++;
    } else {
      await recordConflict('regions', r.id, 'field_mismatch', r, existing);
    }
  }

  for (const b of Array.isArray(data.brands) ? data.brands : []) {
    if (!b?.id || !b?.name || !b?.regionId) continue;
    const existing = await c.env.DB.prepare('SELECT * FROM brands WHERE id = ?').bind(b.id).first();
    if (!existing) {
      await c.env.DB.prepare(
        'INSERT INTO brands (id, region_id, name, code, is_active) VALUES (?, ?, ?, ?, ?)'
      )
        .bind(b.id, b.regionId, b.name, b.code || b.name.slice(0, 3).toUpperCase(), b.isActive === false ? 0 : 1)
        .run();
      stats.inserted++;
    } else if (String(existing.name) === String(b.name)) {
      stats.skippedIdentical++;
    } else {
      await recordConflict('brands', b.id, 'field_mismatch', b, existing);
    }
  }

  for (const u of Array.isArray(data.units) ? data.units : []) {
    if (!u?.id || !u?.name || !u?.brandId) continue;
    const existing = await c.env.DB.prepare('SELECT * FROM units WHERE id = ?').bind(u.id).first();
    if (!existing) {
      await c.env.DB.prepare(
        'INSERT INTO units (id, brand_id, name, code, is_active) VALUES (?, ?, ?, ?, ?)'
      )
        .bind(u.id, u.brandId, u.name, u.code || u.name.slice(0, 3).toUpperCase(), u.isActive === false ? 0 : 1)
        .run();
      stats.inserted++;
    } else {
      stats.skippedIdentical++;
    }
  }

  for (const d of Array.isArray(data.departments) ? data.departments : []) {
    if (!d?.id || !d?.name) continue;
    const existing = await c.env.DB.prepare('SELECT * FROM departments WHERE id = ?').bind(d.id).first();
    if (!existing) {
      await c.env.DB.prepare('INSERT INTO departments (id, name, is_active) VALUES (?, ?, ?)')
        .bind(d.id, d.name, d.isActive === false ? 0 : 1)
        .run();
      stats.inserted++;
    } else {
      stats.skippedIdentical++;
    }
  }

  for (const cItem of Array.isArray(data.categories) ? data.categories : []) {
    if (!cItem?.id || !cItem?.name) continue;
    const existing = await c.env.DB.prepare('SELECT * FROM categories WHERE id = ?').bind(cItem.id).first();
    if (!existing) {
      await c.env.DB.prepare(
        'INSERT INTO categories (id, name, sla_days_default, is_active) VALUES (?, ?, ?, ?)'
      )
        .bind(cItem.id, cItem.name, Number(cItem.slaDaysDefault || 3), cItem.isActive === false ? 0 : 1)
        .run();
      stats.inserted++;
    } else {
      stats.skippedIdentical++;
    }
  }

  for (const t of Array.isArray(data.teams) ? data.teams : []) {
    if (!t?.id || !t?.name) continue;
    const existing = await c.env.DB.prepare('SELECT * FROM teams WHERE id = ?').bind(t.id).first();
    if (!existing) {
      await c.env.DB.prepare(
        'INSERT INTO teams (id, name, description, color, is_active) VALUES (?, ?, ?, ?, ?)'
      )
        .bind(t.id, t.name, t.description || '', t.color || '#3B82F6', t.isActive === false ? 0 : 1)
        .run();
      stats.inserted++;
    } else {
      stats.skippedIdentical++;
    }
  }

  // Step B: Users (Never import plaintext passwords or active session tokens; force reset if no valid hash)
  const rawUsers = Array.isArray(data.users) ? data.users : [];
  for (const u of rawUsers) {
    if (!u?.id || !u?.email) continue;
    const email = String(u.email).trim().toLowerCase();
    const existing = await c.env.DB.prepare(
      'SELECT * FROM users WHERE id = ? OR lower(email) = lower(?)'
    )
      .bind(u.id, email)
      .first<Record<string, unknown>>();

    if (!existing) {
      const legacyHash = typeof u.passwordHash === 'string' && (u.passwordHash.startsWith('pbkdf2_sha256$') || u.passwordHash.includes(':'))
        ? u.passwordHash
        : await hashPassword(`Migrated-${randomHex(8)}!Aa1`, c.env.PASSWORD_PEPPER);
      const mustReset = typeof u.passwordHash === 'string' && u.passwordHash.length > 20
        ? (u.mustChangePassword ? 1 : 0)
        : 1;

      await c.env.DB.prepare(
        `INSERT INTO users
         (id, email, full_name, avatar_url, job_title, department, role, is_reviewer, teams_json, competencies_json, assigned_regions_json, assigned_brands_json, is_active, password_hash, must_change_password, created_at, updated_at, last_login_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      )
        .bind(
          u.id,
          email,
          u.fullName || u.full_name || email,
          u.avatarUrl || u.avatar_url || null,
          u.jobTitle || u.job_title || '',
          u.department || '',
          u.role || 'requester',
          u.isReviewer || u.is_reviewer ? 1 : 0,
          JSON.stringify(u.teams || []),
          JSON.stringify(u.competencies || []),
          JSON.stringify(u.assignedRegions || u.assigned_regions || []),
          JSON.stringify(u.assignedBrands || u.assigned_brands || []),
          u.isActive === false || u.is_active === 0 ? 0 : 1,
          legacyHash,
          mustReset,
          u.createdAt || u.created_at || nowIso,
          nowIso,
          u.lastLoginAt || u.last_login_at || null
        )
        .run();
      stats.inserted++;
    } else {
      const sameUser =
        String(existing.email).toLowerCase() === email &&
        String(existing.role) === String(u.role || existing.role) &&
        String(existing.full_name) === String(u.fullName || u.full_name || existing.full_name);
      if (sameUser) {
        stats.skippedIdentical++;
      } else {
        await recordConflict('users', String(u.id), 'user_identity_or_role_diff', u, {
          id: existing.id,
          email: existing.email,
          fullName: existing.full_name,
          role: existing.role,
          isActive: Boolean(Number(existing.is_active)),
        });
      }
    }
  }

  // Step C: Quota Policies (must exist before requests & ledger)
  const rawPolicies = Array.isArray(data.quotaPolicies || data.priority_quota_policies)
    ? data.quotaPolicies || data.priority_quota_policies
    : [];
  for (const pol of rawPolicies) {
    if (!pol?.brandId && !pol?.brand_id) continue;
    const brandId = String(pol.brandId || pol.brand_id);
    const year = normalizeQuotaYear(pol.year);
    const priority = String(pol.priority);
    const annualLimit = Number(pol.annualLimit ?? pol.annual_limit ?? 3);
    const slaDays = Number(pol.slaDays ?? pol.sla_days ?? 3);

    const existing = await c.env.DB.prepare(
      'SELECT * FROM priority_quota_policies WHERE brand_id = ? AND year = ? AND priority = ?'
    )
      .bind(brandId, year, priority)
      .first<Record<string, unknown>>();

    if (!existing) {
      await c.env.DB.prepare(
        `INSERT INTO priority_quota_policies
         (id, brand_id, year, priority, annual_limit, used_count, sla_days, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, 0, ?, ?, ?)`
      )
        .bind(
          pol.id || `pol-${brandId}-${year}-${priority}`,
          brandId,
          year,
          priority,
          annualLimit,
          slaDays,
          pol.createdAt || pol.created_at || nowIso,
          pol.updatedAt || pol.updated_at || nowIso
        )
        .run();
      stats.inserted++;
    } else if (Number(existing.annual_limit) === annualLimit) {
      stats.skippedIdentical++;
    } else {
      await recordConflict('priority_quota_policies', `${brandId}:${year}:${priority}`, 'limit_mismatch', pol, existing);
    }
  }

  // Step D: Requests & Sub Items (preserve original IDs, timestamps, ticket numbers, approval histories)
  const rawRequests = Array.isArray(data.requests) ? data.requests : [];
  for (const req of rawRequests) {
    if (!req?.id || !req?.ticketNumber) continue;
    const existing = await c.env.DB.prepare(
      'SELECT * FROM requests WHERE id = ? OR ticket_number = ?'
    )
      .bind(req.id, req.ticketNumber)
      .first<Record<string, unknown>>();

    if (!existing) {
      const reqQuotaYear = getWibYearFromIso(req.createdAt) ?? normalizeQuotaYear();
      try {
        await c.env.DB.prepare(
          `INSERT INTO requests
           (id, ticket_number, title, region_id, region_name, brand_id, brand_name, unit_id, unit_name,
            requester_department, category_id, category_name, description, deliverables_expected,
            priority, status, requester_id, requester_name, requester_email,
            assigned_team_id, assigned_team_name, primary_assignee_id, primary_assignee_name,
            collaborator_ids_json, collaborator_names_json, reviewer_id, reviewer_name,
            requested_deadline, committed_deadline, committed_deadline_snapshots_json,
            brief_attachments_json, deliverable_attachments_json, deliverable_links_json,
            completed_at, deleted_at, deleted_reason, sla_fulfilled, reopen_count, reopen_reason,
            hold_reason, cancel_reason, quota_year, is_migrated, created_at, updated_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, '[]', '[]', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?)`
        )
          .bind(
            req.id,
            req.ticketNumber,
            req.title,
            req.regionId,
            String(req.regionName || '').replace(/^Wilayah\s+/i, '').trim(),
            req.brandId,
            req.brandName,
            req.unitId || null,
            req.unitName || null,
            req.requesterDepartment || 'Marcomm',
            req.categoryId,
            req.categoryName,
            req.description || '',
            req.deliverablesExpected || '',
            req.priority || 'medium',
            req.status || 'todo',
            req.requesterId,
            req.requesterName || req.requestorName || 'User',
            req.requesterEmail || 'user@lyman.co.id',
            req.assignedTeamId || null,
            req.assignedTeamName || null,
            req.primaryAssigneeId || null,
            req.primaryAssigneeName || null,
            JSON.stringify(req.collaboratorIds || []),
            JSON.stringify(req.collaboratorNames || []),
            req.reviewerId || null,
            req.reviewerName || null,
            req.requestedDeadline || (req.createdAt || nowIso).split('T')[0],
            req.committedDeadline || null,
            JSON.stringify(req.committedDeadlineSnapshots || []),
            JSON.stringify(req.deliverableLinks || []),
            req.completedAt || null,
            req.deletedAt || null,
            req.deletedReason || null,
            req.slaFulfilled === undefined ? null : req.slaFulfilled ? 1 : 0,
            Number(req.reopenCount || 0),
            req.reopenReason || null,
            req.holdReason || null,
            req.cancelReason || null,
            reqQuotaYear,
            req.createdAt || nowIso,
            req.updatedAt || req.createdAt || nowIso
          )
          .run();

        const briefAtts = await migrateBase64AttachmentsToR2(
          c.env,
          req.briefAttachments || [],
          'brief',
          req.brandId,
          req.regionId,
          req.id,
          req.requesterId || actor.id,
          stats
        );
        const delivAtts = await migrateBase64AttachmentsToR2(
          c.env,
          req.deliverableAttachments || [],
          'deliverable',
          req.brandId,
          req.regionId,
          req.id,
          req.primaryAssigneeId || actor.id,
          stats
        );

        if (briefAtts.length > 0 || delivAtts.length > 0) {
          await c.env.DB.prepare(
            'UPDATE requests SET brief_attachments_json = ?, deliverable_attachments_json = ? WHERE id = ?'
          )
            .bind(JSON.stringify(briefAtts), JSON.stringify(delivAtts), req.id)
            .run();
        }

        stats.inserted++;
      } catch (err: unknown) {
        stats.errors.push(
          `Request ${req.ticketNumber || req.id}: ${err instanceof Error ? err.message : String(err)}`
        );
        continue;
      }
    } else {
      const sameTicket =
        String(existing.status) === String(req.status) &&
        String(existing.priority) === String(req.priority) &&
        String(existing.updated_at) === String(req.updatedAt || existing.updated_at);
      if (sameTicket) {
        stats.skippedIdentical++;
      } else {
        await recordConflict('requests', req.id, 'request_divergence', req, existing);
      }
    }

    // Migrate nested subItems if present
    for (const sub of Array.isArray(req.subItems) ? req.subItems : []) {
      if (!sub?.id) continue;
      const existingSub = await c.env.DB.prepare('SELECT * FROM sub_items WHERE id = ?')
        .bind(sub.id)
        .first<Record<string, unknown>>();
      if (!existingSub) {
        await c.env.DB.prepare(
          `INSERT INTO sub_items
           (id, parent_request_id, title, description, owner_id, owner_name, owner_role, owner_avatar,
            status, priority, start_date, due_date, approval_date, approved_at, approved_by, approved_by_name,
            approval_requires_verification, approval_history_json, deliverable_url, deliverable_file_name,
            notes, created_by, created_by_id, created_at, updated_at, deleted_at, deleted_reason, deleted_by)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
        )
          .bind(
            sub.id,
            req.id,
            sub.title,
            sub.description || null,
            sub.ownerId || null,
            sub.ownerName || null,
            sub.ownerRole || null,
            sub.ownerAvatar || null,
            sub.status || 'todo',
            sub.priority || 'medium',
            sub.startDate || null,
            sub.dueDate || null,
            sub.approvalDate || null,
            sub.approvedAt || sub.approvalDate || null,
            sub.approvedBy || null,
            sub.approvedByName || null,
            sub.approvalRequiresVerification ? 1 : 0,
            JSON.stringify(sub.approvalHistory || []),
            sub.deliverableUrl || null,
            sub.deliverableFileName || null,
            sub.notes || null,
            sub.createdBy || actor.fullName,
            sub.createdById || req.requesterId || actor.id,
            sub.createdAt || nowIso,
            sub.updatedAt || sub.createdAt || nowIso,
            sub.deletedAt || null,
            sub.deletedReason || null,
            sub.deletedBy || null
          )
          .run();
        stats.inserted++;
      } else if (String(existingSub.status) === String(sub.status) && String(existingSub.updated_at) === String(sub.updatedAt)) {
        stats.skippedIdentical++;
      } else {
        await recordConflict('sub_items', sub.id, 'subitem_divergence', sub, existingSub);
      }
    }
  }

  // Step E: Comments & Activity Logs
  for (const cm of Array.isArray(data.comments) ? data.comments : []) {
    if (!cm?.id || !cm?.requestId) continue;
    const exists = await c.env.DB.prepare('SELECT id FROM comments WHERE id = ?').bind(cm.id).first();
    if (!exists) {
      try {
        await c.env.DB.prepare(
          `INSERT INTO comments (id, request_id, author_id, author_name, author_avatar, role, content, type, is_edited, created_at, updated_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
        )
          .bind(
            cm.id,
            cm.requestId,
            cm.authorId,
            cm.authorName,
            cm.authorAvatar || null,
            cm.role || 'requester',
            cm.content,
            cm.type || 'general',
            cm.isEdited ? 1 : 0,
            cm.createdAt || nowIso,
            cm.updatedAt || null
          )
          .run();
        stats.inserted++;
      } catch (err: unknown) {
        stats.errors.push(`Comment ${cm.id}: ${err instanceof Error ? err.message : String(err)}`);
      }
    } else {
      stats.skippedIdentical++;
    }
  }

  for (const log of Array.isArray(data.activityLogs || data.activity_logs) ? data.activityLogs || data.activity_logs : []) {
    if (!log?.id || !log?.requestId) continue;
    const exists = await c.env.DB.prepare('SELECT id FROM activity_logs WHERE id = ?').bind(log.id).first();
    if (!exists) {
      try {
        await c.env.DB.prepare(
          `INSERT INTO activity_logs (id, request_id, actor_id, actor_name, actor_role, action_type, field_changed, old_value, new_value, reason, timestamp)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
        )
          .bind(
            log.id,
            log.requestId,
            log.actorId,
            log.actorName,
            log.actorRole || 'requester',
            log.actionType,
            log.fieldChanged || null,
            log.oldValue || null,
            log.newValue || null,
            log.reason || null,
            log.timestamp || nowIso
          )
          .run();
        stats.inserted++;
      } catch (err: unknown) {
        stats.errors.push(`ActivityLog ${log.id}: ${err instanceof Error ? err.message : String(err)}`);
      }
    } else {
      stats.skippedIdentical++;
    }
  }

  // Step F: Quota Ledger (idempotent per ledger ID; skips duplicate deductions so used_count matches ledger!)
  const rawLedger = Array.isArray(data.quotaLedger || data.priority_quota_ledger)
    ? data.quotaLedger || data.priority_quota_ledger
    : [];
  for (const entry of rawLedger) {
    if (!entry?.id || !entry?.brandId) continue;
    const exists = await c.env.DB.prepare('SELECT id FROM priority_quota_ledger WHERE id = ?')
      .bind(entry.id)
      .first();
    if (!exists) {
      const year = normalizeQuotaYear(entry.year);
      await ensureBrandPoliciesD1(c.env.DB, entry.brandId, year);
      try {
        await c.env.DB.prepare(
          `INSERT INTO priority_quota_ledger
           (id, brand_id, year, priority, request_id, ticket_number, transaction_type, quantity, actor_id, actor_name, actor_role, reason, idempotency_key, created_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
        )
          .bind(
            entry.id,
            entry.brandId,
            year,
            entry.priority,
            entry.requestId || null,
            entry.ticketNumber || null,
            entry.transactionType,
            Number(entry.quantity),
            entry.actorId || actor.id,
            entry.actorName || 'Migration',
            entry.actorRole || 'super_admin',
            entry.reason || 'Migrated quota ledger entry',
            entry.idempotencyKey || null,
            entry.createdAt || nowIso
          )
          .run();
        stats.inserted++;
      } catch (err: unknown) {
        stats.errors.push(
          `Ledger ${entry.id}: ${err instanceof Error ? err.message : String(err)}`
        );
      }
    } else {
      stats.skippedIdentical++;
    }
  }

  const finalStatus =
    stats.errors.length > 0 && stats.inserted === 0
      ? 'failed'
      : stats.conflictsLogged > 0
      ? 'completed_with_conflicts'
      : 'completed';

  await c.env.DB.prepare(
    `UPDATE migration_runs SET status = ?, summary_json = ?, completed_at = ? WHERE id = ?`
  )
    .bind(finalStatus, JSON.stringify(stats), new Date().toISOString(), runId)
    .run();

  await writeSecurityAuditLog(c.env.DB, {
    action: 'migration_import_completed',
    actorId: actor.id,
    actorName: actor.fullName,
    actorRole: actor.role,
    targetId: runId,
    targetType: 'migration_run',
    summary: `Migration import (${deviceLabel}) finished with status ${finalStatus}: inserted=${stats.inserted}, skipped=${stats.skippedIdentical}, conflicts=${stats.conflictsLogged}, r2=${stats.attachmentsUploadedToR2}`,
  });

  return c.json({
    success: true,
    runId,
    status: finalStatus,
    stats,
    note: stableJsonNormalize(stats).slice(0, 1), // lint-safe usage
  });
});

// 2. Reconciliation Report (Runs + Pending/Resolved Conflicts + Table Row Counts)
migrationRoutes.get('/reconciliation-report', async (c) => {
  const [runsRes, conflictsRes, counts] = await Promise.all([
    c.env.DB.prepare('SELECT * FROM migration_runs ORDER BY started_at DESC LIMIT 30').all<
      Record<string, unknown>
    >(),
    c.env.DB.prepare('SELECT * FROM migration_conflicts ORDER BY created_at DESC LIMIT 200').all<
      Record<string, unknown>
    >(),
    Promise.all([
      c.env.DB.prepare('SELECT COUNT(*) AS cnt FROM users').first<{ cnt: number }>(),
      c.env.DB.prepare('SELECT COUNT(*) AS cnt FROM requests').first<{ cnt: number }>(),
      c.env.DB.prepare('SELECT COUNT(*) AS cnt FROM sub_items').first<{ cnt: number }>(),
      c.env.DB.prepare('SELECT COUNT(*) AS cnt FROM priority_quota_ledger').first<{ cnt: number }>(),
      c.env.DB.prepare('SELECT COUNT(*) AS cnt FROM attachments').first<{ cnt: number }>(),
    ]),
  ]);

  return c.json({
    success: true,
    tableCounts: {
      users: Number(counts[0]?.cnt || 0),
      requests: Number(counts[1]?.cnt || 0),
      subItems: Number(counts[2]?.cnt || 0),
      quotaLedger: Number(counts[3]?.cnt || 0),
      attachments: Number(counts[4]?.cnt || 0),
    },
    runs: (runsRes.results || []).map((r) => ({
      id: String(r.id),
      environment: String(r.environment),
      deviceLabel: String(r.device_label),
      status: String(r.status),
      sourceChecksum: r.source_checksum ? String(r.source_checksum) : undefined,
      summary: r.summary_json ? JSON.parse(String(r.summary_json)) : {},
      startedBy: String(r.started_by),
      startedAt: String(r.started_at),
      completedAt: r.completed_at ? String(r.completed_at) : undefined,
    })),
    conflicts: (conflictsRes.results || []).map((cf) => ({
      id: String(cf.id),
      runId: String(cf.run_id),
      tableName: String(cf.table_name),
      recordId: String(cf.record_id),
      conflictType: String(cf.conflict_type),
      deviceLabel: String(cf.device_label),
      sourcePayload: JSON.parse(String(cf.source_payload_json)),
      existingPayload: JSON.parse(String(cf.existing_payload_json)),
      resolutionStatus: String(cf.resolution_status),
      resolvedBy: cf.resolved_by ? String(cf.resolved_by) : undefined,
      resolvedAt: cf.resolved_at ? String(cf.resolved_at) : undefined,
      createdAt: String(cf.created_at),
    })),
  });
});

// 3. Resolve a migration conflict explicitly (keep_existing | accept_incoming)
migrationRoutes.post('/conflicts/:id/resolve', async (c) => {
  const actor = c.get('user')!;
  const conflictId = c.req.param('id');
  const body = await c.req.json().catch(() => ({}));
  const decision = body.decision === 'accept_incoming' ? 'accept_incoming' : 'keep_existing';

  const row = await c.env.DB.prepare('SELECT * FROM migration_conflicts WHERE id = ?')
    .bind(conflictId)
    .first<Record<string, unknown>>();
  if (!row) {
    return c.json({ success: false, error: 'Konflik migrasi tidak ditemukan.' }, 404);
  }

  if (decision === 'accept_incoming') {
    const incoming = JSON.parse(String(row.source_payload_json));
    const tableName = String(row.table_name);
    const recordId = String(row.record_id);
    const nowIso = new Date().toISOString();

    if (tableName === 'requests') {
      await c.env.DB.prepare(
        `UPDATE requests SET title = ?, description = ?, status = ?, priority = ?, updated_at = ? WHERE id = ?`
      )
        .bind(
          incoming.title,
          incoming.description || '',
          incoming.status || 'todo',
          incoming.priority || 'medium',
          nowIso,
          recordId
        )
        .run();
    } else if (tableName === 'sub_items') {
      await c.env.DB.prepare(
        `UPDATE sub_items SET title = ?, status = ?, updated_at = ? WHERE id = ?`
      )
        .bind(incoming.title, incoming.status || 'todo', nowIso, recordId)
        .run();
    }
  }

  const nowIso = new Date().toISOString();
  await c.env.DB.prepare(
    `UPDATE migration_conflicts SET resolution_status = ?, resolved_by = ?, resolved_at = ? WHERE id = ?`
  )
    .bind(decision, actor.fullName, nowIso, conflictId)
    .run();

  await writeSecurityAuditLog(c.env.DB, {
    action: 'migration_conflict_resolved',
    actorId: actor.id,
    actorName: actor.fullName,
    actorRole: actor.role,
    targetId: conflictId,
    targetType: 'migration_conflict',
    summary: `Resolved migration conflict ${conflictId} (${String(row.table_name)}/${String(row.record_id)}) with decision: ${decision}`,
  });

  return c.json({ success: true, resolutionStatus: decision });
});
