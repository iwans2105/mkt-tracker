import { Context, Hono } from 'hono';
import type { D1Database } from '@cloudflare/workers-types';
import type { Attachment, RequestPriority } from '../../types';
import { randomHex, sha256Hex, sha256HexBytes, timingSafeEqualHex } from '../crypto';
import { RATE_LIMIT_WINDOW_MS, writeSecurityAuditLog } from '../middleware/auth';
import {
  rowToBrand,
  rowToCategory,
  rowToDepartment,
  rowToRegion,
  rowToUnit,
  safeJsonParse,
  WorkerAppEnv,
} from '../types';
import { getWibSlaDeadlineDateString, getWibTodayDateString, getWibYear } from '../utils/wib';
import { DEFAULT_SLA_DAYS, ensureBrandPoliciesD1, getBrandQuotaSummaryD1 } from './quotas';

export const PUBLIC_REQUESTER_USER_ID = 'public-requester';
export const MAX_PUBLIC_FILE_BYTES = 25 * 1024 * 1024; // 25 MB strict limit for public submissions
const PUBLIC_TOKEN_FAIL_MAX = 10;
const PUBLIC_UPLOAD_MAX = 20;
const PUBLIC_SUBMIT_MAX = 10;

const PUBLIC_ALLOWED_EXTENSIONS = new Set([
  'pdf',
  'jpg',
  'jpeg',
  'png',
  'webp',
  'docx',
  'xlsx',
  'pptx',
  'mp4',
  'zip',
]);

const PUBLIC_ALLOWED_MIME_PREFIXES = [
  'image/jpeg',
  'image/png',
  'image/webp',
  'video/mp4',
  'application/pdf',
  'application/vnd.openxmlformats-officedocument',
  'application/msword',
  'application/zip',
  'application/x-zip-compressed',
  'application/octet-stream',
];

export interface PublicFormConfigRecord {
  id: 'default';
  enabled: boolean;
  requireToken: boolean;
  allowAttachments: boolean;
  accessToken: string;
  tokenHash: string;
  allowedEmailDomains: string[];
  updatedBy: string | null;
  updatedAt: string;
}

export function normalizeAllowedEmailDomains(raw: unknown): string[] {
  const arr = Array.isArray(raw)
    ? raw.map(String)
    : typeof raw === 'string'
    ? raw.split(',')
    : [];
  const seen = new Set<string>();
  const out: string[] = [];
  for (const item of arr) {
    const cleaned = item.trim().toLowerCase().replace(/^@+/, '');
    if (!cleaned) continue;
    if (/^[a-z0-9.-]+\.[a-z]{2,}$/.test(cleaned) && !seen.has(cleaned)) {
      seen.add(cleaned);
      out.push(cleaned);
    }
  }
  return out;
}

function rowToPublicFormConfig(row: Record<string, unknown>): PublicFormConfigRecord {
  return {
    id: 'default',
    enabled: Boolean(Number(row.enabled)),
    requireToken: Boolean(Number(row.require_token)),
    allowAttachments: Boolean(Number(row.allow_attachments)),
    accessToken: String(row.access_token || ''),
    tokenHash: String(row.token_hash || ''),
    allowedEmailDomains: normalizeAllowedEmailDomains(
      safeJsonParse<string[]>(row.allowed_email_domains_json, [])
    ),
    updatedBy: row.updated_by ? String(row.updated_by) : null,
    updatedAt: String(row.updated_at || new Date().toISOString()),
  };
}

export async function ensurePublicFormConfig(db: D1Database): Promise<PublicFormConfigRecord> {
  const existing = await db
    .prepare("SELECT * FROM public_form_config WHERE id = 'default'")
    .first<Record<string, unknown>>();
  if (existing && String(existing.access_token || '') && String(existing.token_hash || '')) {
    return rowToPublicFormConfig(existing);
  }

  const initialToken = randomHex(16);
  const initialHash = await sha256Hex(initialToken);
  const nowIso = new Date().toISOString();

  await db
    .prepare(
      `INSERT OR IGNORE INTO public_form_config
       (id, enabled, require_token, allow_attachments, access_token, token_hash, allowed_email_domains_json, updated_by, updated_at)
       VALUES ('default', 1, 1, 1, ?, ?, '[]', 'system', ?)`
    )
    .bind(initialToken, initialHash, nowIso)
    .run();

  const reloaded = await db
    .prepare("SELECT * FROM public_form_config WHERE id = 'default'")
    .first<Record<string, unknown>>();
  if (reloaded) {
    return rowToPublicFormConfig(reloaded);
  }

  return {
    id: 'default',
    enabled: true,
    requireToken: true,
    allowAttachments: true,
    accessToken: initialToken,
    tokenHash: initialHash,
    allowedEmailDomains: [],
    updatedBy: 'system',
    updatedAt: nowIso,
  };
}

async function ensurePublicRequesterActor(db: D1Database): Promise<void> {
  await db
    .prepare(
      `INSERT OR IGNORE INTO users
       (id, email, full_name, job_title, department, role, is_reviewer, teams_json, competencies_json,
        assigned_regions_json, assigned_brands_json, is_active, password_hash, must_change_password)
       VALUES (?, 'public-form@system.lyman.local', 'Pengaju Tautan Publik', 'External / Public Link', 'Umum', 'requester', 0, '[]', '[]', '[]', '[]', 0, '!DISABLED_PUBLIC_SYSTEM_ACCOUNT!', 0)`
    )
    .bind(PUBLIC_REQUESTER_USER_ID)
    .run();
}

export function isValidPublicEmail(email: string): boolean {
  if (!email || email.length > 200) return false;
  return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email);
}

export function isEmailDomainAllowed(email: string, allowedDomains: string[]): boolean {
  if (!allowedDomains || allowedDomains.length === 0) return true;
  const parts = email.toLowerCase().split('@');
  if (parts.length !== 2) return false;
  return allowedDomains.includes(parts[1]);
}

export function isAllowedPublicReferenceUrl(rawUrl: string): boolean {
  try {
    const parsed = new URL(rawUrl);
    return parsed.protocol === 'http:' || parsed.protocol === 'https:';
  } catch {
    return false;
  }
}

function sanitizePublicFilename(rawName: string): string {
  const base = rawName.split(/[/\\]/).pop() || 'file';
  return base.replace(/[^a-zA-Z0-9._ -]/g, '_').slice(0, 140) || 'file';
}

function isAllowedPublicFile(fileName: string, mimeType: string): boolean {
  const ext = fileName.split('.').pop()?.toLowerCase() || '';
  if (!PUBLIC_ALLOWED_EXTENSIONS.has(ext)) return false;
  if (!mimeType) return true;
  const lower = mimeType.toLowerCase();
  return PUBLIC_ALLOWED_MIME_PREFIXES.some((p) => lower.startsWith(p));
}

async function checkPublicRateLimit(
  db: D1Database,
  rateKey: string,
  maxAttempts: number,
  windowMs: number = RATE_LIMIT_WINDOW_MS
): Promise<{ allowed: boolean; remainingSecs?: number }> {
  const now = Date.now();
  const row = await db
    .prepare('SELECT attempt_count, first_attempt_ms FROM login_rate_limits WHERE rate_key = ?')
    .bind(rateKey)
    .first<{ attempt_count: number; first_attempt_ms: number }>();

  if (!row) return { allowed: true };
  if (now - row.first_attempt_ms > windowMs) {
    await db.prepare('DELETE FROM login_rate_limits WHERE rate_key = ?').bind(rateKey).run();
    return { allowed: true };
  }
  if (row.attempt_count >= maxAttempts) {
    const remainingSecs = Math.max(1, Math.ceil((windowMs - (now - row.first_attempt_ms)) / 1000));
    return { allowed: false, remainingSecs };
  }
  return { allowed: true };
}

async function recordPublicRateAttempt(
  db: D1Database,
  rateKey: string,
  windowMs: number = RATE_LIMIT_WINDOW_MS
): Promise<void> {
  const now = Date.now();
  const row = await db
    .prepare('SELECT attempt_count, first_attempt_ms FROM login_rate_limits WHERE rate_key = ?')
    .bind(rateKey)
    .first<{ attempt_count: number; first_attempt_ms: number }>();

  if (!row || now - row.first_attempt_ms > windowMs) {
    await db
      .prepare(
        `INSERT INTO login_rate_limits (rate_key, attempt_count, first_attempt_ms, updated_at_ms)
         VALUES (?, 1, ?, ?)
         ON CONFLICT(rate_key) DO UPDATE SET attempt_count = 1, first_attempt_ms = excluded.first_attempt_ms, updated_at_ms = excluded.updated_at_ms`
      )
      .bind(rateKey, now, now)
      .run();
  } else {
    await db
      .prepare('UPDATE login_rate_limits SET attempt_count = attempt_count + 1, updated_at_ms = ? WHERE rate_key = ?')
      .bind(now, rateKey)
      .run();
  }
}

async function verifyPublicFormAccess(
  c: Context<WorkerAppEnv>,
  suppliedToken: string
): Promise<{ ok: true; cfg: PublicFormConfigRecord } | { ok: false; response: Response }> {
  const cfg = await ensurePublicFormConfig(c.env.DB);
  const ip = c.get('clientIp') || '127.0.0.1';

  if (!cfg.enabled) {
    return {
      ok: false,
      response: c.json(
        {
          success: false,
          disabled: true,
          error: 'Formulir permintaan publik sedang dinonaktifkan oleh Administrator.',
        },
        403
      ),
    };
  }

  if (cfg.requireToken) {
    const tokLimit = await checkPublicRateLimit(c.env.DB, `pub_tok_fail:${ip}`, PUBLIC_TOKEN_FAIL_MAX);
    if (!tokLimit.allowed) {
      return {
        ok: false,
        response: c.json(
          {
            success: false,
            requiresToken: true,
            error: `Terlalu banyak percobaan kode akses yang tidak valid. Coba lagi dalam ${Math.ceil(
              (tokLimit.remainingSecs || 60) / 60
            )} menit.`,
          },
          429
        ),
      };
    }

    const trimmedToken = suppliedToken.trim();
    const candidateHash = trimmedToken ? await sha256Hex(trimmedToken) : '';
    const tokenValid = Boolean(trimmedToken) && timingSafeEqualHex(candidateHash, cfg.tokenHash);
    if (!tokenValid) {
      await recordPublicRateAttempt(c.env.DB, `pub_tok_fail:${ip}`);
      return {
        ok: false,
        response: c.json(
          {
            success: false,
            requiresToken: true,
            error: 'Kode akses tautan publik tidak valid atau diperlukan untuk membuka formulir ini.',
          },
          401
        ),
      };
    }
  }

  return { ok: true, cfg };
}

function readTokenFromHeadersOrQuery(c: Context<WorkerAppEnv>): string {
  return c.req.header('x-public-form-token') || c.req.query('token') || '';
}

export const publicRoutes = new Hono<WorkerAppEnv>();

// 1. Get sanitized public form config + active master data ONLY (zero users, requests, logs, or secrets)
publicRoutes.get('/request-form-config', async (c) => {
  const token = readTokenFromHeadersOrQuery(c);
  const access = await verifyPublicFormAccess(c, token);
  if (!access.ok) return access.response;

  const { cfg } = access;
  const [regionsRes, brandsRes, unitsRes, deptsRes, catsRes] = await Promise.all([
    c.env.DB.prepare('SELECT * FROM regions WHERE is_active = 1 ORDER BY name ASC').all<Record<string, unknown>>(),
    c.env.DB.prepare('SELECT * FROM brands WHERE is_active = 1 ORDER BY name ASC').all<Record<string, unknown>>(),
    c.env.DB.prepare('SELECT * FROM units WHERE is_active = 1 ORDER BY name ASC').all<Record<string, unknown>>(),
    c.env.DB.prepare('SELECT * FROM departments WHERE is_active = 1 ORDER BY name ASC').all<Record<string, unknown>>(),
    c.env.DB.prepare('SELECT * FROM categories WHERE is_active = 1 ORDER BY name ASC').all<Record<string, unknown>>(),
  ]);

  return c.json({
    success: true,
    config: {
      enabled: true,
      requireToken: cfg.requireToken,
      allowAttachments: cfg.allowAttachments,
      allowedEmailDomains: cfg.allowedEmailDomains,
      year: getWibYear(),
      todayWib: getWibTodayDateString(),
    },
    masterData: {
      regions: (regionsRes.results || []).map(rowToRegion),
      brands: (brandsRes.results || []).map(rowToBrand),
      units: (unitsRes.results || []).map(rowToUnit),
      departments: (deptsRes.results || []).map(rowToDepartment),
      categories: (catsRes.results || []).map(rowToCategory),
    },
  });
});

// 2. Get Brand annual quota availability summary for PriorityQuotaSelector (no user/ticket details)
publicRoutes.get('/quotas/:brandId', async (c) => {
  const token = readTokenFromHeadersOrQuery(c);
  const access = await verifyPublicFormAccess(c, token);
  if (!access.ok) return access.response;

  const brandId = c.req.param('brandId') || '';
  const brandRow = await c.env.DB.prepare(
    'SELECT id, name FROM brands WHERE id = ? AND is_active = 1'
  )
    .bind(brandId)
    .first<{ id: string; name: string }>();

  if (!brandRow) {
    return c.json({ success: false, error: 'Brand tidak ditemukan atau tidak aktif.' }, 404);
  }

  const summary = await getBrandQuotaSummaryD1(
    c.env.DB,
    brandRow.id,
    brandRow.name,
    getWibYear()
  );

  return c.json({ success: true, summary });
});

// 3. Isolated public brief upload to R2 under public-brief/... with strict size, type & IP rate limit
publicRoutes.post('/upload', async (c) => {
  const ip = c.get('clientIp') || '127.0.0.1';
  const contentType = c.req.header('content-type') || '';
  let suppliedToken = readTokenFromHeadersOrQuery(c);

  let fileName = '';
  let mimeType = 'application/octet-stream';
  let fileBytes: Uint8Array | null = null;
  let brandId: string | null = null;
  let regionId: string | null = null;

  if (contentType.includes('multipart/form-data')) {
    const formData = await c.req.formData().catch(() => null);
    if (!formData) {
      return c.json({ success: false, error: 'Payload multipart tidak valid.' }, 400);
    }
    if (!suppliedToken && formData.get('token')) {
      suppliedToken = String(formData.get('token'));
    }
    const access = await verifyPublicFormAccess(c, suppliedToken);
    if (!access.ok) return access.response;

    if (!access.cfg.allowAttachments) {
      return c.json(
        { success: false, error: 'Unggah lampiran dinonaktifkan pada formulir publik ini.' },
        403
      );
    }

    const rate = await checkPublicRateLimit(c.env.DB, `pub_upload:${ip}`, PUBLIC_UPLOAD_MAX);
    if (!rate.allowed) {
      return c.json(
        {
          success: false,
          error: `Batas unggah file sementara tercapai. Coba lagi dalam ${Math.ceil(
            (rate.remainingSecs || 60) / 60
          )} menit.`,
        },
        429
      );
    }
    await recordPublicRateAttempt(c.env.DB, `pub_upload:${ip}`);

    const fileEntry = formData.get('file');
    if (!fileEntry || typeof fileEntry === 'string') {
      return c.json({ success: false, error: 'File wajib disertakan pada field "file".' }, 400);
    }
    const uploadedFile = fileEntry as File;
    fileName = sanitizePublicFilename(uploadedFile.name || 'attachment');
    mimeType = uploadedFile.type || 'application/octet-stream';
    fileBytes = new Uint8Array(await uploadedFile.arrayBuffer());
    brandId = formData.get('brandId') ? String(formData.get('brandId')) : null;
    regionId = formData.get('regionId') ? String(formData.get('regionId')) : null;
  } else {
    const body = await c.req.json().catch(() => null);
    if (!suppliedToken && body && typeof body.token === 'string') {
      suppliedToken = body.token;
    }
    const access = await verifyPublicFormAccess(c, suppliedToken);
    if (!access.ok) return access.response;

    if (!access.cfg.allowAttachments) {
      return c.json(
        { success: false, error: 'Unggah lampiran dinonaktifkan pada formulir publik ini.' },
        403
      );
    }

    const rate = await checkPublicRateLimit(c.env.DB, `pub_upload:${ip}`, PUBLIC_UPLOAD_MAX);
    if (!rate.allowed) {
      return c.json(
        {
          success: false,
          error: `Batas unggah file sementara tercapai. Coba lagi dalam ${Math.ceil(
            (rate.remainingSecs || 60) / 60
          )} menit.`,
        },
        429
      );
    }
    await recordPublicRateAttempt(c.env.DB, `pub_upload:${ip}`);

    if (!body || !body.fileName || !body.dataBase64) {
      return c.json(
        { success: false, error: 'Gunakan multipart/form-data atau JSON { fileName, mimeType, dataBase64 }.' },
        400
      );
    }
    fileName = sanitizePublicFilename(String(body.fileName));
    mimeType = String(body.mimeType || 'application/octet-stream');
    const cleanB64 = String(body.dataBase64).replace(/^data:[^;]+;base64,/, '');
    try {
      const binary = atob(cleanB64);
      const arr = new Uint8Array(binary.length);
      for (let i = 0; i < binary.length; i++) arr[i] = binary.charCodeAt(i);
      fileBytes = arr;
    } catch {
      return c.json({ success: false, error: 'Format base64 file tidak valid.' }, 400);
    }
    brandId = body.brandId ? String(body.brandId) : null;
    regionId = body.regionId ? String(body.regionId) : null;
  }

  if (!fileBytes || fileBytes.byteLength === 0) {
    return c.json({ success: false, error: 'File kosong tidak dapat diunggah.' }, 400);
  }

  if (fileBytes.byteLength > MAX_PUBLIC_FILE_BYTES) {
    return c.json(
      {
        success: false,
        error: 'Ukuran file melebihi batas maksimum formulir publik (25 MB).',
      },
      413
    );
  }

  if (!isAllowedPublicFile(fileName, mimeType)) {
    return c.json(
      {
        success: false,
        error: `Tipe file atau ekstensi "${fileName}" tidak diizinkan oleh kebijakan keamanan.`,
      },
      400
    );
  }

  if (brandId) {
    const brandExists = await c.env.DB.prepare('SELECT id FROM brands WHERE id = ? AND is_active = 1')
      .bind(brandId)
      .first();
    if (!brandExists) {
      return c.json({ success: false, error: 'Brand tidak valid atau tidak aktif.' }, 400);
    }
  }

  await ensurePublicRequesterActor(c.env.DB);

  const fileId = `att-${Date.now()}-${randomHex(5)}`;
  const checksum = await sha256HexBytes(fileBytes);
  const year = getWibYear();
  const safeBrandFolder = (brandId || 'general').replace(/[^a-zA-Z0-9_-]/g, '_');
  const r2Key = `public-brief/${year}/${safeBrandFolder}/${fileId}-${fileName}`;

  await c.env.FILES_BUCKET.put(r2Key, fileBytes.buffer as ArrayBuffer, {
    httpMetadata: {
      contentType: mimeType,
    },
    customMetadata: {
      uploadedBy: PUBLIC_REQUESTER_USER_ID,
      fileId,
      sha256: checksum,
    },
  });

  const headCheck = await c.env.FILES_BUCKET.head(r2Key);
  if (!headCheck) {
    return c.json({ success: false, error: 'Gagal memverifikasi penyimpanan objek di Cloudflare R2.' }, 500);
  }

  const nowIso = new Date().toISOString();
  await c.env.DB.prepare(
    `INSERT INTO attachments
     (id, r2_key, file_name, mime_type, size_bytes, sha256_checksum, scope_type, brand_id, region_id, request_id, sub_item_id, uploaded_by, uploaded_by_name, created_at)
     VALUES (?, ?, ?, ?, ?, ?, 'brief', ?, ?, NULL, NULL, ?, ?, ?)`
  )
    .bind(
      fileId,
      r2Key,
      fileName,
      mimeType,
      fileBytes.byteLength,
      checksum,
      brandId,
      regionId,
      PUBLIC_REQUESTER_USER_ID,
      'Pengaju Tautan Publik',
      nowIso
    )
    .run();

  return c.json({
    success: true,
    file: {
      id: fileId,
      name: fileName,
      size: fileBytes.byteLength,
      type: mimeType,
      url: `/api/files/${fileId}`,
      uploadedAt: nowIso,
      uploadedBy: 'Pengaju Tautan Publik',
      sha256: checksum,
    },
  });
});

// 4. Isolated Public Work Request Submission (server-side WIB SLA deadline + atomic quota deduction)
publicRoutes.post('/requests', async (c) => {
  const body = await c.req.json().catch(() => ({}));
  const suppliedToken =
    readTokenFromHeadersOrQuery(c) || (typeof body.token === 'string' ? body.token : '');

  const access = await verifyPublicFormAccess(c, suppliedToken);
  if (!access.ok) return access.response;
  const { cfg } = access;

  const ip = c.get('clientIp') || '127.0.0.1';
  const submitRate = await checkPublicRateLimit(c.env.DB, `pub_submit:${ip}`, PUBLIC_SUBMIT_MAX);
  if (!submitRate.allowed) {
    return c.json(
      {
        success: false,
        error: `Terlalu banyak pengiriman permintaan dari alamat Anda. Silakan tunggu ${Math.ceil(
          (submitRate.remainingSecs || 60) / 60
        )} menit sebelum mencoba lagi.`,
      },
      429
    );
  }
  await recordPublicRateAttempt(c.env.DB, `pub_submit:${ip}`);

  const requesterName = typeof body.requesterName === 'string' ? body.requesterName.trim() : '';
  const requesterEmail =
    typeof body.requesterEmail === 'string' ? body.requesterEmail.trim().toLowerCase() : '';
  const requesterDepartment =
    typeof body.requesterDepartment === 'string' ? body.requesterDepartment.trim() : '';
  const title = typeof body.title === 'string' ? body.title.trim() : '';
  const regionId = typeof body.regionId === 'string' ? body.regionId.trim() : '';
  const brandId = typeof body.brandId === 'string' ? body.brandId.trim() : '';
  const rawUnitId = typeof body.unitId === 'string' && body.unitId.trim() ? body.unitId.trim() : null;
  const categoryId = typeof body.categoryId === 'string' ? body.categoryId.trim() : '';
  const description = typeof body.description === 'string' ? body.description.trim() : '';
  const deliverablesExpected =
    typeof body.deliverablesExpected === 'string' ? body.deliverablesExpected.trim() : '';
  const referenceUrl = typeof body.referenceUrl === 'string' ? body.referenceUrl.trim() : '';
  const priority = (typeof body.priority === 'string' ? body.priority.trim() : 'medium') as RequestPriority;
  const idempotencyKey =
    typeof body.idempotencyKey === 'string' && body.idempotencyKey.trim()
      ? `pub:${body.idempotencyKey.trim().slice(0, 120)}`
      : undefined;

  if (requesterName.length < 2 || requesterName.length > 120) {
    return c.json(
      { success: false, error: 'Nama Lengkap Pemohon wajib diisi (2 - 120 karakter).' },
      400
    );
  }
  if (!isValidPublicEmail(requesterEmail)) {
    return c.json({ success: false, error: 'Format Email Pemohon tidak valid.' }, 400);
  }
  if (!isEmailDomainAllowed(requesterEmail, cfg.allowedEmailDomains)) {
    return c.json(
      {
        success: false,
        error: `Email Pemohon harus menggunakan domain korporat yang diizinkan (${cfg.allowedEmailDomains
          .map((d) => `@${d}`)
          .join(', ')}).`,
      },
      400
    );
  }
  if (!requesterDepartment || requesterDepartment.length > 100) {
    return c.json({ success: false, error: 'Departemen Pemohon wajib dipilih.' }, 400);
  }
  if (title.length < 5 || title.length > 200) {
    return c.json(
      { success: false, error: 'Judul pekerjaan wajib diisi (5 - 200 karakter).' },
      400
    );
  }
  if (!regionId || !brandId || !categoryId) {
    return c.json(
      { success: false, error: 'Wilayah, Brand / Entitas, dan Kategori Tugas wajib dipilih.' },
      400
    );
  }
  if (description.length < 15 || description.length > 5000) {
    return c.json(
      { success: false, error: 'Deskripsi brief wajib diisi (15 - 5000 karakter).' },
      400
    );
  }
  if (deliverablesExpected.length < 5 || deliverablesExpected.length > 2000) {
    return c.json(
      { success: false, error: 'Deliverable yang diharapkan wajib diisi (5 - 2000 karakter).' },
      400
    );
  }
  if (!['low', 'medium', 'high', 'urgent'].includes(priority)) {
    return c.json({ success: false, error: 'Prioritas yang dipilih tidak valid.' }, 400);
  }
  if (referenceUrl && !isAllowedPublicReferenceUrl(referenceUrl)) {
    return c.json(
      {
        success: false,
        error: 'Tautan referensi eksternal harus menggunakan protokol http:// atau https://.',
      },
      400
    );
  }

  // Idempotency replay check BEFORE creating anything (returns sanitized confirmation summary ONLY)
  if (idempotencyKey) {
    const existingIdemp = await c.env.DB.prepare(
      'SELECT request_id FROM priority_quota_idempotency WHERE idempotency_key = ?'
    )
      .bind(idempotencyKey)
      .first<{ request_id: string }>();
    if (existingIdemp) {
      const existingReq = await c.env.DB.prepare(
        `SELECT id, ticket_number, title, region_name, brand_name, category_name, priority, requested_deadline, requester_name, requester_email, created_at
         FROM requests WHERE id = ? AND deleted_at IS NULL`
      )
        .bind(existingIdemp.request_id)
        .first<Record<string, unknown>>();
      if (existingReq) {
        const prio = String(existingReq.priority) as RequestPriority;
        return c.json({
          success: true,
          deduplicated: true,
          submission: {
            requestId: String(existingReq.id),
            ticketNumber: String(existingReq.ticket_number),
            title: String(existingReq.title),
            regionName: String(existingReq.region_name).replace(/^Wilayah\s+/i, '').trim(),
            brandName: String(existingReq.brand_name),
            categoryName: String(existingReq.category_name),
            priority: prio,
            slaDays: DEFAULT_SLA_DAYS[prio] ?? 7,
            requestedDeadline: String(existingReq.requested_deadline),
            requesterName: String(existingReq.requester_name),
            requesterEmail: String(existingReq.requester_email),
            submittedAt: String(existingReq.created_at),
          },
        });
      }
    }
  }

  // Validate active Master Data from D1
  const [regRow, brandRow, catRow, unitRow] = await Promise.all([
    c.env.DB.prepare('SELECT id, name FROM regions WHERE id = ? AND is_active = 1')
      .bind(regionId)
      .first<{ id: string; name: string }>(),
    c.env.DB.prepare('SELECT id, region_id, name FROM brands WHERE id = ? AND is_active = 1')
      .bind(brandId)
      .first<{ id: string; region_id: string; name: string }>(),
    c.env.DB.prepare('SELECT id, name FROM categories WHERE id = ? AND is_active = 1')
      .bind(categoryId)
      .first<{ id: string; name: string }>(),
    rawUnitId
      ? c.env.DB.prepare('SELECT id, brand_id, name FROM units WHERE id = ? AND is_active = 1')
          .bind(rawUnitId)
          .first<{ id: string; brand_id: string; name: string }>()
      : Promise.resolve(null),
  ]);

  if (!regRow || !brandRow || !catRow) {
    return c.json(
      { success: false, error: 'Master data wilayah, brand, atau kategori tidak valid atau tidak aktif.' },
      400
    );
  }
  if (brandRow.region_id !== regRow.id) {
    return c.json(
      { success: false, error: 'Brand yang dipilih tidak termasuk dalam wilayah tersebut.' },
      400
    );
  }
  if (rawUnitId && (!unitRow || unitRow.brand_id !== brandRow.id)) {
    return c.json(
      { success: false, error: 'Unit bisnis tidak valid untuk brand yang dipilih.' },
      400
    );
  }

  // Validate brief attachments strictly against D1 public-requester uploads
  const rawAtts = Array.isArray(body.briefAttachments) ? body.briefAttachments : [];
  if (rawAtts.length > 0 && !cfg.allowAttachments) {
    return c.json(
      { success: false, error: 'Lampiran file tidak diizinkan pada formulir publik saat ini.' },
      403
    );
  }
  if (rawAtts.length > 10) {
    return c.json(
      { success: false, error: 'Maksimal 10 lampiran brief per pengajuan.' },
      400
    );
  }

  const verifiedAttachments: Attachment[] = [];
  for (const item of rawAtts) {
    const attId = item && typeof item.id === 'string' ? item.id.trim() : '';
    if (!attId) {
      return c.json({ success: false, error: 'Referensi lampiran brief tidak valid.' }, 400);
    }
    const attRow = await c.env.DB.prepare(
      `SELECT id, file_name, mime_type, size_bytes, created_at
       FROM attachments
       WHERE id = ? AND uploaded_by = ? AND scope_type = 'brief' AND deleted_at IS NULL`
    )
      .bind(attId, PUBLIC_REQUESTER_USER_ID)
      .first<{
        id: string;
        file_name: string;
        mime_type: string;
        size_bytes: number;
        created_at: string;
      }>();

    if (!attRow) {
      return c.json(
        { success: false, error: `Lampiran brief "${attId}" tidak ditemukan atau tidak valid.` },
        400
      );
    }
    verifiedAttachments.push({
      id: attRow.id,
      name: attRow.file_name,
      size: Number(attRow.size_bytes),
      type: attRow.mime_type,
      url: `/api/files/${attRow.id}`,
      uploadedAt: attRow.created_at,
      uploadedBy: requesterName,
    });
  }

  await ensurePublicRequesterActor(c.env.DB);

  const quotaYear = getWibYear();
  await ensureBrandPoliciesD1(c.env.DB, brandRow.id, quotaYear);

  // Authoritative server-side SLA calculation (ignores any client-tampered requestedDeadline)
  const policyRow = await c.env.DB.prepare(
    'SELECT sla_days FROM priority_quota_policies WHERE brand_id = ? AND year = ? AND priority = ?'
  )
    .bind(brandRow.id, quotaYear, priority)
    .first<{ sla_days: number }>();

  const authoritativeSlaDays = policyRow?.sla_days ?? DEFAULT_SLA_DAYS[priority] ?? 7;
  const authoritativeDeadline = getWibSlaDeadlineDateString(authoritativeSlaDays);

  const regionName = regRow.name.replace(/^Wilayah\s+/i, '').trim();
  const brandName = brandRow.name;
  const unitId = unitRow ? unitRow.id : null;
  const unitName = unitRow ? unitRow.name : null;
  const categoryName = catRow.name;
  const finalDescription = referenceUrl
    ? `${description}\n\n[Additional Reference Link]: ${referenceUrl}`
    : description;

  // Lookup active Super Admins and scoped Brand Admins for instant notifications
  const adminUsersRes = await c.env.DB.prepare(
    "SELECT id, role, assigned_regions_json, assigned_brands_json FROM users WHERE is_active = 1 AND role IN ('super_admin', 'admin')"
  ).all<Record<string, unknown>>();
  const scopedAdminIds: string[] = [];
  for (const adm of adminUsersRes.results || []) {
    const admId = String(adm.id);
    if (admId === PUBLIC_REQUESTER_USER_ID) continue;
    const regionsList = safeJsonParse<string[]>(adm.assigned_regions_json, []);
    const brandsList = safeJsonParse<string[]>(adm.assigned_brands_json, []);
    const inScope =
      String(adm.role) === 'super_admin' ||
      ((regionsList.includes('all') || regionsList.includes(regionId)) &&
        (brandsList.includes('all') || brandsList.includes(brandId)));
    if (inScope) scopedAdminIds.push(admId);
  }

  const prefix = `REQ-${quotaYear}-`;
  let createdSummary: {
    requestId: string;
    ticketNumber: string;
    submittedAt: string;
  } | null = null;
  let lastErrorMsg = '';

  for (let attempt = 0; attempt < 8; attempt++) {
    const maxRow = await c.env.DB.prepare(
      'SELECT ticket_number FROM requests WHERE ticket_number LIKE ? ORDER BY ticket_number DESC LIMIT 1'
    )
      .bind(`${prefix}%`)
      .first<{ ticket_number: string }>();

    let nextSeq = 1;
    if (maxRow?.ticket_number) {
      const tail = parseInt(maxRow.ticket_number.replace(prefix, ''), 10);
      if (!Number.isNaN(tail)) nextSeq = tail + 1;
    }

    const ticketNumber = `${prefix}${String(nextSeq + (attempt > 0 ? attempt : 0)).padStart(4, '0')}`;
    const requestId = `req-${Date.now()}-${randomHex(4)}`;
    const nowIso = new Date().toISOString();
    const effIdempKey = idempotencyKey || `pub-req-${requestId}-${quotaYear}-${priority}`;

    const statements = [
      c.env.DB.prepare(
        `INSERT INTO requests
         (id, ticket_number, title, region_id, region_name, brand_id, brand_name, unit_id, unit_name,
          requester_department, category_id, category_name, description, deliverables_expected,
          priority, status, requester_id, requester_name, requester_email,
          requested_deadline, brief_attachments_json, quota_year, is_migrated, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'todo', ?, ?, ?, ?, ?, ?, 0, ?, ?)`
      ).bind(
        requestId,
        ticketNumber,
        title,
        regionId,
        regionName,
        brandId,
        brandName,
        unitId,
        unitName,
        requesterDepartment,
        categoryId,
        categoryName,
        finalDescription,
        deliverablesExpected,
        priority,
        PUBLIC_REQUESTER_USER_ID,
        requesterName,
        requesterEmail,
        authoritativeDeadline,
        JSON.stringify(verifiedAttachments),
        quotaYear,
        nowIso,
        nowIso
      ),
      c.env.DB.prepare(
        `INSERT INTO priority_quota_idempotency (idempotency_key, request_id, brand_id, year, priority, created_at)
         VALUES (?, ?, ?, ?, ?, ?)`
      ).bind(effIdempKey, requestId, brandId, quotaYear, priority, nowIso),
    ];

    if (priority !== 'low') {
      statements.push(
        c.env.DB.prepare(
          `INSERT INTO priority_quota_ledger
           (id, brand_id, year, priority, request_id, ticket_number, transaction_type, quantity, actor_id, actor_name, actor_role, reason, idempotency_key, created_at)
           VALUES (?, ?, ?, ?, ?, ?, 'deduction', -1, ?, ?, 'requester', ?, ?, ?)`
        ).bind(
          `qled-${Date.now()}-${randomHex(4)}`,
          brandId,
          quotaYear,
          priority,
          requestId,
          ticketNumber,
          PUBLIC_REQUESTER_USER_ID,
          requesterName,
          `Public link submission: ${title} (${ticketNumber})`,
          effIdempKey,
          nowIso
        )
      );
    }

    for (const att of verifiedAttachments) {
      statements.push(
        c.env.DB.prepare(
          'UPDATE attachments SET request_id = ?, brand_id = ?, region_id = ?, uploaded_by_name = ? WHERE id = ?'
        ).bind(requestId, brandId, regionId, requesterName, att.id)
      );
    }

    statements.push(
      c.env.DB.prepare(
        `INSERT INTO activity_logs (id, request_id, actor_id, actor_name, actor_role, action_type, new_value, reason, timestamp)
         VALUES (?, ?, ?, ?, 'requester', 'create', ?, ?, ?)`
      ).bind(
        `log-${Date.now()}-${randomHex(4)}`,
        requestId,
        PUBLIC_REQUESTER_USER_ID,
        requesterName,
        ticketNumber,
        `Permintaan diajukan via Tautan Publik (${brandName} · ${priority})`,
        nowIso
      )
    );

    for (const admId of scopedAdminIds) {
      statements.push(
        c.env.DB.prepare(
          `INSERT INTO notifications (id, user_id, request_id, ticket_number, title, message, type, is_read, created_at)
           VALUES (?, ?, ?, ?, ?, ?, 'status_change', 0, ?)`
        ).bind(
          `notif-${Date.now()}-${randomHex(4)}`,
          admId,
          requestId,
          ticketNumber,
          `Tiket Publik Baru: ${ticketNumber}`,
          `${requesterName} (${requesterDepartment} · ${requesterEmail}) mengajukan "${title}" untuk ${brandName} [${priority.toUpperCase()}].`,
          nowIso
        )
      );
    }

    try {
      await c.env.DB.batch(statements);
      createdSummary = { requestId, ticketNumber, submittedAt: nowIso };
      break;
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      lastErrorMsg = msg;

      if (idempotencyKey && msg.includes('UNIQUE') && msg.includes('idempotency')) {
        const existingIdemp = await c.env.DB.prepare(
          'SELECT request_id FROM priority_quota_idempotency WHERE idempotency_key = ?'
        )
          .bind(idempotencyKey)
          .first<{ request_id: string }>();
        if (existingIdemp) {
          const existingReq = await c.env.DB.prepare(
            `SELECT id, ticket_number, title, region_name, brand_name, category_name, priority, requested_deadline, requester_name, requester_email, created_at
             FROM requests WHERE id = ? AND deleted_at IS NULL`
          )
            .bind(existingIdemp.request_id)
            .first<Record<string, unknown>>();
          if (existingReq) {
            return c.json({
              success: true,
              deduplicated: true,
              submission: {
                requestId: String(existingReq.id),
                ticketNumber: String(existingReq.ticket_number),
                title: String(existingReq.title),
                regionName: String(existingReq.region_name).replace(/^Wilayah\s+/i, '').trim(),
                brandName: String(existingReq.brand_name),
                categoryName: String(existingReq.category_name),
                priority: String(existingReq.priority) as RequestPriority,
                slaDays: authoritativeSlaDays,
                requestedDeadline: String(existingReq.requested_deadline),
                requesterName: String(existingReq.requester_name),
                requesterEmail: String(existingReq.requester_email),
                submittedAt: String(existingReq.created_at),
              },
            });
          }
        }
      }

      if (msg.includes('ticket_number') && attempt < 7) {
        continue;
      }

      const summary = await getBrandQuotaSummaryD1(c.env.DB, brandId, brandName, quotaYear);
      const avail = summary.priorities[priority];
      await writeSecurityAuditLog(c.env.DB, {
        action: 'public_quota_consumption_rejected',
        actorId: PUBLIC_REQUESTER_USER_ID,
        actorName: requesterName,
        actorRole: 'requester',
        summary: `Atomic public request+quota rollback for ${brandName} [${priority}] (${requesterEmail}): ${msg}`,
      });

      if (msg.includes('QUOTA_EXHAUSTED') || msg.includes('CHECK') || msg.includes('QUOTA_POLICY')) {
        return c.json(
          {
            success: false,
            error: `Kuota tahunan ${quotaYear} untuk prioritas ${avail.name} pada brand ${brandName} telah habis (0/${avail.annualLimit} tersisa). Silakan pilih prioritas lain.`,
          },
          409
        );
      }

      return c.json(
        { success: false, error: 'Gagal menyimpan permintaan secara atomik. Silakan coba lagi.' },
        500
      );
    }
  }

  if (!createdSummary) {
    return c.json(
      {
        success: false,
        error: `Gagal menghasilkan nomor tiket unik untuk pengajuan Anda: ${lastErrorMsg}`,
      },
      409
    );
  }

  await writeSecurityAuditLog(c.env.DB, {
    action: 'public_request_submitted',
    actorId: PUBLIC_REQUESTER_USER_ID,
    actorName: requesterName,
    actorRole: 'requester',
    targetId: createdSummary.requestId,
    targetType: 'request',
    summary: `Public link request ${createdSummary.ticketNumber} submitted by ${requesterName} <${requesterEmail}> for ${brandName} [${priority}]`,
  });

  return c.json(
    {
      success: true,
      submission: {
        requestId: createdSummary.requestId,
        ticketNumber: createdSummary.ticketNumber,
        title,
        regionName,
        brandName,
        categoryName,
        priority,
        slaDays: authoritativeSlaDays,
        requestedDeadline: authoritativeDeadline,
        requesterName,
        requesterEmail,
        submittedAt: createdSummary.submittedAt,
      },
    },
    201
  );
});
