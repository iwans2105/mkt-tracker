import { Hono } from 'hono';
import type { D1Database } from '@cloudflare/workers-types';
import type {
  CommittedDeadlineSnapshot,
  RequestItem,
  RequestPriority,
  RequestStatus,
  SubItem,
  SubItemApprovalEvent,
} from '../../types';
import {
  canUserViewRequest,
  isUserWithinBrandScope,
  requireAuth,
  writeSecurityAuditLog,
} from '../middleware/auth';
import { randomHex } from '../crypto';
import {
  ensureBrandPoliciesD1,
  getBrandQuotaSummaryD1,
  reallocateQuotaAtomicallyD1,
} from './quotas';
import {
  rowToActivityLog,
  rowToComment,
  rowToRequest,
  rowToSubItem,
  StoredUserRecord,
  WorkerAppEnv,
} from '../types';
import { getWibTodayDateString, getWibYear, normalizeQuotaYear } from '../utils/wib';

export async function fetchAllSubItemsMap(db: D1Database): Promise<Map<string, SubItem[]>> {
  const res = await db
    .prepare('SELECT * FROM sub_items WHERE deleted_at IS NULL ORDER BY created_at ASC')
    .all<Record<string, unknown>>();
  const map = new Map<string, SubItem[]>();
  for (const row of res.results || []) {
    const sub = rowToSubItem(row);
    const list = map.get(sub.parentRequestId) || [];
    list.push(sub);
    map.set(sub.parentRequestId, list);
  }
  return map;
}

export async function loadSingleRequest(db: D1Database, requestId: string): Promise<RequestItem | null> {
  const row = await db
    .prepare('SELECT * FROM requests WHERE id = ? AND deleted_at IS NULL')
    .bind(requestId)
    .first<Record<string, unknown>>();
  if (!row) return null;

  const subRes = await db
    .prepare('SELECT * FROM sub_items WHERE parent_request_id = ? AND deleted_at IS NULL ORDER BY created_at ASC')
    .bind(requestId)
    .all<Record<string, unknown>>();
  return rowToRequest(row, (subRes.results || []).map(rowToSubItem));
}

function isAuthorizedForRequestActions(user: StoredUserRecord, req: RequestItem): boolean {
  if (user.role === 'super_admin') return true;
  if (user.role === 'admin' && isUserWithinBrandScope(user, req.regionId, req.brandId)) return true;
  if (req.primaryAssigneeId === user.id) return true;
  if (Array.isArray(req.collaboratorIds) && req.collaboratorIds.includes(user.id)) return true;
  return false;
}

function canApproveOrReviseRequest(user: StoredUserRecord, req: RequestItem): boolean {
  if (req.status !== 'pending_review') return false;
  if (user.role === 'super_admin') return true;
  if (req.reviewerId && req.reviewerId === user.id) return true;
  if (user.role === 'admin' && isUserWithinBrandScope(user, req.regionId, req.brandId)) return true;
  if (user.isReviewer && isUserWithinBrandScope(user, req.regionId, req.brandId)) return true;
  return false;
}

function canTransitionStatusServer(
  user: StoredUserRecord,
  req: RequestItem,
  targetStatus: RequestStatus
): { allowed: boolean; reason?: string } {
  if (req.status === targetStatus) return { allowed: true };

  const isAdmin = user.role === 'super_admin' || (user.role === 'admin' && isUserWithinBrandScope(user, req.regionId, req.brandId));
  const isAssigned =
    req.primaryAssigneeId === user.id ||
    (Array.isArray(req.collaboratorIds) && req.collaboratorIds.includes(user.id));

  if (req.status === 'todo' && targetStatus === 'in_progress') {
    if (!req.primaryAssigneeId) {
      return { allowed: false, reason: 'Pelaksana Utama belum ditugaskan oleh Admin.' };
    }
    if (!req.committedDeadline) {
      return { allowed: false, reason: 'Tenggat Komitmen belum ditetapkan oleh Admin.' };
    }
    if (!isAdmin && !isAssigned) {
      return { allowed: false, reason: 'Hanya Pelaksana Utama atau Admin yang dapat memulai pekerjaan.' };
    }
    return { allowed: true };
  }

  if ((req.status === 'in_progress' || req.status === 'revision') && targetStatus === 'pending_review') {
    if (!isAuthorizedForRequestActions(user, req)) {
      return {
        allowed: false,
        reason: 'Hanya Super Admin, Marcomm Admin dalam cakupan, atau PIC/Tim Eksekusi yang dapat mengajukan review.',
      };
    }
    const hasDeliverables =
      (req.deliverableAttachments && req.deliverableAttachments.length > 0) ||
      (req.deliverableLinks && req.deliverableLinks.length > 0);
    if (!hasDeliverables) {
      return {
        allowed: false,
        reason: 'Berkas atau tautan hasil pekerjaan wajib dilampirkan sebelum mengajukan review.',
      };
    }
    return { allowed: true };
  }

  if (req.status === 'pending_review' && (targetStatus === 'revision' || targetStatus === 'completed')) {
    if (!canApproveOrReviseRequest(user, req)) {
      return {
        allowed: false,
        reason: 'Hanya Reviewer yang ditunjuk atau Admin berwenang yang dapat menyetujui atau meminta revisi.',
      };
    }
    return { allowed: true };
  }

  if (req.status === 'revision' && targetStatus === 'in_progress') {
    if (!isAuthorizedForRequestActions(user, req)) {
      return { allowed: false, reason: 'Hanya PIC, Kolaborator, atau Admin yang dapat melanjutkan revisi.' };
    }
    return { allowed: true };
  }

  if (req.status === 'completed' && targetStatus === 'in_progress') {
    if (!isAdmin) {
      return { allowed: false, reason: 'Hanya Admin berwenang yang dapat membuka ulang tiket yang sudah selesai.' };
    }
    return { allowed: true };
  }

  if (targetStatus === 'on_hold') {
    if (req.status === 'completed' || req.status === 'cancelled') {
      return { allowed: false, reason: `Tidak dapat menunda permintaan dengan status ${req.status}.` };
    }
    if (!isAuthorizedForRequestActions(user, req)) {
      return { allowed: false, reason: 'Anda tidak memiliki izin untuk menunda permintaan ini.' };
    }
    return { allowed: true };
  }

  if (req.status === 'on_hold') {
    if (!isAuthorizedForRequestActions(user, req)) {
      return { allowed: false, reason: 'Anda tidak memiliki izin melanjutkan permintaan ini.' };
    }
    if (targetStatus === 'in_progress' || targetStatus === 'todo' || targetStatus === 'cancelled') {
      return { allowed: true };
    }
    return { allowed: false, reason: 'Permintaan On Hold hanya dapat dilanjutkan ke In Progress, To Do, atau Cancelled.' };
  }

  if (targetStatus === 'cancelled') {
    if (req.status === 'completed') {
      return { allowed: false, reason: 'Permintaan yang sudah selesai tidak dapat dibatalkan.' };
    }
    if (!isAuthorizedForRequestActions(user, req)) {
      return { allowed: false, reason: 'Anda tidak memiliki izin membatalkan permintaan ini.' };
    }
    return { allowed: true };
  }

  if (req.status === 'cancelled') {
    if (!isAuthorizedForRequestActions(user, req)) {
      return { allowed: false, reason: 'Anda tidak memiliki izin mengaktifkan ulang permintaan ini.' };
    }
    if (targetStatus === 'todo' || targetStatus === 'in_progress') {
      return { allowed: true };
    }
    return { allowed: false, reason: 'Permintaan Cancelled hanya dapat diaktifkan ke To Do atau In Progress.' };
  }

  return {
    allowed: false,
    reason: `Transisi status langsung dari ${req.status} ke ${targetStatus} tidak diizinkan.`,
  };
}

export const requestRoutes = new Hono<WorkerAppEnv>();
requestRoutes.use('*', requireAuth);

// 1. List scoped requests with non-deleted subItems
requestRoutes.get('/', async (c) => {
  const user = c.get('user')!;
  const [reqRes, subMap] = await Promise.all([
    c.env.DB.prepare('SELECT * FROM requests WHERE deleted_at IS NULL ORDER BY created_at DESC').all<
      Record<string, unknown>
    >(),
    fetchAllSubItemsMap(c.env.DB),
  ]);

  const mapped = (reqRes.results || [])
    .map((r) => rowToRequest(r, subMap.get(String(r.id)) || []))
    .filter((r) => canUserViewRequest(user, r));

  return c.json({ success: true, requests: mapped });
});

// 2. Get single request detail (RBAC enforced)
requestRoutes.get('/:id', async (c) => {
  const user = c.get('user')!;
  const requestId = c.req.param('id');
  const reqItem = await loadSingleRequest(c.env.DB, requestId);
  if (!reqItem) {
    return c.json({ success: false, error: 'Permintaan tidak ditemukan.' }, 404);
  }
  if (!canUserViewRequest(user, reqItem)) {
    return c.json({ success: false, error: 'Akses ditolak untuk melihat permintaan ini.' }, 403);
  }
  return c.json({ success: true, request: reqItem });
});

// 3. Atomic Request Creation + Annual Priority Quota Deduction
requestRoutes.post('/', async (c) => {
  const actor = c.get('user')!;
  const body = await c.req.json().catch(() => ({}));

  const title = typeof body.title === 'string' ? body.title.trim() : '';
  const regionId = typeof body.regionId === 'string' ? body.regionId : '';
  const brandId = typeof body.brandId === 'string' ? body.brandId : '';
  const categoryId = typeof body.categoryId === 'string' ? body.categoryId : '';
  const description = typeof body.description === 'string' ? body.description.trim() : '';
  const deliverablesExpected =
    typeof body.deliverablesExpected === 'string' ? body.deliverablesExpected.trim() : '';
  const requestedDeadline =
    typeof body.requestedDeadline === 'string' ? body.requestedDeadline.trim() : '';
  const priority = (body.priority as RequestPriority) || 'medium';
  const idempotencyKey =
    typeof body.idempotencyKey === 'string' && body.idempotencyKey.trim()
      ? body.idempotencyKey.trim()
      : undefined;

  if (!title || !regionId || !brandId || !categoryId || !requestedDeadline) {
    return c.json(
      {
        success: false,
        error: 'Judul, wilayah, brand, kategori, dan target tenggat waktu wajib diisi.',
      },
      400
    );
  }

  if (!['low', 'medium', 'high', 'urgent'].includes(priority)) {
    return c.json({ success: false, error: 'Prioritas tidak valid.' }, 400);
  }

  if (!isUserWithinBrandScope(actor, regionId, brandId)) {
    return c.json(
      { success: false, error: 'Akses ditolak: Brand berada di luar cakupan akun Anda.' },
      403
    );
  }

  const quotaYear = normalizeQuotaYear(body.quotaYear || getWibYear());

  // Idempotency replay check BEFORE creating anything
  if (idempotencyKey) {
    const existingIdemp = await c.env.DB.prepare(
      'SELECT request_id FROM priority_quota_idempotency WHERE idempotency_key = ?'
    )
      .bind(idempotencyKey)
      .first<{ request_id: string }>();
    if (existingIdemp) {
      const existingReq = await loadSingleRequest(c.env.DB, existingIdemp.request_id);
      if (existingReq) {
        return c.json({ success: true, deduplicated: true, request: existingReq });
      }
    }
    const existingByReqLedger = await c.env.DB.prepare(
      'SELECT request_id FROM priority_quota_ledger WHERE idempotency_key = ?'
    )
      .bind(idempotencyKey)
      .first<{ request_id: string }>();
    if (existingByReqLedger) {
      const existingReq = await loadSingleRequest(c.env.DB, existingByReqLedger.request_id);
      if (existingReq) {
        return c.json({ success: true, deduplicated: true, request: existingReq });
      }
    }
  }

  // Lookup authoritative names from D1 master data
  const [regRow, brandRow, catRow, unitRow] = await Promise.all([
    c.env.DB.prepare('SELECT id, name FROM regions WHERE id = ?').bind(regionId).first<{ id: string; name: string }>(),
    c.env.DB.prepare('SELECT id, name FROM brands WHERE id = ?').bind(brandId).first<{ id: string; name: string }>(),
    c.env.DB.prepare('SELECT id, name FROM categories WHERE id = ?').bind(categoryId).first<{ id: string; name: string }>(),
    body.unitId
      ? c.env.DB.prepare('SELECT id, name FROM units WHERE id = ?').bind(String(body.unitId)).first<{ id: string; name: string }>()
      : Promise.resolve(null),
  ]);

  if (!regRow || !brandRow || !catRow) {
    return c.json({ success: false, error: 'Master data wilayah, brand, atau kategori tidak valid.' }, 400);
  }

  const regionName = regRow.name.replace(/^Wilayah\s+/i, '').trim();
  const brandName = brandRow.name;
  const unitId = unitRow?.id || (body.unitId ? String(body.unitId) : null);
  const unitName = unitRow?.name || (body.unitName ? String(body.unitName) : null);
  const categoryName = catRow.name;

  // Ensure requester cannot spoof someone else's identity
  let requesterId = actor.id;
  let requesterName = actor.fullName;
  let requesterEmail = actor.email;
  let requesterDept = typeof body.requesterDepartment === 'string' && body.requesterDepartment.trim()
    ? body.requesterDepartment.trim()
    : actor.department || 'Marketing';

  if ((actor.role === 'super_admin' || actor.role === 'admin') && typeof body.requesterId === 'string' && body.requesterId) {
    const reqUserRow = await c.env.DB.prepare('SELECT id, full_name, email, department FROM users WHERE id = ?')
      .bind(body.requesterId)
      .first<{ id: string; full_name: string; email: string; department: string }>();
    if (reqUserRow) {
      requesterId = reqUserRow.id;
      requesterName = reqUserRow.full_name;
      requesterEmail = reqUserRow.email;
      requesterDept = body.requesterDepartment || reqUserRow.department || requesterDept;
    }
  }

  // Ensure annual quota policies exist before running the atomic batch
  await ensureBrandPoliciesD1(c.env.DB, brandId, quotaYear);

  // Generate sequential ticket number in current WIB year with bounded retry on concurrent ticket_number collision
  const prefix = `REQ-${quotaYear}-`;
  const briefAttachments = Array.isArray(body.briefAttachments) ? body.briefAttachments : [];

  // Lookup active Admins / Super Admins within brand scope once
  const adminUsersRes = await c.env.DB.prepare(
    "SELECT id, role, assigned_regions_json, assigned_brands_json FROM users WHERE is_active = 1 AND role IN ('super_admin', 'admin')"
  ).all<Record<string, unknown>>();
  const scopedAdminIds: string[] = [];
  for (const adm of adminUsersRes.results || []) {
    const admId = String(adm.id);
    if (admId === actor.id) continue;
    const regionsList = JSON.parse(String(adm.assigned_regions_json || '[]')) as string[];
    const brandsList = JSON.parse(String(adm.assigned_brands_json || '[]')) as string[];
    const inScope =
      String(adm.role) === 'super_admin' ||
      ((regionsList.includes('all') || regionsList.includes(regionId)) &&
        (brandsList.includes('all') || brandsList.includes(brandId)));
    if (inScope) scopedAdminIds.push(admId);
  }

  let createdRequestId = '';
  let lastErrorMsg = '';

  for (let attempt = 0; attempt < 8; attempt++) {
    const maxRow = await c.env.DB.prepare(
      `SELECT ticket_number FROM requests WHERE ticket_number LIKE ? ORDER BY ticket_number DESC LIMIT 1`
    )
      .bind(`${prefix}%`)
      .first<{ ticket_number: string }>();
    let nextSeq = 1;
    if (maxRow?.ticket_number) {
      const tail = parseInt(maxRow.ticket_number.replace(prefix, ''), 10);
      if (!Number.isNaN(tail)) nextSeq = tail + 1;
    }
    // Add attempt offset if retrying after collision
    const ticketNumber = `${prefix}${String(nextSeq + (attempt > 0 ? 1 : 0)).padStart(4, '0')}`;
    const requestId = `req-${Date.now()}-${randomHex(4)}`;
    const nowIso = new Date().toISOString();
    const effIdempKey = idempotencyKey || `req-${requestId}-${quotaYear}-${priority}`;

    const statements = [
      c.env.DB.prepare(
        `INSERT INTO requests
         (id, ticket_number, title, region_id, region_name, brand_id, brand_name, unit_id, unit_name,
          requester_department, category_id, category_name, description, deliverables_expected,
          priority, status, requester_id, requester_name, requester_email,
          requested_deadline, brief_attachments_json, quota_year, is_migrated, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'todo', ?, ?, ?, ?, ?, ?, 0, ?, ?)`
      ).bind(
        requestId,
        ticketNumber,
        title,
        regionId,
        regionName,
        brandId,
        brandName,
        unitId,
        unitName,
        requesterDept,
        categoryId,
        categoryName,
        description,
        deliverablesExpected,
        priority,
        requesterId,
        requesterName,
        requesterEmail,
        requestedDeadline,
        JSON.stringify(briefAttachments),
        quotaYear,
        nowIso,
        nowIso
      ),
    ];

    if (priority !== 'low') {
      statements.push(
        c.env.DB.prepare(
          `INSERT INTO priority_quota_idempotency (idempotency_key, request_id, brand_id, year, priority, created_at)
           VALUES (?, ?, ?, ?, ?, ?)`
        ).bind(effIdempKey, requestId, brandId, quotaYear, priority, nowIso),
        c.env.DB.prepare(
          `INSERT INTO priority_quota_ledger
           (id, brand_id, year, priority, request_id, ticket_number, transaction_type, quantity, actor_id, actor_name, actor_role, reason, idempotency_key, created_at)
           VALUES (?, ?, ?, ?, ?, ?, 'deduction', -1, ?, ?, ?, ?, ?, ?)`
        ).bind(
          `qled-${Date.now()}-${randomHex(4)}`,
          brandId,
          quotaYear,
          priority,
          requestId,
          ticketNumber,
          actor.id,
          actor.fullName,
          actor.role,
          `Request submission: ${title} (${ticketNumber})`,
          effIdempKey,
          nowIso
        )
      );
    }

    statements.push(
      c.env.DB.prepare(
        `INSERT INTO activity_logs (id, request_id, actor_id, actor_name, actor_role, action_type, new_value, reason, timestamp)
         VALUES (?, ?, ?, ?, ?, 'create', ?, ?, ?)`
      ).bind(
        `log-${Date.now()}-${randomHex(4)}`,
        requestId,
        actor.id,
        actor.fullName,
        actor.role,
        ticketNumber,
        `Permintaan baru dibuat (${brandName} · ${priority})`,
        nowIso
      )
    );

    for (const admId of scopedAdminIds) {
      statements.push(
        c.env.DB.prepare(
          `INSERT INTO notifications (id, user_id, request_id, ticket_number, title, message, type, is_read, created_at)
           VALUES (?, ?, ?, ?, ?, ?, 'status_change', 0, ?)`
        ).bind(
          `notif-${Date.now()}-${randomHex(4)}`,
          admId,
          requestId,
          ticketNumber,
          `Tiket Baru: ${ticketNumber}`,
          `${requesterName} (${brandName}) mengajukan "${title}" [${priority.toUpperCase()}].`,
          nowIso
        )
      );
    }

    try {
      await c.env.DB.batch(statements);
      createdRequestId = requestId;
      break;
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      lastErrorMsg = msg;

      if (idempotencyKey && msg.includes('UNIQUE') && msg.includes('idempotency')) {
        const existingIdemp = await c.env.DB.prepare(
          'SELECT request_id FROM priority_quota_idempotency WHERE idempotency_key = ?'
        )
          .bind(idempotencyKey)
          .first<{ request_id: string }>();
        if (existingIdemp) {
          const existingReq = await loadSingleRequest(c.env.DB, existingIdemp.request_id);
          if (existingReq) {
            return c.json({ success: true, deduplicated: true, request: existingReq });
          }
        }
      }

      // Retry only on transient ticket_number collision under concurrent inserts
      if (msg.includes('ticket_number') && attempt < 7) {
        continue;
      }

      const summary = await getBrandQuotaSummaryD1(c.env.DB, brandId, brandName, quotaYear);
      const avail = summary.priorities[priority];
      await writeSecurityAuditLog(c.env.DB, {
        action: 'quota_consumption_rejected',
        actorId: actor.id,
        actorName: actor.fullName,
        actorRole: actor.role,
        summary: `Atomic request+quota rollback for ${brandName} [${priority}]: ${msg}`,
      });

      if (msg.includes('QUOTA_EXHAUSTED') || msg.includes('CHECK') || msg.includes('QUOTA_POLICY')) {
        return c.json(
          {
            success: false,
            error: `Kuota tahunan ${quotaYear} untuk prioritas ${avail.name} pada brand ${brandName} telah habis (0/${avail.annualLimit} tersisa). Request tidak dibuat.`,
          },
          409
        );
      }
      return c.json({ success: false, error: `Gagal membuat permintaan secara atomik: ${msg}` }, 500);
    }
  }

  if (!createdRequestId) {
    return c.json(
      { success: false, error: `Gagal menghasilkan nomor tiket unik secara atomik: ${lastErrorMsg}` },
      409
    );
  }

  const created = await loadSingleRequest(c.env.DB, createdRequestId);
  return c.json({ success: true, request: created }, 201);
});

// 4. Update Brief Details (only in 'todo' status; supports atomic priority reallocation)
requestRoutes.put('/:id/brief', async (c) => {
  const actor = c.get('user')!;
  const requestId = c.req.param('id');
  const reqItem = await loadSingleRequest(c.env.DB, requestId);
  if (!reqItem) return c.json({ success: false, error: 'Permintaan tidak ditemukan.' }, 404);

  const canEdit =
    actor.role === 'super_admin' ||
    (actor.role === 'admin' && isUserWithinBrandScope(actor, reqItem.regionId, reqItem.brandId) && reqItem.status === 'todo') ||
    (actor.role === 'requester' && reqItem.requesterId === actor.id && reqItem.status === 'todo');

  if (!canEdit) {
    return c.json(
      { success: false, error: 'Detail brief hanya dapat diubah saat status To Do oleh pemohon atau Admin berwenang.' },
      403
    );
  }

  const body = await c.req.json().catch(() => ({}));
  const nowIso = new Date().toISOString();

  if (body.priority && body.priority !== reqItem.priority) {
    const reqRow = await c.env.DB.prepare('SELECT quota_year FROM requests WHERE id = ?')
      .bind(requestId)
      .first<{ quota_year: number }>();
    const realloc = await reallocateQuotaAtomicallyD1({
      db: c.env.DB,
      brandId: reqItem.brandId,
      brandName: reqItem.brandName,
      oldPriority: reqItem.priority,
      newPriority: body.priority,
      requestId: reqItem.id,
      ticketNumber: reqItem.ticketNumber,
      actor,
      reason: 'Priority modified in request brief',
      year: reqRow?.quota_year,
    });
    if (!realloc.success) {
      return c.json({ success: false, error: realloc.error }, 409);
    }
  }

  const nextTitle = typeof body.title === 'string' && body.title.trim() ? body.title.trim() : reqItem.title;
  const nextDesc = typeof body.description === 'string' ? body.description : reqItem.description;
  const nextDeliv =
    typeof body.deliverablesExpected === 'string'
      ? body.deliverablesExpected
      : reqItem.deliverablesExpected;
  const nextDeadline =
    typeof body.requestedDeadline === 'string' && body.requestedDeadline
      ? body.requestedDeadline
      : reqItem.requestedDeadline;
  const nextPriority = (body.priority as RequestPriority) || reqItem.priority;

  await c.env.DB.batch([
    c.env.DB.prepare(
      `UPDATE requests SET title = ?, description = ?, deliverables_expected = ?, requested_deadline = ?, priority = ?, updated_at = ?
       WHERE id = ?`
    ).bind(nextTitle, nextDesc, nextDeliv, nextDeadline, nextPriority, nowIso, requestId),
    c.env.DB.prepare(
      `INSERT INTO activity_logs (id, request_id, actor_id, actor_name, actor_role, action_type, field_changed, reason, timestamp)
       VALUES (?, ?, ?, ?, ?, 'priority_update', 'brief_details', ?, ?)`
    ).bind(
      `log-${Date.now()}-${randomHex(4)}`,
      requestId,
      actor.id,
      actor.fullName,
      actor.role,
      'Detail brief diperbarui',
      nowIso
    ),
  ]);

  const updated = await loadSingleRequest(c.env.DB, requestId);
  return c.json({ success: true, request: updated });
});

// 5. Assign Request Team, PIC, Reviewer & Committed Deadline
requestRoutes.post('/:id/assign', async (c) => {
  const actor = c.get('user')!;
  const requestId = c.req.param('id');
  const reqItem = await loadSingleRequest(c.env.DB, requestId);
  if (!reqItem) return c.json({ success: false, error: 'Permintaan tidak ditemukan.' }, 404);

  if (
    actor.role !== 'super_admin' &&
    !(actor.role === 'admin' && isUserWithinBrandScope(actor, reqItem.regionId, reqItem.brandId))
  ) {
    return c.json({ success: false, error: 'Hanya Super Admin atau Marcomm Admin dalam cakupan yang dapat menugaskan.' }, 403);
  }

  const body = await c.req.json().catch(() => ({}));
  const { assignedTeamId, primaryAssigneeId, collaboratorIds, reviewerId, committedDeadline, deadlineReason } = body;

  const [teamRow, primaryRow, reviewerRow] = await Promise.all([
    assignedTeamId
      ? c.env.DB.prepare('SELECT id, name FROM teams WHERE id = ?').bind(String(assignedTeamId)).first<{ id: string; name: string }>()
      : Promise.resolve(null),
    primaryAssigneeId
      ? c.env.DB.prepare('SELECT id, full_name FROM users WHERE id = ?').bind(String(primaryAssigneeId)).first<{ id: string; full_name: string }>()
      : Promise.resolve(null),
    reviewerId
      ? c.env.DB.prepare('SELECT id, full_name FROM users WHERE id = ?').bind(String(reviewerId)).first<{ id: string; full_name: string }>()
      : Promise.resolve(null),
  ]);

  const collabIdArr: string[] = Array.isArray(collaboratorIds) ? collaboratorIds.map(String) : [];
  const collabNames: string[] = [];
  for (const cid of collabIdArr) {
    const cr = await c.env.DB.prepare('SELECT full_name FROM users WHERE id = ?')
      .bind(cid)
      .first<{ full_name: string }>();
    if (cr) collabNames.push(cr.full_name);
  }

  const nowIso = new Date().toISOString();
  const newSnapshot: CommittedDeadlineSnapshot = {
    committedDeadline: String(committedDeadline || reqItem.committedDeadline || ''),
    updatedAt: nowIso,
    updatedBy: actor.fullName,
    reason: String(deadlineReason || 'Penetapan tenggat komitmen awal'),
  };
  const snapshots = [newSnapshot, ...(reqItem.committedDeadlineSnapshots || [])];

  const stmts = [
    c.env.DB.prepare(
      `UPDATE requests
       SET assigned_team_id = ?, assigned_team_name = ?, primary_assignee_id = ?, primary_assignee_name = ?,
           collaborator_ids_json = ?, collaborator_names_json = ?, reviewer_id = ?, reviewer_name = ?,
           committed_deadline = ?, committed_deadline_snapshots_json = ?, updated_at = ?
       WHERE id = ?`
    ).bind(
      assignedTeamId || null,
      teamRow?.name || reqItem.assignedTeamName || null,
      primaryAssigneeId || null,
      primaryRow?.full_name || reqItem.primaryAssigneeName || null,
      JSON.stringify(collabIdArr),
      JSON.stringify(collabNames),
      reviewerId || null,
      reviewerRow?.full_name || null,
      committedDeadline || reqItem.committedDeadline || null,
      JSON.stringify(snapshots),
      nowIso,
      requestId
    ),
    c.env.DB.prepare(
      `INSERT INTO activity_logs (id, request_id, actor_id, actor_name, actor_role, action_type, field_changed, new_value, reason, timestamp)
       VALUES (?, ?, ?, ?, ?, 'assign', 'assignment', ?, ?, ?)`
    ).bind(
      `log-${Date.now()}-${randomHex(4)}`,
      requestId,
      actor.id,
      actor.fullName,
      actor.role,
      `${primaryRow?.full_name || '-'} (${teamRow?.name || '-'})`,
      deadlineReason || null,
      nowIso
    ),
  ];

  if (primaryRow && primaryRow.id !== actor.id) {
    stmts.push(
      c.env.DB.prepare(
        `INSERT INTO notifications (id, user_id, request_id, ticket_number, title, message, type, is_read, created_at)
         VALUES (?, ?, ?, ?, ?, ?, 'assignment', 0, ?)`
      ).bind(
        `notif-${Date.now()}-${randomHex(4)}`,
        primaryRow.id,
        requestId,
        reqItem.ticketNumber,
        'Penugasan Tugas Baru',
        `Anda ditugaskan pada "${reqItem.title}". Tenggat komitmen: ${committedDeadline || '-'}`,
        nowIso
      )
    );
  }

  await c.env.DB.batch(stmts);
  const updated = await loadSingleRequest(c.env.DB, requestId);
  return c.json({ success: true, request: updated });
});

// 6. Update Committed Deadline
requestRoutes.put('/:id/deadline', async (c) => {
  const actor = c.get('user')!;
  const requestId = c.req.param('id');
  const reqItem = await loadSingleRequest(c.env.DB, requestId);
  if (!reqItem) return c.json({ success: false, error: 'Permintaan tidak ditemukan.' }, 404);

  if (
    actor.role !== 'super_admin' &&
    !(actor.role === 'admin' && isUserWithinBrandScope(actor, reqItem.regionId, reqItem.brandId))
  ) {
    return c.json({ success: false, error: 'Hanya Super Admin atau Admin berwenang yang dapat mengubah tenggat komitmen.' }, 403);
  }

  const body = await c.req.json().catch(() => ({}));
  const newDeadline = typeof body.newDeadline === 'string' ? body.newDeadline.trim() : '';
  const reason = typeof body.reason === 'string' ? body.reason.trim() : '';
  if (!newDeadline || reason.length < 5) {
    return c.json(
      { success: false, error: 'Tanggal baru dan alasan perubahan (min 5 karakter) wajib diisi.' },
      400
    );
  }

  const nowIso = new Date().toISOString();
  const snapshots: CommittedDeadlineSnapshot[] = [
    { committedDeadline: newDeadline, updatedAt: nowIso, updatedBy: actor.fullName, reason },
    ...(reqItem.committedDeadlineSnapshots || []),
  ];

  const stmts = [
    c.env.DB.prepare(
      'UPDATE requests SET committed_deadline = ?, committed_deadline_snapshots_json = ?, updated_at = ? WHERE id = ?'
    ).bind(newDeadline, JSON.stringify(snapshots), nowIso, requestId),
    c.env.DB.prepare(
      `INSERT INTO activity_logs (id, request_id, actor_id, actor_name, actor_role, action_type, field_changed, old_value, new_value, reason, timestamp)
       VALUES (?, ?, ?, ?, ?, 'deadline_update', 'committedDeadline', ?, ?, ?, ?)`
    ).bind(
      `log-${Date.now()}-${randomHex(4)}`,
      requestId,
      actor.id,
      actor.fullName,
      actor.role,
      reqItem.committedDeadline || '-',
      newDeadline,
      reason,
      nowIso
    ),
  ];

  if (reqItem.requesterId !== actor.id) {
    stmts.push(
      c.env.DB.prepare(
        `INSERT INTO notifications (id, user_id, request_id, ticket_number, title, message, type, is_read, created_at)
         VALUES (?, ?, ?, ?, ?, ?, 'status_change', 0, ?)`
      ).bind(
        `notif-${Date.now()}-${randomHex(4)}`,
        reqItem.requesterId,
        requestId,
        reqItem.ticketNumber,
        'Pembaruan Tenggat Komitmen',
        `Tenggat komitmen untuk "${reqItem.title}" diperbarui menjadi ${newDeadline}. Alasan: ${reason}`,
        nowIso
      )
    );
  }

  await c.env.DB.batch(stmts);
  const updated = await loadSingleRequest(c.env.DB, requestId);
  return c.json({ success: true, request: updated });
});

// 7. Reopen Completed Request
requestRoutes.post('/:id/reopen', async (c) => {
  const actor = c.get('user')!;
  const requestId = c.req.param('id');
  const reqItem = await loadSingleRequest(c.env.DB, requestId);
  if (!reqItem) return c.json({ success: false, error: 'Permintaan tidak ditemukan.' }, 404);

  if (
    actor.role !== 'super_admin' &&
    !(actor.role === 'admin' && isUserWithinBrandScope(actor, reqItem.regionId, reqItem.brandId))
  ) {
    return c.json({ success: false, error: 'Hanya Super Admin atau Admin berwenang yang dapat membuka ulang tiket.' }, 403);
  }

  const body = await c.req.json().catch(() => ({}));
  const reason = typeof body.reason === 'string' ? body.reason.trim() : '';
  if (reason.length < 5) {
    return c.json({ success: false, error: 'Alasan pembukaan ulang wajib diisi (minimal 5 karakter).' }, 400);
  }

  const nowIso = new Date().toISOString();
  const stmts = [
    c.env.DB.prepare(
      `UPDATE requests SET status = 'in_progress', reopen_count = reopen_count + 1, reopen_reason = ?, updated_at = ? WHERE id = ?`
    ).bind(reason, nowIso, requestId),
    c.env.DB.prepare(
      `INSERT INTO activity_logs (id, request_id, actor_id, actor_name, actor_role, action_type, field_changed, old_value, new_value, reason, timestamp)
       VALUES (?, ?, ?, ?, ?, 'reopened', 'status', 'completed', 'in_progress', ?, ?)`
    ).bind(
      `log-${Date.now()}-${randomHex(4)}`,
      requestId,
      actor.id,
      actor.fullName,
      actor.role,
      reason,
      nowIso
    ),
  ];

  if (reqItem.primaryAssigneeId && reqItem.primaryAssigneeId !== actor.id) {
    stmts.push(
      c.env.DB.prepare(
        `INSERT INTO notifications (id, user_id, request_id, ticket_number, title, message, type, is_read, created_at)
         VALUES (?, ?, ?, ?, ?, ?, 'status_change', 0, ?)`
      ).bind(
        `notif-${Date.now()}-${randomHex(4)}`,
        reqItem.primaryAssigneeId,
        requestId,
        reqItem.ticketNumber,
        'Tugas Dibuka Ulang',
        `Admin membuka ulang tugas "${reqItem.title}". Alasan: ${reason}`,
        nowIso
      )
    );
  }

  await c.env.DB.batch(stmts);
  const updated = await loadSingleRequest(c.env.DB, requestId);
  return c.json({ success: true, request: updated });
});

// 8. Add Deliverables (Files / External Links)
requestRoutes.post('/:id/deliverables', async (c) => {
  const actor = c.get('user')!;
  const requestId = c.req.param('id');
  const reqItem = await loadSingleRequest(c.env.DB, requestId);
  if (!reqItem) return c.json({ success: false, error: 'Permintaan tidak ditemukan.' }, 404);

  if (!isAuthorizedForRequestActions(actor, reqItem)) {
    return c.json({ success: false, error: 'Anda tidak memiliki izin mengunggah hasil pekerjaan pada tiket ini.' }, 403);
  }

  const body = await c.req.json().catch(() => ({}));
  const nextAttachments = [...(reqItem.deliverableAttachments || [])];
  if (body.attachment) nextAttachments.push(body.attachment);
  if (Array.isArray(body.attachments)) nextAttachments.push(...body.attachments);

  const nextLinks = [...(reqItem.deliverableLinks || [])];
  if (body.link) nextLinks.push(body.link);

  const nowIso = new Date().toISOString();
  const uploadedNames = [
    ...(Array.isArray(body.attachments) ? body.attachments.map((a: any) => a.name) : []),
    ...(body.attachment ? [body.attachment.name] : []),
    ...(body.link ? [body.link.title] : []),
  ].join(', ');

  await c.env.DB.batch([
    c.env.DB.prepare(
      `UPDATE requests SET deliverable_attachments_json = ?, deliverable_links_json = ?, updated_at = ? WHERE id = ?`
    ).bind(JSON.stringify(nextAttachments), JSON.stringify(nextLinks), nowIso, requestId),
    c.env.DB.prepare(
      `INSERT INTO activity_logs (id, request_id, actor_id, actor_name, actor_role, action_type, field_changed, new_value, timestamp)
       VALUES (?, ?, ?, ?, ?, 'deliverable_upload', 'deliverables', ?, ?)`
    ).bind(
      `log-${Date.now()}-${randomHex(4)}`,
      requestId,
      actor.id,
      actor.fullName,
      actor.role,
      uploadedNames || 'Deliverable Files',
      nowIso
    ),
  ]);

  const updated = await loadSingleRequest(c.env.DB, requestId);
  return c.json({ success: true, request: updated });
});

// 9. Priority Reallocation
requestRoutes.post('/:id/priority', async (c) => {
  const actor = c.get('user')!;
  const requestId = c.req.param('id');
  const reqItem = await loadSingleRequest(c.env.DB, requestId);
  if (!reqItem) return c.json({ success: false, error: 'Permintaan tidak ditemukan.' }, 404);

  if (
    actor.role !== 'super_admin' &&
    !(actor.role === 'admin' && isUserWithinBrandScope(actor, reqItem.regionId, reqItem.brandId)) &&
    !(actor.role === 'requester' && reqItem.requesterId === actor.id && reqItem.status === 'todo')
  ) {
    return c.json({ success: false, error: 'Akses ditolak untuk mengubah prioritas permintaan ini.' }, 403);
  }

  const body = await c.req.json().catch(() => ({}));
  const newPriority = body.newPriority as RequestPriority;
  if (!['low', 'medium', 'high', 'urgent'].includes(newPriority)) {
    return c.json({ success: false, error: 'Prioritas baru tidak valid.' }, 400);
  }

  const row = await c.env.DB.prepare('SELECT quota_year FROM requests WHERE id = ?')
    .bind(requestId)
    .first<{ quota_year: number }>();

  const result = await reallocateQuotaAtomicallyD1({
    db: c.env.DB,
    brandId: reqItem.brandId,
    brandName: reqItem.brandName,
    oldPriority: reqItem.priority,
    newPriority,
    requestId: reqItem.id,
    ticketNumber: reqItem.ticketNumber,
    actor,
    reason: String(body.reason || 'Priority updated'),
    year: row?.quota_year,
  });

  if (!result.success) {
    return c.json({ success: false, error: result.error }, 409);
  }

  const updated = await loadSingleRequest(c.env.DB, requestId);
  return c.json({ success: true, request: updated });
});

// 10. Request Action Gateway Check (backward-compatible explicit endpoint)
requestRoutes.post('/:id/actions', async (c) => {
  const actor = c.get('user')!;
  const requestId = c.req.param('id');
  const reqItem = await loadSingleRequest(c.env.DB, requestId);
  if (!reqItem) return c.json({ success: false, error: 'Permintaan tidak ditemukan.' }, 404);

  const body = await c.req.json().catch(() => ({}));
  const action = String(body.action || '');
  const reason = typeof body.reason === 'string' ? body.reason.trim() : '';

  if (!['submit_review', 'put_on_hold', 'cancel_request', 'resume'].includes(action)) {
    return c.json({ success: false, error: 'Tindakan yang diminta tidak dikenal.' }, 400);
  }

  if (!isAuthorizedForRequestActions(actor, reqItem)) {
    await writeSecurityAuditLog(c.env.DB, {
      action: 'rbac_request_action_denied',
      actorId: actor.id,
      actorName: actor.fullName,
      actorRole: actor.role,
      targetId: requestId,
      targetType: 'request',
      summary: `Blocked unauthorized '${action}' attempt on request ${requestId}`,
    });
    return c.json(
      {
        success: false,
        error:
          'Akses Ditolak (403 Forbidden): Hanya Super Admin, Marcomm Admin dalam cakupan, atau PIC / Tim Eksekusi yang ditugaskan yang diizinkan.',
      },
      403
    );
  }

  if ((action === 'put_on_hold' || action === 'cancel_request') && reason.length < 5) {
    return c.json({ success: false, error: 'Alasan minimal 5 karakter wajib diisi.' }, 400);
  }

  return c.json({ success: true, authorized: true, action, requestId });
});

// 11. Authoritative Status Transition Endpoint
requestRoutes.post('/:id/status', async (c) => {
  const actor = c.get('user')!;
  const requestId = c.req.param('id');
  const reqItem = await loadSingleRequest(c.env.DB, requestId);
  if (!reqItem) return c.json({ success: false, error: 'Permintaan tidak ditemukan.' }, 404);

  const body = await c.req.json().catch(() => ({}));
  const newStatus = body.newStatus as RequestStatus;
  if (!['todo', 'in_progress', 'pending_review', 'revision', 'completed', 'on_hold', 'cancelled'].includes(newStatus)) {
    return c.json({ success: false, error: 'Status target tidak valid.' }, 400);
  }

  const check = canTransitionStatusServer(actor, reqItem, newStatus);
  if (!check.allowed) {
    return c.json({ success: false, error: check.reason || 'Transisi status ditolak.' }, 403);
  }

  const revisionNote = typeof body.revisionNote === 'string' ? body.revisionNote.trim() : '';
  const holdReason = typeof body.holdReason === 'string' ? body.holdReason.trim() : '';
  const cancelReason = typeof body.cancelReason === 'string' ? body.cancelReason.trim() : '';

  if (newStatus === 'revision' && revisionNote.length < 5) {
    return c.json({ success: false, error: 'Catatan revisi wajib diisi (minimal 5 karakter).' }, 400);
  }
  if (newStatus === 'on_hold' && holdReason.length < 5) {
    return c.json({ success: false, error: 'Alasan penundaan wajib diisi (minimal 5 karakter).' }, 400);
  }
  if (newStatus === 'cancelled' && cancelReason.length < 5) {
    return c.json({ success: false, error: 'Alasan pembatalan wajib diisi (minimal 5 karakter).' }, 400);
  }

  const oldStatus = reqItem.status;
  const nowIso = new Date().toISOString();
  let completedAt = reqItem.completedAt || null;
  let slaFulfilled = reqItem.slaFulfilled === undefined ? null : reqItem.slaFulfilled ? 1 : 0;

  if (newStatus === 'completed') {
    completedAt = nowIso;
    const todayWib = getWibTodayDateString();
    slaFulfilled = reqItem.committedDeadline ? (todayWib <= reqItem.committedDeadline ? 1 : 0) : 1;
  }

  const nextDeliverables = [...(reqItem.deliverableAttachments || [])];
  if (body.deliverableAttachment) nextDeliverables.push(body.deliverableAttachment);
  const nextLinks = [...(reqItem.deliverableLinks || [])];
  if (body.deliverableLink) nextLinks.push(body.deliverableLink);

  let actionType = 'status_change';
  let logReason: string | null = revisionNote || null;
  if (newStatus === 'revision') actionType = 'revision_requested';
  else if (newStatus === 'completed') actionType = 'approved';
  else if (newStatus === 'pending_review') actionType = 'review_submitted';
  else if (newStatus === 'on_hold') {
    actionType = 'on_hold';
    logReason = holdReason;
  } else if (oldStatus === 'on_hold') {
    actionType = 'resumed_from_hold';
  } else if (newStatus === 'cancelled') {
    actionType = 'cancelled';
    logReason = cancelReason;
  }

  const stmts = [
    c.env.DB.prepare(
      `UPDATE requests
       SET status = ?, completed_at = ?, sla_fulfilled = ?,
           hold_reason = ?, cancel_reason = ?,
           deliverable_attachments_json = ?, deliverable_links_json = ?,
           updated_at = ?
       WHERE id = ?`
    ).bind(
      newStatus,
      completedAt,
      slaFulfilled,
      newStatus === 'on_hold' ? holdReason : reqItem.holdReason || null,
      newStatus === 'cancelled' ? cancelReason : reqItem.cancelReason || null,
      JSON.stringify(nextDeliverables),
      JSON.stringify(nextLinks),
      nowIso,
      requestId
    ),
    c.env.DB.prepare(
      `INSERT INTO activity_logs (id, request_id, actor_id, actor_name, actor_role, action_type, field_changed, old_value, new_value, reason, timestamp)
       VALUES (?, ?, ?, ?, ?, ?, 'status', ?, ?, ?, ?)`
    ).bind(
      `log-${Date.now()}-${randomHex(4)}`,
      requestId,
      actor.id,
      actor.fullName,
      actor.role,
      actionType,
      oldStatus,
      newStatus,
      logReason,
      nowIso
    ),
  ];

  if (newStatus === 'revision' && revisionNote) {
    stmts.push(
      c.env.DB.prepare(
        `INSERT INTO comments (id, request_id, author_id, author_name, author_avatar, role, content, type, is_edited, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, 'revision_note', 0, ?)`
      ).bind(
        `cmt-${Date.now()}-${randomHex(4)}`,
        requestId,
        actor.id,
        actor.fullName,
        actor.avatarUrl || null,
        actor.role,
        revisionNote,
        nowIso
      )
    );
  }

  const addNotif = (userId: string, title: string, message: string, type: string) => {
    if (!userId || userId === actor.id) return;
    stmts.push(
      c.env.DB.prepare(
        `INSERT INTO notifications (id, user_id, request_id, ticket_number, title, message, type, is_read, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, 0, ?)`
      ).bind(`notif-${Date.now()}-${randomHex(4)}`, userId, requestId, reqItem.ticketNumber, title, message, type, nowIso)
    );
  };

  if (newStatus === 'revision' && reqItem.primaryAssigneeId) {
    addNotif(reqItem.primaryAssigneeId, 'Revisi Diminta', `${actor.fullName} meminta revisi untuk "${reqItem.title}".`, 'revision');
  } else if (newStatus === 'completed') {
    addNotif(reqItem.requesterId, 'Tugas Selesai', `Tugas "${reqItem.title}" telah disetujui dan ditandai Selesai Disetujui.`, 'completed');
  } else if (newStatus === 'pending_review') {
    const target = reqItem.reviewerId || reqItem.requesterId;
    addNotif(target, 'Pengajuan Review Baru', `${actor.fullName} mengirimkan hasil pekerjaan untuk direview.`, 'review_request');
  } else if (newStatus === 'on_hold') {
    if (reqItem.requesterId) addNotif(reqItem.requesterId, 'Permintaan Ditunda', `${actor.fullName} menunda permintaan "${reqItem.title}". Alasan: ${holdReason}`, 'on_hold');
    if (reqItem.primaryAssigneeId) addNotif(reqItem.primaryAssigneeId, 'Permintaan Ditunda', `${actor.fullName} menunda permintaan "${reqItem.title}". Alasan: ${holdReason}`, 'on_hold');
  } else if (newStatus === 'cancelled') {
    if (reqItem.requesterId) addNotif(reqItem.requesterId, 'Permintaan Dibatalkan', `${actor.fullName} membatalkan permintaan "${reqItem.title}". Alasan: ${cancelReason}`, 'cancelled');
    if (reqItem.primaryAssigneeId) addNotif(reqItem.primaryAssigneeId, 'Permintaan Dibatalkan', `${actor.fullName} membatalkan permintaan "${reqItem.title}". Alasan: ${cancelReason}`, 'cancelled');
  }

  await c.env.DB.batch(stmts);
  const updated = await loadSingleRequest(c.env.DB, requestId);
  return c.json({ success: true, request: updated });
});

// 12. Comments & Activity Logs
requestRoutes.get('/:id/comments', async (c) => {
  const actor = c.get('user')!;
  const requestId = c.req.param('id');
  const reqItem = await loadSingleRequest(c.env.DB, requestId);
  if (!reqItem) return c.json({ success: false, error: 'Permintaan tidak ditemukan.' }, 404);
  if (!canUserViewRequest(actor, reqItem)) return c.json({ success: false, error: 'Akses ditolak.' }, 403);

  const res = await c.env.DB.prepare(
    'SELECT * FROM comments WHERE request_id = ? ORDER BY created_at ASC'
  )
    .bind(requestId)
    .all<Record<string, unknown>>();
  return c.json({ success: true, comments: (res.results || []).map(rowToComment) });
});

requestRoutes.post('/:id/comments', async (c) => {
  const actor = c.get('user')!;
  const requestId = c.req.param('id');
  const reqItem = await loadSingleRequest(c.env.DB, requestId);
  if (!reqItem) return c.json({ success: false, error: 'Permintaan tidak ditemukan.' }, 404);
  if (!canUserViewRequest(actor, reqItem)) return c.json({ success: false, error: 'Akses ditolak.' }, 403);

  const body = await c.req.json().catch(() => ({}));
  const content = typeof body.content === 'string' ? body.content.trim() : '';
  const type = body.type === 'revision_note' ? 'revision_note' : 'general';
  if (!content) return c.json({ success: false, error: 'Komentar tidak boleh kosong.' }, 400);

  const id = `cmt-${Date.now()}-${randomHex(4)}`;
  const nowIso = new Date().toISOString();
  await c.env.DB.batch([
    c.env.DB.prepare(
      `INSERT INTO comments (id, request_id, author_id, author_name, author_avatar, role, content, type, is_edited, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, ?)`
    ).bind(id, requestId, actor.id, actor.fullName, actor.avatarUrl || null, actor.role, content, type, nowIso),
    c.env.DB.prepare('UPDATE requests SET updated_at = ? WHERE id = ?').bind(nowIso, requestId),
  ]);

  const row = await c.env.DB.prepare('SELECT * FROM comments WHERE id = ?').bind(id).first<Record<string, unknown>>();
  return c.json({ success: true, comment: row ? rowToComment(row) : null }, 201);
});

requestRoutes.get('/:id/logs', async (c) => {
  const actor = c.get('user')!;
  const requestId = c.req.param('id');
  const reqItem = await loadSingleRequest(c.env.DB, requestId);
  if (!reqItem) return c.json({ success: false, error: 'Permintaan tidak ditemukan.' }, 404);
  if (!canUserViewRequest(actor, reqItem)) return c.json({ success: false, error: 'Akses ditolak.' }, 403);

  const res = await c.env.DB.prepare(
    'SELECT * FROM activity_logs WHERE request_id = ? ORDER BY timestamp DESC'
  )
    .bind(requestId)
    .all<Record<string, unknown>>();
  return c.json({ success: true, logs: (res.results || []).map(rowToActivityLog) });
});

// 13. Sub Items (Level 2 Deliverables — Zero Priority Quota Consumption)
requestRoutes.post('/:id/sub-items', async (c) => {
  const actor = c.get('user')!;
  const parentRequestId = c.req.param('id');
  const parentReq = await loadSingleRequest(c.env.DB, parentRequestId);
  if (!parentReq) return c.json({ success: false, error: 'Permintaan induk tidak ditemukan.' }, 404);

  if (
    actor.role !== 'super_admin' &&
    !(actor.role === 'admin' && isUserWithinBrandScope(actor, parentReq.regionId, parentReq.brandId))
  ) {
    return c.json(
      { success: false, error: 'Hanya Super Admin dan Marcomm Admin dalam cakupan yang dapat membuat Sub Item.' },
      403
    );
  }

  const body = await c.req.json().catch(() => ({}));
  const title = typeof body.title === 'string' ? body.title.trim() : '';
  if (!title) return c.json({ success: false, error: 'Judul Sub Item wajib diisi.' }, 400);

  const subId = `sub-${Date.now()}-${randomHex(4)}`;
  const nowIso = new Date().toISOString();

  let ownerName = body.ownerName || null;
  let ownerRole = body.ownerRole || null;
  let ownerAvatar = body.ownerAvatar || null;
  if (body.ownerId) {
    const ownerRow = await c.env.DB.prepare('SELECT full_name, job_title, avatar_url FROM users WHERE id = ?')
      .bind(String(body.ownerId))
      .first<{ full_name: string; job_title: string; avatar_url: string | null }>();
    if (ownerRow) {
      ownerName = ownerRow.full_name;
      ownerRole = ownerRow.job_title;
      ownerAvatar = ownerRow.avatar_url;
    }
  }

  const stmts = [
    c.env.DB.prepare(
      `INSERT INTO sub_items
       (id, parent_request_id, title, description, owner_id, owner_name, owner_role, owner_avatar,
        status, priority, start_date, due_date, deliverable_url, deliverable_file_name, notes,
        created_by, created_by_id, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).bind(
      subId,
      parentRequestId,
      title,
      body.description || null,
      body.ownerId || null,
      ownerName,
      ownerRole,
      ownerAvatar,
      body.status || 'todo',
      body.priority || 'medium',
      body.startDate || null,
      body.dueDate || null,
      body.deliverableUrl || null,
      body.deliverableFileName || null,
      body.notes || null,
      actor.fullName,
      actor.id,
      nowIso,
      nowIso
    ),
    c.env.DB.prepare(
      `INSERT INTO activity_logs (id, request_id, actor_id, actor_name, actor_role, action_type, field_changed, new_value, reason, timestamp)
       VALUES (?, ?, ?, ?, ?, 'subitem_created', 'subItem', ?, ?, ?)`
    ).bind(
      `log-${Date.now()}-${randomHex(4)}`,
      parentRequestId,
      actor.id,
      actor.fullName,
      actor.role,
      title,
      `Sub Item dibuat: "${title}"${ownerName ? ` (Pelaksana: ${ownerName})` : ''}`,
      nowIso
    ),
    c.env.DB.prepare('UPDATE requests SET updated_at = ? WHERE id = ?').bind(nowIso, parentRequestId),
  ];

  if (body.ownerId && String(body.ownerId) !== actor.id) {
    stmts.push(
      c.env.DB.prepare(
        `INSERT INTO notifications (id, user_id, request_id, ticket_number, title, message, type, is_read, created_at)
         VALUES (?, ?, ?, ?, ?, ?, 'subitem_assigned', 0, ?)`
      ).bind(
        `notif-${Date.now()}-${randomHex(4)}`,
        String(body.ownerId),
        parentRequestId,
        parentReq.ticketNumber,
        'Penugasan Sub Item Baru',
        `${actor.fullName} menugaskan Anda pada Sub Item "${title}" di dalam ${parentReq.title}`,
        nowIso
      )
    );
  }

  await c.env.DB.batch(stmts);
  const subRow = await c.env.DB.prepare('SELECT * FROM sub_items WHERE id = ?').bind(subId).first<Record<string, unknown>>();
  return c.json({ success: true, subItem: subRow ? rowToSubItem(subRow) : null }, 201);
});

requestRoutes.put('/:id/sub-items/:subId', async (c) => {
  const actor = c.get('user')!;
  const parentRequestId = c.req.param('id');
  const subId = c.req.param('subId');
  const parentReq = await loadSingleRequest(c.env.DB, parentRequestId);
  if (!parentReq) return c.json({ success: false, error: 'Permintaan induk tidak ditemukan.' }, 404);

  if (
    actor.role !== 'super_admin' &&
    !(actor.role === 'admin' && isUserWithinBrandScope(actor, parentReq.regionId, parentReq.brandId))
  ) {
    return c.json({ success: false, error: 'Hanya Super Admin dan Marcomm Admin yang dapat mengubah Sub Item.' }, 403);
  }

  const subRow = await c.env.DB.prepare(
    'SELECT * FROM sub_items WHERE id = ? AND parent_request_id = ? AND deleted_at IS NULL'
  )
    .bind(subId, parentRequestId)
    .first<Record<string, unknown>>();
  if (!subRow) return c.json({ success: false, error: 'Sub Item tidak ditemukan.' }, 404);
  const existing = rowToSubItem(subRow);

  const body = await c.req.json().catch(() => ({}));
  const nowIso = new Date().toISOString();
  const nextTitle = typeof body.title === 'string' && body.title.trim() ? body.title.trim() : existing.title;

  await c.env.DB.batch([
    c.env.DB.prepare(
      `UPDATE sub_items
       SET title = ?, description = ?, owner_id = ?, owner_name = ?, owner_role = ?, owner_avatar = ?,
           status = ?, priority = ?, due_date = ?, deliverable_url = ?, deliverable_file_name = ?, notes = ?, updated_at = ?
       WHERE id = ?`
    ).bind(
      nextTitle,
      body.description !== undefined ? body.description : existing.description || null,
      body.ownerId !== undefined ? body.ownerId : existing.ownerId || null,
      body.ownerName !== undefined ? body.ownerName : existing.ownerName || null,
      body.ownerRole !== undefined ? body.ownerRole : existing.ownerRole || null,
      body.ownerAvatar !== undefined ? body.ownerAvatar : existing.ownerAvatar || null,
      body.status || existing.status,
      body.priority || existing.priority,
      body.dueDate !== undefined ? body.dueDate : existing.dueDate || null,
      body.deliverableUrl !== undefined ? body.deliverableUrl : existing.deliverableUrl || null,
      body.deliverableFileName !== undefined ? body.deliverableFileName : existing.deliverableFileName || null,
      body.notes !== undefined ? body.notes : existing.notes || null,
      nowIso,
      subId
    ),
    c.env.DB.prepare(
      `INSERT INTO activity_logs (id, request_id, actor_id, actor_name, actor_role, action_type, field_changed, old_value, new_value, reason, timestamp)
       VALUES (?, ?, ?, ?, ?, 'subitem_updated', 'subItem', ?, ?, ?, ?)`
    ).bind(
      `log-${Date.now()}-${randomHex(4)}`,
      parentRequestId,
      actor.id,
      actor.fullName,
      actor.role,
      existing.title,
      nextTitle,
      `Sub Item "${nextTitle}" diperbarui oleh Admin.`,
      nowIso
    ),
    c.env.DB.prepare('UPDATE requests SET updated_at = ? WHERE id = ?').bind(nowIso, parentRequestId),
  ]);

  const updatedRow = await c.env.DB.prepare('SELECT * FROM sub_items WHERE id = ?').bind(subId).first<Record<string, unknown>>();
  return c.json({ success: true, subItem: updatedRow ? rowToSubItem(updatedRow) : null });
});

requestRoutes.delete('/:id/sub-items/:subId', async (c) => {
  const actor = c.get('user')!;
  const parentRequestId = c.req.param('id');
  const subId = c.req.param('subId');
  const parentReq = await loadSingleRequest(c.env.DB, parentRequestId);
  if (!parentReq) return c.json({ success: false, error: 'Permintaan induk tidak ditemukan.' }, 404);

  if (
    actor.role !== 'super_admin' &&
    !(actor.role === 'admin' && isUserWithinBrandScope(actor, parentReq.regionId, parentReq.brandId))
  ) {
    return c.json({ success: false, error: 'Hanya Super Admin dan Marcomm Admin yang dapat menghapus Sub Item.' }, 403);
  }

  const subRow = await c.env.DB.prepare(
    'SELECT * FROM sub_items WHERE id = ? AND parent_request_id = ? AND deleted_at IS NULL'
  )
    .bind(subId, parentRequestId)
    .first<Record<string, unknown>>();
  if (!subRow) return c.json({ success: false, error: 'Sub Item tidak ditemukan.' }, 404);

  const body = await c.req.json().catch(() => ({}));
  const reason = typeof body.reason === 'string' ? body.reason.trim() : '';
  if (reason.length < 5) {
    return c.json({ success: false, error: 'Alasan penghapusan wajib diisi minimal 5 karakter.' }, 400);
  }

  const nowIso = new Date().toISOString();
  await c.env.DB.batch([
    c.env.DB.prepare(
      'UPDATE sub_items SET deleted_at = ?, deleted_reason = ?, deleted_by = ?, updated_at = ? WHERE id = ?'
    ).bind(nowIso, reason, actor.fullName, nowIso, subId),
    c.env.DB.prepare(
      `INSERT INTO activity_logs (id, request_id, actor_id, actor_name, actor_role, action_type, field_changed, old_value, reason, timestamp)
       VALUES (?, ?, ?, ?, ?, 'subitem_deleted', 'subItem', ?, ?, ?)`
    ).bind(
      `log-${Date.now()}-${randomHex(4)}`,
      parentRequestId,
      actor.id,
      actor.fullName,
      actor.role,
      String(subRow.title),
      `Sub Item "${String(subRow.title)}" dihapus: ${reason}`,
      nowIso
    ),
    c.env.DB.prepare('UPDATE requests SET updated_at = ? WHERE id = ?').bind(nowIso, parentRequestId),
  ]);

  return c.json({ success: true });
});

requestRoutes.post('/:id/sub-items/:subId/progress', async (c) => {
  const actor = c.get('user')!;
  const parentRequestId = c.req.param('id');
  const subId = c.req.param('subId');
  const parentReq = await loadSingleRequest(c.env.DB, parentRequestId);
  if (!parentReq) return c.json({ success: false, error: 'Permintaan induk tidak ditemukan.' }, 404);

  const subRow = await c.env.DB.prepare(
    'SELECT * FROM sub_items WHERE id = ? AND parent_request_id = ? AND deleted_at IS NULL'
  )
    .bind(subId, parentRequestId)
    .first<Record<string, unknown>>();
  if (!subRow) return c.json({ success: false, error: 'Sub Item tidak ditemukan.' }, 404);
  const existing = rowToSubItem(subRow);

  const isAdmin =
    actor.role === 'super_admin' ||
    (actor.role === 'admin' && isUserWithinBrandScope(actor, parentReq.regionId, parentReq.brandId));
  const isOwner = actor.role === 'team_member' && existing.ownerId === actor.id;

  if (!isAdmin && !isOwner) {
    return c.json(
      { success: false, error: 'Anda hanya dapat memperbarui progres Sub Item yang ditugaskan kepada Anda.' },
      403
    );
  }

  const body = await c.req.json().catch(() => ({}));
  const canApprove = isAdmin || (parentReq.reviewerId && parentReq.reviewerId === actor.id);
  if (body.status === 'completed' && !canApprove) {
    return c.json(
      { success: false, error: 'Persetujuan resmi diperlukan untuk menyelesaikan Sub Item.' },
      403
    );
  }

  const nextStatus = (body.status as RequestStatus) || existing.status;
  const nowIso = new Date().toISOString();

  const stmts = [
    c.env.DB.prepare(
      `UPDATE sub_items
       SET status = ?, deliverable_url = ?, deliverable_file_name = ?, notes = ?, updated_at = ?
       WHERE id = ?`
    ).bind(
      nextStatus,
      body.deliverableUrl !== undefined ? body.deliverableUrl : existing.deliverableUrl || null,
      body.deliverableFileName !== undefined ? body.deliverableFileName : existing.deliverableFileName || null,
      body.notes !== undefined ? body.notes : existing.notes || null,
      nowIso,
      subId
    ),
    c.env.DB.prepare(
      `INSERT INTO activity_logs (id, request_id, actor_id, actor_name, actor_role, action_type, field_changed, old_value, new_value, reason, timestamp)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).bind(
      `log-${Date.now()}-${randomHex(4)}`,
      parentRequestId,
      actor.id,
      actor.fullName,
      actor.role,
      nextStatus === 'completed' ? 'subitem_approved' : 'subitem_status_change',
      nextStatus === 'completed' ? 'subItem_approval' : 'subItem_status',
      existing.status,
      nextStatus,
      `Progres "${existing.title}" diperbarui menjadi ${nextStatus}.${body.notes ? ` Catatan: ${body.notes}` : ''}`,
      nowIso
    ),
    c.env.DB.prepare('UPDATE requests SET updated_at = ? WHERE id = ?').bind(nowIso, parentRequestId),
  ];

  if (nextStatus === 'pending_review' && parentReq.reviewerId && parentReq.reviewerId !== actor.id) {
    stmts.push(
      c.env.DB.prepare(
        `INSERT INTO notifications (id, user_id, request_id, ticket_number, title, message, type, is_read, created_at)
         VALUES (?, ?, ?, ?, ?, ?, 'subitem_review', 0, ?)`
      ).bind(
        `notif-${Date.now()}-${randomHex(4)}`,
        parentReq.reviewerId,
        parentRequestId,
        parentReq.ticketNumber,
        'Sub Item Siap Direview',
        `${actor.fullName} mengirimkan hasil pekerjaan untuk Sub Item "${existing.title}" di dalam ${parentReq.title}.`,
        nowIso
      )
    );
  }

  await c.env.DB.batch(stmts);
  const updatedRow = await c.env.DB.prepare('SELECT * FROM sub_items WHERE id = ?').bind(subId).first<Record<string, unknown>>();
  return c.json({ success: true, subItem: updatedRow ? rowToSubItem(updatedRow) : null });
});

requestRoutes.post('/:id/sub-items/:subId/approve', async (c) => {
  const actor = c.get('user')!;
  const parentRequestId = c.req.param('id');
  const subId = c.req.param('subId');
  const parentReq = await loadSingleRequest(c.env.DB, parentRequestId);
  if (!parentReq) return c.json({ success: false, error: 'Permintaan induk tidak ditemukan.' }, 404);

  const canApprove =
    actor.role === 'super_admin' ||
    (actor.role === 'admin' && isUserWithinBrandScope(actor, parentReq.regionId, parentReq.brandId)) ||
    (parentReq.reviewerId && parentReq.reviewerId === actor.id);
  if (!canApprove) {
    return c.json(
      { success: false, error: 'Hanya Super Admin, Admin dalam cakupan, atau Reviewer yang berwenang yang dapat menyetujui Sub Item.' },
      403
    );
  }

  const subRow = await c.env.DB.prepare(
    'SELECT * FROM sub_items WHERE id = ? AND parent_request_id = ? AND deleted_at IS NULL'
  )
    .bind(subId, parentRequestId)
    .first<Record<string, unknown>>();
  if (!subRow) return c.json({ success: false, error: 'Sub Item tidak ditemukan.' }, 404);
  const existing = rowToSubItem(subRow);

  const serverApprovedAt = new Date().toISOString();
  const nextHistory: SubItemApprovalEvent[] = [
    ...(existing.approvalHistory || []),
    {
      approvedAt: serverApprovedAt,
      approvedBy: actor.id,
      approvedByName: actor.fullName,
      approverRole: actor.role,
    },
  ];

  const stmts = [
    c.env.DB.prepare(
      `UPDATE sub_items
       SET status = 'completed', approval_date = ?, approved_at = ?, approved_by = ?, approved_by_name = ?,
           approval_requires_verification = 0, approval_history_json = ?, updated_at = ?
       WHERE id = ?`
    ).bind(
      serverApprovedAt,
      serverApprovedAt,
      actor.id,
      actor.fullName,
      JSON.stringify(nextHistory),
      serverApprovedAt,
      subId
    ),
    c.env.DB.prepare(
      `INSERT INTO activity_logs (id, request_id, actor_id, actor_name, actor_role, action_type, field_changed, old_value, new_value, reason, timestamp)
       VALUES (?, ?, ?, ?, ?, 'subitem_approved', 'subItem_approval', ?, 'completed', ?, ?)`
    ).bind(
      `log-${Date.now()}-${randomHex(4)}`,
      parentRequestId,
      actor.id,
      actor.fullName,
      actor.role,
      existing.status,
      `Sub Item "${existing.title}" disetujui oleh ${actor.fullName}.`,
      serverApprovedAt
    ),
    c.env.DB.prepare('UPDATE requests SET updated_at = ? WHERE id = ?').bind(serverApprovedAt, parentRequestId),
  ];

  if (existing.ownerId && existing.ownerId !== actor.id) {
    stmts.push(
      c.env.DB.prepare(
        `INSERT INTO notifications (id, user_id, request_id, ticket_number, title, message, type, is_read, created_at)
         VALUES (?, ?, ?, ?, ?, ?, 'subitem_approved', 0, ?)`
      ).bind(
        `notif-${Date.now()}-${randomHex(4)}`,
        existing.ownerId,
        parentRequestId,
        parentReq.ticketNumber,
        'Sub Item Disetujui!',
        `Pekerjaan Anda untuk Sub Item "${existing.title}" telah disetujui oleh ${actor.fullName}.`,
        serverApprovedAt
      )
    );
  }

  await c.env.DB.batch(stmts);
  await writeSecurityAuditLog(c.env.DB, {
    action: 'subitem_approved',
    actorId: actor.id,
    actorName: actor.fullName,
    actorRole: actor.role,
    targetId: subId,
    targetType: 'sub_item',
    summary: `Approved Sub Item '${existing.title}' (${subId}) under Request '${parentRequestId}'`,
  });

  return c.json({
    success: true,
    approvedAt: serverApprovedAt,
    approvedBy: actor.id,
    approvedByName: actor.fullName,
    approverRole: actor.role,
  });
});

requestRoutes.post('/:id/sub-items/:subId/reconcile-approval', async (c) => {
  const actor = c.get('user')!;
  const parentRequestId = c.req.param('id');
  const subId = c.req.param('subId');
  if (actor.role !== 'super_admin' && actor.role !== 'admin') {
    return c.json(
      { success: false, error: 'Hanya Super Admin atau Marcomm Admin yang dapat merekonsiliasi tanggal persetujuan.' },
      403
    );
  }

  const subRow = await c.env.DB.prepare(
    'SELECT * FROM sub_items WHERE id = ? AND parent_request_id = ? AND deleted_at IS NULL'
  )
    .bind(subId, parentRequestId)
    .first<Record<string, unknown>>();
  if (!subRow) return c.json({ success: false, error: 'Sub Item tidak ditemukan.' }, 404);
  const existing = rowToSubItem(subRow);

  const body = await c.req.json().catch(() => ({}));
  const verifiedApprovalDate = typeof body.verifiedApprovalDate === 'string' ? body.verifiedApprovalDate.trim() : '';
  const justification = typeof body.justification === 'string' ? body.justification.trim() : '';
  if (!verifiedApprovalDate || justification.length < 5) {
    return c.json(
      { success: false, error: 'Tanggal persetujuan terverifikasi dan alasan justifikasi (min 5 karakter) wajib diisi.' },
      400
    );
  }

  const nowIso = new Date().toISOString();
  const nextHistory: SubItemApprovalEvent[] = [
    ...(existing.approvalHistory || []),
    {
      approvedAt: verifiedApprovalDate,
      approvedBy: actor.id,
      approvedByName: actor.fullName,
      approverRole: actor.role,
      notes: `Direkonsiliasi: ${justification}`,
      reconciled: true,
    },
  ];

  await c.env.DB.batch([
    c.env.DB.prepare(
      `UPDATE sub_items
       SET approval_date = ?, approved_at = ?, approved_by = ?, approved_by_name = ?,
           approval_requires_verification = 0, approval_history_json = ?, updated_at = ?
       WHERE id = ?`
    ).bind(
      verifiedApprovalDate,
      verifiedApprovalDate,
      actor.id,
      actor.fullName,
      JSON.stringify(nextHistory),
      nowIso,
      subId
    ),
    c.env.DB.prepare(
      `INSERT INTO activity_logs (id, request_id, actor_id, actor_name, actor_role, action_type, field_changed, old_value, new_value, reason, timestamp)
       VALUES (?, ?, ?, ?, ?, 'subitem_approved', 'subItem_approval_reconciliation', 'unverified', ?, ?, ?)`
    ).bind(
      `log-${Date.now()}-${randomHex(4)}`,
      parentRequestId,
      actor.id,
      actor.fullName,
      actor.role,
      verifiedApprovalDate,
      `Tanggal persetujuan direkonsiliasi oleh ${actor.fullName}: ${justification}`,
      nowIso
    ),
    c.env.DB.prepare('UPDATE requests SET updated_at = ? WHERE id = ?').bind(nowIso, parentRequestId),
  ]);

  await writeSecurityAuditLog(c.env.DB, {
    action: 'subitem_approval_reconciled',
    actorId: actor.id,
    actorName: actor.fullName,
    actorRole: actor.role,
    targetId: subId,
    targetType: 'sub_item',
    summary: `Reconciled historical approval date for Sub Item '${subId}' to ${verifiedApprovalDate}: ${justification}`,
  });

  return c.json({
    success: true,
    reconciledAt: nowIso,
    verifiedApprovalDate,
    approvedBy: actor.id,
    approvedByName: actor.fullName,
  });
});
