import { Hono } from 'hono';
import {
  clearD1RateLimit,
  checkD1RateLimit,
  clearSessionCookie,
  createSessionInD1,
  recordD1FailedAttempt,
  requireAuth,
  requireRole,
  revokeOtherUserSessions,
  revokeUserSessions,
  setSessionCookie,
  writeSecurityAuditLog,
} from '../middleware/auth';
import {
  hashPassword,
  isLegacyHashFormat,
  randomHex,
  sha256Hex,
  timingSafeEqualHex,
  validatePasswordStrength,
  verifyPassword,
} from '../crypto';
import { rowToUser, sanitizeUser, WorkerAppEnv } from '../types';

export const authRoutes = new Hono<WorkerAppEnv>();

// 1. Login
authRoutes.post('/login', async (c) => {
  const body = await c.req.json().catch(() => ({}));
  const email = typeof body.email === 'string' ? body.email.trim().toLowerCase() : '';
  const password = typeof body.password === 'string' ? body.password : '';
  const clientIp = c.get('clientIp');

  if (!email || !password) {
    return c.json(
      {
        success: false,
        error: !email ? 'Silakan masukkan alamat email.' : 'Silakan masukkan password.',
      },
      400
    );
  }

  const rateKeys = [`ip:${clientIp}`, `email:${email}`];
  const rateLimit = await checkD1RateLimit(c.env.DB, rateKeys);
  if (!rateLimit.allowed) {
    return c.json(
      {
        success: false,
        error: `Terlalu banyak percobaan gagal. Silakan tunggu ${rateLimit.remainingSecs} detik sebelum mencoba lagi.`,
      },
      429
    );
  }

  const row = await c.env.DB.prepare('SELECT * FROM users WHERE lower(email) = lower(?)')
    .bind(email)
    .first<Record<string, unknown>>();

  if (!row) {
    await recordD1FailedAttempt(c.env.DB, rateKeys);
    await writeSecurityAuditLog(c.env.DB, {
      action: 'auth_login_failed',
      actorId: 'anonymous',
      actorName: email,
      actorRole: 'guest',
      summary: `Failed login attempt for unknown email: ${email}`,
      details: { ip: clientIp },
    });
    return c.json({ success: false, error: 'Email atau password tidak sesuai.' }, 401);
  }

  const user = rowToUser(row);
  if (!user.isActive) {
    await writeSecurityAuditLog(c.env.DB, {
      action: 'auth_login_blocked_inactive',
      actorId: user.id,
      actorName: user.fullName,
      actorRole: user.role,
      summary: `Login blocked for suspended account: ${user.email}`,
      details: { ip: clientIp },
    });
    return c.json(
      { success: false, error: 'Akun Anda tidak aktif. Silakan hubungi administrator.' },
      403
    );
  }

  const verified = await verifyPassword(password, user.passwordHash, c.env.PASSWORD_PEPPER);
  if (!verified) {
    await recordD1FailedAttempt(c.env.DB, rateKeys);
    await writeSecurityAuditLog(c.env.DB, {
      action: 'auth_login_failed',
      actorId: user.id,
      actorName: user.fullName,
      actorRole: user.role,
      summary: `Invalid password attempt for account: ${user.email}`,
      details: { ip: clientIp },
    });
    return c.json({ success: false, error: 'Email atau password tidak sesuai.' }, 401);
  }

  await clearD1RateLimit(c.env.DB, rateKeys);

  // Transparently upgrade legacy scrypt hash or unpeppered hash to PBKDF2-SHA256 + Pepper on login
  const nowIso = new Date().toISOString();
  const shouldRehash =
    isLegacyHashFormat(user.passwordHash) ||
    (Boolean(c.env.PASSWORD_PEPPER) && !user.passwordHash.includes('$1$'));
  const upgradedHash = shouldRehash
    ? await hashPassword(password, c.env.PASSWORD_PEPPER)
    : user.passwordHash;

  await c.env.DB.prepare(
    'UPDATE users SET last_login_at = ?, password_hash = ?, updated_at = ? WHERE id = ?'
  )
    .bind(nowIso, upgradedHash, nowIso, user.id)
    .run();

  user.lastLoginAt = nowIso;
  const previousSession = c.get('session');
  const { session, csrfToken } = await createSessionInD1(c, user, previousSession?.sessionId);
  setSessionCookie(c, session.sessionId);

  await writeSecurityAuditLog(c.env.DB, {
    action: 'auth_login_success',
    actorId: user.id,
    actorName: user.fullName,
    actorRole: user.role,
    summary: `User logged in successfully: ${user.fullName} (${user.role})`,
    details: { ip: clientIp, sessionId: session.sessionId },
  });

  return c.json({
    success: true,
    user: sanitizeUser(user),
    csrfToken,
  });
});

// 2. Current session check
authRoutes.get('/me', (c) => {
  const user = c.get('user');
  const session = c.get('session');
  const csrfToken = c.get('csrfToken');
  if (user && session && csrfToken) {
    return c.json({
      success: true,
      authenticated: true,
      user: sanitizeUser(user),
      csrfToken,
    });
  }
  return c.json({ success: true, authenticated: false });
});

// 3. Logout (ensure pending audit metadata & session termination persist to D1 before clearing cookie)
authRoutes.post('/logout', async (c) => {
  const session = c.get('session');
  const user = c.get('user');
  const body = await c.req.json().catch(() => ({}));
  const savedAt = new Date().toISOString();
  if (session) {
    await writeSecurityAuditLog(c.env.DB, {
      action: 'auth_logout',
      actorId: session.userId,
      actorName: user?.fullName || session.email,
      actorRole: session.role,
      summary: `User logged out: ${user?.fullName || session.email}`,
      details: {
        flushedClientChanges: Boolean(body?.flushedClientChanges),
        savedAt,
      },
    });
    await c.env.DB.prepare('DELETE FROM sessions WHERE session_id = ?')
      .bind(session.sessionId)
      .run();
  }
  clearSessionCookie(c);
  return c.json({
    success: true,
    savedAt,
    message: 'Sesi dan perubahan berhasil disimpan ke database.',
  });
});

// 4. Forgot password (anti-enumeration generic response)
authRoutes.post('/forgot-password', async (c) => {
  const body = await c.req.json().catch(() => ({}));
  const email = typeof body.email === 'string' ? body.email.trim().toLowerCase() : '';
  if (!email) {
    return c.json({ success: false, error: 'Silakan masukkan alamat email yang valid.' }, 400);
  }

  const row = await c.env.DB.prepare('SELECT * FROM users WHERE lower(email) = lower(?)')
    .bind(email)
    .first<Record<string, unknown>>();

  if (row && Boolean(Number(row.is_active))) {
    const user = rowToUser(row);
    const rawToken = randomHex(32);
    const tokenHash = await sha256Hex(rawToken);
    const expiresAt = Date.now() + 15 * 60 * 1000;

    await c.env.DB.prepare(
      'UPDATE users SET recovery_token_hash = ?, recovery_expires_at = ?, updated_at = ? WHERE id = ?'
    )
      .bind(tokenHash, expiresAt, new Date().toISOString(), user.id)
      .run();

    await writeSecurityAuditLog(c.env.DB, {
      action: 'auth_password_reset_requested',
      actorId: user.id,
      actorName: user.fullName,
      actorRole: user.role,
      summary: `Password reset requested for: ${user.email}`,
    });
  }

  return c.json({
    success: true,
    message:
      'Jika email terdaftar pada sistem MARCOMM TASK, permintaan pemulihan telah dicatat. Untuk lingkungan portal korporat PT Lyman Devindo, silakan hubungi Administrator (admin.marcomm@lyman.co.id) untuk verifikasi identitas dan penyelesaian reset password.',
  });
});

// 5. Reset password with verified token
authRoutes.post('/reset-password', async (c) => {
  const body = await c.req.json().catch(() => ({}));
  const email = typeof body.email === 'string' ? body.email.trim().toLowerCase() : '';
  const token = typeof body.token === 'string' ? body.token.trim() : '';
  const newPassword = typeof body.newPassword === 'string' ? body.newPassword : '';

  if (!email || !token || !newPassword) {
    return c.json({ success: false, error: 'Data pemulihan tidak lengkap.' }, 400);
  }

  const strength = validatePasswordStrength(newPassword);
  if (!strength.valid) {
    return c.json({ success: false, error: strength.error }, 400);
  }

  const row = await c.env.DB.prepare('SELECT * FROM users WHERE lower(email) = lower(?)')
    .bind(email)
    .first<Record<string, unknown>>();

  if (!row || !row.recovery_token_hash || !row.recovery_expires_at) {
    return c.json({ success: false, error: 'Token pemulihan tidak valid atau telah kadaluarsa.' }, 400);
  }

  const user = rowToUser(row);
  if (Date.now() > (user.recoveryExpiresAt || 0)) {
    await c.env.DB.prepare(
      'UPDATE users SET recovery_token_hash = NULL, recovery_expires_at = NULL WHERE id = ?'
    )
      .bind(user.id)
      .run();
    return c.json(
      { success: false, error: 'Token pemulihan telah kadaluarsa. Silakan ajukan kembali.' },
      400
    );
  }

  const incomingHash = await sha256Hex(token);
  if (!timingSafeEqualHex(incomingHash, user.recoveryTokenHash || '')) {
    return c.json({ success: false, error: 'Token pemulihan tidak valid.' }, 400);
  }

  const newHash = await hashPassword(newPassword, c.env.PASSWORD_PEPPER);
  const nowIso = new Date().toISOString();

  await c.env.DB.batch([
    c.env.DB.prepare(
      `UPDATE users SET password_hash = ?, recovery_token_hash = NULL, recovery_expires_at = NULL,
       must_change_password = 0, password_changed_at = ?, updated_at = ? WHERE id = ?`
    ).bind(newHash, nowIso, nowIso, user.id),
    c.env.DB.prepare('DELETE FROM sessions WHERE user_id = ?').bind(user.id),
  ]);

  await writeSecurityAuditLog(c.env.DB, {
    action: 'auth_password_reset_completed',
    actorId: user.id,
    actorName: user.fullName,
    actorRole: user.role,
    summary: `Password reset completed for: ${user.email}`,
  });

  return c.json({
    success: true,
    message: 'Password berhasil diperbarui. Silakan login dengan password baru Anda.',
  });
});

// 6. Change my password (rotates current session + revokes all other sessions)
authRoutes.post('/change-password', requireAuth, async (c) => {
  const user = c.get('user')!;
  const currentSession = c.get('session')!;
  const body = await c.req.json().catch(() => ({}));
  const currentPassword = typeof body.currentPassword === 'string' ? body.currentPassword : '';
  const newPassword = typeof body.newPassword === 'string' ? body.newPassword : '';
  const confirmNewPassword = typeof body.confirmNewPassword === 'string' ? body.confirmNewPassword : '';

  if (!currentPassword || !newPassword || !confirmNewPassword) {
    return c.json(
      { success: false, error: 'Semua kolom password (lama, baru, konfirmasi) wajib diisi.' },
      400
    );
  }

  if (newPassword !== confirmNewPassword) {
    return c.json({ success: false, error: 'Konfirmasi password baru tidak cocok.' }, 400);
  }

  const strength = validatePasswordStrength(newPassword);
  if (!strength.valid) {
    return c.json({ success: false, error: strength.error }, 400);
  }

  const ok = await verifyPassword(currentPassword, user.passwordHash, c.env.PASSWORD_PEPPER);
  if (!ok) {
    await writeSecurityAuditLog(c.env.DB, {
      action: 'auth_password_change_failed',
      actorId: user.id,
      actorName: user.fullName,
      actorRole: user.role,
      summary: `Failed self-service password change: Incorrect current password for ${user.email}`,
    });
    return c.json({ success: false, error: 'Password saat ini tidak sesuai.' }, 401);
  }

  if (currentPassword === newPassword) {
    return c.json(
      { success: false, error: 'Password baru tidak boleh sama dengan password saat ini.' },
      400
    );
  }

  const newHash = await hashPassword(newPassword, c.env.PASSWORD_PEPPER);
  const nowIso = new Date().toISOString();

  await c.env.DB.prepare(
    `UPDATE users SET password_hash = ?, must_change_password = 0, password_changed_at = ?, updated_at = ? WHERE id = ?`
  )
    .bind(newHash, nowIso, nowIso, user.id)
    .run();

  user.mustChangePassword = false;

  // Rotate current session ID & CSRF secret and revoke all other sessions
  const { session: rotated, csrfToken } = await createSessionInD1(
    c,
    user,
    currentSession.sessionId
  );
  await revokeOtherUserSessions(c.env.DB, user.id, rotated.sessionId);
  setSessionCookie(c, rotated.sessionId);

  await writeSecurityAuditLog(c.env.DB, {
    action: 'auth_password_change_success',
    actorId: user.id,
    actorName: user.fullName,
    actorRole: user.role,
    summary: `Password changed & session rotated by user: ${user.email}`,
  });

  return c.json({
    success: true,
    message: 'Password berhasil diperbarui.',
    user: sanitizeUser(user),
    csrfToken,
  });
});

// 7. Super Admin reset password for another user (requires Super Admin password reauthentication)
authRoutes.post('/admin/reset-password', requireRole(['super_admin']), async (c) => {
  const adminUser = c.get('user')!;
  const body = await c.req.json().catch(() => ({}));
  const { targetUserId, newPassword, confirmNewPassword, mustChangePassword, adminPassword } = body;

  if (!targetUserId || !newPassword || !confirmNewPassword || !adminPassword) {
    return c.json(
      {
        success: false,
        error:
          'Data reset password tidak lengkap (ID target, password baru, konfirmasi, dan verifikasi password admin wajib diisi).',
      },
      400
    );
  }

  if (newPassword !== confirmNewPassword) {
    return c.json({ success: false, error: 'Konfirmasi password baru tidak cocok.' }, 400);
  }

  const reauthOk = await verifyPassword(
    String(adminPassword),
    adminUser.passwordHash,
    c.env.PASSWORD_PEPPER
  );
  if (!reauthOk) {
    await writeSecurityAuditLog(c.env.DB, {
      action: 'auth_admin_reset_reauth_failed',
      actorId: adminUser.id,
      actorName: adminUser.fullName,
      actorRole: adminUser.role,
      summary: `Failed Super Admin re-authentication during reset attempt for user ID: ${targetUserId}`,
    });
    return c.json(
      {
        success: false,
        error: 'Verifikasi password Super Admin tidak valid. Tindakan dibatalkan demi keamanan.',
      },
      401
    );
  }

  const targetRow = await c.env.DB.prepare('SELECT * FROM users WHERE id = ?')
    .bind(String(targetUserId))
    .first<Record<string, unknown>>();
  if (!targetRow) {
    return c.json({ success: false, error: 'Pengguna target tidak ditemukan.' }, 404);
  }
  const targetUser = rowToUser(targetRow);

  const strength = validatePasswordStrength(String(newPassword));
  if (!strength.valid) {
    return c.json({ success: false, error: strength.error }, 400);
  }

  const newHash = await hashPassword(String(newPassword), c.env.PASSWORD_PEPPER);
  const nowIso = new Date().toISOString();
  const forceChange = Boolean(mustChangePassword);

  await c.env.DB.prepare(
    `UPDATE users SET password_hash = ?, must_change_password = ?, password_changed_at = ?, updated_at = ? WHERE id = ?`
  )
    .bind(newHash, forceChange ? 1 : 0, nowIso, nowIso, targetUser.id)
    .run();

  await revokeUserSessions(c.env.DB, targetUser.id);

  await writeSecurityAuditLog(c.env.DB, {
    action: 'auth_admin_password_reset',
    actorId: adminUser.id,
    actorName: adminUser.fullName,
    actorRole: adminUser.role,
    targetId: targetUser.id,
    targetType: 'user',
    summary: `Super Admin reset password for ${targetUser.fullName} (${targetUser.email}). Force Change on Next Login: ${forceChange}`,
  });

  return c.json({
    success: true,
    message: `Password untuk akun ${targetUser.fullName} (${targetUser.email}) berhasil direset.`,
  });
});

// 8. Verified One-Time First Super Admin Recovery / Bootstrap (guarded by BOOTSTRAP_ADMIN_TOKEN Secret)
authRoutes.post('/bootstrap-recovery', async (c) => {
  const secretToken = c.env.BOOTSTRAP_ADMIN_TOKEN;
  if (!secretToken || secretToken.length < 16) {
    return c.json(
      { success: false, error: 'Bootstrap recovery is disabled (BOOTSTRAP_ADMIN_TOKEN not configured).' },
      403
    );
  }

  const existingLock = await c.env.DB.prepare(
    "SELECT value FROM system_bootstrap_state WHERE key = 'super_admin_recovered_at'"
  ).first<{ value: string }>();
  if (existingLock) {
    return c.json(
      { success: false, error: 'Bootstrap recovery has already been consumed and locked.' },
      403
    );
  }

  const body = await c.req.json().catch(() => ({}));
  const providedToken = typeof body.bootstrapToken === 'string' ? body.bootstrapToken : '';
  const email = typeof body.email === 'string' ? body.email.trim().toLowerCase() : '';
  const newPassword = typeof body.newPassword === 'string' ? body.newPassword : '';

  const providedHash = await sha256Hex(providedToken);
  const expectedHash = await sha256Hex(secretToken);
  if (!timingSafeEqualHex(providedHash, expectedHash)) {
    await writeSecurityAuditLog(c.env.DB, {
      action: 'auth_bootstrap_recovery_denied',
      actorId: 'anonymous',
      actorName: email || 'unknown',
      actorRole: 'guest',
      summary: 'Invalid BOOTSTRAP_ADMIN_TOKEN provided to /api/auth/bootstrap-recovery',
      details: { ip: c.get('clientIp') },
    });
    return c.json({ success: false, error: 'Invalid bootstrap verification token.' }, 403);
  }

  if (!email || !newPassword) {
    return c.json({ success: false, error: 'Email Super Admin dan password baru wajib diisi.' }, 400);
  }

  const strength = validatePasswordStrength(newPassword);
  if (!strength.valid) {
    return c.json({ success: false, error: strength.error }, 400);
  }

  const row = await c.env.DB.prepare(
    "SELECT * FROM users WHERE lower(email) = lower(?) AND role = 'super_admin'"
  )
    .bind(email)
    .first<Record<string, unknown>>();
  if (!row) {
    return c.json({ success: false, error: 'Super Admin account not found.' }, 404);
  }

  const user = rowToUser(row);
  const newHash = await hashPassword(newPassword, c.env.PASSWORD_PEPPER);
  const nowIso = new Date().toISOString();

  await c.env.DB.batch([
    c.env.DB.prepare(
      `UPDATE users SET password_hash = ?, must_change_password = 0, password_changed_at = ?, updated_at = ? WHERE id = ?`
    ).bind(newHash, nowIso, nowIso, user.id),
    c.env.DB.prepare('DELETE FROM sessions WHERE user_id = ?').bind(user.id),
    c.env.DB.prepare(
      `INSERT INTO system_bootstrap_state (key, value, updated_at) VALUES ('super_admin_recovered_at', ?, ?)`
    ).bind(nowIso, nowIso),
  ]);

  await writeSecurityAuditLog(c.env.DB, {
    action: 'auth_bootstrap_recovery_completed',
    actorId: user.id,
    actorName: user.fullName,
    actorRole: user.role,
    summary: `One-time Super Admin recovery completed and locked for ${user.email}`,
    details: { ip: c.get('clientIp') },
  });

  return c.json({
    success: true,
    message: 'Super Admin recovery succeeded and one-time bootstrap token is now locked.',
  });
});

// 9. Security Audit Logs (Super Admin & Marcomm Admin)
authRoutes.get('/audit-logs', requireRole(['super_admin', 'admin']), async (c) => {
  const result = await c.env.DB.prepare(
    'SELECT * FROM security_audit_logs ORDER BY timestamp DESC LIMIT 500'
  ).all<Record<string, unknown>>();

  const data = (result.results || []).map((r) => ({
    id: String(r.id),
    timestamp: String(r.timestamp),
    action: String(r.action),
    actorId: String(r.actor_id),
    actorName: String(r.actor_name),
    actorRole: String(r.actor_role),
    targetId: r.target_id ? String(r.target_id) : undefined,
    targetType: r.target_type ? String(r.target_type) : undefined,
    summary: String(r.summary),
    details: r.details_json ? JSON.parse(String(r.details_json)) : undefined,
  }));

  return c.json({ success: true, data });
});
