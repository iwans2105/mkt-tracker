import { Hono } from 'hono';
import { requireAuth, requireRole, writeSecurityAuditLog } from '../middleware/auth';
import {
  rowToBrand,
  rowToCategory,
  rowToDepartment,
  rowToRegion,
  rowToTeam,
  rowToUnit,
  WorkerAppEnv,
} from '../types';

export const masterDataRoutes = new Hono<WorkerAppEnv>();

// Fetch all organizational master data
masterDataRoutes.get('/', requireAuth, async (c) => {
  const [regionsRes, brandsRes, unitsRes, deptsRes, catsRes, teamsRes] = await Promise.all([
    c.env.DB.prepare('SELECT * FROM regions WHERE is_active = 1 ORDER BY name ASC').all<Record<string, unknown>>(),
    c.env.DB.prepare('SELECT * FROM brands WHERE is_active = 1 ORDER BY name ASC').all<Record<string, unknown>>(),
    c.env.DB.prepare('SELECT * FROM units WHERE is_active = 1 ORDER BY name ASC').all<Record<string, unknown>>(),
    c.env.DB.prepare('SELECT * FROM departments WHERE is_active = 1 ORDER BY name ASC').all<Record<string, unknown>>(),
    c.env.DB.prepare('SELECT * FROM categories WHERE is_active = 1 ORDER BY name ASC').all<Record<string, unknown>>(),
    c.env.DB.prepare('SELECT * FROM teams WHERE is_active = 1 ORDER BY name ASC').all<Record<string, unknown>>(),
  ]);

  return c.json({
    success: true,
    data: {
      regions: (regionsRes.results || []).map(rowToRegion),
      brands: (brandsRes.results || []).map(rowToBrand),
      units: (unitsRes.results || []).map(rowToUnit),
      departments: (deptsRes.results || []).map(rowToDepartment),
      categories: (catsRes.results || []).map(rowToCategory),
      teams: (teamsRes.results || []).map(rowToTeam),
    },
  });
});

// Regions
masterDataRoutes.post('/regions', requireRole(['super_admin', 'admin']), async (c) => {
  const body = await c.req.json().catch(() => ({}));
  const name = String(body.name || '').replace(/^Wilayah\s+/i, '').trim();
  const code = String(body.code || 'REG').trim().toUpperCase();
  if (!name) return c.json({ success: false, error: 'Region name is required.' }, 400);

  const id = body.id ? String(body.id) : `reg-${Date.now()}`;
  const now = new Date().toISOString();
  await c.env.DB.prepare(
    'INSERT INTO regions (id, name, code, is_active, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?)'
  )
    .bind(id, name, code, body.isActive === false ? 0 : 1, now, now)
    .run();
  return c.json({ success: true, item: { id, name, code, isActive: body.isActive !== false } }, 201);
});

masterDataRoutes.put('/regions/:id', requireRole(['super_admin', 'admin']), async (c) => {
  const id = c.req.param('id');
  const body = await c.req.json().catch(() => ({}));
  const name = String(body.name || '').replace(/^Wilayah\s+/i, '').trim();
  const code = String(body.code || 'REG').trim().toUpperCase();
  const isActive = body.isActive !== false ? 1 : 0;
  await c.env.DB.prepare('UPDATE regions SET name = ?, code = ?, is_active = ?, updated_at = ? WHERE id = ?')
    .bind(name, code, isActive, new Date().toISOString(), id)
    .run();
  return c.json({ success: true, item: { id, name, code, isActive: Boolean(isActive) } });
});

masterDataRoutes.delete('/regions/:id', requireRole(['super_admin', 'admin']), async (c) => {
  const id = c.req.param('id');
  const ref = await c.env.DB.prepare('SELECT id FROM requests WHERE region_id = ? LIMIT 1').bind(id).first();
  if (ref) {
    await c.env.DB.prepare('UPDATE regions SET is_active = 0, updated_at = ? WHERE id = ?')
      .bind(new Date().toISOString(), id)
      .run();
  } else {
    await c.env.DB.prepare('DELETE FROM regions WHERE id = ?').bind(id).run();
  }
  return c.json({ success: true });
});

// Brands
masterDataRoutes.post('/brands', requireRole(['super_admin', 'admin']), async (c) => {
  const body = await c.req.json().catch(() => ({}));
  const name = String(body.name || '').trim();
  const regionId = String(body.regionId || '').trim();
  const code = String(body.code || 'BRD').trim().toUpperCase();
  if (!name || !regionId) return c.json({ success: false, error: 'Brand name and regionId are required.' }, 400);

  const id = body.id ? String(body.id) : `brand-${Date.now()}`;
  const now = new Date().toISOString();
  await c.env.DB.prepare(
    'INSERT INTO brands (id, region_id, name, code, is_active, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)'
  )
    .bind(id, regionId, name, code, body.isActive === false ? 0 : 1, now, now)
    .run();
  return c.json({ success: true, item: { id, regionId, name, code, isActive: body.isActive !== false } }, 201);
});

masterDataRoutes.put('/brands/:id', requireRole(['super_admin', 'admin']), async (c) => {
  const id = c.req.param('id');
  const body = await c.req.json().catch(() => ({}));
  const name = String(body.name || '').trim();
  const regionId = String(body.regionId || '').trim();
  const code = String(body.code || 'BRD').trim().toUpperCase();
  const isActive = body.isActive !== false ? 1 : 0;
  await c.env.DB.prepare(
    'UPDATE brands SET region_id = ?, name = ?, code = ?, is_active = ?, updated_at = ? WHERE id = ?'
  )
    .bind(regionId, name, code, isActive, new Date().toISOString(), id)
    .run();
  return c.json({ success: true, item: { id, regionId, name, code, isActive: Boolean(isActive) } });
});

masterDataRoutes.delete('/brands/:id', requireRole(['super_admin', 'admin']), async (c) => {
  const id = c.req.param('id');
  const ref = await c.env.DB.prepare('SELECT id FROM requests WHERE brand_id = ? LIMIT 1').bind(id).first();
  const pol = await c.env.DB.prepare('SELECT id FROM priority_quota_policies WHERE brand_id = ? LIMIT 1').bind(id).first();
  if (ref || pol) {
    await c.env.DB.prepare('UPDATE brands SET is_active = 0, updated_at = ? WHERE id = ?')
      .bind(new Date().toISOString(), id)
      .run();
  } else {
    await c.env.DB.prepare('DELETE FROM brands WHERE id = ?').bind(id).run();
  }
  return c.json({ success: true });
});

// Units
masterDataRoutes.post('/units', requireRole(['super_admin', 'admin']), async (c) => {
  const body = await c.req.json().catch(() => ({}));
  const name = String(body.name || '').trim();
  const brandId = String(body.brandId || '').trim();
  const code = String(body.code || 'UNIT').trim().toUpperCase();
  if (!name || !brandId) return c.json({ success: false, error: 'Unit name and brandId are required.' }, 400);

  const id = body.id ? String(body.id) : `unit-${Date.now()}`;
  const now = new Date().toISOString();
  await c.env.DB.prepare(
    'INSERT INTO units (id, brand_id, name, code, is_active, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)'
  )
    .bind(id, brandId, name, code, body.isActive === false ? 0 : 1, now, now)
    .run();
  return c.json({ success: true, item: { id, brandId, name, code, isActive: body.isActive !== false } }, 201);
});

masterDataRoutes.put('/units/:id', requireRole(['super_admin', 'admin']), async (c) => {
  const id = c.req.param('id');
  const body = await c.req.json().catch(() => ({}));
  const name = String(body.name || '').trim();
  const brandId = String(body.brandId || '').trim();
  const code = String(body.code || 'UNIT').trim().toUpperCase();
  const isActive = body.isActive !== false ? 1 : 0;
  await c.env.DB.prepare(
    'UPDATE units SET brand_id = ?, name = ?, code = ?, is_active = ?, updated_at = ? WHERE id = ?'
  )
    .bind(brandId, name, code, isActive, new Date().toISOString(), id)
    .run();
  return c.json({ success: true, item: { id, brandId, name, code, isActive: Boolean(isActive) } });
});

masterDataRoutes.delete('/units/:id', requireRole(['super_admin', 'admin']), async (c) => {
  const id = c.req.param('id');
  await c.env.DB.prepare('UPDATE units SET is_active = 0, updated_at = ? WHERE id = ?')
    .bind(new Date().toISOString(), id)
    .run();
  return c.json({ success: true });
});

// Departments
masterDataRoutes.post('/departments', requireRole(['super_admin', 'admin']), async (c) => {
  const body = await c.req.json().catch(() => ({}));
  const name = String(body.name || '').trim();
  if (!name) return c.json({ success: false, error: 'Department name is required.' }, 400);
  const id = body.id ? String(body.id) : `dept-${Date.now()}`;
  const now = new Date().toISOString();
  await c.env.DB.prepare(
    'INSERT INTO departments (id, name, is_active, created_at, updated_at) VALUES (?, ?, ?, ?, ?)'
  )
    .bind(id, name, body.isActive === false ? 0 : 1, now, now)
    .run();
  return c.json({ success: true, item: { id, name, isActive: body.isActive !== false } }, 201);
});

masterDataRoutes.put('/departments/:id', requireRole(['super_admin', 'admin']), async (c) => {
  const id = c.req.param('id');
  const body = await c.req.json().catch(() => ({}));
  const name = String(body.name || '').trim();
  const isActive = body.isActive !== false ? 1 : 0;
  await c.env.DB.prepare('UPDATE departments SET name = ?, is_active = ?, updated_at = ? WHERE id = ?')
    .bind(name, isActive, new Date().toISOString(), id)
    .run();
  return c.json({ success: true, item: { id, name, isActive: Boolean(isActive) } });
});

masterDataRoutes.delete('/departments/:id', requireRole(['super_admin', 'admin']), async (c) => {
  const id = c.req.param('id');
  await c.env.DB.prepare('UPDATE departments SET is_active = 0, updated_at = ? WHERE id = ?')
    .bind(new Date().toISOString(), id)
    .run();
  return c.json({ success: true });
});

// Categories
masterDataRoutes.post('/categories', requireRole(['super_admin', 'admin']), async (c) => {
  const body = await c.req.json().catch(() => ({}));
  const name = String(body.name || '').trim();
  const slaDaysDefault = Math.max(1, Number(body.slaDaysDefault || 3));
  if (!name) return c.json({ success: false, error: 'Category name is required.' }, 400);
  const id = body.id ? String(body.id) : `cat-${Date.now()}`;
  const now = new Date().toISOString();
  await c.env.DB.prepare(
    'INSERT INTO categories (id, name, sla_days_default, is_active, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?)'
  )
    .bind(id, name, slaDaysDefault, body.isActive === false ? 0 : 1, now, now)
    .run();
  return c.json(
    { success: true, item: { id, name, slaDaysDefault, isActive: body.isActive !== false } },
    201
  );
});

masterDataRoutes.put('/categories/:id', requireRole(['super_admin', 'admin']), async (c) => {
  const id = c.req.param('id');
  const body = await c.req.json().catch(() => ({}));
  const name = String(body.name || '').trim();
  const slaDaysDefault = Math.max(1, Number(body.slaDaysDefault || 3));
  const isActive = body.isActive !== false ? 1 : 0;
  await c.env.DB.prepare(
    'UPDATE categories SET name = ?, sla_days_default = ?, is_active = ?, updated_at = ? WHERE id = ?'
  )
    .bind(name, slaDaysDefault, isActive, new Date().toISOString(), id)
    .run();
  return c.json({ success: true, item: { id, name, slaDaysDefault, isActive: Boolean(isActive) } });
});

masterDataRoutes.delete('/categories/:id', requireRole(['super_admin', 'admin']), async (c) => {
  const id = c.req.param('id');
  const ref = await c.env.DB.prepare('SELECT id FROM requests WHERE category_id = ? LIMIT 1').bind(id).first();
  if (ref) {
    await c.env.DB.prepare('UPDATE categories SET is_active = 0, updated_at = ? WHERE id = ?')
      .bind(new Date().toISOString(), id)
      .run();
  } else {
    await c.env.DB.prepare('DELETE FROM categories WHERE id = ?').bind(id).run();
  }
  return c.json({ success: true });
});

// Teams
masterDataRoutes.post('/teams', requireRole(['super_admin', 'admin']), async (c) => {
  const body = await c.req.json().catch(() => ({}));
  const name = String(body.name || '').trim();
  const description = String(body.description || '').trim();
  const color = String(body.color || '#065F46');
  if (!name) return c.json({ success: false, error: 'Team name is required.' }, 400);
  const id = body.id ? String(body.id) : `team-${Date.now()}`;
  const now = new Date().toISOString();
  await c.env.DB.prepare(
    'INSERT INTO teams (id, name, description, color, is_active, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)'
  )
    .bind(id, name, description, color, body.isActive === false ? 0 : 1, now, now)
    .run();

  const actor = c.get('user')!;
  await writeSecurityAuditLog(c.env.DB, {
    action: 'master_data_team_created',
    actorId: actor.id,
    actorName: actor.fullName,
    actorRole: actor.role,
    targetId: id,
    targetType: 'team',
    summary: `Created execution team: ${name}`,
  });

  return c.json(
    { success: true, item: { id, name, description, color, isActive: body.isActive !== false } },
    201
  );
});

masterDataRoutes.put('/teams/:id', requireRole(['super_admin', 'admin']), async (c) => {
  const id = c.req.param('id');
  const body = await c.req.json().catch(() => ({}));
  const name = String(body.name || '').trim();
  const description = String(body.description || '').trim();
  const color = String(body.color || '#065F46');
  const isActive = body.isActive !== false ? 1 : 0;
  await c.env.DB.prepare(
    'UPDATE teams SET name = ?, description = ?, color = ?, is_active = ?, updated_at = ? WHERE id = ?'
  )
    .bind(name, description, color, isActive, new Date().toISOString(), id)
    .run();
  return c.json({ success: true, item: { id, name, description, color, isActive: Boolean(isActive) } });
});

masterDataRoutes.delete('/teams/:id', requireRole(['super_admin', 'admin']), async (c) => {
  const id = c.req.param('id');
  await c.env.DB.prepare('UPDATE teams SET is_active = 0, updated_at = ? WHERE id = ?')
    .bind(new Date().toISOString(), id)
    .run();
  return c.json({ success: true });
});
