import { Hono } from 'hono';
import { canUserViewRequest, requireAuth } from '../middleware/auth';
import { fetchAllSubItemsMap } from './requests';
import { rowToNotification, rowToRequest, WorkerAppEnv } from '../types';

export const notificationRoutes = new Hono<WorkerAppEnv>();
notificationRoutes.use('*', requireAuth);

notificationRoutes.get('/', async (c) => {
  const user = c.get('user')!;
  const res = await c.env.DB.prepare(
    'SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 200'
  )
    .bind(user.id)
    .all<Record<string, unknown>>();
  return c.json({
    success: true,
    notifications: (res.results || []).map(rowToNotification),
  });
});

notificationRoutes.post('/:id/read', async (c) => {
  const user = c.get('user')!;
  const id = c.req.param('id');
  await c.env.DB.prepare('UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?')
    .bind(id, user.id)
    .run();
  return c.json({ success: true });
});

notificationRoutes.post('/read-all', async (c) => {
  const user = c.get('user')!;
  await c.env.DB.prepare('UPDATE notifications SET is_read = 1 WHERE user_id = ?')
    .bind(user.id)
    .run();
  return c.json({ success: true });
});

export const syncRoutes = new Hono<WorkerAppEnv>();
syncRoutes.use('*', requireAuth);

// Authenticated Smart Polling endpoint (replaces WebSocket/Supabase Realtime for Cloudflare Workers)
syncRoutes.get('/', async (c) => {
  const user = c.get('user')!;
  const [reqRes, subMap, notifRes] = await Promise.all([
    c.env.DB.prepare('SELECT * FROM requests WHERE deleted_at IS NULL ORDER BY created_at DESC').all<
      Record<string, unknown>
    >(),
    fetchAllSubItemsMap(c.env.DB),
    c.env.DB.prepare('SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 100')
      .bind(user.id)
      .all<Record<string, unknown>>(),
  ]);

  const requests = (reqRes.results || [])
    .map((r) => rowToRequest(r, subMap.get(String(r.id)) || []))
    .filter((r) => canUserViewRequest(user, r));
  const notifications = (notifRes.results || []).map(rowToNotification);

  return c.json({
    success: true,
    syncedAt: new Date().toISOString(),
    requests,
    notifications,
    unreadCount: notifications.filter((n) => !n.isRead).length,
  });
});
