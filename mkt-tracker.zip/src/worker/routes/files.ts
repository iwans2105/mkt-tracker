import { Hono } from 'hono';
import {
  canUserViewRequest,
  isUserWithinBrandScope,
  requireAuth,
  writeSecurityAuditLog,
} from '../middleware/auth';
import { randomHex, sha256HexBytes } from '../crypto';
import { rowToSubItem, rowToRequest, WorkerAppEnv } from '../types';

export const MAX_GENERAL_FILE_BYTES = 50 * 1024 * 1024; // 50 MB
export const MAX_DELIVERABLE_FILE_BYTES = 100 * 1024 * 1024; // 100 MB

const ALLOWED_EXTENSIONS = new Set([
  'png',
  'jpg',
  'jpeg',
  'webp',
  'gif',
  'svg',
  'pdf',
  'doc',
  'docx',
  'xls',
  'xlsx',
  'ppt',
  'pptx',
  'psd',
  'ai',
  'eps',
  'mp4',
  'mov',
  'mpeg',
  'avi',
  'wav',
  'mp3',
  'zip',
  'txt',
  'csv',
]);

const ALLOWED_MIME_PREFIXES = [
  'image/',
  'video/',
  'audio/',
  'application/pdf',
  'application/msword',
  'application/vnd.openxmlformats-officedocument',
  'application/vnd.ms-',
  'application/postscript',
  'application/zip',
  'application/x-zip-compressed',
  'application/octet-stream',
  'text/plain',
  'text/csv',
];

function sanitizeFilename(rawName: string): string {
  const base = rawName.split(/[/\\]/).pop() || 'file';
  return base.replace(/[^a-zA-Z0-9._ -]/g, '_').slice(0, 140) || 'file';
}

function isAllowedFile(fileName: string, mimeType: string): boolean {
  const ext = fileName.split('.').pop()?.toLowerCase() || '';
  if (!ALLOWED_EXTENSIONS.has(ext)) return false;
  if (!mimeType) return true;
  const lowerMime = mimeType.toLowerCase();
  return ALLOWED_MIME_PREFIXES.some((p) => lowerMime.startsWith(p));
}

export const fileRoutes = new Hono<WorkerAppEnv>();

// 1. Upload file privately to R2 + record metadata & SHA-256 in D1
fileRoutes.post('/upload', requireAuth, async (c) => {
  const user = c.get('user')!;
  const contentType = c.req.header('content-type') || '';

  let fileName = '';
  let mimeType = 'application/octet-stream';
  let fileBytes: Uint8Array | null = null;
  let scopeType: 'brief' | 'deliverable' | 'subitem' | 'avatar' = 'brief';
  let brandId: string | null = null;
  let regionId: string | null = null;
  let requestId: string | null = null;
  let subItemId: string | null = null;

  if (contentType.includes('multipart/form-data')) {
    const formData = await c.req.formData().catch(() => null);
    if (!formData) {
      return c.json({ success: false, error: 'Payload multipart tidak valid.' }, 400);
    }
    const fileEntry = formData.get('file');
    if (!fileEntry || typeof fileEntry === 'string') {
      return c.json({ success: false, error: 'File wajib disertakan pada field "file".' }, 400);
    }
    const uploadedFile = fileEntry as File;
    fileName = sanitizeFilename(uploadedFile.name || 'attachment');
    mimeType = uploadedFile.type || 'application/octet-stream';
    fileBytes = new Uint8Array(await uploadedFile.arrayBuffer());

    const rawScope = String(formData.get('scopeType') || 'brief');
    if (['brief', 'deliverable', 'subitem', 'avatar'].includes(rawScope)) {
      scopeType = rawScope as typeof scopeType;
    }
    brandId = formData.get('brandId') ? String(formData.get('brandId')) : null;
    regionId = formData.get('regionId') ? String(formData.get('regionId')) : null;
    requestId = formData.get('requestId') ? String(formData.get('requestId')) : null;
    subItemId = formData.get('subItemId') ? String(formData.get('subItemId')) : null;
  } else {
    const body = await c.req.json().catch(() => null);
    if (!body || !body.fileName || !body.dataBase64) {
      return c.json(
        { success: false, error: 'Gunakan multipart/form-data atau JSON { fileName, mimeType, dataBase64 }.' },
        400
      );
    }
    fileName = sanitizeFilename(String(body.fileName));
    mimeType = String(body.mimeType || 'application/octet-stream');
    const cleanB64 = String(body.dataBase64).replace(/^data:[^;]+;base64,/, '');
    try {
      const binary = atob(cleanB64);
      const arr = new Uint8Array(binary.length);
      for (let i = 0; i < binary.length; i++) arr[i] = binary.charCodeAt(i);
      fileBytes = arr;
    } catch {
      return c.json({ success: false, error: 'Format base64 file tidak valid.' }, 400);
    }
    if (['brief', 'deliverable', 'subitem', 'avatar'].includes(String(body.scopeType || ''))) {
      scopeType = body.scopeType;
    }
    brandId = body.brandId ? String(body.brandId) : null;
    regionId = body.regionId ? String(body.regionId) : null;
    requestId = body.requestId ? String(body.requestId) : null;
    subItemId = body.subItemId ? String(body.subItemId) : null;
  }

  if (!fileBytes || fileBytes.byteLength === 0) {
    return c.json({ success: false, error: 'File kosong tidak dapat diunggah.' }, 400);
  }

  const maxLimit =
    scopeType === 'deliverable' || scopeType === 'subitem'
      ? MAX_DELIVERABLE_FILE_BYTES
      : MAX_GENERAL_FILE_BYTES;
  if (fileBytes.byteLength > maxLimit) {
    return c.json(
      {
        success: false,
        error: `Ukuran file melebihi batas maksimum (${Math.round(maxLimit / (1024 * 1024))} MB).`,
      },
      413
    );
  }

  if (!isAllowedFile(fileName, mimeType)) {
    return c.json(
      {
        success: false,
        error: `Tipe file atau ekstensi "${fileName}" tidak diizinkan oleh kebijakan keamanan.`,
      },
      400
    );
  }

  // Brand scope authorization check if brandId or requestId supplied
  if (requestId) {
    const reqRow = await c.env.DB.prepare('SELECT * FROM requests WHERE id = ? AND deleted_at IS NULL')
      .bind(requestId)
      .first<Record<string, unknown>>();
    if (!reqRow) {
      return c.json({ success: false, error: 'Request referensi tidak ditemukan.' }, 404);
    }
    const subRows = await c.env.DB.prepare(
      'SELECT * FROM sub_items WHERE parent_request_id = ? AND deleted_at IS NULL'
    )
      .bind(requestId)
      .all<Record<string, unknown>>();
    const mappedReq = rowToRequest(reqRow, (subRows.results || []).map(rowToSubItem));
    if (!canUserViewRequest(user, mappedReq)) {
      return c.json({ success: false, error: 'Akses ditolak untuk request ini.' }, 403);
    }
    brandId = brandId || mappedReq.brandId;
    regionId = regionId || mappedReq.regionId;
  } else if (brandId && !isUserWithinBrandScope(user, regionId, brandId)) {
    return c.json({ success: false, error: 'Akses ditolak: Brand di luar cakupan akun Anda.' }, 403);
  }

  const fileId = `att-${Date.now()}-${randomHex(5)}`;
  const checksum = await sha256HexBytes(fileBytes);
  const year = new Date().getUTCFullYear();
  const safeBrandFolder = brandId || 'general';
  const r2Key = `${scopeType}/${year}/${safeBrandFolder}/${fileId}-${fileName}`;

  await c.env.FILES_BUCKET.put(r2Key, fileBytes.buffer as ArrayBuffer, {
    httpMetadata: {
      contentType: mimeType,
    },
    customMetadata: {
      uploadedBy: user.id,
      fileId,
      sha256: checksum,
    },
  });

  const headCheck = await c.env.FILES_BUCKET.head(r2Key);
  if (!headCheck) {
    return c.json({ success: false, error: 'Gagal memverifikasi penyimpanan objek di Cloudflare R2.' }, 500);
  }

  const nowIso = new Date().toISOString();
  await c.env.DB.prepare(
    `INSERT INTO attachments
     (id, r2_key, file_name, mime_type, size_bytes, sha256_checksum, scope_type, brand_id, region_id, request_id, sub_item_id, uploaded_by, uploaded_by_name, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  )
    .bind(
      fileId,
      r2Key,
      fileName,
      mimeType,
      fileBytes.byteLength,
      checksum,
      scopeType,
      brandId,
      regionId,
      requestId,
      subItemId,
      user.id,
      user.fullName,
      nowIso
    )
    .run();

  return c.json({
    success: true,
    file: {
      id: fileId,
      name: fileName,
      size: fileBytes.byteLength,
      type: mimeType,
      url: `/api/files/${fileId}`,
      uploadedAt: nowIso,
      uploadedBy: user.fullName,
      sha256: checksum,
    },
  });
});

// 2. Authorized Private File Retrieval from R2
fileRoutes.get('/:id', requireAuth, async (c) => {
  const user = c.get('user')!;
  const fileId = c.req.param('id');
  const forceDownload = c.req.query('download') === '1' || c.req.query('download') === 'true';

  const meta = await c.env.DB.prepare('SELECT * FROM attachments WHERE id = ? AND deleted_at IS NULL')
    .bind(fileId)
    .first<Record<string, unknown>>();

  if (!meta) {
    return c.json({ success: false, error: 'File tidak ditemukan atau telah dihapus.' }, 404);
  }

  const scopeType = String(meta.scope_type);
  if (scopeType === 'backup' && user.role !== 'super_admin' && user.role !== 'admin') {
    return c.json({ success: false, error: 'Akses ditolak: Hanya Admin yang dapat mengunduh backup.' }, 403);
  }

  if (meta.request_id) {
    const reqRow = await c.env.DB.prepare('SELECT * FROM requests WHERE id = ?')
      .bind(String(meta.request_id))
      .first<Record<string, unknown>>();
    if (reqRow) {
      const subRows = await c.env.DB.prepare(
        'SELECT * FROM sub_items WHERE parent_request_id = ? AND deleted_at IS NULL'
      )
        .bind(String(meta.request_id))
        .all<Record<string, unknown>>();
      const mappedReq = rowToRequest(reqRow, (subRows.results || []).map(rowToSubItem));
      if (!canUserViewRequest(user, mappedReq)) {
        return c.json({ success: false, error: 'Akses ditolak untuk lampiran request ini.' }, 403);
      }
    }
  } else if (
    scopeType !== 'avatar' &&
    meta.brand_id &&
    !isUserWithinBrandScope(
      user,
      meta.region_id ? String(meta.region_id) : undefined,
      String(meta.brand_id)
    )
  ) {
    return c.json({ success: false, error: 'Akses ditolak: Lampiran berada di luar cakupan brand Anda.' }, 403);
  }

  const r2Obj = await c.env.FILES_BUCKET.get(String(meta.r2_key));
  if (!r2Obj) {
    return c.json({ success: false, error: 'Objek file tidak ditemukan pada R2 Storage.' }, 404);
  }

  const fileName = String(meta.file_name);
  const mimeType = String(meta.mime_type || 'application/octet-stream');
  const isSafeInline =
    mimeType.startsWith('image/') && !mimeType.includes('svg') || mimeType === 'application/pdf';
  const disposition =
    forceDownload || !isSafeInline
      ? `attachment; filename="${fileName.replace(/"/g, '')}"`
      : `inline; filename="${fileName.replace(/"/g, '')}"`;

  const headers = new Headers();
  headers.set('Content-Type', mimeType);
  headers.set('Content-Disposition', disposition);
  headers.set('Cache-Control', 'private, no-store');
  headers.set('X-Content-Type-Options', 'nosniff');
  headers.set('X-File-SHA256', String(meta.sha256_checksum));

  return new Response(r2Obj.body as unknown as BodyInit, {
    status: 200,
    headers,
  });
});

// 3. Soft delete file metadata (Super Admin, Admin, or uploader before completion)
fileRoutes.delete('/:id', requireAuth, async (c) => {
  const user = c.get('user')!;
  const fileId = c.req.param('id');

  const meta = await c.env.DB.prepare('SELECT * FROM attachments WHERE id = ? AND deleted_at IS NULL')
    .bind(fileId)
    .first<Record<string, unknown>>();
  if (!meta) {
    return c.json({ success: false, error: 'File tidak ditemukan.' }, 404);
  }

  const isOwner = String(meta.uploaded_by) === user.id;
  if (user.role !== 'super_admin' && user.role !== 'admin' && !isOwner) {
    return c.json({ success: false, error: 'Anda tidak memiliki izin menghapus file ini.' }, 403);
  }

  const nowIso = new Date().toISOString();
  await c.env.DB.prepare('UPDATE attachments SET deleted_at = ? WHERE id = ?')
    .bind(nowIso, fileId)
    .run();

  await writeSecurityAuditLog(c.env.DB, {
    action: 'file_soft_deleted',
    actorId: user.id,
    actorName: user.fullName,
    actorRole: user.role,
    targetId: fileId,
    targetType: 'attachment',
    summary: `Soft deleted attachment ${String(meta.file_name)}`,
  });

  return c.json({ success: true });
});
