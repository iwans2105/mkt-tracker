import crypto from 'node:crypto';

const encoder = new TextEncoder();

export function toHex(bytes: Uint8Array): string {
  return Array.from(bytes)
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');
}

export function fromHex(hex: string): Uint8Array {
  const clean = hex.trim();
  const out = new Uint8Array(Math.floor(clean.length / 2));
  for (let i = 0; i < out.length; i++) {
    out[i] = parseInt(clean.slice(i * 2, i * 2 + 2), 16);
  }
  return out;
}

export function randomHex(byteLength: number): string {
  const bytes = new Uint8Array(byteLength);
  globalThis.crypto.getRandomValues(bytes);
  return toHex(bytes);
}

export function timingSafeEqualHex(aHex: string, bHex: string): boolean {
  if (!aHex || !bHex || aHex.length !== bHex.length) return false;
  const a = fromHex(aHex);
  const b = fromHex(bHex);
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) {
    diff |= a[i] ^ b[i];
  }
  return diff === 0;
}

export async function sha256Hex(input: string | Uint8Array): Promise<string> {
  const data = typeof input === 'string' ? encoder.encode(input) : input;
  const digest = await globalThis.crypto.subtle.digest('SHA-256', data as BufferSource);
  return toHex(new Uint8Array(digest));
}

export const sha256HexBytes = sha256Hex;

export async function hmacSha256Hex(secret: string, message: string): Promise<string> {
  const key = await globalThis.crypto.subtle.importKey(
    'raw',
    encoder.encode(secret),
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign']
  );
  const sig = await globalThis.crypto.subtle.sign('HMAC', key, encoder.encode(message));
  return toHex(new Uint8Array(sig));
}

export async function createCsrfToken(csrfSecret: string, sessionId: string, sessionSecret?: string): Promise<string> {
  const effectiveKey = sessionSecret ? `${csrfSecret}:${sessionSecret}` : csrfSecret;
  return hmacSha256Hex(effectiveKey, sessionId);
}

export async function verifyCsrfToken(
  token: string,
  csrfSecret: string,
  sessionId: string,
  sessionSecret?: string
): Promise<boolean> {
  if (!token || !csrfSecret || !sessionId) return false;
  const expected = await createCsrfToken(csrfSecret, sessionId, sessionSecret);
  return timingSafeEqualHex(token, expected);
}

/**
 * Derive password digest using WebCrypto PBKDF2-SHA256 (100,000 iterations - max supported by Cloudflare Workers BoringSSL).
 * Incorporates server-side PASSWORD_PEPPER via HMAC pre-step when configured.
 */
async function pbkdf2Sha256(
  passwordInput: string,
  saltHex: string,
  iterations: number
): Promise<string> {
  const baseKey = await globalThis.crypto.subtle.importKey(
    'raw',
    encoder.encode(passwordInput),
    'PBKDF2',
    false,
    ['deriveBits']
  );
  const derived = await globalThis.crypto.subtle.deriveBits(
    {
      name: 'PBKDF2',
      salt: fromHex(saltHex) as BufferSource,
      iterations,
      hash: 'SHA-256',
    },
    baseKey,
    256
  );
  return toHex(new Uint8Array(derived));
}

/**
 * Hashes new passwords using PBKDF2-SHA256 (100k iterations) + optional PASSWORD_PEPPER.
 * Format: pbkdf2_sha256$100000$<peppered:0|1>$<saltHex>$<hashHex>
 */
export async function hashPassword(password: string, pepper?: string): Promise<string> {
  const saltHex = randomHex(16);
  const effective = pepper ? await hmacSha256Hex(pepper, password) : password;
  const iterations = 100000;
  const hashHex = await pbkdf2Sha256(effective, saltHex, iterations);
  const pepperFlag = pepper ? '1' : '0';
  return `pbkdf2_sha256$${iterations}$${pepperFlag}$${saltHex}$${hashHex}`;
}

/**
 * Verifies BOTH:
 * 1) Modern WebCrypto PBKDF2-SHA256 format (`pbkdf2_sha256$...`)
 * 2) Legacy Node scrypt format (`saltHex:derivedHex` with N=16384, r=8, p=1) for seamless legacy migration
 */
export async function verifyPassword(
  password: string,
  storedHash: string,
  pepper?: string
): Promise<boolean> {
  try {
    if (!storedHash || !password) return false;

    if (storedHash.startsWith('pbkdf2_sha256$')) {
      const parts = storedHash.split('$');
      if (parts.length !== 5) return false;
      const iterations = parseInt(parts[1], 10);
      const pepperFlag = parts[2];
      const saltHex = parts[3];
      const expectedHex = parts[4];
      if (!Number.isFinite(iterations) || iterations < 10000) return false;

      if (pepperFlag === '1') {
        if (!pepper) return false;
        const effective = await hmacSha256Hex(pepper, password);
        const derived = await pbkdf2Sha256(effective, saltHex, iterations);
        return timingSafeEqualHex(derived, expectedHex);
      }
      const derived = await pbkdf2Sha256(password, saltHex, iterations);
      return timingSafeEqualHex(derived, expectedHex);
    }

    // Legacy scrypt format from server_users.json: `${saltHex}:${derivedHex}`
    const colonParts = storedHash.split(':');
    if (colonParts.length === 2) {
      const [salt, expectedHex] = colonParts;
      const derived = crypto.scryptSync(password, salt, 64, { N: 16384, r: 8, p: 1 });
      return timingSafeEqualHex(derived.toString('hex'), expectedHex);
    }

    return false;
  } catch {
    return false;
  }
}

export function isLegacyHashFormat(storedHash: string): boolean {
  return !storedHash.startsWith('pbkdf2_sha256$');
}

export const COMMONLY_COMPROMISED_PASSWORDS = new Set([
  'password1234',
  '123456789012',
  '1234567890123',
  'qwertyuiopas',
  'admin12345678',
  'password12345',
  'administrator1',
  'letmein123456',
  'welcome123456',
]);

export function validatePasswordStrength(password: string): { valid: boolean; error?: string } {
  if (!password || typeof password !== 'string') {
    return { valid: false, error: 'Password wajib diisi.' };
  }
  if (password.length < 12) {
    return {
      valid: false,
      error: 'Password minimal 12 karakter untuk standar keamanan enterprise PT Lyman Devindo.',
    };
  }
  const normalized = password.toLowerCase().replace(/[^a-z0-9]/g, '');
  if (
    COMMONLY_COMPROMISED_PASSWORDS.has(password.toLowerCase()) ||
    COMMONLY_COMPROMISED_PASSWORDS.has(normalized)
  ) {
    return {
      valid: false,
      error: 'Password terlalu umum dan mudah ditebak. Gunakan kombinasi kata sandi atau frasa unik.',
    };
  }
  return { valid: true };
}
