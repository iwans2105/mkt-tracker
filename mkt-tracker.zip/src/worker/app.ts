import { Hono } from 'hono';
import { authMiddleware } from './middleware/auth';
import { authRoutes } from './routes/auth';
import { userRoutes } from './routes/users';
import { masterDataRoutes } from './routes/masterData';
import { quotaRoutes } from './routes/quotas';
import { requestRoutes } from './routes/requests';
import { fileRoutes } from './routes/files';
import { aiRoutes } from './routes/ai';
import { systemRoutes } from './routes/system';
import { migrationRoutes } from './routes/migration';
import { notificationRoutes, syncRoutes } from './routes/notifications';
import { publicRoutes } from './routes/public';
import { WorkerAppEnv } from './types';

export function createWorkerApp() {
  const app = new Hono<WorkerAppEnv>();

  // Baseline Security & No-Store Cache Headers on every API response
  app.use('*', async (c, next) => {
    await next();
    c.res.headers.set('X-Content-Type-Options', 'nosniff');
    c.res.headers.set('Referrer-Policy', 'strict-origin-when-cross-origin');
    c.res.headers.set('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
    if (c.req.path.startsWith('/api/')) {
      if (!c.res.headers.has('Cache-Control')) {
        c.res.headers.set('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
      }
      c.res.headers.set('Pragma', 'no-cache');
      c.res.headers.set('Expires', '0');
      c.res.headers.set('Surrogate-Control', 'no-store');
    }
  });

  // Global D1 Session + CSRF Protection Middleware on /api/*
  app.use('/api/*', authMiddleware);

  // Mount Domain Routes
  app.route('/api/auth', authRoutes);
  app.route('/api/users', userRoutes);
  app.route('/api/master-data', masterDataRoutes);
  app.route('/api/quotas', quotaRoutes);
  app.route('/api/requests', requestRoutes);
  app.route('/api/files', fileRoutes);
  app.route('/api/ai', aiRoutes);
  app.route('/api/system', systemRoutes);
  app.route('/api/migration', migrationRoutes);
  app.route('/api/notifications', notificationRoutes);
  app.route('/api/sync', syncRoutes);
  app.route('/api/public', publicRoutes);

  // Health alias
  app.get('/api/health', (c) => {
    return c.json({
      success: true,
      status: 'ok',
      runtime: 'cloudflare-workers-hono',
      environment: c.env.ENVIRONMENT || 'local',
    });
  });

  // Global 404 for unknown API paths (returns structured JSON, never leaks stack traces)
  app.all('/api/*', (c) => {
    return c.json({ success: false, error: `Endpoint API tidak ditemukan: ${c.req.path}` }, 404);
  });

  // Global API Error Handler
  app.onError((err, c) => {
    console.error('[Worker Unhandled Error]:', err);
    return c.json(
      {
        success: false,
        error: 'Terjadi kesalahan internal pada server Worker.',
      },
      500
    );
  });

  return app;
}

export const workerApp = createWorkerApp();
