import type { ExecutionContext } from '@cloudflare/workers-types';
import { workerApp } from './app';
import { WorkerBindings } from './types';

export default {
  async fetch(request: Request, env: WorkerBindings, ctx: ExecutionContext): Promise<Response> {
    const url = new URL(request.url);
    if (url.pathname.startsWith('/api/')) {
      return workerApp.fetch(request, env, ctx);
    }

    // Delegate static SPA assets to Workers Static Assets binding when deployed on Cloudflare
    if (env.ASSETS) {
      const assetRes = (await env.ASSETS.fetch(
        request as unknown as Parameters<typeof env.ASSETS.fetch>[0]
      )) as unknown as Response;

      const contentType = assetRes.headers.get('content-type') || '';
      const acceptHeader = request.headers.get('accept') || '';
      const isHtmlRoute =
        contentType.includes('text/html') ||
        url.pathname === '/' ||
        url.pathname.endsWith('.html') ||
        (!url.pathname.includes('.') && acceptHeader.includes('text/html'));

      if (isHtmlRoute) {
        const cloned = new Response(assetRes.body, {
          status: assetRes.status,
          statusText: assetRes.statusText,
          headers: new Headers(assetRes.headers),
        });
        cloned.headers.set('Cache-Control', 'no-cache, no-store, must-revalidate');
        cloned.headers.set('Pragma', 'no-cache');
        cloned.headers.set('Expires', '0');
        return cloned;
      }

      return assetRes;
    }

    return new Response('MARCOMM TASK Worker Online', {
      status: 200,
      headers: { 'Content-Type': 'text/plain' },
    });
  },
};
