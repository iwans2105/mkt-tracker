import { Context, Next } from 'hono';
import { getCookie, setCookie, deleteCookie } from 'hono/cookie';
import type { RequestItem, UserRole } from '../../types';
import { createCsrfToken, randomHex, verifyCsrfToken } from '../crypto';
import { rowToUser, SessionRecord, StoredUserRecord, WorkerAppEnv } from '../types';

export const SESSION_LIFESPAN_MS = 8 * 60 * 60 * 1000; // 8 hours sliding expiry
export const RATE_LIMIT_WINDOW_MS = 15 * 60 * 1000; // 15 minutes
export const MAX_FAILED_ATTEMPTS = 5;

export function extractClientIp(c: Context<WorkerAppEnv>): string {
  return (
    c.req.header('cf-connecting-ip') ||
    c.req.header('x-forwarded-for')?.split(',')[0]?.trim() ||
    c.req.header('x-real-ip') ||
    '127.0.0.1'
  );
}

export function isHttpsOrigin(c: Context<WorkerAppEnv>): boolean {
  const origin = c.env.APP_ORIGIN || '';
  if (origin.startsWith('https://')) return true;
  const proto = c.req.header('x-forwarded-proto') || '';
  if (proto === 'https') return true;
  try {
    return new URL(c.req.url).protocol === 'https:';
  } catch {
    return false;
  }
}

export function setSessionCookie(c: Context<WorkerAppEnv>, sessionId: string) {
  setCookie(c, 'marcomm_sid', sessionId, {
    httpOnly: true,
    sameSite: 'Lax',
    secure: isHttpsOrigin(c),
    path: '/',
    maxAge: SESSION_LIFESPAN_MS / 1000,
  });
}

export function clearSessionCookie(c: Context<WorkerAppEnv>) {
  deleteCookie(c, 'marcomm_sid', { path: '/' });
}

export async function createSessionInD1(
  c: Context<WorkerAppEnv>,
  user: StoredUserRecord,
  replaceSessionId?: string
): Promise<{ session: SessionRecord; csrfToken: string }> {
  const sessionId = randomHex(32);
  const csrfSecret = randomHex(16);
  const now = Date.now();
  const expiresAt = now + SESSION_LIFESPAN_MS;
  const ipAddress = c.get('clientIp') || extractClientIp(c);
  const userAgent = c.req.header('user-agent') || '';

  const statements = [];
  if (replaceSessionId) {
    statements.push(
      c.env.DB.prepare('DELETE FROM sessions WHERE session_id = ?').bind(replaceSessionId)
    );
  }
  statements.push(
    c.env.DB.prepare(
      `INSERT INTO sessions (session_id, user_id, email, role, csrf_secret, created_at, expires_at, last_active_at, ip_address, user_agent)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).bind(sessionId, user.id, user.email, user.role, csrfSecret, now, expiresAt, now, ipAddress, userAgent)
  );
  await c.env.DB.batch(statements);

  const csrfToken = await createCsrfToken(csrfSecret, sessionId, c.env.SESSION_SECRET);
  return {
    session: {
      sessionId,
      userId: user.id,
      email: user.email,
      role: user.role,
      csrfSecret,
      createdAt: now,
      expiresAt,
      lastActiveAt: now,
      ipAddress,
      userAgent,
    },
    csrfToken,
  };
}

export async function revokeUserSessions(db: WorkerAppEnv['Bindings']['DB'], userId: string) {
  await db.prepare('DELETE FROM sessions WHERE user_id = ?').bind(userId).run();
}

export async function revokeOtherUserSessions(
  db: WorkerAppEnv['Bindings']['DB'],
  userId: string,
  keepSessionId: string
) {
  await db
    .prepare('DELETE FROM sessions WHERE user_id = ? AND session_id != ?')
    .bind(userId, keepSessionId)
    .run();
}

export async function writeSecurityAuditLog(
  db: WorkerAppEnv['Bindings']['DB'],
  entry: {
    action: string;
    actorId: string;
    actorName: string;
    actorRole: string;
    targetId?: string;
    targetType?: string;
    summary: string;
    details?: Record<string, unknown>;
  }
) {
  const id = `sec-${Date.now()}-${randomHex(4)}`;
  const timestamp = new Date().toISOString();
  await db
    .prepare(
      `INSERT INTO security_audit_logs (id, timestamp, action, actor_id, actor_name, actor_role, target_id, target_type, summary, details_json)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    )
    .bind(
      id,
      timestamp,
      entry.action,
      entry.actorId,
      entry.actorName,
      entry.actorRole,
      entry.targetId || null,
      entry.targetType || null,
      entry.summary,
      JSON.stringify(entry.details || {})
    )
    .run();
}

// D1-backed Edge-Consistent Rate Limiting (keyed by IP and normalized email)
export async function checkD1RateLimit(
  db: WorkerAppEnv['Bindings']['DB'],
  keys: string[]
): Promise<{ allowed: boolean; remainingSecs?: number }> {
  const now = Date.now();
  for (const rateKey of keys) {
    const row = await db
      .prepare('SELECT rate_key, attempt_count, first_attempt_ms FROM login_rate_limits WHERE rate_key = ?')
      .bind(rateKey)
      .first<{ rate_key: string; attempt_count: number; first_attempt_ms: number }>();

    if (!row) continue;

    if (now - row.first_attempt_ms > RATE_LIMIT_WINDOW_MS) {
      await db.prepare('DELETE FROM login_rate_limits WHERE rate_key = ?').bind(rateKey).run();
      continue;
    }

    if (row.attempt_count >= MAX_FAILED_ATTEMPTS) {
      const remainingSecs = Math.max(
        1,
        Math.ceil((RATE_LIMIT_WINDOW_MS - (now - row.first_attempt_ms)) / 1000)
      );
      return { allowed: false, remainingSecs };
    }
  }
  return { allowed: true };
}

export async function recordD1FailedAttempt(
  db: WorkerAppEnv['Bindings']['DB'],
  keys: string[]
): Promise<void> {
  const now = Date.now();
  for (const rateKey of keys) {
    const row = await db
      .prepare('SELECT attempt_count, first_attempt_ms FROM login_rate_limits WHERE rate_key = ?')
      .bind(rateKey)
      .first<{ attempt_count: number; first_attempt_ms: number }>();

    if (!row || now - row.first_attempt_ms > RATE_LIMIT_WINDOW_MS) {
      await db
        .prepare(
          `INSERT INTO login_rate_limits (rate_key, attempt_count, first_attempt_ms, updated_at_ms)
           VALUES (?, 1, ?, ?)
           ON CONFLICT(rate_key) DO UPDATE SET attempt_count = 1, first_attempt_ms = excluded.first_attempt_ms, updated_at_ms = excluded.updated_at_ms`
        )
        .bind(rateKey, now, now)
        .run();
    } else {
      await db
        .prepare(
          'UPDATE login_rate_limits SET attempt_count = attempt_count + 1, updated_at_ms = ? WHERE rate_key = ?'
        )
        .bind(now, rateKey)
        .run();
    }
  }
}

export async function clearD1RateLimit(
  db: WorkerAppEnv['Bindings']['DB'],
  keys: string[]
): Promise<void> {
  for (const rateKey of keys) {
    await db.prepare('DELETE FROM login_rate_limits WHERE rate_key = ?').bind(rateKey).run();
  }
}

const CSRF_EXEMPT_PATHS = new Set([
  '/api/auth/login',
  '/api/auth/forgot-password',
  '/api/auth/reset-password',
  '/api/auth/bootstrap-recovery',
]);

export async function authMiddleware(c: Context<WorkerAppEnv>, next: Next) {
  const clientIp = extractClientIp(c);
  c.set('clientIp', clientIp);

  const sessionId = getCookie(c, 'marcomm_sid');
  if (!sessionId) {
    await next();
    return;
  }

  const sessRow = await c.env.DB.prepare(
    'SELECT * FROM sessions WHERE session_id = ?'
  )
    .bind(sessionId)
    .first<Record<string, unknown>>();

  if (!sessRow) {
    clearSessionCookie(c);
    await next();
    return;
  }

  const now = Date.now();
  const expiresAt = Number(sessRow.expires_at);
  if (now > expiresAt) {
    await c.env.DB.prepare('DELETE FROM sessions WHERE session_id = ?').bind(sessionId).run();
    clearSessionCookie(c);
    await next();
    return;
  }

  const userRow = await c.env.DB.prepare('SELECT * FROM users WHERE id = ?')
    .bind(String(sessRow.user_id))
    .first<Record<string, unknown>>();

  if (!userRow || !Boolean(Number(userRow.is_active))) {
    // Immediate revocation if user deactivated or removed
    await c.env.DB.prepare('DELETE FROM sessions WHERE user_id = ?')
      .bind(String(sessRow.user_id))
      .run();
    clearSessionCookie(c);
    await next();
    return;
  }

  const user = rowToUser(userRow);
  const csrfSecret = String(sessRow.csrf_secret);
  const session: SessionRecord = {
    sessionId,
    userId: user.id,
    email: user.email,
    role: user.role,
    csrfSecret,
    createdAt: Number(sessRow.created_at),
    expiresAt: now + SESSION_LIFESPAN_MS,
    lastActiveAt: now,
    ipAddress: sessRow.ip_address ? String(sessRow.ip_address) : undefined,
    userAgent: sessRow.user_agent ? String(sessRow.user_agent) : undefined,
  };

  // Slide session window if older than 60s to reduce write amplification while enforcing inactivity timeout
  if (now - Number(sessRow.last_active_at) > 60 * 1000) {
    await c.env.DB.prepare('UPDATE sessions SET last_active_at = ?, expires_at = ? WHERE session_id = ?')
      .bind(now, session.expiresAt, sessionId)
      .run();
  }

  const expectedCsrf = await createCsrfToken(csrfSecret, sessionId, c.env.SESSION_SECRET);
  c.set('session', session);
  c.set('user', user);
  c.set('csrfToken', expectedCsrf);

  // Enforce CSRF on all state-changing HTTP methods when an authenticated session is active
  if (['POST', 'PUT', 'PATCH', 'DELETE'].includes(c.req.method)) {
    const reqPath = new URL(c.req.url).pathname;
    if (!CSRF_EXEMPT_PATHS.has(reqPath) && !reqPath.startsWith('/api/public/')) {
      const clientToken = c.req.header('x-csrf-token') || '';
      const ok = await verifyCsrfToken(clientToken, csrfSecret, sessionId, c.env.SESSION_SECRET);
      if (!ok) {
        return c.json(
          {
            success: false,
            error: 'Sesi tidak valid (CSRF token missing or mismatch). Silakan muat ulang halaman.',
          },
          403
        );
      }
    }
  }

  await next();
}

export async function requireAuth(c: Context<WorkerAppEnv>, next: Next) {
  const user = c.get('user');
  if (!user) {
    return c.json(
      {
        success: false,
        error: 'Autentikasi diperlukan. Silakan login kembali.',
      },
      401
    );
  }
  await next();
}

export function requireRole(allowedRoles: UserRole[]) {
  return async (c: Context<WorkerAppEnv>, next: Next) => {
    const user = c.get('user');
    if (!user) {
      return c.json({ success: false, error: 'Autentikasi diperlukan.' }, 401);
    }
    if (!allowedRoles.includes(user.role)) {
      return c.json(
        {
          success: false,
          error: `Akses ditolak. Peran '${user.role}' tidak memiliki izin untuk tindakan ini.`,
        },
        403
      );
    }
    await next();
  };
}

export function isUserWithinBrandScope(
  user: StoredUserRecord,
  regionId?: string | null,
  brandId?: string | null
): boolean {
  if (user.role === 'super_admin') return true;
  if (user.role === 'admin' || user.role === 'requester' || user.role === 'team_member') {
    const regOk =
      user.assignedRegions.includes('all') ||
      !regionId ||
      user.assignedRegions.includes(regionId);
    const brandOk =
      user.assignedBrands.includes('all') ||
      !brandId ||
      user.assignedBrands.includes(brandId);
    if (user.role === 'admin') return regOk && brandOk;
    if (user.role === 'requester') {
      // Requesters may only act within their assigned brand/region
      return regOk && brandOk;
    }
  }
  return true;
}

export function canUserViewRequest(user: StoredUserRecord, req: RequestItem): boolean {
  if (user.role === 'super_admin') return true;
  if (user.role === 'admin') {
    return isUserWithinBrandScope(user, req.regionId, req.brandId);
  }
  if (user.role === 'requester') {
    return req.requesterId === user.id;
  }
  if (user.role === 'team_member') {
    const isAssignee =
      req.primaryAssigneeId === user.id ||
      (Array.isArray(req.collaboratorIds) && req.collaboratorIds.includes(user.id));
    const isSubOwner =
      Array.isArray(req.subItems) && req.subItems.some((s) => !s.deletedAt && s.ownerId === user.id);
    const isTeamMatch = req.assignedTeamId ? user.teams.includes(req.assignedTeamId) : false;
    return isAssignee || isSubOwner || isTeamMatch;
  }
  return false;
}
