import type { D1Database, Fetcher, R2Bucket } from '@cloudflare/workers-types';
import type {
  ActivityLog,
  Attachment,
  Brand,
  Category,
  Comment,
  CommittedDeadlineSnapshot,
  DeliverableLink,
  Department,
  NotificationItem,
  PriorityQuotaLedgerEntry,
  PriorityQuotaPolicy,
  Region,
  RequestItem,
  RequestPriority,
  RequestStatus,
  SubItem,
  SubItemApprovalEvent,
  Team,
  Unit,
  User,
  UserRole,
} from '../types';

export interface WorkerBindings {
  DB: D1Database;
  FILES_BUCKET: R2Bucket;
  ASSETS?: Fetcher;
  APP_ORIGIN?: string;
  ENVIRONMENT?: string;
  CUSTOM_DOMAIN_STATUS?: string;
  SESSION_SECRET?: string;
  PASSWORD_PEPPER?: string;
  GEMINI_API_KEY?: string;
  BOOTSTRAP_ADMIN_TOKEN?: string;
  SMTP_HOST?: string;
  SMTP_PORT?: string;
  SMTP_USER?: string;
  SMTP_PASS?: string;
  SMTP_FROM?: string;
}

export interface StoredUserRecord extends User {
  passwordHash: string;
  recoveryTokenHash?: string;
  recoveryExpiresAt?: number;
  passwordChangedAt?: string;
}

export interface SessionRecord {
  sessionId: string;
  userId: string;
  email: string;
  role: UserRole;
  csrfSecret: string;
  createdAt: number;
  expiresAt: number;
  lastActiveAt: number;
  ipAddress?: string;
  userAgent?: string;
}

export interface WorkerVariables {
  user?: StoredUserRecord;
  session?: SessionRecord;
  csrfToken?: string;
  clientIp: string;
}

export interface WorkerAppEnv {
  Bindings: WorkerBindings;
  Variables: WorkerVariables;
}

export function safeJsonParse<T>(raw: unknown, fallback: T): T {
  if (typeof raw !== 'string' || !raw) return fallback;
  try {
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

export function sanitizeUser(u: StoredUserRecord): User {
  const {
    passwordHash: _pw,
    recoveryTokenHash: _rt,
    recoveryExpiresAt: _re,
    passwordChangedAt: _pc,
    ...safe
  } = u;
  return safe;
}

export function rowToUser(row: Record<string, unknown>): StoredUserRecord {
  return {
    id: String(row.id),
    email: String(row.email),
    fullName: String(row.full_name),
    avatarUrl: row.avatar_url ? String(row.avatar_url) : undefined,
    jobTitle: String(row.job_title || ''),
    department: String(row.department || ''),
    role: row.role as UserRole,
    isReviewer: Boolean(Number(row.is_reviewer)),
    teams: safeJsonParse<string[]>(row.teams_json, []),
    competencies: safeJsonParse<string[]>(row.competencies_json, []),
    assignedRegions: safeJsonParse<string[]>(row.assigned_regions_json, []),
    assignedBrands: safeJsonParse<string[]>(row.assigned_brands_json, []),
    isActive: Boolean(Number(row.is_active)),
    createdAt: String(row.created_at),
    lastLoginAt: row.last_login_at ? String(row.last_login_at) : undefined,
    mustChangePassword: Boolean(Number(row.must_change_password)),
    passwordHash: String(row.password_hash || ''),
    recoveryTokenHash: row.recovery_token_hash ? String(row.recovery_token_hash) : undefined,
    recoveryExpiresAt: row.recovery_expires_at ? Number(row.recovery_expires_at) : undefined,
    passwordChangedAt: row.password_changed_at ? String(row.password_changed_at) : undefined,
  };
}

export function rowToRegion(row: Record<string, unknown>): Region {
  return {
    id: String(row.id),
    name: String(row.name).replace(/^Wilayah\s+/i, '').trim(),
    code: String(row.code),
    isActive: Boolean(Number(row.is_active)),
  };
}

export function rowToBrand(row: Record<string, unknown>): Brand {
  return {
    id: String(row.id),
    regionId: String(row.region_id),
    name: String(row.name),
    code: String(row.code),
    isActive: Boolean(Number(row.is_active)),
  };
}

export function rowToUnit(row: Record<string, unknown>): Unit {
  return {
    id: String(row.id),
    brandId: String(row.brand_id),
    name: String(row.name),
    code: String(row.code),
    isActive: Boolean(Number(row.is_active)),
  };
}

export function rowToDepartment(row: Record<string, unknown>): Department {
  return {
    id: String(row.id),
    name: String(row.name),
    isActive: Boolean(Number(row.is_active)),
  };
}

export function rowToCategory(row: Record<string, unknown>): Category {
  return {
    id: String(row.id),
    name: String(row.name),
    slaDaysDefault: Number(row.sla_days_default || 3),
    isActive: Boolean(Number(row.is_active)),
  };
}

export function rowToTeam(row: Record<string, unknown>): Team {
  return {
    id: String(row.id),
    name: String(row.name),
    description: String(row.description || ''),
    color: String(row.color || '#3B82F6'),
    isActive: Boolean(Number(row.is_active)),
  };
}

export function rowToSubItem(row: Record<string, unknown>): SubItem {
  return {
    id: String(row.id),
    parentRequestId: String(row.parent_request_id),
    title: String(row.title),
    description: row.description ? String(row.description) : undefined,
    ownerId: row.owner_id ? String(row.owner_id) : undefined,
    ownerName: row.owner_name ? String(row.owner_name) : undefined,
    ownerRole: row.owner_role ? String(row.owner_role) : undefined,
    ownerAvatar: row.owner_avatar ? String(row.owner_avatar) : undefined,
    status: row.status as RequestStatus,
    priority: row.priority as RequestPriority,
    startDate: row.start_date ? String(row.start_date) : undefined,
    dueDate: row.due_date ? String(row.due_date) : undefined,
    approvalDate: row.approval_date ? String(row.approval_date) : undefined,
    approvedAt: row.approved_at ? String(row.approved_at) : undefined,
    approvedBy: row.approved_by ? String(row.approved_by) : undefined,
    approvedByName: row.approved_by_name ? String(row.approved_by_name) : undefined,
    approvalRequiresVerification: Boolean(Number(row.approval_requires_verification)),
    approvalHistory: safeJsonParse<SubItemApprovalEvent[]>(row.approval_history_json, []),
    deliverableUrl: row.deliverable_url ? String(row.deliverable_url) : undefined,
    deliverableFileName: row.deliverable_file_name ? String(row.deliverable_file_name) : undefined,
    notes: row.notes ? String(row.notes) : undefined,
    createdBy: String(row.created_by),
    createdById: String(row.created_by_id),
    createdAt: String(row.created_at),
    updatedAt: String(row.updated_at),
    deletedAt: row.deleted_at ? String(row.deleted_at) : undefined,
    deletedReason: row.deleted_reason ? String(row.deleted_reason) : undefined,
    deletedBy: row.deleted_by ? String(row.deleted_by) : undefined,
  };
}

export function rowToRequest(row: Record<string, unknown>, subItems: SubItem[] = []): RequestItem {
  const status = row.status as RequestStatus;
  const committedDeadline = row.committed_deadline ? String(row.committed_deadline) : undefined;
  const nowStr = new Date().toISOString().split('T')[0];
  const isOverdue =
    status !== 'completed' &&
    status !== 'cancelled' &&
    status !== 'on_hold' &&
    Boolean(committedDeadline && committedDeadline < nowStr);

  const requesterName = String(row.requester_name);
  return {
    id: String(row.id),
    ticketNumber: String(row.ticket_number),
    title: String(row.title),
    regionId: String(row.region_id),
    regionName: String(row.region_name).replace(/^Wilayah\s+/i, '').trim(),
    brandId: String(row.brand_id),
    brandName: String(row.brand_name),
    unitId: row.unit_id ? String(row.unit_id) : undefined,
    unitName: row.unit_name ? String(row.unit_name) : undefined,
    requesterDepartment: String(row.requester_department),
    categoryId: String(row.category_id),
    categoryName: String(row.category_name),
    description: String(row.description),
    deliverablesExpected: String(row.deliverables_expected),
    priority: row.priority as RequestPriority,
    status,
    requesterId: String(row.requester_id),
    requesterName,
    requestorName: requesterName,
    requesterEmail: String(row.requester_email),
    assignedTeamId: row.assigned_team_id ? String(row.assigned_team_id) : undefined,
    assignedTeamName: row.assigned_team_name ? String(row.assigned_team_name) : undefined,
    primaryAssigneeId: row.primary_assignee_id ? String(row.primary_assignee_id) : undefined,
    primaryAssigneeName: row.primary_assignee_name ? String(row.primary_assignee_name) : undefined,
    collaboratorIds: safeJsonParse<string[]>(row.collaborator_ids_json, []),
    collaboratorNames: safeJsonParse<string[]>(row.collaborator_names_json, []),
    reviewerId: row.reviewer_id ? String(row.reviewer_id) : undefined,
    reviewerName: row.reviewer_name ? String(row.reviewer_name) : undefined,
    requestedDeadline: String(row.requested_deadline),
    committedDeadline,
    committedDeadlineSnapshots: safeJsonParse<CommittedDeadlineSnapshot[]>(
      row.committed_deadline_snapshots_json,
      []
    ),
    briefAttachments: safeJsonParse<Attachment[]>(row.brief_attachments_json, []),
    deliverableAttachments: safeJsonParse<Attachment[]>(row.deliverable_attachments_json, []),
    deliverableLinks: safeJsonParse<DeliverableLink[]>(row.deliverable_links_json, []),
    subItems,
    isOverdue,
    completedAt: row.completed_at ? String(row.completed_at) : undefined,
    deletedAt: row.deleted_at ? String(row.deleted_at) : undefined,
    deletedReason: row.deleted_reason ? String(row.deleted_reason) : undefined,
    slaFulfilled:
      row.sla_fulfilled === null || row.sla_fulfilled === undefined
        ? undefined
        : Boolean(Number(row.sla_fulfilled)),
    reopenCount: Number(row.reopen_count || 0),
    reopenReason: row.reopen_reason ? String(row.reopen_reason) : undefined,
    holdReason: row.hold_reason ? String(row.hold_reason) : undefined,
    cancelReason: row.cancel_reason ? String(row.cancel_reason) : undefined,
    createdAt: String(row.created_at),
    updatedAt: String(row.updated_at),
  };
}

export function rowToComment(row: Record<string, unknown>): Comment {
  return {
    id: String(row.id),
    requestId: String(row.request_id),
    authorId: String(row.author_id),
    authorName: String(row.author_name),
    authorAvatar: row.author_avatar ? String(row.author_avatar) : undefined,
    role: row.role as UserRole,
    content: String(row.content),
    type: (row.type as 'general' | 'revision_note') || 'general',
    isEdited: Boolean(Number(row.is_edited)),
    createdAt: String(row.created_at),
    updatedAt: row.updated_at ? String(row.updated_at) : undefined,
  };
}

export function rowToActivityLog(row: Record<string, unknown>): ActivityLog {
  return {
    id: String(row.id),
    requestId: String(row.request_id),
    actorId: String(row.actor_id),
    actorName: String(row.actor_name),
    actorRole: row.actor_role as UserRole,
    actionType: row.action_type as ActivityLog['actionType'],
    fieldChanged: row.field_changed ? String(row.field_changed) : undefined,
    oldValue: row.old_value ? String(row.old_value) : undefined,
    newValue: row.new_value ? String(row.new_value) : undefined,
    reason: row.reason ? String(row.reason) : undefined,
    timestamp: String(row.timestamp),
  };
}

export function rowToNotification(row: Record<string, unknown>): NotificationItem {
  return {
    id: String(row.id),
    userId: String(row.user_id),
    requestId: row.request_id ? String(row.request_id) : undefined,
    ticketNumber: row.ticket_number ? String(row.ticket_number) : undefined,
    title: String(row.title),
    message: String(row.message),
    type: row.type as NotificationItem['type'],
    isRead: Boolean(Number(row.is_read)),
    createdAt: String(row.created_at),
  };
}

export function rowToQuotaPolicy(row: Record<string, unknown>): PriorityQuotaPolicy & { usedCount: number } {
  return {
    id: String(row.id),
    brandId: String(row.brand_id),
    year: Number(row.year),
    priority: row.priority as RequestPriority,
    annualLimit: Number(row.annual_limit),
    usedCount: Number(row.used_count || 0),
    slaDays: Number(row.sla_days),
    createdAt: String(row.created_at),
    updatedAt: String(row.updated_at),
  };
}

export function rowToQuotaLedger(row: Record<string, unknown>): PriorityQuotaLedgerEntry {
  return {
    id: String(row.id),
    brandId: String(row.brand_id),
    year: Number(row.year),
    priority: row.priority as RequestPriority,
    requestId: row.request_id ? String(row.request_id) : undefined,
    ticketNumber: row.ticket_number ? String(row.ticket_number) : undefined,
    transactionType: row.transaction_type as PriorityQuotaLedgerEntry['transactionType'],
    quantity: Number(row.quantity),
    actorId: String(row.actor_id),
    actorName: String(row.actor_name),
    actorRole: String(row.actor_role),
    reason: String(row.reason),
    idempotencyKey: row.idempotency_key ? String(row.idempotency_key) : undefined,
    createdAt: String(row.created_at),
  };
}
