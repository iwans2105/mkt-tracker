export function getWibYear(now: Date = new Date()): number {
  try {
    const formatter = new Intl.DateTimeFormat('en-CA', {
      timeZone: 'Asia/Jakarta',
      year: 'numeric',
    });
    return parseInt(formatter.format(now), 10);
  } catch {
    return now.getFullYear();
  }
}

export function normalizeQuotaYear(rawYear?: number | string | null): number {
  const parsed =
    typeof rawYear === 'number'
      ? rawYear
      : rawYear !== undefined && rawYear !== null
      ? parseInt(String(rawYear), 10)
      : NaN;
  if (Number.isInteger(parsed) && parsed >= 1900 && parsed <= 9999) {
    return parsed;
  }
  return getWibYear();
}

export function getWibYearFromIso(isoStr?: string | null): number | null {
  if (!isoStr) return null;
  try {
    const d = new Date(isoStr);
    if (Number.isNaN(d.getTime())) return null;
    const formatter = new Intl.DateTimeFormat('en-CA', {
      timeZone: 'Asia/Jakarta',
      year: 'numeric',
    });
    const yr = parseInt(formatter.format(d), 10);
    return Number.isInteger(yr) && yr >= 1900 && yr <= 9999 ? yr : null;
  } catch {
    return null;
  }
}

export function getWibTodayDateString(now: Date = new Date()): string {
  try {
    return new Intl.DateTimeFormat('en-CA', {
      timeZone: 'Asia/Jakarta',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
    }).format(now);
  } catch {
    return now.toISOString().split('T')[0];
  }
}

export function getWibSlaDeadlineDateString(slaDays: number, now: Date = new Date()): string {
  const safeDays = Math.max(1, Number.isFinite(slaDays) ? Math.round(slaDays) : 1);
  const baseDateStr = getWibTodayDateString(now);
  const [year, month, day] = baseDateStr.split('-').map(Number);
  return new Date(Date.UTC(year, month - 1, day + safeDays)).toISOString().split('T')[0];
}

