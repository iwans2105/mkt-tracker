export type UserRole = 'requester' | 'team_member' | 'admin' | 'super_admin';

export type RequestStatus =
  | 'todo'            // To Do / Backlog
  | 'in_progress'     // In Progress
  | 'pending_review'  // Pending Review / Approval
  | 'revision'        // Revision
  | 'completed'       // Completed
  | 'on_hold'         // On Hold
  | 'cancelled';      // Cancelled

export type RequestPriority = 'low' | 'medium' | 'high' | 'urgent';

export const PRIORITY_SLA_DAYS: Record<RequestPriority, number> = {
  urgent: 1,
  high: 3,
  medium: 7,
  low: 14,
};

export interface Region {
  id: string;
  name: string;
  code: string;
  isActive: boolean;
}

export interface Brand {
  id: string;
  regionId: string;
  name: string;
  code: string;
  isActive: boolean;
}

export interface Unit {
  id: string;
  brandId: string; // e.g. Lyman Devindo
  name: string;
  code: string;
  isActive: boolean;
}

export interface Department {
  id: string;
  name: string;
  isActive: boolean;
}

export interface Category {
  id: string;
  name: string;
  slaDaysDefault: number;
  isActive: boolean;
}

export interface Team {
  id: string;
  name: string;
  description: string;
  color: string;
  isActive: boolean;
}

export interface User {
  id: string;
  email: string;
  fullName: string;
  avatarUrl?: string;
  jobTitle: string;
  department: string;
  role: UserRole;
  isReviewer: boolean;
  teams: string[]; // Team IDs
  competencies: string[]; // e.g. 'Social Media', 'Dokumentasi', 'Graphic Design', etc.
  assignedRegions: string[]; // Region IDs ('all' or specific IDs)
  assignedBrands: string[]; // Brand IDs ('all' or specific IDs)
  isActive: boolean;
  createdAt: string;
  passwordHash?: string;
  lastLoginAt?: string;
  recoveryTokenHash?: string;
  recoveryExpiresAt?: number;
  mustChangePassword?: boolean;
}


export interface Attachment {
  id: string;
  name: string;
  size: number; // in bytes
  type: string;
  url: string;
  uploadedAt: string;
  uploadedBy: string;
}

export interface DeliverableLink {
  id: string;
  title: string;
  url: string;
  createdAt: string;
  createdBy: string;
}

export interface CommittedDeadlineSnapshot {
  committedDeadline: string;
  updatedAt: string;
  updatedBy: string;
  reason: string;
}

export interface SubItem {
  id: string;
  parentRequestId: string;
  title: string;
  description?: string;
  ownerId?: string;
  ownerName?: string;
  ownerRole?: string;
  ownerAvatar?: string;
  status: RequestStatus;
  priority: RequestPriority;
  startDate?: string;
  dueDate?: string; // YYYY-MM-DD
  approvalDate?: string; // ISO string when approved
  approvedAt?: string; // Alias for approvalDate
  approvedBy?: string; // Approver user ID
  approvedByName?: string; // Approver user name
  approvalRequiresVerification?: boolean; // Flagged if completed but approval date missing from historical record
  approvalHistory?: SubItemApprovalEvent[]; // Historical approval events across revisions
  deliverableUrl?: string;
  deliverableFileName?: string;
  notes?: string;
  createdBy: string;
  createdById: string;
  createdAt: string;
  updatedAt: string;
  deletedAt?: string; // Soft delete timestamp
  deletedReason?: string;
  deletedBy?: string;
}

export interface SubItemApprovalEvent {
  approvedAt: string;
  approvedBy: string;
  approvedByName: string;
  approverRole?: string;
  notes?: string;
  reconciled?: boolean;
}

export interface RequestItem {
  id: string;
  ticketNumber: string; // REQ-2026-XXXXXX
  title: string;
  regionId: string;
  regionName: string;
  brandId: string;
  brandName: string;
  unitId?: string;
  unitName?: string;
  requesterDepartment: string;
  categoryId: string;
  categoryName: string;
  description: string;
  deliverablesExpected: string;
  priority: RequestPriority;
  status: RequestStatus;
  requesterId: string;
  requesterName: string; // Requestor's Name
  requestorName?: string; // Canonical alias for Requestor's Name
  requesterEmail: string;

  // Assignment details
  assignedTeamId?: string;
  assignedTeamName?: string;
  primaryAssigneeId?: string;
  primaryAssigneeName?: string;
  collaboratorIds: string[]; // User IDs
  collaboratorNames?: string[];
  reviewerId?: string;
  reviewerName?: string;

  // Deadlines
  requestedDeadline: string; // ISO date string YYYY-MM-DD
  committedDeadline?: string; // ISO date string YYYY-MM-DD
  committedDeadlineSnapshots: CommittedDeadlineSnapshot[];

  // Attachments & links
  briefAttachments: Attachment[];
  deliverableAttachments: Attachment[];
  deliverableLinks: DeliverableLink[];

  // Sub Items / Subtasks (Level 2 deliverables)
  subItems?: SubItem[];

  // Time & SLA Metrics
  isOverdue?: boolean;
  completedAt?: string;
  deletedAt?: string;
  deletedReason?: string;
  slaFulfilled?: boolean;
  reopenCount: number;
  reopenReason?: string;
  holdReason?: string;
  cancelReason?: string;

  createdAt: string;
  updatedAt: string;
}

export interface Comment {
  id: string;
  requestId: string;
  authorId: string;
  authorName: string;
  authorAvatar?: string;
  role: UserRole;
  content: string;
  type: 'general' | 'revision_note';
  isEdited: boolean;
  createdAt: string;
  updatedAt?: string;
}

export type ActionType =
  | 'create'
  | 'assign'
  | 'status_change'
  | 'deadline_update'
  | 'priority_update'
  | 'deliverable_upload'
  | 'review_submitted'
  | 'revision_requested'
  | 'approved'
  | 'reopened'
  | 'on_hold'
  | 'resumed_from_hold'
  | 'cancelled'
  | 'subitem_created'
  | 'subitem_updated'
  | 'subitem_deleted'
  | 'subitem_status_change'
  | 'subitem_approved';

export interface ActivityLog {
  id: string;
  requestId: string;
  actorId: string;
  actorName: string;
  actorRole: UserRole;
  actionType: ActionType;
  fieldChanged?: string;
  oldValue?: string;
  newValue?: string;
  reason?: string;
  timestamp: string;
}

export interface NotificationItem {
  id: string;
  userId: string;
  requestId?: string;
  ticketNumber?: string;
  title: string;
  message: string;
  type:
    | 'assignment'
    | 'status_change'
    | 'review_request'
    | 'revision'
    | 'completed'
    | 'on_hold'
    | 'cancelled'
    | 'deadline_approaching'
    | 'overdue'
    | 'comment'
    | 'subitem_assigned'
    | 'subitem_status_change'
    | 'subitem_review'
    | 'subitem_approved';
  isRead: boolean;
  createdAt: string;
}

export interface FilterState {
  search: string;
  status: RequestStatus | 'all';
  priority: RequestPriority | 'all';
  regionId: string | 'all';
  brandId: string | 'all';
  categoryId: string | 'all';
  assignedTeamId: string | 'all';
  assigneeId: string | 'all';
  requesterId?: string | 'all';
  overdueOnly: boolean;
  dateRange: 'all' | 'today' | 'this_week' | 'this_month' | 'custom';
  startDate?: string;
  endDate?: string;
}

export interface WorkItemCountingSummary {
  totalRequests: number;
  totalWorkItems: number;
  totalSubItems: number;
  todoWorkItems: number;
  inProgressWorkItems: number;
  pendingReviewWorkItems: number;
  completedWorkItems: number;
  onHoldWorkItems: number;
  cancelledWorkItems: number;
  // V12 Distinct Completed Metrics
  completedParentRequests: number;
  contributingParentRequests: number;
  // Status key aliases for direct mapped access
  todo: number;
  in_progress: number;
  pending_review: number;
  completed: number;
  on_hold: number;
  cancelled: number;
}

export interface AnalyticsSummary extends WorkItemCountingSummary {
  totalRequests: number;
  completedRequests: number;
  activeRequests: number;
  onTrackRequests: number;
  overdueRequests: number;
  unscheduledRequests: number;
  avgCompletionDays: number | null;
  slaFulfillmentRate: number | null; // percentage e.g. 87.5
}

// --- Brand-Based Annual Priority Quota Management Types ---

export interface PriorityQuotaPolicy {
  id: string;
  brandId: string;
  year: number;
  priority: RequestPriority;
  annualLimit: number; // e.g. 3 for urgent, 6 for high, 9 for medium, -1 for unlimited
  slaDays: number;
  createdAt: string;
  updatedAt: string;
}

export interface PriorityQuotaLedgerEntry {
  id: string;
  brandId: string;
  year: number;
  priority: RequestPriority;
  requestId?: string;
  ticketNumber?: string;
  transactionType: 'deduction' | 'release' | 'adjustment' | 'reconciliation' | 'policy_init';
  quantity: number; // -1 for deduction/consume, +1 for release/refund
  actorId: string;
  actorName: string;
  actorRole: string;
  reason: string;
  idempotencyKey?: string;
  createdAt: string;
}

export interface PriorityAvailability {
  priority: RequestPriority;
  name: string;
  slaDays: number;
  annualLimit: number; // -1 for unlimited
  used: number;
  remaining: number; // -1 for unlimited
  utilizationPercent: number;
  isExhausted: boolean;
  statusLabel: string; // 'Available' | 'Quota Exhausted' | 'Unlimited'
}

export interface BrandQuotaSummary {
  brandId: string;
  brandName: string;
  year: number;
  priorities: Record<RequestPriority, PriorityAvailability>;
  warningCount: number; // number of priorities with remaining === 1
  exhaustedCount: number; // number of priorities with remaining === 0
  lastUpdated: string;
}

export interface PriorityQuotaReconciliationPreview {
  year: number;
  totalEligibleRequests: number;
  isApplied: boolean;
  appliedAt?: string;
  appliedBy?: string;
  brands: {
    brandId: string;
    brandName: string;
    priorities: {
      priority: RequestPriority;
      currentUsed: number;
      projectedUsage: number;
      limit: number;
      projectedRemaining: number;
      requestCount: number;
      requests: { id: string; ticketNumber: string; title: string; createdAt: string }[];
    }[];
  }[];
}

export type ReportingPeriodMode = 'calendar_year' | 'custom_range';

export type DatePreset =
  | 'today'
  | 'last_7_days'
  | 'last_30_days'
  | 'this_month'
  | 'last_month'
  | 'this_quarter'
  | 'this_year'
  | 'last_year';

export interface PriorityPeriodMetric {
  priority: RequestPriority;
  consumed: number;
  released: number;
  adjusted: number;
  netUsage: number;
  requestCount: number;
}

export interface PeriodReportingMetrics {
  mode: ReportingPeriodMode;
  brandId: string;
  brandName: string;
  startDate: string;
  endDate: string;
  startIsoWib: string;
  endIsoWib: string;
  affectedYears: number[];
  totalRequestCount: number;
  totalConsumed: number;
  totalReleased: number;
  totalAdjusted: number;
  totalNetUsage: number;
  priorities: Record<RequestPriority, PriorityPeriodMetric>;
  ledgerEntries: PriorityQuotaLedgerEntry[];
}


